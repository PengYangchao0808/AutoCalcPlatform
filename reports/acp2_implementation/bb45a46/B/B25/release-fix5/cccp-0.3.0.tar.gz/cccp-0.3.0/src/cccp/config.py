"""
Configuration Loader
====================

YAML configuration loading and validation.

Author: QCcalc Team
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_NAME = "cccp.yaml"
USER_CONFIG_NAME = ".cccp.yaml"

# Legacy filenames from the previous ``conformer_search`` package namespace.
# Retained as fallback read targets so existing systemd deployments keep working
# until operators migrate ~/.conformer_search.yaml -> ~/.cccp.yaml.
_LEGACY_DEFAULT_CONFIG_NAME = "conformer_search.yaml"
_LEGACY_USER_CONFIG_NAME = ".conformer_search.yaml"

# ---------------------------------------------------------------------------
# Configuration domains (C07 — science vs Services platform separation)
# ---------------------------------------------------------------------------
# ACP's on-disk YAML layout merges two ownership domains into one mapping:
#
# 1. SCIENCE domain (CCCP owns): top-level sections ``executables``,
#    ``resources``, ``theory``, ``thermo``, ``mrrho_settings``, ``censo``,
#    ``nmr``, ``protocols``, ``mechanism`` and ``optimization_control`` —
#    plus any unknown future keys.  CCCP parses and validates these.
# 2. PLATFORM domain (Services owns): :data:`PLATFORM_CONFIG_SECTIONS`.
#    ``cluster`` carries ``enabled``/``execution_mode``/``type``/``queue``/
#    ``walltime``/``extra_flags``/``nodes``/``local``/``local_retention`` etc.
#    CCCP treats the whole section as an **opaque, passively-merged**
#    mapping: it never parses remote nodes, never validates
#    ``execution_mode``, and never imports the Services implementation
#    (``acp`` / ``acp_services``).  The authoritative platform schema and
#    validation (``RemoteExecutionConfig`` / ``RemoteNode`` /
#    ``acp_services.contracts.config_validation``), the ``acp init`` wizard
#    and the platform YAML defaults live in the upper layer, which performs
#    the final platform assembly.
#
# ``load_config`` remains the **legacy full-config compatibility entry
# point** (science ∪ platform, unchanged output); science-only callers use
# :func:`load_science_config`.  The built-in platform defaults here are a
# transitional CCCP-side baseline only — see :func:`get_platform_defaults`.
PLATFORM_CONFIG_SECTIONS: frozenset[str] = frozenset({"cluster"})


def _find_project_root() -> Path | None:
    """
    Find the project root directory by searching upward for config/defaults.yaml.
    
    Returns:
        Path to project root, or None if not found
    """
    current = Path(__file__).resolve()
    for parent in [current] + list(current.parents):
        if (parent / 'config' / 'defaults.yaml').exists():
            return parent
        if (parent / 'defaults.yaml').exists():
            return parent
    return None


def _load_user_config(config: dict[str, Any]) -> dict[str, Any]:
    """Merge the user-home config (~/.cccp.yaml).

    Backward-compat: when ``~/.cccp.yaml`` is absent, fall back to reading the
    legacy ``~/.conformer_search.yaml`` so existing systemd deployments keep
    working until operators migrate the file. If both files exist, the new
    ``~/.cccp.yaml`` wins and a WARNING is emitted (no automatic merge to avoid
    ambiguous field conflicts).
    """
    user_home = Path.home()
    new_path = user_home / USER_CONFIG_NAME
    legacy_path = user_home / _LEGACY_USER_CONFIG_NAME

    if new_path.exists():
        if legacy_path.exists():
            logger.warning(
                "Old config file %s still exists alongside %s. "
                "Please migrate and delete the old file.",
                legacy_path, new_path,
            )
        with open(new_path, encoding='utf-8') as f:
            user_config = yaml.safe_load(f) or {}
        return _merge_configs(config, user_config)

    if legacy_path.exists():
        logger.warning(
            "Reading legacy user config %s — please rename to %s.",
            legacy_path, new_path,
        )
        with open(legacy_path, encoding='utf-8') as f:
            user_config = yaml.safe_load(f) or {}
        return _merge_configs(config, user_config)

    return config


def load_config(
    config_path: Path | None = None,
    overrides: dict[str, Any] | None = None,
    defaults_path: Path | None = None
) -> dict[str, Any]:
    """
    Load the LEGACY FULL configuration from multiple sources, merged in order
    (latest wins):

    1. Built-in defaults (config/defaults.yaml or _get_default_config())
    2. User home config (~/.cccp.yaml, falls back to ~/.conformer_search.yaml)
    3. Local directory config (./cccp.yaml, falls back to ./conformer_search.yaml)
    4. Explicit config file (--config)
    5. Environment variable overrides (CONFSEARCH_*)
    6. Command-line parameter overrides

    Transitional contract: this is the compatibility assembly of both
    ownership domains.  It returns the science sections plus the platform
    sections (:data:`PLATFORM_CONFIG_SECTIONS`) exactly as before the split;
    the platform section is merged passively and never parsed here.  New
    science-only callers should use :func:`load_science_config`; platform
    callers should read :func:`load_platform_section` and hand it to the
    Services parser (``RemoteExecutionConfig.from_config_dict``).

    Args:
        config_path: Explicit config file path (--config)
        overrides: Command-line parameter overrides (e.g., --nproc, --mem)
        defaults_path: Path to defaults.yaml (auto-detected if None)

    Returns:
        Merged configuration dictionary
    """
    config = {}

    # Auto-detect defaults.yaml if not explicitly provided
    if defaults_path is None:
        project_root = _find_project_root()
        possible_defaults = []
        if project_root:
            possible_defaults.append(project_root / 'config' / 'defaults.yaml')
        possible_defaults.extend([
            Path(__file__).resolve().parent.parent.parent / 'config' / 'defaults.yaml',
            Path.cwd() / 'config' / 'defaults.yaml',
            Path.home() / '.config' / 'cccp' / 'defaults.yaml',
            Path.home() / '.config' / 'conformer_search' / 'defaults.yaml',
        ])
        for p in possible_defaults:
            if p.exists():
                defaults_path = p
                break

    if defaults_path and Path(defaults_path).exists():
        with open(defaults_path, encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}
        logger.info(f"Loaded defaults from: {defaults_path}")
    else:
        config = _get_default_config()
        logger.debug("Using built-in default configuration")

    config = _load_user_config(config)

    local_config = Path.cwd() / DEFAULT_CONFIG_NAME
    legacy_local_config = Path.cwd() / _LEGACY_DEFAULT_CONFIG_NAME
    if local_config.exists():
        if legacy_local_config.exists():
            logger.warning(
                "Old local config %s still exists alongside %s. "
                "Please migrate and delete the old file.",
                legacy_local_config, local_config,
            )
        with open(local_config, encoding='utf-8') as f:
            local_cfg = yaml.safe_load(f) or {}
        config = _merge_configs(config, local_cfg)
    elif legacy_local_config.exists():
        logger.warning(
            "Reading legacy local config %s — please rename to %s.",
            legacy_local_config, local_config,
        )
        with open(legacy_local_config, encoding='utf-8') as f:
            local_cfg = yaml.safe_load(f) or {}
        config = _merge_configs(config, local_cfg)

    if config_path and Path(config_path).exists():
        with open(config_path, encoding='utf-8') as f:
            user_config = yaml.safe_load(f) or {}
        config = _merge_configs(config, user_config)
        logger.info(f"Loaded explicit config from: {config_path}")

    config = _apply_env_overrides(config)

    if overrides:
        config = _merge_configs(config, overrides)

    config = _validate_config(config)

    return config


def split_config_domains(
    config: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Split a merged configuration into ``(science, platform)``.

    The platform mapping is a verbatim shallow copy of the
    :data:`PLATFORM_CONFIG_SECTIONS` present in *config*; no CCCP-side
    parsing, coercion or validation is applied to it.  Unknown science keys
    stay in the science mapping.

    Args:
        config: A merged configuration dictionary (e.g. from
            :func:`load_config`).

    Returns:
        Tuple of ``(science_config, platform_config)``.
    """
    platform = {key: config[key] for key in PLATFORM_CONFIG_SECTIONS if key in config}
    science = {key: value for key, value in config.items() if key not in PLATFORM_CONFIG_SECTIONS}
    return science, platform


def load_science_config(
    config_path: Path | None = None,
    overrides: dict[str, Any] | None = None,
    defaults_path: Path | None = None,
) -> dict[str, Any]:
    """Load the SCIENCE-domain configuration (minimal-install entry point).

    Uses the identical six-source merge order as :func:`load_config`, then
    strips the platform sections.  A science-only CCCP install therefore
    needs no Services platform layer: this function never imports
    ``acp`` / ``acp_services`` and never touches ``cluster``.
    """
    config = load_config(
        config_path=config_path, overrides=overrides, defaults_path=defaults_path
    )
    science, _ = split_config_domains(config)
    return science


def load_platform_section(
    config_path: Path | None = None,
    overrides: dict[str, Any] | None = None,
    defaults_path: Path | None = None,
) -> dict[str, Any]:
    """Return only the PLATFORM-domain sections of the merged config.

    The result is an opaque pass-through mapping; the upper (Services)
    layer owns parsing and validation.  Kept alongside
    :func:`load_science_config` so every public entry point's returned
    fields are explicit.
    """
    config = load_config(
        config_path=config_path, overrides=overrides, defaults_path=defaults_path
    )
    _, platform = split_config_domains(config)
    return platform


def get_science_defaults() -> dict[str, Any]:
    """Built-in SCIENCE-domain defaults (no platform sections)."""
    return {
        'executables': {
            'orca': {
                'path': 'orca',
                'nproc': 10,
                'maxcore': None
            },
            'xtb': {
                'path': 'xtb',
                'fallback_paths': ['/opt/xtb/bin/xtb', '/usr/local/bin/xtb']
            },
            'crest': {
                'path': 'crest',
                'gfn_level': 2
            },
            'censo': {
                'path': 'censo'
            },
            'isostat': {
                'path': 'isostat'
            },
            'shermo': {
                'path': 'Shermo'
            },
            'molclus': {
                'path': 'molclus'
            }
        },
        'resources': {
            'nproc': 16,
            'mem': '30GB',
            'orca_maxcore_safety': 0.8,
            'isostat_gdis': 1.0,
            'isostat_intermediate_gdis': 0.5,
            'isostat_energy_window_kcal': 3.0,
            'isostat_intermediate_energy_window_kcal': 10.0,
        },
        'theory': {
            'optimization': {
                'engine': 'orca',
                'method': 'r2SCAN-3c',
                'basis': '',
                'solvent': None,
                'solvent_model': 'none'
            },
            'frequency': {
                'engine': 'orca',
            },
            'single_point': {
                'method': 'wB97M-V',
                'basis': 'def2-TZVPP',
                'solvent': None,
                'solvent_model': 'none',
                'engine': 'orca'
            },
            'preoptimization': {
                'gfn_level': 2,
                'solvent': None,
                'solvent_model': 'none'
            },
            'nmr': {
                'engine': 'orca',
                'method': 'mPW1PW91',
                'basis': '6-311G(d)',
                'solvent': None,
                'solvent_model': 'cpcm'
            }
        },
        'thermo': {
            'temperature_k': 298.15,
            'pressure_atm': 1.0,
            'scl_zpe': 0.9905,
            'shermo_ilowfreq': 2,
            'shermo_imagreal': 0,
            'shermo_conc': 1.0
        },
        'mrrho_settings': {
            'gfn_level': 2,
            'sthr': 50.0,
            'imagthr': -100.0,
            'temperature_k': 298.15,
            'max_parallel': 4,
        },
        'censo': {
            'preset': 'censo-light',
            'solvent': None,
            'solvent_model': 'none',
            'temperature': 298.15,
            'scale': 1.0,
            'keep_all': False,
            'ewin': 6.0,
            'refinement_threshold': 0.99,
            'refinement_func': 'wb97m-v',
            'refinement_basis': 'def2-tzvpp',
            'optimization': {
                'enabled': True,
                'functional': 'r2SCAN-3c',
                'threshold': 3.0,
                'optlevel': 'normal',
                'maxcyc': 200,
                'optcycles': 8,
                'macrocycles': True,
                'xtb_opt': True,
            },
            'presets': {},
            'levels': {},
        },
        'nmr': {
            'temperature_k': 298.15,
            'energy_window_kcal': 3.0,
            'max_conformers': 10,
            'references': {
                '1H': None,
                '13C': None,
                '15N': None,
                '19F': None,
                '31P': None,
            }
        },
        'protocols': {
            'default': 'censo-lite',
            'benchmark': {
                'stages': {
                    'crest': True,
                    'clustering': True,
                    'optimization': True,
                    'frequency': True,
                    'single_point': True,
                    'shermo': True,
                },
                'two_stage_enabled': True,
                'ngeom_default': 3,
                'ngeom_max': 6,
                'funnel': {
                    'search_mode': 'crest_two_stage_gfn0_to_gfn2',
                    'clustering_mode': 'isostat',
                    'prescreen_mode': 'none',
                    'rerank_mode': 'none',
                },
                'handoff': {
                    'mode': 'optimize_all_candidates',
                    'ranking_after_handoff': 'final_sp_minimum',
                },
                'final_opt_sp': {
                    'final_sp_method': 'DLPNO-CCSD(T)',
                    'final_sp_basis': 'def2-TZVPP',
                },
            },
            'ext': {
                'stages': {
                    'crest': True,
                    'clustering': True,
                    'optimization': True,
                    'frequency': True,
                    'single_point': True,
                    'shermo': True,
                },
                'two_stage_enabled': True,
                'ngeom_default': 3,
                'ngeom_max': 6,
                'funnel': {
                    'search_mode': 'crest_two_stage_gfn0_to_gfn2',
                    'clustering_mode': 'isostat',
                    'prescreen_mode': 'none',
                    'rerank_mode': 'none',
                },
                'handoff': {
                    'mode': 'optimize_all_candidates',
                    'ranking_after_handoff': 'final_sp_minimum',
                },
                'final_opt_sp': {
                    'final_sp_method': 'wB97M-V',
                    'final_sp_basis': 'def2-TZVPP',
                },
            },
            'full': {
                'stages': {
                    'crest': True,
                    'clustering': True,
                    'optimization': True,
                    'frequency': True,
                    'single_point': True,
                    'shermo': True,
                },
                'two_stage_enabled': False,
                'ngeom_default': 12,
                'ngeom_max': 24,
                'funnel': {
                    'search_mode': 'crest_gfn2',
                    'clustering_mode': 'isostat',
                    'prescreen_mode': 'low_cost_dft_sp',
                    'rerank_mode': 'r2scan3c_sp_plus_mrrho',
                    'prescreen_window_kcal': 4.0,
                    'screening_window_kcal': 3.5,
                    'survivor_window_kcal': 3.0,
                },
                'handoff': {
                    'mode': 'optimize_all_survivors_within_window',
                    'ranking_after_handoff': 'final_sp_plus_boltzmann',
                },
                'final_opt_sp': {
                    'final_sp_method': 'wB97M-V',
                    'final_sp_basis': 'def2-TZVPP',
                },
            },
            'lite': {
                'stages': {
                    'crest': True,
                    'clustering': True,
                    'optimization': True,
                    'frequency': True,
                    'single_point': True,
                    'shermo': True,
                },
                'two_stage_enabled': False,
                'ngeom_default': 4,
                'ngeom_max': 6,
                'funnel': {
                    'search_mode': 'crest_gfn2',
                    'clustering_mode': 'isostat',
                    'prescreen_mode': 'none',
                    'rerank_mode': 'r2scan3c_sp',
                    'use_mrrho_like_correction': True,
                    'optimize_limit': 1,
                    'top2_fallback_enabled': True,
                    'boltzmann_cutoff': 0.90,
                },
                'handoff': {
                    'mode': 'optimize_rank1',
                    'fallback_mode': 'optimize_top2_if_gap_small',
                    'small_gap_kcal': 1.0,
                    'ranking_after_handoff': 'final_sp_minimum',
                },
                'final_opt_sp': {
                    'final_sp_method': 'wB97M-V',
                    'final_sp_basis': 'def2-TZVPP',
                },
            },
            'zero': {
                'stages': {
                    'crest': True,
                    'clustering': True,
                    'optimization': True,
                    'frequency': True,
                    'single_point': True,
                    'shermo': True,
                },
                'two_stage_enabled': False,
                'ngeom_default': 1,
                'ngeom_max': 3,
                'funnel': {
                    'search_mode': 'crest_gfn2',
                    'clustering_mode': 'isostat',
                    'prescreen_mode': 'none',
                    'rerank_mode': 'none',
                    'narrow_window_kcal': 0.5,
                    'optimize_limit': 1,
                },
                'handoff': {
                    'mode': 'optimize_rank1',
                    'fallback_mode': 'optimize_all_within_0p5_kcal',
                    'ranking_after_handoff': 'final_sp_minimum',
                },
                'final_opt_sp': {},
            },
        },
        'optimization_control': {
            # 'auto' = infer Recalc_Hess from molecular elements (see defaults.yaml).
            'recalc_hess': 'auto',
            'timeout': {
                'default_seconds': 864000
            },
        },
    }


def get_platform_defaults() -> dict[str, Any]:
    """Built-in PLATFORM-domain defaults (the ``cluster`` section).

    Transitional CCCP-side baseline only.  The authoritative platform
    defaults, platform YAML section, ``acp init`` wizard and ``RemoteNode``
    validation are owned by the Services layer (B integration batch); the
    upper layer assembles the final platform config.
    """
    return {
        'cluster': {
            'enabled': False,
            'execution_mode': 'local',
            'poll_interval': 30,
            'retention_days': 180,
            'auto_sync': True,
            'require_all_binaries': True,
            'pre_cmds': [],
            'type': 'local',
            'queue': 'normal',
            # Empty = no #BSUB -W run-time limit by default (jobs run to
            # completion). Keep in sync with config/defaults.yaml.
            'walltime': '',
            'extra_flags': '',
            # Node entries are parsed by acp.scheduler.remote.config.RemoteNode.
            # Optional per-node keys (see config/defaults.yaml cluster example):
            #   queue: LSF queue override; omitted/blank -> cluster.queue.
            #   capabilities: static declaration; omitted -> node is generic.
            #     software: only orca, xtb, crest, censo, shermo, isostat,
            #       molclus are valid (unknown names dropped with a warning).
            #     tags: free-form labels; only declared tags ever satisfy a
            #       tag requirement at submission.
            'nodes': [],
            # Local execution-target admission ceiling. MUST stay in sync
            # with config/defaults.yaml cluster.local.
            'local': {
                'max_jobs': 4,
            },
            # Local run_root lifecycle management (Phase 5B). MUST stay in
            # sync with config/defaults.yaml cluster.local_retention.
            'local_retention': {
                'enabled': True,
                'completed_days': 30,
                'failed_days': 90,
                'cancelled_days': 30,
                'db_record_days': 365,
                'cleanup_interval_hours': 6,
                'disk_cleanup_threshold': 90,
                'disk_skip_threshold': 95,
                'max_dirs_per_sweep': 200,
                'vacuum_after_db_cleanup': False,
            },
        },
    }


def _get_default_config() -> dict[str, Any]:
    """LEGACY full-config defaults (science ∪ platform), unchanged output.

    Compatibility view over :func:`get_science_defaults` and
    :func:`get_platform_defaults`; callers that want a single domain use
    those directly.
    """
    return _merge_configs(get_science_defaults(), get_platform_defaults())


def _merge_configs(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """
    Recursively merge two configuration dictionaries.
    
    Args:
        base: Base configuration
        override: Override configuration
        
    Returns:
        Merged configuration
    """
    result = base.copy()

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _merge_configs(result[key], value)
        else:
            result[key] = value

    return result


def _set_nested(config: dict[str, Any], keys: list[str], value: Any) -> None:
    """Set a value at a nested key path, creating intermediate dicts as needed.
    
    Args:
        config: The configuration dictionary to modify in place.
        keys: List of string keys forming the path.
        value: The value to set at the leaf.
    """
    for k in keys[:-1]:
        config = config.setdefault(k, {})
    config[keys[-1]] = value


def _apply_env_overrides(config: dict[str, Any]) -> dict[str, Any]:
    """
    Apply environment variable overrides.
    
    Environment variables:
    - CONFSEARCH_NPROC
    - CONFSEARCH_MEM
    - CONFSEARCH_ORCA_PATH
    - CONFSEARCH_ORCA_LD_LIBRARY_PATH
    - CONFSEARCH_XTB_PATH
    - CONFSEARCH_CREST_PATH
    - CONFSEARCH_CENSO_PATH
    - CONFSEARCH_ISOSTAT_PATH
    - CONFSEARCH_SHERMO_PATH
    - CONFSEARCH_MOLCLUS_PATH

    Args:
        config: Configuration dictionary

    Returns:
        Configuration with environment overrides applied
    """
    env_mappings = {
        'CONFSEARCH_NPROC': ('resources', 'nproc', int),
        'CONFSEARCH_MEM': ('resources', 'mem', str),
        'CONFSEARCH_ORCA_PATH': ('executables', ['orca', 'path'], str),
        'CONFSEARCH_ORCA_LD_LIBRARY_PATH': ('executables', ['orca', 'ld_library_path'], str),
        'CONFSEARCH_XTB_PATH': ('executables', ['xtb', 'path'], str),
        'CONFSEARCH_CREST_PATH': ('executables', ['crest', 'path'], str),
        'CONFSEARCH_CENSO_PATH': ('executables', ['censo', 'path'], str),
        'CONFSEARCH_ISOSTAT_PATH': ('executables', ['isostat', 'path'], str),
        'CONFSEARCH_SHERMO_PATH': ('executables', ['shermo', 'path'], str),
        'CONFSEARCH_MOLCLUS_PATH': ('executables', ['molclus', 'path'], str),
        'CONFSEARCH_PROTOCOL': ('protocols', 'default', str),
        'CONFSEARCH_MRRHO_STHR': ('mrrho_settings', 'sthr', float),
        'CONFSEARCH_MRRHO_IMAGTHR': ('mrrho_settings', 'imagthr', float),
    }

    for env_var, (section, key, value_type) in env_mappings.items():
        env_value = os.environ.get(env_var)
        if env_value:
            section_dict = config.setdefault(section, {})
            if isinstance(key, list):
                _set_nested(section_dict, key, value_type(env_value))
                logger.debug(f"Applied env override: {env_var} -> {section}.{'.'.join(key)}")
            else:
                section_dict[key] = value_type(env_value)
                logger.debug(f"Applied env override: {env_var} -> {section}.{key}")

    if os.environ.get('CONFSEARCH_NPROC'):
        config.setdefault('executables', {}).setdefault('orca', {})['nproc'] = int(os.environ['CONFSEARCH_NPROC'])

    return config


def _validate_config(config: dict[str, Any]) -> dict[str, Any]:
    """Validate a full (science ∪ platform) configuration in place.

    Legacy full-config entry: runs science-domain validation, then the
    CCCP-side platform-section normalization, preserving the exact pre-split
    behaviour of :func:`load_config`.

    Args:
        config: Configuration dictionary

    Returns:
        Validated configuration
    """
    config = _validate_science_config(config)
    _validate_platform_section(config)
    return config


def _validate_science_config(config: dict[str, Any]) -> dict[str, Any]:
    """Validate the SCIENCE domain and apply science defaults in place.

    Args:
        config: Configuration dictionary

    Returns:
        Validated configuration
    """
    if 'resources' not in config:
        config['resources'] = {}

    if config['resources'].get('nproc', 0) <= 0:
        import multiprocessing
        config['resources']['nproc'] = min(multiprocessing.cpu_count(), 32)
        logger.warning(f"Invalid nproc, using {config['resources']['nproc']}")

    from cccp.utils.resource_utils import normalize_memory

    memory = config['resources'].get('mem')
    if memory is None or memory == "":
        memory = _get_default_config()['resources']['mem']
    config['resources']['mem'] = normalize_memory(memory)

    protocol = config.get('protocols', {}).get('default', 'censo-lite')
    if protocol not in ('ext', 'full', 'lite', 'zero', 'benchmark', 'censo-lite'):
        logger.warning(f"Unknown protocol '{protocol}', using 'censo-lite'")
        config['protocols']['default'] = 'censo-lite'

    valid_engines = ('orca',)
    theory = config.setdefault('theory', {})

    opt_engine = theory.setdefault('optimization', {}).get('engine', 'orca')
    if opt_engine == 'gaussian':
        logger.warning(
            "Optimization engine 'gaussian' is no longer supported; using 'orca'"
        )
        theory['optimization']['engine'] = 'orca'
    elif opt_engine not in valid_engines:
        logger.warning(f"Invalid optimization engine '{opt_engine}', defaulting to 'orca'")
        theory['optimization']['engine'] = 'orca'

    freq_engine = theory.setdefault('frequency', {}).get('engine', 'orca')
    if freq_engine == 'gaussian':
        logger.warning(
            "Frequency engine 'gaussian' is no longer supported; using 'orca'"
        )
        theory['frequency']['engine'] = 'orca'
    elif freq_engine not in valid_engines:
        logger.warning(f"Invalid frequency engine '{freq_engine}', defaulting to 'orca'")
        theory['frequency']['engine'] = 'orca'

    nmr_engine = theory.setdefault('nmr', {}).get('engine', 'orca')
    if nmr_engine == 'gaussian':
        logger.warning("NMR engine 'gaussian' is no longer supported; using 'orca'")
        theory['nmr']['engine'] = 'orca'
    elif nmr_engine not in valid_engines:
        logger.warning(f"Invalid NMR engine '{nmr_engine}', defaulting to 'orca'")
        theory['nmr']['engine'] = 'orca'

    nmr = config.setdefault('nmr', {})

    temperature_k = nmr.get('temperature_k', 298.15)
    if isinstance(temperature_k, bool) or not isinstance(temperature_k, (int, float)) or temperature_k <= 0:
        logger.warning(f"Invalid NMR temperature_k '{temperature_k}', defaulting to 298.15")
        temperature_k = 298.15
    nmr['temperature_k'] = float(temperature_k)

    energy_window_kcal = nmr.get('energy_window_kcal', 3.0)
    if (
        isinstance(energy_window_kcal, bool)
        or not isinstance(energy_window_kcal, (int, float))
        or energy_window_kcal < 0
    ):
        logger.warning(
            f"Invalid NMR energy_window_kcal '{energy_window_kcal}', defaulting to 3.0"
        )
        energy_window_kcal = 3.0
    nmr['energy_window_kcal'] = float(energy_window_kcal)

    max_conformers = nmr.get('max_conformers', 10)
    if max_conformers is not None and (
        isinstance(max_conformers, bool)
        or not isinstance(max_conformers, int)
        or max_conformers < 1
    ):
        logger.warning(
            f"Invalid NMR max_conformers '{max_conformers}', defaulting to 10"
        )
        max_conformers = 10
    nmr['max_conformers'] = max_conformers

    references = nmr.setdefault('references', {})
    # Defaults are None (unset): the NMR workflow resolves TMS references
    # from the solvent-aware Goodman TMSdata table (acp.nmr.models.
    # lookup_tms_shieldings) keyed by (method, basis, solvent). Only an
    # explicit user value here overrides the table.
    default_references = {
        '1H': None,
        '13C': None,
        '15N': None,
        '19F': None,
        '31P': None,
    }
    for nucleus, default_value in default_references.items():
        value = references.get(nucleus, default_value)
        if value is None:
            references[nucleus] = None
            continue
        if not isinstance(value, bool) and isinstance(value, (int, float)):
            references[nucleus] = float(value)
            continue
        logger.warning(
            f"Invalid NMR reference '{nucleus}={value}', defaulting to {default_value}"
        )
        references[nucleus] = default_value

    return config


def _validate_platform_section(config: dict[str, Any]) -> None:
    """Normalize the CCCP-side baseline of the PLATFORM ``cluster`` section.

    The only platform-aware validation CCCP performs: it normalizes
    ``cluster.local_retention`` so the legacy full-config entry
    (:func:`load_config`) keeps its exact pre-split output.  It never parses
    remote nodes or ``execution_mode`` — that authority stays in Services
    (``RemoteExecutionConfig`` / ``acp_services.contracts.config_validation``).
    Bad values are coerced/repair in place with a warning rather than failing
    hard — config load must never crash the server.
    """
    cluster = config.setdefault('cluster', {})
    section = cluster.setdefault('local_retention', {})

    def _positive_int(key: str, default: int) -> None:
        value = section.get(key, default)
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            logger.warning(
                f"Invalid cluster.local_retention.{key}={value!r}, defaulting to {default}"
            )
            value = default
        section[key] = value

    _positive_int('completed_days', 30)
    _positive_int('failed_days', 90)
    _positive_int('cancelled_days', 30)
    _positive_int('db_record_days', 365)
    _positive_int('cleanup_interval_hours', 6)
    _positive_int('max_dirs_per_sweep', 200)

    cleanup_thr = section.get('disk_cleanup_threshold', 90)
    skip_thr = section.get('disk_skip_threshold', 95)
    for key, default in (('disk_cleanup_threshold', 90), ('disk_skip_threshold', 95)):
        value = section.get(key, default)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not (0 < value <= 100):
            logger.warning(
                f"Invalid cluster.local_retention.{key}={value!r}, defaulting to {default}"
            )
            section[key] = default
    cleanup_thr = section['disk_cleanup_threshold']
    skip_thr = section['disk_skip_threshold']
    if cleanup_thr >= skip_thr:
        logger.warning(
            f"cluster.local_retention.disk_cleanup_threshold ({cleanup_thr}) must be "
            f"strictly below disk_skip_threshold ({skip_thr}); resetting to 90/95"
        )
        section['disk_cleanup_threshold'] = 90
        section['disk_skip_threshold'] = 95

    if not isinstance(section.get('enabled', True), bool):
        section['enabled'] = True
    if not isinstance(section.get('vacuum_after_db_cleanup', False), bool):
        section['vacuum_after_db_cleanup'] = False


def save_config(config: dict[str, Any], output_path: Path):
    """
    Save configuration to YAML file.
    
    Args:
        config: Configuration dictionary
        output_path: Output file path
    """
    with open(output_path, 'w', encoding='utf-8') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)
