"""
ORCA Interface
=============

Interface for ORCA quantum chemistry software.

Author: QCcalc Team (adapted from RPH)
"""

# pyright: reportArgumentType=false, reportAny=false, reportConstantRedefinition=false, reportDeprecated=false, reportExplicitAny=false, reportImplicitOverride=false, reportImplicitStringConcatenation=false, reportMissingParameterType=false, reportMissingTypeArgument=false, reportPrivateUsage=false, reportUnannotatedClassAttribute=false, reportUnknownArgumentType=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportUnknownVariableType=false, reportUnnecessaryComparison=false, reportUnusedCallResult=false, reportUnusedImport=false, reportUnusedParameter=false
# mypy: ignore-errors

import json
import logging
import os
import re
import shutil
import subprocess
import threading
from collections.abc import Callable, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

from cccp.qc.hessian_policy import resolve_recalc_hess
from cccp.qc.interfaces.base import QCInterfaceBase, QCResult
from cccp.qc.interfaces.constraints import (
    CoordinateConstraint,
    CoordinateSpec,
    ReactionCoordinatePlan,
    orca_constraint_block,
)
from cccp.qc.interfaces.orca_ts import (
    IrcResult,
    TsOptResult,
    discover_irc_trajectory_files,
    freq_block_for_ts,
    irc_block,
    irc_route,
    parse_irc_endpoints,
    parse_ts_frequency_map,
    parse_ts_mode_vectors,
    ts_geom_block,
)
from cccp.qc.interfaces.route_render import (
    RouteKeyword,
    orca_gfn_solvent_token,
    orca_keyword_context,
    render_route_line,
)
from cccp.qc.interfaces.xtb_scan import RelaxedScanPoint, RelaxedScanResult
from cccp.qc.keyword_registry import (
    KeywordValueError,
    calculation_policy,
    canonical_token,
    canonical_tokens,
    method_family,
    resolve,
    resolve_implementation,
    scf_rank,
)
from cccp.qc.method_meta import method_meta, scf_constraint
from cccp.qc.translation import render_opt_geom_lines
from cccp.software import SoftwareNotFoundError, orca_runtime_env, resolve_executable
from cccp.utils import ensure_dir
from cccp.utils.file_io import read_xyz, read_xyz_multiframe, write_xyz
from cccp.utils.geometry_tools import LogParser
from cccp.utils.resource_utils import mem_to_mb, resolve_orca_maxcore
from cccp.utils.solvent_map import orca_smd_solvent

logger = logging.getLogger(__name__)

#: Canonical ``scf_convergence`` emission tokens (registry authority) — used
#: to recognise SCF directives among free-form ``route_extras`` literals.
_SCF_CONVERGENCE_TOKENS: frozenset[str] = frozenset(
    token.upper() for token in canonical_tokens("scf_convergence")
)

# ORCA output failure classification patterns
_SCF_FAILURE_PATTERNS = [
    "SCF NOT CONVERGED",
    "SCF failed to converge",
    "DIIS convergence not achieved",
    "ERROR: SCF convergence",
]
_GEOMETRY_NOT_CONVERGED_PATTERNS = [
    "THE OPTIMIZATION HAS NOT CONVERGED",
    "OPTIMIZATION DID NOT CONVERGE",
    "GEOMETRY OPTIMIZATION DID NOT CONVERGE",
]
_MEMORY_FAILURE_PATTERNS = [
    "cannot allocate",
    "out of memory",
    "insufficient memory",
    "memory allocation failed",
    "std::bad_alloc",
]


def classify_orca_failure(output_path: Path) -> str:
    """Classify an ORCA failure mode from the output file.

    Reads the tail of *output_path* and returns one of:
    ``"scf_failure"``, ``"geometry_not_converged"``, ``"memory_failure"``,
    ``"crash_timeout"``, or ``"unknown"``.
    """
    try:
        output_path = Path(output_path)
        if not output_path.is_file():
            return "unknown"
        text = output_path.read_text(encoding="utf-8", errors="replace")
        tail_lines = text[-80_000:].splitlines()
    except OSError:
        return "unknown"

    tail_text = "\n".join(tail_lines)
    tail_lower = tail_text.lower()

    for pat in _MEMORY_FAILURE_PATTERNS:
        if pat in tail_lower:
            return "memory_failure"

    for pat in _GEOMETRY_NOT_CONVERGED_PATTERNS:
        if pat.lower() in tail_lower:
            return "geometry_not_converged"

    for pat in _SCF_FAILURE_PATTERNS:
        if pat.lower() in tail_lower:
            return "scf_failure"

    if "scf iterations" in tail_lower and "scf converged" not in tail_lower:
        return "scf_failure"

    return "unknown"


def _resolve_method_meta(method: str | None) -> dict[str, Any] | None:
    """Look up ``METHOD_META`` for *method* (case-insensitive).

    The metadata lives in ``cccp.qc.method_meta`` (single source of truth
    for calculation semantics; plan todo 7 / delta D5) — no ``acp``
    dependency, so isolated and integrated environments resolve identical
    defaults (DLPNO aux blocks included).
    """
    if not method:
        return None
    return method_meta(method)


# --- Hessian resolver (module-level cache) ---------------------------------
# The Hessian policy implementation lives in ``cccp.qc.hessian_policy``
# (in-package, no reverse dependency) and is imported at module top; the
# previous lazy ``acp`` import is gone.  The module-level cache keeps
# ``_get_resolver`` the single access point with a stable callable identity
# (tests assert cached-identity semantics).
_RESOLVER = None


def _get_resolver():
    """Return the cached ``resolve_recalc_hess`` callable."""
    global _RESOLVER
    if _RESOLVER is None:
        _RESOLVER = resolve_recalc_hess
    return _RESOLVER


def _resolve_recalc_hess_lazy(
    explicit: object,
    configured: object,
    symbols: list[str] | None,
):
    """Thin wrapper around the cccp resolver; preserves cached access."""
    return _get_resolver()(
        explicit=explicit,
        configured=configured,
        symbols=symbols,
    )


def _record_hessian_resolution(
    out_dir: Path,
    inp_file: Path,
    resolution,
    input_value: object,
    config_value: object,
) -> None:
    """Write a ``<stem>.hessian.json`` sidecar next to the ORCA input.

    Captures the *resolved* Hessian policy so the actual ORCA ``%geom``
    block can be reproduced bit-for-bit. ``auto`` resolution depends on
    the concrete molecule, so recording only the input ``"auto"`` value
    is insufficient for replay (plan §7.5).

    Failures are logged and swallowed: provenance must never break the
    actual ORCA run.
    """
    try:
        sidecar = inp_file.with_suffix(".hessian.json")
        payload = {
            "interval": int(resolution.interval),
            "enabled": bool(resolution.enabled),
            "source": resolution.source,
            "reason": resolution.reason,
            "heavy_elements": list(resolution.heavy_elements),
            "triggering_elements": list(resolution.triggering_elements),
            "input_value": input_value,
            "config_value": config_value,
            "resolved_at": datetime.now(timezone.utc).isoformat(),
        }
        ensure_dir(out_dir)
        with sidecar.open("w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, sort_keys=True)
    except Exception as exc:  # pragma: no cover - best-effort provenance
        logger.warning("Failed to write Hessian resolution sidecar: %s", exc)


_NMR_NUCLEUS_TENSOR_RE = re.compile(
    r"^\s*Nucleus\s+(\d+)\s*([A-Za-z]{1,2})\s*:\s*isotropic\s*=\s*"
    r"([-+]?\d+\.\d+)\s*anisotropy\s*=\s*([-+]?\d+\.\d+)"
)
_NMR_TENSOR_COMP_RE = re.compile(r"([XYZ]{2})\s*=\s*([-+]?\d+\.\d+)")
# ORCA 5.x summary table fallback:
#   Nucleus   Element   Isotropic(ppm)
#      0         6 C       45.230
_NMR_SUMMARY_ROW_RE = re.compile(r"^\s*(\d+)\s+(\d+)\s*([A-Za-z]{1,2})\s+([-+]?\d+\.\d+)\s*$")
# ORCA 6.x summary table variant — the element-number column is replaced by
# the element symbol and anisotropy is appended:
#   Nucleus  Element    Isotropic     Anisotropy
#       0       C          184.706         21.749
_NMR_SUMMARY_ROW_ORCA6_RE = re.compile(
    r"^\s*(\d+)\s+([A-Za-z]{1,2})\s+([-+]?\d+\.\d+)\s+([-+]?\d+\.\d+)\s*$"
)
_NMR_TENSOR_HEADER = "NMR SHIELDING TENSOR"
_NMR_SUMMARY_HEADER = "CHEMICAL SHIELDING SUMMARY"
_NMR_SHIELDING_HEADERS = (_NMR_TENSOR_HEADER, _NMR_SUMMARY_HEADER)


class NmrShieldingParser:
    """Parse ORCA GIAO NMR shielding output.

    Handles both formats emitted by ORCA 5.x:

    * the full ``NMR SHIELDING TENSOR (PPM)`` block (per-nucleus tensor
      components, written by ``%eprnmr`` or the simple ``NMR`` keyword);
    * the compact ``CHEMICAL SHIELDING SUMMARY (ppm)`` table.

    Returns a mapping of 0-based atom index → shielding descriptor. The
    ORCA ``Nucleus NH:`` line numbers atoms from 1; the parser converts
    to 0-based to match :class:`Structure` indexing.
    """

    @staticmethod
    def parse(
        log_file: Path,
        expected_symbols: list[str] | tuple[str, ...] | None = None,
    ) -> dict[int, dict[str, Any]]:
        """Parse the last NMR shielding section from an ORCA log.

        Args:
            log_file: ORCA ``.out`` log path.
            expected_symbols: When provided, validate that the parsed
                element sequence matches (raises ``ValueError`` on mismatch).

        Returns:
            Dict ``{atom_index(0-based): {"symbol", "isotropic",
            "anisotropy", "tensor_components"}}``.
        """
        try:
            text = Path(log_file).read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning("Could not read NMR shielding from %s: %s", log_file, exc)
            return {}

        lines = text.splitlines()
        shieldings = NmrShieldingParser._parse_tensor_block(lines)
        if not shieldings:
            shieldings = NmrShieldingParser._parse_summary_block(lines)

        if not shieldings:
            logger.warning("No NMR shielding section found in %s", log_file)
            return {}

        if expected_symbols is not None:
            NmrShieldingParser._validate_symbols(shieldings, expected_symbols)
        return shieldings

    @staticmethod
    def _parse_tensor_block(lines: list[str]) -> dict[int, dict[str, Any]]:
        """Parse the ``NMR SHIELDING TENSOR (PPM)`` block."""
        # find the last occurrence of the tensor header
        start = None
        for idx in range(len(lines) - 1, -1, -1):
            if _NMR_TENSOR_HEADER in lines[idx]:
                start = idx + 1
                break
        if start is None:
            return {}

        result: dict[int, dict[str, Any]] = {}
        current: dict[str, Any] | None = None
        for line in lines[start:]:
            if not line.strip():
                if current is not None:
                    result[int(current["atom_index"])] = current
                    current = None
                # blank lines inside a tensor block are normal; only stop
                # when we hit a completely new section / end of relevant data
                continue
            m = _NMR_NUCLEUS_TENSOR_RE.match(line)
            if m:
                if current is not None:
                    result[int(current["atom_index"])] = current
                current = {
                    "atom_index": int(m.group(1)) - 1,  # → 0-based
                    "symbol": _normalize_nmr_symbol(m.group(2)),
                    "isotropic": float(m.group(3)),
                    "anisotropy": float(m.group(4)),
                    "tensor_components": {},
                }
                continue
            if current is not None:
                for comp in _NMR_TENSOR_COMP_RE.finditer(line):
                    current["tensor_components"][comp.group(1)] = float(comp.group(2))
                # stop scanning once we clearly leave the tensor block
                if "JOB DONE" in line or line.startswith("----"):
                    if current is not None:
                        result[int(current["atom_index"])] = current
                        current = None
                    break
        if current is not None:
            result[int(current["atom_index"])] = current
        return result

    @staticmethod
    def _parse_summary_block(lines: list[str]) -> dict[int, dict[str, Any]]:
        """Parse the ``CHEMICAL SHIELDING SUMMARY (ppm)`` table fallback."""
        start = None
        for idx in range(len(lines) - 1, -1, -1):
            if _NMR_SUMMARY_HEADER in lines[idx]:
                start = idx + 1
                break
        if start is None:
            return {}

        result: dict[int, dict[str, Any]] = {}
        for line in lines[start:]:
            m5 = _NMR_SUMMARY_ROW_RE.match(line)
            m6 = _NMR_SUMMARY_ROW_ORCA6_RE.match(line)
            if m5 is None and m6 is None:
                stripped = line.strip()
                if not stripped or stripped.startswith("-"):
                    continue
                # skip the column-header row ("Nucleus Element Isotropic(ppm)")
                lowered = stripped.lower()
                if lowered.startswith("nucleus") and "isotropic" in lowered:
                    continue
                if result:
                    break  # already collected rows → left the table
                continue  # haven't seen data yet → keep scanning
            if m5 is not None:
                # ORCA 5.x layout: <nucleus#> <element_num> <element_sym> <iso>
                # ORCA 5.x summary table Nucleus column is 0-based (starts at 0),
                # unlike the TENSOR block's "Nucleus N El:" which is 1-based.
                # Real ORCA 5.x output example (confirmed by ORCA manual §9.10):
                #   Nucleus   Element   Isotropic(ppm)
                #      0         6 C       45.230
                atom_idx = int(m5.group(1))  # 0-based, no -1
                symbol = _normalize_nmr_symbol(m5.group(3))
                isotropic = float(m5.group(4))
                anisotropy: float | None = None
            else:
                if m6 is None:  # pragma: no cover - guard above
                    continue
                # ORCA 6.x layout: <nucleus#> <element_sym> <iso> <anisotropy>
                atom_idx = int(m6.group(1))
                symbol = _normalize_nmr_symbol(m6.group(2))
                isotropic = float(m6.group(3))
                anisotropy = float(m6.group(4))
            result[atom_idx] = {
                "atom_index": atom_idx,
                "symbol": symbol,
                "isotropic": isotropic,
                "anisotropy": anisotropy,
                "tensor_components": {},
            }
        return result

    @staticmethod
    def _validate_symbols(
        shieldings: dict[int, dict[str, Any]],
        expected_symbols: list[str] | tuple[str, ...],
    ) -> None:
        expected = [_normalize_nmr_symbol(s) for s in expected_symbols]
        indices = sorted(shieldings)
        out_of_range = [index for index in indices if index < 0 or index >= len(expected)]
        if out_of_range:
            raise ValueError(f"Parsed shielding atom indices outside the molecule: {out_of_range}")
        parsed = [shieldings[index]["symbol"] for index in indices]
        expected_at_indices = [expected[index] for index in indices]
        if parsed != expected_at_indices:
            raise ValueError(
                f"Parsed shielding symbols {parsed} do not match expected {expected_at_indices}"
            )


def _normalize_nmr_symbol(symbol: str) -> str:
    """Return a normalized element symbol (Title-case, stripped)."""
    s = symbol.strip()
    if not s:
        return s
    return s[:1].upper() + s[1:].lower()


_FREQ_SECTION_HEADER = "VIBRATIONAL FREQUENCIES"
_FREQ_LINE_RE = re.compile(r"^\s*\d+:\s+([-+]?\d+\.\d+)\s+cm\*\*-1", re.MULTILINE)
_CARTESIAN_COORD_HEADER = "CARTESIAN COORDINATES (ANGSTROEM)"
# ORCA prints the banner as ``*               RELAXED SURFACE SCAN STEP   1   *``:
# allow an optional leading ``*``; use ``[ \t]`` (not ``\s``) so the match cannot
# start on an earlier banner-decoration line.
_SCAN_STEP_RE = re.compile(
    r"^[ \t]*\*?[ \t]*RELAXED[ \t]+SURFACE[ \t]+SCAN[ \t]+STEP[ \t]+\d+.*$", re.MULTILINE
)
_SCAN_SUMMARY_MARKER = "calculated surface"
_COORD_LINE_RE = re.compile(
    r"^\s*([A-Z][a-z]?)\s+"
    r"([-+]?\d+(?:\.\d+)?(?:[EeDd][+-]?\d+)?)\s+"
    r"([-+]?\d+(?:\.\d+)?(?:[EeDd][+-]?\d+)?)\s+"
    r"([-+]?\d+(?:\.\d+)?(?:[EeDd][+-]?\d+)?)\s*$"
)
_NUMERIC_TOKEN_RE = re.compile(r"[-+]?\d+(?:\.\d+)?(?:[EeDd][+-]?\d+)?")


def _parse_frequencies(output_file: Path) -> list[float]:
    """Parse the final frequency section from an ORCA log.

    ORCA 5.x prints frequency lines as ``   N:     value cm**-1`` (imaginary
    modes carry a ``***imaginary mode***`` suffix).  ``Opt Freq`` jobs
    contain one section per Hessian recalculation during optimization; only
    the last section corresponds to the final geometry.  The six
    translational/rotational zero modes are excluded.

    Args:
        output_file: ORCA ``.out`` log path

    Returns:
        Vibrational frequencies (cm**-1); empty list on parse failure.
    """
    try:
        with open(output_file, encoding="utf-8", errors="replace") as f:
            content = f.read()
    except OSError as e:
        logger.warning("Could not read frequency data from %s: %s", output_file, e)
        return []
    sections = content.split(_FREQ_SECTION_HEADER)
    if len(sections) < 2:
        logger.warning("No VIBRATIONAL FREQUENCIES section found in %s", output_file)
        return []
    frequencies = [float(m.group(1)) for m in _FREQ_LINE_RE.finditer(sections[-1])]
    return [f for f in frequencies if f != 0.0]


def _is_orca_gfn_xtb_method(method: str | None) -> bool:
    if not method:
        return False
    return method_family(method) in {"gfn", "gfnff"}


def _looser_opt_level(opt_level: str | None) -> str | None:
    """Relax a geometry-convergence keyword by one notch (tight→normal)."""
    if opt_level is None:
        return "normal"
    return {
        "verytight": "tight",
        "very_tight": "tight",
        "tight": "normal",
    }.get(str(opt_level).strip().lower(), opt_level)


# ── Electronic-state SCF block renderer (design doc §9) ─────────────────
#
# ``scf_options`` is a JSON-safe dict produced by the ACP electronic-state
# module. It is the ONLY sanctioned way to build a ``%scf`` block for spin
# control; raw ``extra_blocks`` containing ``%scf`` are rejected so the
# rendered input stays verifiable (§9.6).

_SCF_OPTIONS_KEYS = frozenset(
    {
        "hf_typ",
        "guess_mix_angle",
        "flip_spin_atoms",
        "final_ms",
        "broken_sym_na",
        "broken_sym_nb",
        "mo_read_path",
        "stab_perform",
        "stab_restart",
        "no_use_sym",
        "write_spin_density",
        "scf_extra_lines",
        "damp",
        "dampfac",
        "shift",
        "shiftfac",
    }
)


def _scf_option_bool(options: dict, key: str) -> bool:
    return bool(options.get(key, False))


def _scf_option_float(options: dict, key: str) -> float | None:
    value = options.get(key)
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None


def _scf_option_int(options: dict, key: str) -> int | None:
    value = options.get(key)
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and float(value).is_integer():
        return int(value)
    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            return None
    return None


def render_scf_block(scf_options: dict | None) -> str | None:
    """Render the single structured ``%scf`` block (§9.6).

    Args:
        scf_options: Structured spin/guess/stability options. Unknown keys
            are ignored so future contract fields do not break rendering.

    Returns:
        The rendered input text, or ``None`` when no SCF directives apply.
    """
    if not scf_options:
        return None

    lines: list[str] = []

    hf_typ = scf_options.get("hf_typ")
    if isinstance(hf_typ, str) and hf_typ.strip():
        lines.append(f"  HFTyp {hf_typ.strip()}")

    guess_mix_angle = _scf_option_float(scf_options, "guess_mix_angle")
    if guess_mix_angle is not None:
        lines.append(f"  GuessMix {guess_mix_angle:g}")

    flip_atoms = scf_options.get("flip_spin_atoms")
    if isinstance(flip_atoms, (list, tuple)) and flip_atoms:
        atoms = [int(a) for a in flip_atoms if isinstance(a, (int, float))]
        if atoms:
            lines.append("  FlipSpin " + ", ".join(str(a) for a in atoms))
        final_ms = _scf_option_float(scf_options, "final_ms")
        if final_ms is not None:
            lines.append(f"  FinalMs {final_ms:g}")

    broken_na = _scf_option_int(scf_options, "broken_sym_na")
    broken_nb = _scf_option_int(scf_options, "broken_sym_nb")
    if broken_na is not None and broken_nb is not None:
        lines.append(f"  BrokenSym {broken_na},{broken_nb}")

    if _scf_option_bool(scf_options, "stab_perform"):
        lines.append("  STABPerform true")
        if _scf_option_bool(scf_options, "stab_restart"):
            lines.append("  STABRestartUHFifUnstable true")

    maxiter = scf_options.get("maxiter")
    if isinstance(maxiter, (int, float)) and maxiter > 0:
        lines.append(f"  MaxIter {int(maxiter)}")

    damp = scf_options.get("damp")
    if damp:
        lines.append("  Damp true")
        dampfac = scf_options.get("dampfac", 0.50)
        lines.append(f"  DampFac {float(dampfac):.2f}")

    shift = scf_options.get("shift")
    if shift:
        lines.append("  Shift true")
        shiftfac = scf_options.get("shiftfac", 0.30)
        lines.append(f"  ShiftFac {float(shiftfac):.2f}")

    for extra in scf_options.get("scf_extra_lines") or []:
        if isinstance(extra, str) and extra.strip():
            lines.append(f"  {extra.strip()}")

    if not lines:
        return None
    return "%scf\n" + "\n".join(lines) + "\nend"


def render_moinp_block(scf_options: dict | None) -> str | None:
    """Render the ``%moinp`` block for MORead guesses (§5.3 moread)."""
    if not scf_options:
        return None
    path = scf_options.get("mo_read_path")
    if not isinstance(path, str) or not path:
        return None
    return f'%moinp "{path}"'


def render_spin_density_plots_block(scf_options: dict | None) -> str | None:
    """Render a ``%plots`` block writing a spin-density cube (§5.1)."""
    if not scf_options or not _scf_option_bool(scf_options, "write_spin_density"):
        return None
    return "%plots\n  Format Gaussian_Cube\n  SpinDens true\nend"


def scf_route_extras(scf_options: dict | None) -> list[str]:
    """Route-line keywords implied by the electronic-state options."""
    if not scf_options:
        return []
    extras: list[str] = []
    if _scf_option_bool(scf_options, "no_use_sym"):
        extras.append("NoUseSym")
    if scf_options.get("mo_read_path"):
        extras.append("Moread")
    return extras


# ── Spin diagnostics parsing (design doc §10.3, §12.1) ──────────────────

_SPIN_CONTAMINATION_HEADER = "UHF SPIN CONTAMINATION"
_S2_EXPECTATION_RE = re.compile(r"Expectation value of <S\*\*2>\s*:\s*([-+]?\d+\.\d+)")
_S2_IDEAL_RE = re.compile(r"Ideal value S\*\(S\+1\) for S=([-+]?\d+\.\d+)\s*:\s*([-+]?\d+\.\d+)")
_MULLIKEN_SPIN_HEADER = "MULLIKEN ATOMIC CHARGES AND SPIN POPULATIONS"
_LOEWDIN_SPIN_HEADER = "LOEWDIN ATOMIC CHARGES AND SPIN POPULATIONS"
_ATOMIC_POPULATION_ROW_RE = re.compile(
    r"^\s*(\d+)\s+([A-Za-z]{1,2})\s*:\s+([-+]?\d+\.\d+)(?:\s+([-+]?\d+\.\d+))?\s*$"
)


def _parse_spin_contamination(text: str) -> dict[str, Any]:
    """Parse the last ``UHF SPIN CONTAMINATION`` block."""
    sections = text.split(_SPIN_CONTAMINATION_HEADER)
    if len(sections) < 2:
        return {}
    tail = sections[-1]
    result: dict[str, Any] = {}
    match = _S2_EXPECTATION_RE.search(tail)
    if match:
        result["s2"] = float(match.group(1))
    ideal = _S2_IDEAL_RE.search(tail)
    if ideal:
        result["ideal_s"] = float(ideal.group(1))
        result["expected_s2"] = float(ideal.group(2))
    return result


def _parse_atomic_spin_populations(text: str, header: str) -> dict[int, float]:
    """Parse one atomic-charges-and-spin-populations table."""
    sections = text.split(header)
    if len(sections) < 2:
        return {}
    populations: dict[int, float] = {}
    for line in sections[-1].splitlines():
        match = _ATOMIC_POPULATION_ROW_RE.match(line)
        if not match:
            stripped = line.strip()
            if populations and (not stripped or stripped.startswith("-")):
                break
            continue
        atom_index = int(match.group(1))
        spin_value = match.group(4)
        if spin_value is None:
            continue
        populations[atom_index] = float(spin_value)
    return populations


def parse_electronic_state_diagnostics(output_file: Path) -> dict[str, Any]:
    """Extract ``<S²>`` and atomic spin populations from an ORCA log (§10.3).

    Args:
        output_file: ORCA ``.out`` log path.

    Returns:
        ``{"s2", "expected_s2", "ideal_s", "mulliken_spin_populations",
        "loewdin_spin_populations"}`` — fields absent when ORCA did not
        print them (e.g. restricted runs have no spin contamination block).
    """
    diagnostics: dict[str, Any] = {}
    try:
        text = Path(output_file).read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        logger.warning("Could not read spin diagnostics from %s: %s", output_file, exc)
        return diagnostics

    diagnostics.update(_parse_spin_contamination(text))
    mulliken = _parse_atomic_spin_populations(text, _MULLIKEN_SPIN_HEADER)
    if mulliken:
        diagnostics["mulliken_spin_populations"] = mulliken
    loewdin = _parse_atomic_spin_populations(text, _LOEWDIN_SPIN_HEADER)
    if loewdin:
        diagnostics["loewdin_spin_populations"] = loewdin
    return diagnostics


def _with_spin_metadata(metadata: dict[str, Any] | None, output_file: Path) -> dict[str, Any]:
    """Attach parsed spin diagnostics to a QCResult metadata dict."""
    merged = dict(metadata or {})
    diagnostics = parse_electronic_state_diagnostics(output_file)
    if diagnostics:
        merged["electronic_state_diagnostics"] = diagnostics
    return merged


# ── CASSCF / NEVPT2 parsing (design doc §11, §12.1) ─────────────────────

_FINAL_ENERGY_RE = re.compile(r"FINAL SINGLE POINT ENERGY\s+([-+]?\d+\.\d+)")
_NATURAL_OCCUPATION_RE = re.compile(r"^\s*N\[\s*(\d+)\]\s*=\s*([-+]?\d+\.\d+)\s*$", re.MULTILINE)
_NATURAL_OCCUPATION_HEADER_RE = re.compile(
    r"Natural Orbital Occupation Numbers\s*?:?", re.IGNORECASE
)
_ORBITAL_OPT_CONVERGED_MARKER = "ORBITAL OPTIMIZATION HAS CONVERGED"
_NEVPT2_ROOT_HEADER_RE = re.compile(r"MULT\s+(\d+)\s*,\s*ROOT\s+(\d+)")
_NEVPT2_TOTAL_CORRECTION_RE = re.compile(r"Total Energy Correction\s*:\s*dE\s*=\s*([-+]?\d+\.\d+)")
_NEVPT2_ZERO_ORDER_RE = re.compile(r"Zero Order Energy\s*:\s*E0\s*=\s*([-+]?\d+\.\d+)")
_NEVPT2_TOTAL_RE = re.compile(r"Total Energy \(E0\+dE\)\s*:\s*E\s*=\s*([-+]?\d+\.\d+)")
_CAS_ENERGY_CONVERGED_RE = re.compile(r"THE\s+CAS-SCF\s+ENERGY\s+HAS\s+CONVERGED")
_CAS_GRADIENT_CONVERGED_RE = re.compile(r"THE\s+CAS-SCF\s+GRADIENT\s+HAS\s+CONVERGED")
_CAS_RESULTS_SECTION_RE = re.compile(r"(?:CAS-SCF|CASSCF)\s+RESULTS")
_FINAL_CASSCF_ENERGY_RE = re.compile(r"Final CASSCF energy\s*:\s*([-+]?\d+\.\d+)")
_N_OCC_LINE_RE = re.compile(r"^\s*N\(occ\)=\s*((?:[-+]?\d+\.\d+\s*)+)\s*$", re.MULTILINE)
_CAS_ROOT_LINE_RE = re.compile(r"^\s*ROOT\s+(\d+):\s*E=\s*([-+]?\d+\.\d+)")
_CAS_MULT_IN_LINE_RE = re.compile(r"MULT\s*=\s*(\d+)")
_CASSCF_JOB_BOUNDARY_RE = re.compile(r"ORCA TERMINATED NORMALLY|Program Version \d")
_CASSCF_ROOT_ENERGY_RE = re.compile(
    r"^\s*(?:Mult|MULT)\s+(\d+)\s*,\s*(?:Root|ROOT)\s+(\d+).*?([-+]?\d+\.\d{4,})",
)


def _parse_natural_occupations(text: str) -> list[float]:
    """Parse the last ``Natural Orbital Occupation Numbers`` listing."""
    header_matches = list(_NATURAL_OCCUPATION_HEADER_RE.finditer(text))
    if not header_matches:
        return []
    tail = text[header_matches[-1].end() :]
    occupations: list[tuple[int, float]] = []
    for match in _NATURAL_OCCUPATION_RE.finditer(tail):
        occupations.append((int(match.group(1)), float(match.group(2))))
        if len(occupations) >= 500:
            break
    return [value for _, value in sorted(occupations)]


def _last_cas_convergence_marker_end(text: str) -> int | None:
    """End offset of the last CAS convergence marker, or ``None``.

    Recognizes the ORCA 6.1.1 ``THE CAS-SCF ENERGY/GRADIENT HAS CONVERGED``
    marker lines (variable whitespace) and the legacy
    ``ORBITAL OPTIMIZATION HAS CONVERGED`` marker.  Plain SCF convergence
    (``THE SCF HAS CONVERGED``) is deliberately NOT a CAS marker.
    """
    ends = [m.end() for m in _CAS_ENERGY_CONVERGED_RE.finditer(text)]
    ends += [m.end() for m in _CAS_GRADIENT_CONVERGED_RE.finditer(text)]
    legacy = text.find(_ORBITAL_OPT_CONVERGED_MARKER)
    if legacy >= 0:
        ends.append(legacy + len(_ORBITAL_OPT_CONVERGED_MARKER))
    return max(ends) if ends else None


def _parse_active_occupations(text: str) -> list[float]:
    """Active-space occupations (never inactive/virtual ``OCC`` table entries).

    Prefers the LAST ``N(occ)= v1 v2 ...`` print occurring after the final
    CAS convergence marker (ORCA 6.1.x CAS-SCF iteration output — the line
    lists active orbitals only); otherwise falls back to the explicit
    ``Natural Orbital Occupation Numbers`` listing (older format).
    """
    marker_end = _last_cas_convergence_marker_end(text)
    if marker_end is not None:
        matches = list(_N_OCC_LINE_RE.finditer(text, marker_end))
        if matches:
            return [float(value) for value in matches[-1].group(1).split()]
    return _parse_natural_occupations(text)


def _parse_nevpt2_roots(text: str) -> list[dict[str, Any]]:
    """Parse per-root blocks of the ``NEVPT2 Results`` section (§12.1)."""
    sections = text.split("NEVPT2 Results")
    if len(sections) < 2:
        return []
    roots: list[dict[str, Any]] = []
    for block in sections[1:]:
        header = _NEVPT2_ROOT_HEADER_RE.search(block)
        correction = _NEVPT2_TOTAL_CORRECTION_RE.search(block)
        zero_order = _NEVPT2_ZERO_ORDER_RE.search(block)
        total = _NEVPT2_TOTAL_RE.search(block)
        if not (header and (total or zero_order)):
            continue
        roots.append(
            {
                "multiplicity": int(header.group(1)),
                "root": int(header.group(2)),
                "casscf_energy_hartree": float(zero_order.group(1)) if zero_order else None,
                "nevpt2_correction_hartree": float(correction.group(1)) if correction else None,
                "correlated_energy_hartree": float(total.group(1)) if total else None,
            }
        )
    return roots


def _parse_casscf_root_energies(text: str) -> list[dict[str, Any]]:
    """Per-root energies from the last ``CAS-SCF RESULTS``/``CASSCF RESULTS`` section."""
    sections = _CAS_RESULTS_SECTION_RE.split(text)
    if len(sections) < 2:
        return []
    roots: list[dict[str, Any]] = []
    multiplicity: int | None = None
    for line in sections[-1].splitlines():
        mult_match = _CAS_MULT_IN_LINE_RE.search(line)
        if mult_match:
            multiplicity = int(mult_match.group(1))
        match = _CASSCF_ROOT_ENERGY_RE.match(line)
        if match:
            roots.append(
                {
                    "multiplicity": int(match.group(1)),
                    "root": int(match.group(2)),
                    "casscf_energy_hartree": float(match.group(3)),
                }
            )
            continue
        root_match = _CAS_ROOT_LINE_RE.match(line)
        if root_match:
            roots.append(
                {
                    "multiplicity": multiplicity if multiplicity is not None else 1,
                    "root": int(root_match.group(1)),
                    "casscf_energy_hartree": float(root_match.group(2)),
                }
            )
    return roots


def _final_cas_results_present(text: str, casscf_roots: list[dict[str, Any]]) -> bool:
    """True when the last CAS results section carries final converged facts.

    A convergence marker alone (e.g. an energy marker on a truncated log)
    does not prove completion — the results section must hold a
    ``Final CASSCF energy`` line or parsed per-root energies.
    """
    sections = list(_CAS_RESULTS_SECTION_RE.finditer(text))
    if not sections:
        return False
    tail = text[sections[-1].end() :]
    return bool(_FINAL_CASSCF_ENERGY_RE.search(tail)) or bool(casscf_roots)


def _casscf_job_blocks(text: str) -> list[str]:
    """Split a multi-job log at ORCA job boundaries (banner / termination)."""
    blocks = [block for block in _CASSCF_JOB_BOUNDARY_RE.split(text) if block.strip()]
    return blocks or [text]


def _casscf_bound_energy(text: str) -> float | None:
    """CAS energy bound to the last CAS-bearing job block.

    The block must show CAS evidence (convergence marker or CAS results
    section); ``FINAL SINGLE POINT ENERGY`` occurrences after the block's
    ``NEVPT2 Results`` correlation region are excluded so an unrelated
    later method never masquerades as the CAS energy.  Falls back to the
    section's ``Final CASSCF energy`` line, then to the ROOT 0 energy.
    """
    for block in reversed(_casscf_job_blocks(text)):
        has_marker = _last_cas_convergence_marker_end(block) is not None
        if not has_marker and not _CAS_RESULTS_SECTION_RE.search(block):
            continue
        cas_region = block.split("NEVPT2 Results")[0]
        matches = _FINAL_ENERGY_RE.findall(cas_region)
        if matches:
            return float(matches[-1])
        final_match = _FINAL_CASSCF_ENERGY_RE.search(block)
        if final_match:
            return float(final_match.group(1))
        roots = _parse_casscf_root_energies(block)
        if roots:
            ground = next((r for r in roots if r["root"] == 0), roots[0])
            return float(ground["casscf_energy_hartree"])
    return None


def parse_casscf_output(output_file: Path) -> dict[str, Any]:
    """Extract CASSCF/NEVPT2 energies and natural occupations (§12.1).

    Args:
        output_file: ORCA ``.out`` log path.

    Returns:
        ``{"casscf_energy", "natural_occupations", "nevpt2_roots",
        "casscf_roots", "converged"}``.
    """
    result: dict[str, Any] = {
        "casscf_energy": None,
        "natural_occupations": [],
        "nevpt2_roots": [],
        "casscf_roots": [],
        "converged": False,
    }
    try:
        text = Path(output_file).read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        logger.warning("Could not read CASSCF output %s: %s", output_file, exc)
        return result

    casscf_roots = _parse_casscf_root_energies(text)
    has_marker = _last_cas_convergence_marker_end(text) is not None
    result["casscf_energy"] = _casscf_bound_energy(text)
    result["converged"] = has_marker and _final_cas_results_present(text, casscf_roots)
    result["natural_occupations"] = _parse_active_occupations(text)
    result["nevpt2_roots"] = _parse_nevpt2_roots(text)
    result["casscf_roots"] = casscf_roots
    return result


def _orca_scan_line(scan_coordinate: CoordinateSpec, points: int) -> str:
    """Render one ORCA relaxed-scan line from a :class:`CoordinateSpec`."""
    if scan_coordinate.role == "monitor":
        raise ValueError("ORCA relaxed_scan does not accept monitor-only coordinates")
    if scan_coordinate.start is None or scan_coordinate.end is None:
        raise ValueError("ORCA relaxed_scan requires scan_coordinate.start and .end")
    kind_map = {"distance": "B", "angle": "A", "dihedral": "D"}
    kind = kind_map[scan_coordinate.kind]
    atoms = " ".join(str(int(atom)) for atom in scan_coordinate.atoms)
    return (
        f"    {kind} {atoms} = {float(scan_coordinate.start):.8f}, "
        f"{float(scan_coordinate.end):.8f}, {int(points)}"
    )


def _orca_scan_route_settings(
    method: str,
    solvent: str | None,
    solvent_model: str | None,
    use_scants: bool,
    route_extras: Sequence[object] | str | None,
) -> tuple[list[str], str | None, str | None]:
    if route_extras is None:
        extras: list[str] = []
    elif isinstance(route_extras, str):
        extras = [token for token in route_extras.split() if token]
    else:
        extras = [str(item) for item in route_extras if item]
    if use_scants:
        extras.append("ScanTS")
    if _is_orca_gfn_xtb_method(method):
        # GFN solvent rule (T7): ALPB-only under ORCA, keyed by
        # resolve_implementation via orca_keyword_context — ALPB emits
        # ALPB(<solvent>), none/unset emits nothing, GBSA/CPCM/SMD raise
        # KeywordValueError (PLATFORM POLICY; see orca_gfn_solvent_token
        # for the capability/dependency/policy split). The model is never
        # rewritten and no %cpcm block is reachable for GFN.
        token = orca_gfn_solvent_token(method, solvent, solvent_model)
        if token:
            extras.append(token)
        return extras, None, "none"
    return extras, solvent, solvent_model


def _parse_cartesian_block(
    lines: list[str],
    start_index: int,
) -> tuple[NDArray[np.float64] | None, list[str] | None, int]:
    cursor = start_index + 1
    while cursor < len(lines):
        stripped = lines[cursor].strip()
        if not stripped or set(stripped) <= {"-"}:
            cursor += 1
            continue
        break

    symbols: list[str] = []
    coords: list[list[float]] = []
    while cursor < len(lines):
        stripped = lines[cursor].strip()
        if not stripped or set(stripped) <= {"-"}:
            break
        match = _COORD_LINE_RE.match(lines[cursor])
        if match is None:
            break
        symbols.append(match.group(1))
        coords.append(
            [
                float(match.group(2).replace("D", "E").replace("d", "e")),
                float(match.group(3).replace("D", "E").replace("d", "e")),
                float(match.group(4).replace("D", "E").replace("d", "e")),
            ]
        )
        cursor += 1
    if not coords:
        return None, None, start_index + 1
    return np.asarray(coords, dtype=np.float64), symbols, cursor


def _parse_all_cartesian_blocks(log_text: str) -> list[tuple[NDArray[np.float64], list[str]]]:
    lines = log_text.splitlines()
    blocks: list[tuple[NDArray[np.float64], list[str]]] = []
    cursor = 0
    while cursor < len(lines):
        if _CARTESIAN_COORD_HEADER not in lines[cursor]:
            cursor += 1
            continue
        coords, symbols, next_cursor = _parse_cartesian_block(lines, cursor)
        if coords is not None and symbols is not None:
            blocks.append((coords, symbols))
        cursor = max(next_cursor, cursor + 1)
    return blocks


def _notify_scan_point(
    point_callback: Callable[[object], None] | None,
    point: object,
) -> None:
    """Invoke a relaxed-scan point callback, never raising into the scan loop."""
    if point_callback is None:
        return
    try:
        point_callback(point)
    except Exception as exc:  # noqa: BLE001
        logger.warning("relaxed-scan point_callback failed: %s", exc)


def parse_relaxed_scan_cartesian_blocks(
    log_text: str,
) -> list[tuple[NDArray[np.float64], list[str]]]:
    """Extract the converged geometry of every relaxed-scan step.

    Each step section holds one ``CARTESIAN COORDINATES`` block per geometry
    optimization cycle; the converged geometry is the LAST block before the
    next step banner (or the summary table / end of file for the final step).
    """
    step_matches = list(_SCAN_STEP_RE.finditer(log_text))
    if not step_matches:
        return _parse_all_cartesian_blocks(log_text)
    summary_offset = log_text.lower().find(_SCAN_SUMMARY_MARKER)
    blocks: list[tuple[NDArray[np.float64], list[str]]] = []
    for index, match in enumerate(step_matches):
        if index + 1 < len(step_matches):
            section_end = step_matches[index + 1].start()
        elif summary_offset >= 0:
            section_end = summary_offset
        else:
            section_end = len(log_text)
        section_blocks = _parse_all_cartesian_blocks(log_text[match.end() : section_end])
        if section_blocks:
            blocks.append(section_blocks[-1])
    return blocks


def parse_relaxed_scan_allxyz_frames(
    allxyz_path: Path,
) -> list[tuple[NDArray[np.float64], list[str]]]:
    """Read converged per-step geometries from ORCA's ``*.allxyz`` trajectory."""
    try:
        stacked, symbols = read_xyz_multiframe(allxyz_path)
    except (OSError, ValueError) as exc:
        logger.debug("Could not read %s: %s", allxyz_path, exc)
        return []
    if not symbols or stacked.size == 0:
        return []
    n_atoms = len(symbols)
    n_frames = int(stacked.shape[0] // n_atoms)
    return [
        (np.asarray(stacked[i * n_atoms : (i + 1) * n_atoms], dtype=np.float64), symbols)
        for i in range(n_frames)
    ]


def _parse_relaxed_scan_energy_table(log_text: str, coordinate_count: int = 1) -> list[float]:
    """Parse the relaxed-scan summary table from an ORCA output.

    ORCA emits two sub-tables — ``'Actual Energy'`` followed by ``SCF energy``;
    the SCF variant is all zeros for GFN-xTB methods (no SCF section), so
    degenerate all-zero tables are skipped in favour of the last usable one.
    """
    lines = log_text.splitlines()
    header_indices = [
        index
        for index, line in enumerate(lines)
        if "calculated surface" in line.strip().lower()
        or ("relaxed surface scan" in line.strip().lower() and "step" not in line.strip().lower())
    ]
    if not header_indices:
        return []
    for start in reversed(header_indices):
        energies = _parse_relaxed_scan_energy_rows(lines, start + 1, coordinate_count)
        if energies and any(value != 0.0 for value in energies):
            return energies
    return _parse_relaxed_scan_energy_rows(lines, header_indices[-1] + 1, coordinate_count)


def _parse_relaxed_scan_energy_rows(
    lines: list[str],
    start: int,
    coordinate_count: int,
) -> list[float]:
    energies: list[float] = []
    saw_data = False
    for line in lines[start:]:
        stripped = line.strip()
        if not stripped:
            if saw_data:
                break
            continue
        if set(stripped) <= {"-"}:
            continue
        if stripped[0].isalpha():
            if saw_data:
                break
            continue
        tokens = _NUMERIC_TOKEN_RE.findall(stripped.replace("D", "E").replace("d", "e"))
        if len(tokens) < coordinate_count + 1:
            if saw_data:
                break
            continue
        try:
            numeric_values = [float(token) for token in tokens]
        except ValueError:
            continue
        energies.append(numeric_values[-1])
        saw_data = True
    return energies


def parse_relaxed_scan_energy_ledger(path: Path, coordinate_count: int = 1) -> list[float]:
    """Parse ORCA's ``*.relaxscanact.dat`` energy ledger when present."""
    energies: list[float] = []
    try:
        for raw_line in Path(path).read_text(encoding="utf-8", errors="ignore").splitlines():
            values = raw_line.split()
            if len(values) < coordinate_count + 1:
                continue
            try:
                energies.append(float(values[coordinate_count]))
            except ValueError:
                continue
    except OSError:
        return []
    return energies


def _apply_mode_displacement(
    coordinates: np.ndarray,
    mode_vector: np.ndarray,
    step_size: float,
    sign: str = "plus",
) -> np.ndarray:
    """Displace coordinates along a normalized normal-mode vector.

    Args:
        coordinates: Cartesian coordinates (N, 3).
        mode_vector: Cartesian displacement vector (N, 3).
        step_size: Displacement amplitude in Å.
        sign: ``"plus"`` or ``"minus"``.

    Returns:
        Displaced coordinates.
    """
    coords = np.asarray(coordinates, dtype=float).reshape((-1, 3))
    vector = np.asarray(mode_vector, dtype=float).reshape((-1, 3))
    if coords.shape != vector.shape:
        raise ValueError(
            f"mode_vector shape must match coordinates shape: {vector.shape} vs {coords.shape}"
        )
    norm = float(np.linalg.norm(vector))
    if norm <= 0.0:
        raise ValueError("mode_vector must be non-zero to apply a mode displacement")
    sign_key = str(sign).strip().lower()
    if sign_key not in {"plus", "minus"}:
        raise ValueError(f"mode_displacement_sign must be 'plus' or 'minus', got {sign!r}")
    direction = 1.0 if sign_key == "plus" else -1.0
    return coords + direction * float(step_size) * (vector / norm)


def _copy_irc_hessian(
    hessian_source: Path,
    target_dir: Path,
    input_stem: str,
) -> Path:
    """Stage a Hessian file under the ORCA basename expected by IRC."""
    source = Path(hessian_source)
    if not source.exists():
        raise FileNotFoundError(f"IRC Hessian file not found: {source}")
    staged = target_dir / f"{input_stem}.hess"
    if source.resolve() != staged.resolve():
        shutil.copy2(source, staged)
    return staged


def _discover_sibling_hessian(source_path: Path | None) -> Path | None:
    """Look for a sibling ``.hess`` file next to a geometry source path."""
    if source_path is None:
        return None
    source = Path(source_path)
    parent = source.parent
    exact = parent / f"{source.stem}.hess"
    if exact.exists():
        return exact
    matches = sorted(parent.glob("*.hess"))
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        logger.warning(
            "Multiple sibling Hessian files found next to %s; "
            "skipping automatic IRC Hessian handoff",
            source,
        )
    return None


def _read_endpoint_geometry(
    endpoint_file: Path,
    expected_symbols: list[str],
) -> NDArray[np.float64] | None:
    """Read an IRC endpoint XYZ and validate its atom ordering."""
    try:
        coordinates, parsed_symbols = read_xyz(endpoint_file)
    except OSError as e:
        logger.warning("Failed to read IRC endpoint %s: %s", endpoint_file, e)
        return None

    if len(parsed_symbols) != len(expected_symbols):
        logger.warning(
            "IRC endpoint %s atom count mismatch: %d vs expected %d",
            endpoint_file,
            len(parsed_symbols),
            len(expected_symbols),
        )
        return None
    normalized_expected = [_normalize_nmr_symbol(symbol) for symbol in expected_symbols]
    normalized_parsed = [_normalize_nmr_symbol(symbol) for symbol in parsed_symbols]
    if normalized_parsed != normalized_expected:
        logger.warning(
            "IRC endpoint %s symbols %s do not match expected ordering %s",
            endpoint_file,
            normalized_parsed,
            normalized_expected,
        )
        return None
    return np.asarray(coordinates, dtype=float).reshape((-1, 3))


class ORCAInterface(QCInterfaceBase):
    """
    Interface for ORCA calculations.
    """

    def __init__(
        self,
        config: dict[str, Any],
        method: str = "M062X",
        basis: str = "def2-TZVPP",
        solvent: str = None,
        solvent_model: str = "none",
        **kwargs,
    ):
        """
        Initialize ORCA interface.

        Args:
            config: Configuration dictionary
            method: DFT method
            basis: Basis set
            solvent: Solvent model
            solvent_model: Solvent model type - none, smd, cpcm (default
                none). GFN methods accept only none/ALPB (GBSA/CPCM/SMD
                raise ``KeywordValueError`` — PLATFORM POLICY).
            **kwargs: Additional parameters
        """
        super().__init__(config, **kwargs)

        self.method = method
        self.basis = basis
        self.solvent = solvent
        self.solvent_model = solvent_model

        orca_config = self.executables.get("orca", {})
        self.exe_path = Path(orca_config.get("path", "orca"))
        self.executable = resolve_executable(
            "orca",
            configured_path=orca_config.get("path", "orca"),
        )
        self._orca_ld_library_path = orca_config.get("ld_library_path")
        self._orca_mpi_path = orca_config.get("mpi_path")

        resources = self.resources
        orca_nproc_config = orca_config.get("nproc")
        self.nproc = kwargs.get(
            "nprocs",
            orca_nproc_config if orca_nproc_config is not None else resources.get("nproc", 16),
        )

        from cccp.config import _get_default_config

        default_resources = _get_default_config()["resources"]
        self.mem_str = resources.get("mem", default_resources["mem"])
        self.mem_mb = mem_to_mb(self.mem_str)

        self._maxcore_safety = resources.get(
            "orca_maxcore_safety", default_resources["orca_maxcore_safety"]
        )
        self._maxcore_pin = kwargs.get("maxcore", orca_config.get("maxcore"))
        self.maxcore = resolve_orca_maxcore(
            self.mem_mb,
            self.nproc,
            self._maxcore_safety,
            self._maxcore_pin,
        )

        self.charge = kwargs.get("charge", 0)
        self.multiplicity = kwargs.get("multiplicity", 1)

    def _require_executable(self) -> str:
        if self.executable is None:
            raise SoftwareNotFoundError(
                "ORCA executable not found. Add 'orca' to PATH or configure executables.orca.path."
            )
        return str(self.executable)

    def is_available(self) -> bool:
        return self.executable is not None

    def _memory_input_blocks(
        self, extra_blocks: list | None, nproc: int | None = None
    ) -> tuple[int, list]:
        """Validate raw maxcore overrides and render a single budgeted directive."""
        actual_nproc = self.nproc if nproc is None else nproc
        default_maxcore = resolve_orca_maxcore(
            self.mem_mb, actual_nproc, self._maxcore_safety, self._maxcore_pin
        )
        maxcore = None
        remaining = []
        for block in extra_blocks or []:
            if not isinstance(block, str):
                remaining.append(block)
                continue
            lines = []
            for line in block.splitlines(keepends=True):
                if re.match(r"\s*%maxcore\b", line, re.IGNORECASE):
                    match = re.fullmatch(r"\s*%maxcore\s+(\d+)\s*(?:#.*)?", line, re.IGNORECASE)
                    if match is None:
                        raise ValueError("Raw %maxcore must specify a positive integer in MB")
                    value = resolve_orca_maxcore(self.mem_mb, actual_nproc, maxcore=int(match[1]))
                    if maxcore is not None and value != maxcore:
                        raise ValueError("Conflicting raw %maxcore directives")
                    maxcore = value
                else:
                    lines.append(line)
            if any(line.strip() for line in lines):
                remaining.append("".join(lines))
        if maxcore is not None and self._maxcore_pin is not None and maxcore != self._maxcore_pin:
            logger.warning(
                "Raw %%maxcore %s MB overrides configured maxcore %s MB per process",
                maxcore,
                self._maxcore_pin,
            )
        return default_maxcore if maxcore is None else maxcore, remaining

    def _build_input_blocks(
        self,
        calc_type: str = "opt",
        method: str = None,
        basis: str = None,
        route_extras: list = None,
        geom_maxiter: int = None,
        extra_blocks: list = None,
        recalc_hess: object = None,
        solvent: str = None,
        solvent_model: str = None,
        aux_basis: str = None,
        aux_j_basis: str = None,
        aux_c_basis: str = None,
        symbols: list[str] | None = None,
        geom_extra_lines: list[str] | None = None,
        scf_options: dict | None = None,
        trust_radius: float | None = None,
        initial_hessian: str | None = None,
        opt_level: str | None = None,
        scf_maxiter: int | None = None,
        scf_convergence: str | None = None,
        scf_strategy: str | None = None,
        grid: str | None = None,
        dispersion: str | None = None,
        nproc: int | None = None,
    ) -> tuple[str, Any]:
        """Build ORCA input blocks.

        Input-construction half of the input boundary (F7): a PURE renderer
        — no filesystem or process access.  ``_write_input`` persists the
        rendered text and the xyz body; ``_run_orca`` owns the process call.
        The ``%geom`` body is rendered by the shared translation-layer
        function :func:`cccp.qc.translation.render_opt_geom_lines`.

        Args:
            calc_type: Calculation type
            method: Override method (uses self.method if None)
            basis: Override basis (uses self.basis if None)
            route_extras: Extra route-line keywords appended to the ``!`` line
                (e.g. ``["RIJCOSX", "VeryTightSCF"]``)
            geom_maxiter: Optional MaxIter for the %geom block (opt only)
            extra_blocks: Extra raw input blocks appended after the route
            recalc_hess: Hessian policy for the %geom block (opt only);
                accepts ``"auto"``, ``0``, positive ``N``, or ``None``
                (follow config). See plan §5.1 for full semantics.
            solvent: Override solvent (uses self.solvent if None)
            solvent_model: Override solvent model (uses self.solvent_model if None)
            aux_basis: Legacy auxiliary basis (backward compat, migrated to aux_c_basis)
            aux_j_basis: Auxiliary /J basis for RI-J fitting
            aux_c_basis: Auxiliary /C basis for RI-MP2 correlation
            symbols: Atomic symbols of the molecule. Required when
                ``recalc_hess`` resolves to ``"auto"`` and no explicit
                numeric value is available; ignored otherwise.
            geom_extra_lines: Extra lines appended inside the generated
                ``%geom`` block (after Recalc_Hess / MaxIter, before ``end``).
            scf_options: Structured electronic-state options; the single
                sanctioned source of ``%scf`` spin directives (§9.6). A raw
                ``extra_blocks`` entry starting with ``%scf`` is rejected
                while structured options are present.

        Returns:
            A 2-tuple ``(input_str, resolution)`` where ``input_str`` is
            the rendered ORCA input and ``resolution`` is the resolved
            :class:`HessianResolution` for opt-family calcs (``None`` for
            non-opt routes). The caller is expected to persist the
            resolution alongside the input file.
        """
        _method = method if method is not None else self.method
        _basis = basis if basis is not None else self.basis
        _route_extras = [str(x) for x in route_extras if x] if route_extras else []
        _solvent = solvent if solvent is not None else self.solvent
        _solvent_model = (
            solvent_model if solvent_model is not None else self.solvent_model
        ) or "none"

        _route_extras.extend(scf_route_extras(scf_options))

        blocks = []

        meta = _resolve_method_meta(_method)
        basis_inline = True if meta is None else bool(meta.get("basis_inline", True))

        _extras_upper = {str(x).upper() for x in _route_extras}

        _kw_family, _kw_implementation = orca_keyword_context(_method)

        _scf_constraint = scf_constraint(_method)
        _scf_constraint_active = _scf_constraint is not None and not basis_inline

        # Governed enumerated params go through the single route renderer;
        # site quirks are declared as RouteKeyword flags, not inline token logic.
        builtin = (meta or {}).get("builtin_dispersion")
        _governed_keywords: list[RouteKeyword] = [
            RouteKeyword("opt_level", opt_level),
            RouteKeyword(
                "scf_convergence",
                None if _scf_constraint_active else scf_convergence,
            ),
            # Historical quirk preserved: scf_strategy tokens never joined
            # the dedup set.
            RouteKeyword("scf_strategy", scf_strategy, register=False),
        ]

        if scf_maxiter is not None and scf_maxiter > 0:
            if scf_options is None:
                scf_options = {}
            scf_options.setdefault("maxiter", scf_maxiter)

        # Named grid / dispersion parameters (PES DFT-scan extension): these
        # used to be reachable only through raw route_extras.  Composite 3c
        # and GFN methods are immune — the former strip the token via the
        # builtin-dispersion filter below, the latter have no basis/dispersion
        # layer at all. The `not _gfn_method` guard keeps the lookup itself
        # out of the registry for GFN methods (no warning, no emission).
        _gfn_method = _is_orca_gfn_xtb_method(_method)
        if not _gfn_method:
            _governed_keywords.append(RouteKeyword("grid", grid))
            _meta_ri = (meta or {}).get("ri_support", "user")
            _governed_keywords.append(
                RouteKeyword(
                    "dispersion",
                    dispersion,
                    emit=_meta_ri == "user",
                    suppress_tokens=(
                        frozenset({builtin}) if builtin else frozenset()
                    ),
                )
            )

        # GFN solvent rule (T7): one shared rule for the whole GFN family —
        # ALPB emits ALPB(<solvent>) on the ! line, none/unset emits nothing,
        # GBSA/CPCM/SMD raise KeywordValueError (PLATFORM POLICY; the %cpcm
        # block below is DFT-only and unreachable for GFN).
        _gfn_solvent_token = (
            orca_gfn_solvent_token(_method, _solvent, _solvent_model) if _gfn_method else None
        )

        calc_type_map = {
            "opt": "Opt",
            "freq": "Freq",
            "sp": "SP",
            "nmr": "NMR",
        }
        route = calc_type_map.get(calc_type, calc_type)

        if (
            route == "Freq"
            and _solvent
            and _solvent_model.lower() != "cpcm"
            and _solvent_model.lower() != "none"
        ):
            route = "NumFreq"

        ri_support = (meta or {}).get("ri_support", "user")

        _aux_j = aux_j_basis
        _aux_c = aux_c_basis
        _filtered_extras: list[str] = []

        _aux_basis_pattern = re.compile(r"/([JC])(?=$|[^A-Za-z])")

        if not aux_j_basis and not aux_c_basis and not aux_basis:
            for x in _route_extras:
                xs = str(x)
                m = _aux_basis_pattern.search(xs)
                if m:
                    kind = m.group(1)
                    if kind == "J" and not _aux_j:
                        _aux_j = xs
                    elif kind == "C" and not _aux_c:
                        _aux_c = xs
                    else:
                        _filtered_extras.append(x)
                else:
                    _filtered_extras.append(x)
        else:
            _filtered_extras = list(_route_extras)

        if aux_basis and not _aux_c:
            _aux_c = aux_basis

        if ri_support in ("composite", "automatic"):
            _ri_keywords = {"RI", "RIJCOSX", "RIJK", "NONE"}
            _filtered_extras = [
                x
                for x in _filtered_extras
                if str(x).upper() not in _ri_keywords and not _aux_basis_pattern.search(str(x))
            ]
            _aux_j = None
            if ri_support == "composite":
                _aux_c = None

        if builtin:
            _filtered_extras = [x for x in _filtered_extras if str(x).upper() != builtin.upper()]

        if _gfn_solvent_token:
            _filtered_extras.append(_gfn_solvent_token)

        _scf_slot: str | None = None
        if _scf_constraint_active:
            # Exactly ONE convergence directive per constrained route: an
            # explicit value (governed kwarg first, then a route_extras
            # literal) replaces the method floor; below-floor values are
            # promoted with a warning; every other SCF literal is stripped.
            _scf_literals = [
                str(x).strip()
                for x in _filtered_extras
                if str(x).strip().upper() in _SCF_CONVERGENCE_TOKENS
            ]
            _filtered_extras = [
                x
                for x in _filtered_extras
                if str(x).strip().upper() not in _SCF_CONVERGENCE_TOKENS
            ]
            _floor_token, _ = canonical_token(
                "scf_convergence",
                _scf_constraint["default"],
                implementation=_kw_implementation,
            )
            _explicit_token: str | None = None
            if scf_convergence:
                _explicit_token, _ = canonical_token(
                    "scf_convergence", scf_convergence, implementation=_kw_implementation
                )
            if _explicit_token is None and _scf_literals:
                _explicit_token = _scf_literals[0]
            _explicit_rank = scf_rank(_explicit_token) if _explicit_token else None
            _floor_rank = scf_rank(_floor_token) if _floor_token else None
            if (
                _explicit_token is not None
                and _explicit_rank is not None
                and _floor_rank is not None
                and _explicit_rank < _floor_rank
            ):
                logger.warning(
                    "SCF convergence %s is below %s minimum for %s; using %s",
                    _explicit_token,
                    _scf_constraint["default"],
                    _method,
                    _floor_token,
                )
                _explicit_token = None
            _scf_slot = _explicit_token or _floor_token

        _route_segments: list[str | RouteKeyword] = [
            *_filtered_extras,
            *_governed_keywords,
        ]
        if not basis_inline:
            method_name = _method
            if _method.lower() == "dlpno-ccsd(t)":
                method_name = "DLPNO-CCSD(T)"

            if _scf_slot:
                method_name = f"{method_name} {_scf_slot}"
            blocks.append(
                render_route_line(
                    [method_name, route, *_route_segments],
                    context=(_kw_family, _kw_implementation),
                    seen=_extras_upper,
                )
            )
        else:
            # basis is a governed segment (T6): GFN-family values are
            # stripped with a warning by the renderer; an EMPTY basis keeps
            # its historical spacing slot (the `! B3LYP  Opt` double space).
            _basis_segment: str | RouteKeyword = RouteKeyword("basis", _basis) if _basis else ""
            blocks.append(
                render_route_line(
                    [_method, _basis_segment, route, *_route_segments],
                    context=(_kw_family, _kw_implementation),
                    seen=_extras_upper,
                )
            )

        needs_basis_block = (
            _aux_j
            or _aux_c
            or (
                not basis_inline
                and meta is not None
                and (meta.get("default_aux_j") or meta.get("default_aux_c"))
            )
        )
        if _gfn_method and needs_basis_block:
            # T6: GFN family consumes no auxiliary basis — the whole %basis
            # block is DFT-only and is suppressed; every dropped aux value
            # (explicit params and route_extras-extracted /J //C alike) gets
            # the registry strip warning.
            for _aux_value in (_aux_j, _aux_c):
                if _aux_value:
                    _, _aux_warning = resolve(
                        "aux",
                        str(_aux_value),
                        family=_kw_family,
                        implementation=_kw_implementation,
                    )
                    if _aux_warning:
                        logger.warning("%s", _aux_warning)
            needs_basis_block = False
        if needs_basis_block:
            blocks.append("%basis")
            if not basis_inline:
                effective_basis = _basis or (meta or {}).get("default_basis", "")
                if effective_basis:
                    blocks.append(f'  basis "{effective_basis}"')
            final_aux_j = _aux_j or (meta or {}).get("default_aux_j")
            final_aux_c = _aux_c or (meta or {}).get("default_aux_c")
            for blk in extra_blocks or []:
                if isinstance(blk, dict):
                    if "auxJ" in blk:
                        final_aux_j = blk["auxJ"]
                    if "auxC" in blk:
                        final_aux_c = blk["auxC"]
            if final_aux_j:
                blocks.append(f'  auxJ  "{final_aux_j}"')
            if final_aux_c:
                blocks.append(f'  auxC  "{final_aux_c}"')
            blocks.append("end")

        actual_nproc = self.nproc if nproc is None else nproc
        maxcore, extra_blocks = self._memory_input_blocks(extra_blocks, actual_nproc)
        blocks.append(f"%maxcore {maxcore}")
        blocks.append(f"%pal nprocs {actual_nproc} end")

        # Hessian policy resolution (plan §7.2).
        # ``recalc_hess`` accepts "auto" / 0 / N / None and is resolved
        # through the shared ACP resolver. ``configured`` defaults to
        # "auto" so an unset config still triggers element inference.
        to_cfg = self.config.get("optimization_control") or {}
        configured_recalc = to_cfg.get("recalc_hess", "auto")

        resolution = None
        is_opt_route = route.split()[0] == "Opt"
        if is_opt_route:
            resolution = _resolve_recalc_hess_lazy(
                explicit=recalc_hess,
                configured=configured_recalc,
                symbols=symbols,
            )
            blocks.append("%geom")
            blocks.extend(
                render_opt_geom_lines(
                    initial_hessian=initial_hessian,
                    recalc_hess_interval=resolution.interval,
                    trust_radius=trust_radius,
                    max_cycles=geom_maxiter,
                    extra_lines=geom_extra_lines,
                )
            )
            blocks.append("end")

            if resolution.reason == "auto" and resolution.enabled:
                logger.info(
                    "Auto Hessian recalc enabled: interval=%d, non-light elements=%s",
                    resolution.interval,
                    ",".join(resolution.heavy_elements) or "(none)",
                )

        scf_block = render_scf_block(scf_options)
        if scf_block:
            blocks.append(scf_block)
        moinp_block = render_moinp_block(scf_options)
        if moinp_block:
            blocks.append(moinp_block)
        plots_block = render_spin_density_plots_block(scf_options)
        if plots_block:
            blocks.append(plots_block)

        if extra_blocks:
            for blk in extra_blocks:
                # Skip dict entries — they are structured overrides consumed
                # earlier (e.g. DLPNO %basis block auxJ/auxC overrides via
                # R19). Only stringifiable blocks render as raw input.
                if isinstance(blk, dict):
                    continue
                if blk:
                    raw = str(blk).lstrip()
                    if scf_block and raw.lower().startswith("%scf"):
                        message = (
                            "raw %scf block conflicts with the structured "
                            "electronic-state module (§9.6); use scf_options"
                        )
                        raise ValueError(message)
                    blocks.append(str(blk))

        if not _gfn_method and _solvent and _solvent_model.lower() != "none":
            # DFT-only solvent block; the GFN family never reaches here
            # (ALPB route token emitted above; GBSA/CPCM/SMD raise earlier).
            blocks.append("%cpcm")
            if _solvent_model.lower() == "cpcm":
                blocks.append(f'  SMDsolvent "{orca_smd_solvent(_solvent)}"')
            else:  # smd (default)
                blocks.append("  smd true")
                blocks.append(f'  SMDsolvent "{orca_smd_solvent(_solvent)}"')
            blocks.append("end")

        return "\n".join(blocks), resolution

    def _write_input(
        self,
        input_file: Path,
        coordinates: np.ndarray,
        symbols: list[str],
        calc_type: str = "opt",
        charge: int | None = None,
        multiplicity: int | None = None,
        method: str = None,
        basis: str = None,
        route_extras: list = None,
        geom_maxiter: int = None,
        extra_blocks: list = None,
        recalc_hess: object = None,
        solvent: str = None,
        solvent_model: str = None,
        aux_basis: str = None,
        aux_j_basis: str = None,
        aux_c_basis: str = None,
        geom_extra_lines: list[str] | None = None,
        scf_options: dict | None = None,
        trust_radius: float | None = None,
        initial_hessian: str | None = None,
        opt_level: str | None = None,
        scf_maxiter: int | None = None,
        scf_convergence: str | None = None,
        scf_strategy: str | None = None,
        grid: str | None = None,
        dispersion: str | None = None,
    ):
        """Write ORCA input file.

        Write half of the input boundary (F7): delegates rendering to
        :meth:`_build_input_blocks` and only assembles the xyz body,
        persists the file, and records the Hessian resolution.
        """
        charge = charge if charge is not None else self.charge
        multiplicity = multiplicity if multiplicity is not None else self.multiplicity

        blocks, resolution = self._build_input_blocks(
            calc_type,
            method=method,
            basis=basis,
            route_extras=route_extras,
            geom_maxiter=geom_maxiter,
            extra_blocks=extra_blocks,
            recalc_hess=recalc_hess,
            solvent=solvent,
            solvent_model=solvent_model,
            aux_basis=aux_basis,
            aux_j_basis=aux_j_basis,
            aux_c_basis=aux_c_basis,
            symbols=symbols,
            geom_extra_lines=geom_extra_lines,
            scf_options=scf_options,
            trust_radius=trust_radius,
            initial_hessian=initial_hessian,
            opt_level=opt_level,
            scf_maxiter=scf_maxiter,
            scf_convergence=scf_convergence,
            scf_strategy=scf_strategy,
            grid=grid,
            dispersion=dispersion,
        )

        ensure_dir(input_file.parent)

        with open(input_file, "w", encoding="utf-8") as f:
            f.write(blocks + "\n")
            f.write(f"\n* xyz {charge} {multiplicity}\n")

            for symbol, coord in zip(symbols, coordinates):
                f.write(f"{symbol:2s} {coord[0]:15.10f} {coord[1]:15.10f} {coord[2]:15.10f}\n")

            f.write("*\n")

        # Persist the resolved Hessian policy for reproducibility (plan §7.5).
        # ``auto`` resolves to a molecule-specific interval; recording only
        # the input "auto" would make the actual %geom block unreproducible.
        if resolution is not None:
            configured_recalc = (self.config.get("optimization_control") or {}).get(
                "recalc_hess", "auto"
            )
            _record_hessian_resolution(
                input_file.parent,
                input_file,
                resolution,
                input_value=recalc_hess,
                config_value=configured_recalc,
            )

    def _run_orca(
        self,
        input_file: Path,
        output_file: Path,
        output_callback: Callable[[str], None] | None = None,
    ) -> bool:
        """
        Run ORCA calculation.

        Args:
            input_file: Input file
            output_file: Output file

        Returns:
            True if calculation completed successfully
        """
        ensure_dir(output_file.parent)

        to_cfg = self.config.get("optimization_control") or {}
        to_val = to_cfg.get("timeout") or {}
        timeout = to_val.get("default_seconds", 864000) if isinstance(to_val, dict) else 864000
        executable = self._require_executable()

        def _orca_fatal_marker(text: str) -> bool:
            """Detect fatal ORCA termination that still returned exit code 0."""
            lowered = text.lower()
            return "error termination" in lowered or "aborting the run" in lowered

        try:
            env = orca_runtime_env(
                self._orca_ld_library_path,
                mpi_path=self._orca_mpi_path,
                orca_dir=self.executable.parent if self.executable else None,
            )

            env = dict(os.environ if env is None else env)
            # ORCA's external xTB helper uses OpenMP independently of %pal.
            # Pin library threads so native scans respect the task allocation.
            for thread_key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
                env[thread_key] = str(max(1, self.nproc))
            env["OMP_MAX_ACTIVE_LEVELS"] = "1"
            # Keep the established synchronous path for callers that do not
            # request live parsing (NMR, SP, scan, and older integrations).
            # Optimization primitives opt into the streaming path below by
            # passing ``output_callback``.
            if output_callback is None:
                result = subprocess.run(
                    [executable, str(input_file)],
                    cwd=input_file.parent,
                    capture_output=True,
                    text=True,
                    env=env,
                    timeout=timeout,
                )
                with open(output_file, "w", encoding="utf-8") as handle:
                    handle.write(result.stdout)
                    if result.stderr:
                        handle.write("\nSTDERR:\n")
                        handle.write(result.stderr)
                if result.returncode != 0:
                    return False
                return not _orca_fatal_marker(f"{result.stdout or ''}\n{result.stderr or ''}")

            process = subprocess.Popen(
                [executable, str(input_file)],
                cwd=input_file.parent,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                env=env,
            )

            write_lock = threading.Lock()
            stderr_header_written = False

            def drain(stream: Any, *, is_stderr: bool) -> None:
                nonlocal stderr_header_written
                if stream is None:
                    return
                for line in iter(stream.readline, ""):
                    with write_lock, open(output_file, "a", encoding="utf-8") as handle:
                        if is_stderr and not stderr_header_written:
                            handle.write("\nSTDERR:\n")
                            stderr_header_written = True
                        handle.write(line)
                        handle.flush()
                    if not is_stderr and output_callback is not None:
                        try:
                            output_callback(line)
                        except Exception:
                            # A visualization recorder must never terminate a
                            # production QC process because of malformed output.
                            logger.debug("ORCA output callback failed", exc_info=True)

            # The output file is created before the reader threads start, so a
            # polling API can distinguish "running with no output yet" from a
            # calculation that has not started.
            output_file.write_text("", encoding="utf-8")
            stdout_thread = threading.Thread(
                target=drain,
                args=(process.stdout,),
                kwargs={"is_stderr": False},
                daemon=True,
            )
            stderr_thread = threading.Thread(
                target=drain,
                args=(process.stderr,),
                kwargs={"is_stderr": True},
                daemon=True,
            )
            stdout_thread.start()
            stderr_thread.start()
            try:
                return_code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.kill()
                return_code = process.wait()
                logger.error("ORCA calculation timed out: %s", input_file)
                return False
            finally:
                stdout_thread.join(timeout=2)
                stderr_thread.join(timeout=2)

            if return_code != 0:
                return False
            try:
                captured_text = output_file.read_text(encoding="utf-8", errors="replace")
            except OSError:
                captured_text = ""
            if _orca_fatal_marker(captured_text):
                logger.error("ORCA reported a fatal error despite exit code 0: %s", input_file)
                return False
            return True

        except subprocess.TimeoutExpired:
            logger.error(f"ORCA calculation timed out: {input_file}")
            return False
        except Exception as e:
            logger.error(f"ORCA calculation failed: {e}")
            return False

    def optimize(
        self,
        coordinates: np.ndarray,
        symbols: list[str],
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "optimize",
        method: str = None,
        basis: str = None,
        **kwargs,
    ) -> QCResult:
        """
        Perform geometry optimization.

        Args:
            coordinates: Initial coordinates (N, 3)
            symbols: Element symbols
            charge: Molecular charge
            multiplicity: Spin multiplicity
            output_dir: Output directory
            output_name: Base name for output files
            method: Override method (uses self.method if None)
            basis: Override basis (uses self.basis if None)
            **kwargs: Additional parameters

        Returns:
            QCResult with optimization results
        """
        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"

        _solvent = kwargs.pop("solvent", None)
        _solvent_model = kwargs.pop("solvent_model", None)
        _output_callback = kwargs.pop("output_callback", None)

        _mo_read_path = kwargs.pop("mo_read_path", None)
        if _mo_read_path:
            _scf_opts = kwargs.get("scf_options")
            if _scf_opts is None:
                _scf_opts = {}
                kwargs["scf_options"] = _scf_opts
            _scf_opts.setdefault("mo_read_path", _mo_read_path)

        for _damp_key in ("scf_damp", "scf_damp_fac", "scf_shift", "scf_shift_fac"):
            _damp_val = kwargs.pop(_damp_key, None)
            if _damp_val is not None:
                _scf_opts_key = _damp_key.replace("scf_", "", 1)
                _scf_opts = kwargs.get("scf_options") or {}
                _scf_opts.setdefault(_scf_opts_key, _damp_val)
                kwargs["scf_options"] = _scf_opts

        self._write_input(
            input_file,
            coordinates,
            symbols,
            "opt",
            charge,
            multiplicity,
            method=method,
            basis=basis,
            route_extras=kwargs.get("route_extras"),
            geom_maxiter=kwargs.pop("geom_maxiter", kwargs.pop("max_cycles", None)),
            extra_blocks=kwargs.get("extra_blocks"),
            recalc_hess=kwargs.get("recalc_hess"),
            solvent=_solvent,
            solvent_model=_solvent_model,
            aux_basis=kwargs.get("aux_basis"),
            aux_j_basis=kwargs.get("aux_j_basis"),
            aux_c_basis=kwargs.get("aux_c_basis"),
            scf_options=kwargs.get("scf_options"),
            trust_radius=kwargs.get("trust_radius"),
            initial_hessian=kwargs.get("initial_hessian"),
            opt_level=kwargs.get("opt_level"),
            scf_maxiter=kwargs.get("scf_maxiter"),
            scf_convergence=kwargs.get("scf_convergence"),
            scf_strategy=kwargs.get("scf_strategy"),
        )

        success = (
            self._run_orca(input_file, output_file, output_callback=_output_callback)
            if _output_callback is not None
            else self._run_orca(input_file, output_file)
        )

        if not success:
            failure_class = classify_orca_failure(output_file)
            return QCResult(
                success=False,
                error_message=f"ORCA optimization failed [{failure_class}]",
                output_file=input_file,
                log_file=output_file,
            )

        coords, syms, error = LogParser.extract_last_converged_coords(output_file, "orca")
        energy = LogParser.extract_energy(output_file, "orca")

        if coords is None:
            return QCResult(
                success=False,
                error_message=error or "Could not extract coordinates",
                output_file=input_file,
                log_file=output_file,
            )

        return QCResult(
            success=True,
            energy=energy,
            coordinates=coords,
            symbols=syms or symbols,
            converged=True,
            output_file=input_file,
            log_file=output_file,
            metadata=_with_spin_metadata(None, output_file),
        )

    def constrained_optimize(
        self,
        coordinates: np.ndarray,
        symbols: list[str],
        constraints: Sequence[CoordinateConstraint],
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "constrained_optimize",
        method: str = None,
        basis: str = None,
        **kwargs,
    ) -> QCResult:
        """Perform an ORCA optimization with a ``%geom Constraints`` block."""
        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"

        _solvent = kwargs.pop("solvent", None)
        _solvent_model = kwargs.pop("solvent_model", None)
        geom_extra_lines = [f"  {line}" for line in orca_constraint_block(constraints).splitlines()]

        self._write_input(
            input_file,
            coordinates,
            symbols,
            "opt",
            charge,
            multiplicity,
            method=method,
            basis=basis,
            route_extras=kwargs.get("route_extras"),
            geom_maxiter=kwargs.get("geom_maxiter"),
            extra_blocks=kwargs.get("extra_blocks"),
            recalc_hess=kwargs.get("recalc_hess"),
            solvent=_solvent,
            solvent_model=_solvent_model,
            aux_basis=kwargs.get("aux_basis"),
            aux_j_basis=kwargs.get("aux_j_basis"),
            aux_c_basis=kwargs.get("aux_c_basis"),
            geom_extra_lines=geom_extra_lines,
            scf_options=kwargs.get("scf_options"),
            opt_level=kwargs.get("opt_level"),
            scf_maxiter=kwargs.get("scf_maxiter"),
            scf_convergence=kwargs.get("scf_convergence"),
            grid=kwargs.get("grid"),
            dispersion=kwargs.get("dispersion"),
        )

        try:
            success = self._run_orca(input_file, output_file)
        except SoftwareNotFoundError as exc:
            return QCResult(
                success=False,
                error_message=str(exc),
                output_file=input_file,
                log_file=output_file,
            )

        if not success:
            failure_class = classify_orca_failure(output_file)
            return QCResult(
                success=False,
                error_message=(
                    f"ORCA constrained optimization failed [{failure_class}]"
                ),
                output_file=input_file,
                log_file=output_file,
            )

        coords, syms, error = LogParser.extract_last_converged_coords(output_file, "orca")
        energy = LogParser.extract_energy(output_file, "orca")

        if coords is None:
            failure_class = classify_orca_failure(output_file)
            return QCResult(
                success=False,
                error_message=f"{error or 'Could not extract coordinates'} [{failure_class}]",
                output_file=input_file,
                log_file=output_file,
            )

        return QCResult(
            success=True,
            energy=energy,
            coordinates=coords,
            symbols=syms or symbols,
            converged=True,
            output_file=input_file,
            log_file=output_file,
        )

    def relaxed_scan(
        self,
        coordinates: NDArray[np.float64],
        symbols: list[str],
        scan_coordinate: CoordinateSpec | None = None,
        points: int | None = None,
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "orca_relaxed_scan",
        method: str = "GFN2-xTB",
        basis: str | None = None,
        solvent: str | None = None,
        solvent_model: str | None = None,
        use_scants: bool = True,
        full_scan: bool = True,
        plan: ReactionCoordinatePlan | None = None,
        **kwargs,
    ) -> RelaxedScanResult:
        """Run an ORCA relaxed scan over one local coordinate.

        ``scan_coordinate`` reuses the generic 0-based :class:`CoordinateSpec`
        primitive; ORCA input text follows the relaxed-scan rendering used by
        the RPH reference implementation.
        """
        if points is not None and points < 2:
            raise ValueError("ORCA relaxed_scan requires points >= 2")
        if plan is not None and (len(plan.drive_coordinates()) > 1 or any(c.values for c in plan.coordinates) or plan.fixed_endpoints):
            return self._run_synchronous_relaxed_scan(
                coordinates,
                symbols,
                plan,
                charge=charge,
                multiplicity=multiplicity,
                output_dir=output_dir,
                output_name=output_name,
                method=method,
                basis=basis,
                solvent=solvent,
                solvent_model=solvent_model,
                geom_maxiter=kwargs.pop("geom_maxiter", kwargs.pop("max_cycles", None)),
                recalc_hess=kwargs.pop("recalc_hess", 0),
                route_extras=kwargs.pop("route_extras", None),
                point_callback=kwargs.pop("point_callback", None),
                opt_level=kwargs.pop("opt_level", None),
                scf_convergence=kwargs.pop("scf_convergence", None),
                scf_maxiter=kwargs.pop("scf_maxiter", None),
                grid=kwargs.pop("grid", None),
                dispersion=kwargs.pop("dispersion", None),
                aux_j_basis=kwargs.pop("aux_j_basis", None),
                aux_c_basis=kwargs.pop("aux_c_basis", None),
                retry_count=kwargs.pop("retry_count", 0),
                retry_strategy=kwargs.pop("retry_strategy", "previous_geometry"),
                failure_policy=kwargs.pop("failure_policy", "abort"),
                reuse_previous_geometry=kwargs.pop("reuse_previous_geometry", True),
            )
        if scan_coordinate is None or points is None:
            raise ValueError("ORCA relaxed_scan requires one scan coordinate and points")
        if scan_coordinate.role == "monitor":
            raise ValueError("ORCA relaxed_scan requires a drive/freeze coordinate")

        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_xyz = output_dir / f"{output_name}_start.xyz"
        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"
        write_xyz(
            input_xyz,
            np.asarray(coordinates, dtype=float),
            symbols,
            title="ORCA relaxed scan start",
        )

        eff_method = method or self.method or "GFN2-xTB"
        eff_basis = basis if basis is not None else self.basis
        eff_solvent = solvent if solvent is not None else self.solvent
        eff_solvent_model = (
            solvent_model if solvent_model is not None else self.solvent_model
        )
        recalc_hess = kwargs.pop("recalc_hess", 0)
        geom_maxiter = kwargs.pop("geom_maxiter", kwargs.pop("max_cycles", None))
        if kwargs.pop("point_callback", None) is not None:
            # Native scans are one blocking subprocess (no per-point hook);
            # live data comes from the incremental reader in acp.results.
            logger.debug(
                "point_callback ignored for native ORCA relaxed scan; "
                "live data comes from the incremental scan-artifact reader"
            )
        opt_level = kwargs.pop("opt_level", None)
        scf_convergence = kwargs.pop("scf_convergence", None)
        scf_maxiter = kwargs.pop("scf_maxiter", None)
        grid = kwargs.pop("grid", None)
        dispersion = kwargs.pop("dispersion", None)
        aux_j_basis = kwargs.pop("aux_j_basis", None)
        aux_c_basis = kwargs.pop("aux_c_basis", None)
        _retry_keys = ("retry_count", "retry_strategy", "failure_policy", "reuse_previous_geometry")
        _retry_kwargs = {key: kwargs.pop(key) for key in _retry_keys if key in kwargs}
        if _retry_kwargs:
            logger.warning(
                "Native ORCA relaxed scan is a single subprocess: per-point retry "
                "kwargs %s are accepted but ignored (execution_mode=native_scan)",
                sorted(_retry_kwargs),
            )
        route_extras, input_solvent, input_solvent_model = _orca_scan_route_settings(
            eff_method,
            eff_solvent,
            eff_solvent_model,
            use_scants,
            kwargs.pop("route_extras", None),
        )
        if kwargs:
            logger.warning(
                "Unused ORCA relaxed_scan kwargs for %s: %s",
                output_name,
                sorted(kwargs),
            )

        geom_extra_lines = ["  Scan", _orca_scan_line(scan_coordinate, points), "  end"]
        if use_scants and full_scan:
            geom_extra_lines.append("  FullScan true")

        self._write_input(
            input_file,
            np.asarray(coordinates, dtype=float),
            symbols,
            "opt",
            charge,
            multiplicity,
            method=eff_method,
            basis=eff_basis,
            route_extras=route_extras,
            geom_maxiter=geom_maxiter,
            recalc_hess=recalc_hess,
            solvent=input_solvent,
            solvent_model=input_solvent_model,
            geom_extra_lines=geom_extra_lines,
            opt_level=opt_level,
            scf_convergence=scf_convergence,
            scf_maxiter=scf_maxiter,
            grid=grid,
            dispersion=dispersion,
            aux_j_basis=aux_j_basis,
            aux_c_basis=aux_c_basis,
        )

        try:
            success = self._run_orca(input_file, output_file)
        except SoftwareNotFoundError as exc:
            return RelaxedScanResult(
                points=[],
                input_xyz=input_xyz,
                scan_dir=output_dir,
                success=False,
                message=str(exc),
            )
        if not success:
            maxiter = geom_maxiter if geom_maxiter is not None else "ORCA default"
            return RelaxedScanResult(
                points=[],
                input_xyz=input_xyz,
                scan_dir=output_dir,
                success=False,
                message=(
                    f"ORCA relaxed scan failed (per-point geometry MaxIter={maxiter}); "
                    "if a scan point did not converge, raise --geom-maxiter"
                ),
            )

        output_text = output_file.read_text(encoding="utf-8", errors="replace")
        result_points = self._collect_relaxed_scan_points(
            output_text, output_dir, output_name, scan_coordinate, points
        )

        message = ""
        scan_success = bool(result_points)
        if len(result_points) != points:
            scan_success = False
            message = f"ORCA relaxed scan returned {len(result_points)} frame(s); expected {points}"

        return RelaxedScanResult(
            points=result_points,
            input_xyz=input_xyz,
            scan_dir=output_dir,
            success=scan_success,
            message=message,
        )

    def _run_synchronous_relaxed_scan(
        self,
        coordinates: NDArray[np.float64],
        symbols: list[str],
        plan: ReactionCoordinatePlan,
        *,
        charge: int,
        multiplicity: int,
        output_dir: Path | None,
        output_name: str,
        method: str,
        basis: str | None,
        solvent: str | None,
        solvent_model: str | None,
        geom_maxiter: int | None,
        recalc_hess: object,
        route_extras: list[str] | None,
        point_callback: Callable[[object], None] | None = None,
        opt_level: str | None = None,
        scf_convergence: str | None = None,
        scf_maxiter: int | None = None,
        grid: str | None = None,
        dispersion: str | None = None,
        aux_j_basis: str | None = None,
        aux_c_basis: str | None = None,
        retry_count: int = 0,
        retry_strategy: str = "previous_geometry",
        failure_policy: str = "abort",
        reuse_previous_geometry: bool = True,
    ) -> RelaxedScanResult:
        """Run multiple driven coordinates at one shared progress value.

        ORCA's native ``Scan`` block is intentionally limited to one
        coordinate in this interface.  The generic four-atom double-bond
        selection therefore uses one constrained optimization per frame,
        placing both distance constraints in the same ``%geom`` block.

        ``point_callback`` is invoked with each terminal
        :class:`~cccp.qc.interfaces.xtb_scan.RelaxedScanPoint` (success or
        failure) so callers can publish live scan snapshots; callback
        errors are logged and never abort the scan.

        Retry semantics (per point, at most ``retry_count`` retries):
        ``previous_geometry`` reseeds from the last converged frame,
        ``original_geometry`` reseeds from the scan-start geometry, and
        ``looser_convergence`` retries with the geometry convergence
        keyword relaxed one notch (tight→normal).  Retries never change the
        method/basis/solvent — the calculation level is fixed outside the
        loop.  The legacy driver policies ``retry_previous`` /
        ``retry_original`` act as strategy overrides and abort the scan once
        retries are exhausted; ``mark_failed_continue`` records the frame as
        failed and proceeds to the next point; ``abort`` stops the scan.
        """
        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)
        input_xyz = output_dir / f"{output_name}_start.xyz"
        write_xyz(
            input_xyz,
            np.asarray(coordinates, dtype=float),
            symbols,
            title="ORCA synchronous relaxed scan start",
        )

        drive_coordinates = plan.drive_coordinates()
        if not drive_coordinates:
            raise ValueError("synchronous relaxed scan requires a drive coordinate")
        eff_method = method or self.method or "GFN2-xTB"
        eff_basis = basis if basis is not None else self.basis
        eff_solvent = solvent if solvent is not None else self.solvent
        eff_solvent_model = (
            solvent_model if solvent_model is not None else self.solvent_model
        )
        resolved_route_extras, input_solvent, input_solvent_model = _orca_scan_route_settings(
            eff_method,
            eff_solvent,
            eff_solvent_model,
            False,
            route_extras,
        )

        effective_strategy = retry_strategy
        continue_on_failure = failure_policy == "mark_failed_continue"
        if failure_policy == "retry_original":
            effective_strategy = "original_geometry"
        elif failure_policy == "retry_previous":
            effective_strategy = "previous_geometry"

        start_coordinates = np.asarray(coordinates, dtype=float)
        current_coordinates = start_coordinates
        result_points: list[RelaxedScanPoint] = []
        extra_xtb_blocks = None
        if plan.xtb_scc_max_iterations is not None:
            if not _is_orca_gfn_xtb_method(eff_method) or not 1 <= int(plan.xtb_scc_max_iterations) <= 10000:
                raise ValueError("invalid xTB SCC iteration limit")
            extra_xtb_blocks = [f'%xtb\n XTBINPUTSTRING "--iterations {int(plan.xtb_scc_max_iterations)}"\nend']
        for index in range(plan.points):
            frame_dir = output_dir / f"frame_{index:03d}"
            targets = plan.coordinate_targets(index)
            progress = plan.lambda_values[index] if plan.lambda_values else index / max(plan.points - 1, 1)
            retry_history: list[dict[str, Any]] = []
            active_opt_level = opt_level
            result = None
            for attempt in range(1 + max(0, int(retry_count))):
                if attempt > 0 and effective_strategy == "original_geometry":
                    seed = start_coordinates
                elif reuse_previous_geometry:
                    seed = current_coordinates
                else:
                    seed = start_coordinates
                if plan.reference_geometries:
                    seed = np.asarray(plan.reference_geometries[index], dtype=float)
                if plan.fixed_endpoints and index in (0, plan.points - 1):
                    result = self.single_point(seed, symbols, charge=charge, multiplicity=multiplicity,
                        output_dir=frame_dir, output_name=f"{output_name}_boundary",
                        method=eff_method, basis=eff_basis, solvent=input_solvent, solvent_model=input_solvent_model,
                        extra_blocks=extra_xtb_blocks, route_extras=resolved_route_extras, scf_convergence=scf_convergence,
                        scf_maxiter=scf_maxiter, grid=grid, dispersion=dispersion, aux_j_basis=aux_j_basis, aux_c_basis=aux_c_basis)
                    result.coordinates = seed.copy()
                    break
                result = self.constrained_optimize(
                    seed,
                    symbols,
                    plan.frame_constraints(index),
                    extra_blocks=extra_xtb_blocks,
                    charge=charge,
                    multiplicity=multiplicity,
                    output_dir=frame_dir,
                    output_name=f"{output_name}_try{attempt + 1}",
                    method=eff_method,
                    basis=eff_basis,
                    solvent=input_solvent,
                    solvent_model=input_solvent_model,
                    geom_maxiter=geom_maxiter,
                    recalc_hess=recalc_hess,
                    route_extras=resolved_route_extras,
                    opt_level=active_opt_level,
                    scf_convergence=scf_convergence,
                    scf_maxiter=scf_maxiter,
                    grid=grid,
                    dispersion=dispersion,
                    aux_j_basis=aux_j_basis,
                    aux_c_basis=aux_c_basis,
                )
                if result.success and result.coordinates is not None and result.energy is not None and np.isfinite(result.energy):
                    retry_history.append(
                        {
                            "attempt": attempt + 1,
                            "strategy": "initial" if attempt == 0 else effective_strategy,
                            "opt_level": active_opt_level,
                            "failure_class": None,
                        }
                    )
                    break
                failure_class = (
                    classify_orca_failure(result.log_file)
                    if result is not None and result.log_file
                    else "unknown"
                )
                retry_history.append(
                    {
                        "attempt": attempt + 1,
                        "strategy": "initial" if attempt == 0 else effective_strategy,
                        "opt_level": active_opt_level,
                        "failure_class": failure_class,
                    }
                )
                if effective_strategy == "looser_convergence":
                    active_opt_level = _looser_opt_level(active_opt_level)

            if result is None or not result.success or result.coordinates is None or result.energy is None or not np.isfinite(result.energy):
                retry_history_dicts = [dict(entry) for entry in retry_history]
                result_points.append(
                    RelaxedScanPoint(
                        frame_index=index,
                        progress=progress,
                        coordinates=None,
                        symbols=None,
                        energy_hartree=None,
                        success=False,
                        coordinate_values=targets,
                        metadata={
                            "retry_history": retry_history_dicts,
                            "scf_converged": (
                                False
                                if retry_history
                                and retry_history[-1].get("failure_class") == "scf_failure"
                                else None
                            ),
                        },
                    )
                )
                _notify_scan_point(point_callback, result_points[-1])
                if continue_on_failure:
                    logger.warning(
                        "Synchronous ORCA scan frame %d failed after %d attempt(s) "
                        "(failure_policy=mark_failed_continue)",
                        index,
                        len(retry_history),
                    )
                    continue
                return RelaxedScanResult(
                    points=result_points,
                    input_xyz=input_xyz,
                    scan_dir=output_dir,
                    success=False,
                    message=(
                        f"Synchronous ORCA scan failed at frame {index}: "
                        f"{(result.error_message if result else None) or 'constrained opt failed'}"
                    ),
                )

            current_coordinates = np.asarray(result.coordinates, dtype=float)
            result_points.append(
                RelaxedScanPoint(
                    frame_index=index,
                    progress=progress,
                    coordinates=current_coordinates,
                    symbols=list(result.symbols or symbols),
                    energy_hartree=result.energy,
                    success=True,
                    coordinate_values=targets,
                    metadata={
                        "retry_history": [dict(entry) for entry in retry_history],
                        "scf_converged": True,
                        "frame_role": "fixed_boundary_single_point" if plan.fixed_endpoints and index in (0, plan.points-1) else "constrained_optimization",
                        "reference_guided": bool(plan.reference_geometries),
                    },
                )
            )
            _notify_scan_point(point_callback, result_points[-1])

        return RelaxedScanResult(
            points=result_points,
            input_xyz=input_xyz,
            scan_dir=output_dir,
            success=True,
            message="",
        )

    def parse_relaxed_scan_output(
        self,
        output_file: Path,
        scan_coordinate: CoordinateSpec,
        points: int,
        output_dir: Path = None,
        output_name: str = None,
    ) -> RelaxedScanResult:
        """Re-parse a completed ORCA relaxed-scan run without re-executing it.

        Args:
            output_file: Existing ORCA ``.out`` log from a finished relaxed scan.
            scan_coordinate: The drive coordinate the scan was run with.
            points: Expected number of scan points.
            output_dir: Scan directory (defaults to ``output_file.parent``).
            output_name: Scan basename (defaults to ``output_file.stem``).

        Returns:
            :class:`RelaxedScanResult` rebuilt from the existing artifacts
            (``*.allxyz`` preferred, ``.out`` fallback), including regenerated
            ``scan_frames/frame_NNN.xyz`` files.
        """
        output_file = Path(output_file)
        output_dir = Path(output_dir) if output_dir else output_file.parent
        output_name = output_name if output_name is not None else output_file.stem
        output_text = output_file.read_text(encoding="utf-8", errors="replace")
        result_points = self._collect_relaxed_scan_points(
            output_text, output_dir, output_name, scan_coordinate, points
        )
        message = ""
        scan_success = bool(result_points)
        if len(result_points) != points:
            scan_success = False
            message = (
                f"ORCA relaxed scan output {output_file.name} yielded "
                f"{len(result_points)} frame(s); expected {points}"
            )
        return RelaxedScanResult(
            points=result_points,
            input_xyz=output_dir / f"{output_name}_start.xyz",
            scan_dir=output_dir,
            success=scan_success,
            message=message,
        )

    def _collect_relaxed_scan_points(
        self,
        output_text: str,
        output_dir: Path,
        output_name: str,
        scan_coordinate: CoordinateSpec,
        points: int,
    ) -> list[RelaxedScanPoint]:
        frame_blocks = parse_relaxed_scan_allxyz_frames(output_dir / f"{output_name}.allxyz")
        if len(frame_blocks) != points:
            frame_blocks = parse_relaxed_scan_cartesian_blocks(output_text)
            if len(frame_blocks) > points:
                frame_blocks = frame_blocks[-points:]

        energies = _parse_relaxed_scan_energy_table(output_text, coordinate_count=1)
        if len(energies) < len(frame_blocks):
            ledger_matches = sorted(output_dir.glob(f"{output_name}*.relaxscanact.dat"))
            for ledger_path in ledger_matches:
                ledger_energies = parse_relaxed_scan_energy_ledger(ledger_path, coordinate_count=1)
                if len(ledger_energies) >= len(frame_blocks):
                    energies = ledger_energies
        if len(energies) > len(frame_blocks):
            energies = energies[-len(frame_blocks) :]

        frame_dir = output_dir / "scan_frames"
        ensure_dir(frame_dir)
        result_points: list[RelaxedScanPoint] = []
        start_value = scan_coordinate.start
        end_value = scan_coordinate.end
        assert start_value is not None and end_value is not None
        denominator = max(points - 1, 1)
        for index, (frame_coords, frame_symbols) in enumerate(frame_blocks):
            frame_path = frame_dir / f"frame_{index:03d}.xyz"
            write_xyz(frame_path, frame_coords, frame_symbols, title=f"scan frame {index}")
            progress = index / denominator
            target = float(start_value + progress * (end_value - start_value))
            result_points.append(
                RelaxedScanPoint(
                    frame_index=index,
                    progress=progress,
                    coordinates=frame_coords,
                    symbols=frame_symbols,
                    energy_hartree=energies[index] if index < len(energies) else None,
                    success=True,
                    coordinate_values={scan_coordinate.id: target},
                )
            )
        return result_points

    def single_point(
        self,
        coordinates: np.ndarray,
        symbols: list[str],
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "sp",
        method: str = None,
        basis: str = None,
        **kwargs,
    ) -> QCResult:
        """
        Perform single-point energy calculation.

        Args:
            coordinates: Molecular coordinates (N, 3)
            symbols: Element symbols
            charge: Molecular charge
            multiplicity: Spin multiplicity
            output_dir: Output directory
            output_name: Base name for output files
            method: Override method (uses self.method if None)
            basis: Override basis (uses self.basis if None)
            **kwargs: Additional parameters

        Returns:
            QCResult with single-point energy
        """
        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"

        _solvent = kwargs.pop("solvent", None)
        _solvent_model = kwargs.pop("solvent_model", None)

        _mo_read_path = kwargs.pop("mo_read_path", None)
        if _mo_read_path:
            _scf_opts = kwargs.get("scf_options")
            if _scf_opts is None:
                _scf_opts = {}
                kwargs["scf_options"] = _scf_opts
            _scf_opts.setdefault("mo_read_path", _mo_read_path)

        for _damp_key in ("scf_damp", "scf_damp_fac", "scf_shift", "scf_shift_fac"):
            _damp_val = kwargs.pop(_damp_key, None)
            if _damp_val is not None:
                _scf_opts_key = _damp_key.replace("scf_", "", 1)
                _scf_opts = kwargs.get("scf_options") or {}
                _scf_opts.setdefault(_scf_opts_key, _damp_val)
                kwargs["scf_options"] = _scf_opts

        self._write_input(
            input_file,
            coordinates,
            symbols,
            "sp",
            charge,
            multiplicity,
            method=method,
            basis=basis,
            route_extras=kwargs.get("route_extras"),
            extra_blocks=kwargs.get("extra_blocks"),
            solvent=_solvent,
            solvent_model=_solvent_model,
            aux_basis=kwargs.get("aux_basis"),
            aux_j_basis=kwargs.get("aux_j_basis"),
            aux_c_basis=kwargs.get("aux_c_basis"),
            scf_options=kwargs.get("scf_options"),
            scf_maxiter=kwargs.get("scf_maxiter"),
            scf_convergence=kwargs.get("scf_convergence"),
            scf_strategy=kwargs.get("scf_strategy"),
            grid=kwargs.get("grid"),
            dispersion=kwargs.get("dispersion"),
        )

        success = self._run_orca(input_file, output_file)

        if not success:
            return QCResult(
                success=False,
                error_message="ORCA SP calculation failed",
                output_file=input_file,
                log_file=output_file,
            )

        energy = LogParser.extract_energy(output_file, "orca")

        if energy is None:
            return QCResult(
                success=False,
                error_message="Could not extract energy",
                output_file=input_file,
                log_file=output_file,
            )

        return QCResult(
            success=True,
            energy=energy,
            coordinates=coordinates,
            symbols=symbols,
            converged=True,
            output_file=input_file,
            log_file=output_file,
            metadata=_with_spin_metadata(None, output_file),
        )

    def frequency(
        self,
        coordinates: np.ndarray,
        symbols: list[str],
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "freq",
        method: str = None,
        basis: str = None,
        **kwargs,
    ) -> QCResult:
        """
        Perform frequency calculation.

        Args:
            coordinates: Molecular coordinates (N, 3)
            symbols: Element symbols
            charge: Molecular charge
            multiplicity: Spin multiplicity
            output_dir: Output directory
            output_name: Base name for output files
            method: Override method (uses self.method if None)
            basis: Override basis (uses self.basis if None)
            **kwargs: Additional parameters

        Returns:
            QCResult with frequency results
        """
        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"

        _solvent = kwargs.pop("solvent", None)
        _solvent_model = kwargs.pop("solvent_model", None)

        _mo_read_path = kwargs.pop("mo_read_path", None)
        if _mo_read_path:
            _scf_opts = kwargs.get("scf_options")
            if _scf_opts is None:
                _scf_opts = {}
                kwargs["scf_options"] = _scf_opts
            _scf_opts.setdefault("mo_read_path", _mo_read_path)

        for _damp_key in ("scf_damp", "scf_damp_fac", "scf_shift", "scf_shift_fac"):
            _damp_val = kwargs.pop(_damp_key, None)
            if _damp_val is not None:
                _scf_opts_key = _damp_key.replace("scf_", "", 1)
                _scf_opts = kwargs.get("scf_options") or {}
                _scf_opts.setdefault(_scf_opts_key, _damp_val)
                kwargs["scf_options"] = _scf_opts

        self._write_input(
            input_file,
            coordinates,
            symbols,
            "freq",
            charge,
            multiplicity,
            method=method,
            basis=basis,
            route_extras=kwargs.get("route_extras"),
            extra_blocks=kwargs.get("extra_blocks"),
            solvent=_solvent,
            solvent_model=_solvent_model,
            aux_basis=kwargs.get("aux_basis"),
            aux_j_basis=kwargs.get("aux_j_basis"),
            aux_c_basis=kwargs.get("aux_c_basis"),
            scf_options=kwargs.get("scf_options"),
            scf_maxiter=kwargs.get("scf_maxiter"),
            scf_convergence=kwargs.get("scf_convergence"),
            scf_strategy=kwargs.get("scf_strategy"),
        )

        success = self._run_orca(input_file, output_file)

        if not success:
            return QCResult(
                success=False,
                error_message="ORCA frequency calculation failed",
                output_file=input_file,
                log_file=output_file,
            )

        energy = LogParser.extract_energy(output_file, "orca")
        coords, syms, _ = LogParser.extract_last_converged_coords(output_file, "orca")

        frequencies = _parse_frequencies(output_file)

        return QCResult(
            success=True,
            energy=energy,
            coordinates=coords if coords is not None else coordinates,
            symbols=syms or symbols,
            converged=True,
            output_file=input_file,
            log_file=output_file,
            frequencies=frequencies if frequencies else None,
            has_frequencies=len(frequencies) > 0,
            metadata=_with_spin_metadata(None, output_file),
        )

    def casscf(
        self,
        coordinates: np.ndarray,
        symbols: list[str],
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "casscf",
        method: str = None,
        basis: str = None,
        *,
        active_electrons: int = None,
        active_orbitals: int = None,
        nroots: int = 1,
        state_weights: Sequence[float] = (),
        dynamic_correlation: str = "none",
        orbital_source: str | Path | None = None,
        active_orbital_indices: Sequence[int] = (),
        frozen_core: bool = True,
        max_iterations: int | None = None,
        **kwargs,
    ) -> QCResult:
        """Run a CASSCF (optionally NEVPT2) single-point calculation.

        Args:
            coordinates: Molecular coordinates (N, 3)
            symbols: Element symbols
            charge: Molecular charge
            multiplicity: Target multiplicity (``%casscf mult``)
            output_dir: Output directory
            output_name: Base name for output files
            method: Unused for the route (CASSCF is its own model chemistry);
                accepted for interface symmetry
            basis: Basis set override (uses self.basis if None)
            active_electrons: Number of active-space electrons (``nel``)
            active_orbitals: Number of active-space orbitals (``norb``)
            nroots: Number of roots (state-averaged when > 1)
            state_weights: Optional per-root state-average weights
            dynamic_correlation: ``"none"`` | ``"sc_nevpt2"`` | ``"fic_nevpt2"``
            orbital_source: Existing ``.gbw`` used as initial orbitals (MORead)
            active_orbital_indices: Explicit active orbital indices (recorded
                as provenance; ORCA uses the Moread orbital order)
            frozen_core: Keep core orbitals frozen (ORCA default)
            max_iterations: Optional CI MaxIter override
            **kwargs: ``scf_options`` renders an additional ``%scf`` block

        Returns:
            QCResult with ``metadata["casscf"]`` carrying energies, natural
            occupations and per-root NEVPT2 data (design doc §12.1).
        """
        if active_electrons is None or active_orbitals is None:
            return QCResult(
                success=False,
                error_message="CASSCF requires active_electrons and active_orbitals",
            )
        if active_electrons <= 0 or active_orbitals <= 0:
            return QCResult(
                success=False,
                error_message="CASSCF active space must be positive",
            )

        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"

        _basis = basis if basis is not None else self.basis

        route_keywords = ["CASSCF", "TightSCF"]
        dc = str(dynamic_correlation or "none").lower()
        if dc in ("sc_nevpt2", "nevpt2"):
            route_keywords.append("NEVPT2")
        elif dc == "fic_nevpt2":
            route_keywords.append("FIC-NEVPT2")
        elif dc not in ("", "none"):
            return QCResult(
                success=False,
                error_message=f"unknown dynamic_correlation {dynamic_correlation!r}",
            )
        if not frozen_core:
            route_keywords.append("NoFrozenCore")

        scf_options = kwargs.get("scf_options")
        route_keywords.extend(scf_route_extras(scf_options))
        if orbital_source:
            if "Moread" not in route_keywords:
                route_keywords.append("Moread")

        lines: list[str] = []
        route_parts = (
            [RouteKeyword("basis", _basis)] + route_keywords
            if _basis
            else list(route_keywords)
        )
        lines.append(render_route_line(route_parts))

        lines.append("%casscf")
        lines.append(f"  nel {int(active_electrons)}")
        lines.append(f"  norb {int(active_orbitals)}")
        lines.append(f"  mult {int(multiplicity)}")
        lines.append(f"  nroots {int(nroots)}")
        weights = [float(w) for w in state_weights or ()]
        if weights:
            weight_text = ", ".join(f"{w:g}" for w in weights)
            lines.append(f"  weights[0] = {weight_text}")
        if max_iterations is not None and int(max_iterations) > 0:
            lines.append("  CI")
            lines.append(f"    MaxIter {int(max_iterations)}")
            lines.append("  end")
        lines.append("end")

        scf_block = render_scf_block(scf_options)
        if scf_block:
            lines.append(scf_block)
        if orbital_source:
            lines.append(f'%moinp "{orbital_source}"')

        lines.append(f"%maxcore {self.maxcore}")
        lines.append(f"%pal nprocs {self.nproc} end")

        body = "\n".join(lines) + "\n"
        body += f"\n* xyz {charge} {int(multiplicity)}\n"
        for symbol, coord in zip(symbols, coordinates):
            body += f"{symbol:2s} {coord[0]:15.10f} {coord[1]:15.10f} {coord[2]:15.10f}\n"
        body += "*\n"

        ensure_dir(input_file.parent)
        input_file.write_text(body, encoding="utf-8")

        try:
            success = self._run_orca(input_file, output_file)
        except SoftwareNotFoundError as exc:
            return QCResult(
                success=False,
                error_message=str(exc),
                output_file=input_file,
                log_file=output_file,
            )
        if not success:
            return QCResult(
                success=False,
                error_message="ORCA CASSCF calculation failed",
                output_file=input_file,
                log_file=output_file,
            )

        parsed = parse_casscf_output(output_file)
        energy = None
        nevpt2_roots = parsed.get("nevpt2_roots") or []
        if dc != "none" and nevpt2_roots:
            energy = nevpt2_roots[0].get("correlated_energy_hartree")
        if energy is None:
            energy = parsed.get("casscf_energy")

        if energy is None:
            return QCResult(
                success=False,
                error_message="Could not extract CASSCF energy",
                output_file=input_file,
                log_file=output_file,
            )

        metadata = {
            "casscf": {
                "active_electrons": int(active_electrons),
                "active_orbitals": int(active_orbitals),
                "multiplicity": int(multiplicity),
                "nroots": int(nroots),
                "state_weights": weights,
                "active_orbital_indices": [int(i) for i in active_orbital_indices or ()],
                "orbital_source": str(orbital_source) if orbital_source else None,
                "dynamic_correlation": dc,
                "casscf_energy_hartree": parsed.get("casscf_energy"),
                "nevpt2_correction_hartree": nevpt2_roots[0].get("nevpt2_correction_hartree")
                if nevpt2_roots
                else None,
                "correlated_energy_hartree": nevpt2_roots[0].get("correlated_energy_hartree")
                if nevpt2_roots
                else None,
                "natural_occupations": parsed.get("natural_occupations") or [],
                "nevpt2_roots": nevpt2_roots,
                "casscf_roots": parsed.get("casscf_roots") or [],
                "converged": bool(parsed.get("converged")),
            },
        }
        return QCResult(
            success=True,
            energy=energy,
            coordinates=coordinates,
            symbols=symbols,
            converged=bool(parsed.get("converged")),
            output_file=input_file,
            log_file=output_file,
            metadata=metadata,
        )

    def nmr_shielding(
        self,
        coordinates: np.ndarray,
        symbols: list[str],
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "nmr",
        method: str = None,
        basis: str = None,
        nuclei: list[str] | None = None,
        **kwargs,
    ) -> QCResult:
        """Perform a GIAO NMR shielding calculation via ORCA ``%eprnmr``.

        Uses a dedicated input writer (``_write_nmr_input``) that emits the
        ``%eprnmr`` block for explicit nucleus selection rather than the
        simple ``NMR`` route keyword, giving finer control over which nuclei
        are computed. The default method/basis is ``mPW1PW91/6-311G(d)`` to
        match the Goodman DP4/DP5 error model (DevDoc §8.0); callers that
        override the level must keep the error model consistent.

        Args:
            coordinates: Molecular coordinates (N, 3).
            symbols: Element symbols.
            charge: Molecular charge.
            multiplicity: Spin multiplicity.
            output_dir: Output directory.
            output_name: Base name for output files.
            method: DFT method override (default mPW1PW91 if neither this
                nor ``self.method`` is set).
            basis: Basis set override (default 6-311G(d)).
            nuclei: Target nuclei as element symbols (e.g. ``["C", "H"]``).
                When ``None``, defaults to all distinct elements present in
                the molecule that are NMR-active (1H, 13C, 19F, 31P, 15N).
            **kwargs: ``solvent`` / ``solvent_model`` and other overrides.

        Returns:
            :class:`QCResult` with ``metadata["shieldings"]`` holding the
            parsed shielding dict (0-based atom index → descriptor).
        """
        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"

        solvent = kwargs.pop("solvent", None)
        solvent_model = kwargs.pop("solvent_model", None)

        self._write_nmr_input(
            input_file,
            coordinates,
            symbols,
            charge=charge,
            multiplicity=multiplicity,
            method=method,
            basis=basis,
            solvent=solvent,
            solvent_model=solvent_model,
            nuclei=nuclei,
        )

        success = self._run_orca(input_file, output_file)

        if not success:
            return QCResult(
                success=False,
                error_message="ORCA NMR calculation failed",
                output_file=input_file,
                log_file=output_file,
            )

        energy = LogParser.extract_energy(output_file, "orca")
        shieldings = NmrShieldingParser.parse(output_file, expected_symbols=symbols)

        return QCResult(
            success=True,
            energy=energy,
            coordinates=coordinates,
            symbols=symbols,
            converged=True,
            output_file=input_file,
            log_file=output_file,
            metadata={"shieldings": shieldings},
        )

    def transition_state_opt(
        self,
        coordinates: NDArray[np.float64],
        symbols: list[str],
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "ts_opt",
        method: str = None,
        basis: str = None,
        initial_hessian: str = "calculate",
        recalc_hess: int = 5,
        trust_radius: float = 0.15,
        calculate_frequencies: bool = True,
        **kwargs,
    ) -> TsOptResult:
        """Run OptTS, optionally followed by independent frequency validation.

        By default the input carries an ``! OptTS NumFreq`` route and a ``%geom`` block
        requesting a calculated Hessian / RecalcHess / Trust (initial trust
        radius); the ``NumFreq`` keyword requests the independent numerical
        frequency analysis used to verify the transition state (exactly one
        imaginary mode).

        Args:
            coordinates: Initial TS-guess coordinates (N, 3).
            symbols: Element symbols.
            charge: Molecular charge.
            multiplicity: Spin multiplicity.
            output_dir: Output directory.
            output_name: Base name for output files.
            method: Override method (uses ``self.method`` if None).
            basis: Override basis (uses ``self.basis`` if None).
            initial_hessian: ``"calculate"`` (default) / ``"model"`` / ``"read"``.
                ``"read"`` stages *hess_file* (when supplied) as the ORCA
                ``InHess Read`` source.
            recalc_hess: Recalculate Hessian every N steps (0 disables).
            trust_radius: Initial Trust (trust radius) for the TS optimizer.
            calculate_frequencies: Include NumFreq validation. Calculation plans
                with an explicit FREQ step pass False to avoid a hidden extra run.
            **kwargs: ``solvent`` / ``solvent_model`` / ``grid`` / ``scf`` /
                ``nproc`` / ``ts_mode`` / ``opt_level`` /
                ``geom_maxiter`` / ``max_cycles`` /
                ``mode_displacement`` / ``mode_vector`` /
                ``mode_displacement_sign`` overrides, plus ``hess_file``
                (``Path`` to an ORCA ``.hess`` staged as
                ``<output_name>.hess`` and referenced by ``InHessName``).
                ``ts_mode`` accepts ``True`` (legacy mode-0 rescue) or an
                **optimizer-side mode index** resolved from the staged
                Hessian (``M 0`` = lowest eigenvalue) — a raw
                frequency-output index must go through the tsmode mapping
                first.

        Returns:
            :class:`TsOptResult` with the converged TS geometry, energies and
            imaginary frequencies.
        """
        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"

        _solvent = kwargs.pop("solvent", None)
        _solvent_model = kwargs.pop("solvent_model", None)
        _grid = kwargs.pop("grid", None)
        _scf = kwargs.pop("scf", None)
        _nproc = kwargs.pop("nproc", None)
        _ts_mode = kwargs.pop("ts_mode", False)
        _opt_level = kwargs.pop("opt_level", None)
        _mode_displacement = kwargs.pop("mode_displacement", None)
        _mode_vector = kwargs.pop("mode_vector", None)
        _mode_displacement_sign = kwargs.pop("mode_displacement_sign", "plus")
        _output_callback = kwargs.pop("output_callback", None)
        _hess_file = kwargs.pop("hess_file", None)
        geom_maxiter = kwargs.pop("geom_maxiter", kwargs.pop("max_cycles", None))
        # Use the same electronic-state and SCF rendering as ordinary OPT/FREQ.
        scf_options = dict(kwargs.pop("scf_options", None) or {})
        mo_read_path = kwargs.pop("mo_read_path", None)
        if mo_read_path:
            scf_options.setdefault("mo_read_path", mo_read_path)
        for name in ("scf_damp", "scf_damp_fac", "scf_shift", "scf_shift_fac"):
            value = kwargs.pop(name, None)
            if value is not None:
                option_name = {"scf_damp_fac": "dampfac", "scf_shift_fac": "shiftfac"}.get(name, name.removeprefix("scf_"))
                scf_options.setdefault(option_name, value)
        input_options = {
            name: kwargs.pop(name, None)
            for name in (
                "scf_maxiter", "scf_convergence", "scf_strategy", "route_extras",
                "extra_blocks", "aux_basis", "aux_j_basis", "aux_c_basis", "dispersion",
            )
        }
        # Rescue controls are owned by the calculation primitive, not ORCA.
        kwargs.pop("opt_rescue_policy", None)
        kwargs.pop("opt_max_rescue", None)
        if kwargs:
            logger.warning(
                "Unused ORCA transition_state_opt kwargs for %s: %s",
                output_name,
                sorted(kwargs),
            )

        staged_hessian: Path | None = None
        if _hess_file is not None:
            if initial_hessian == "calculate":
                raise ValueError(
                    "hess_file cannot be combined with initial_hessian='calculate'; "
                    "a read Hessian source must not silently request recomputation"
                )
            staged_hessian = _copy_irc_hessian(Path(_hess_file), output_dir, output_name)
        elif initial_hessian == "read":
            logger.warning(
                "transition_state_opt %s requested initial_hessian='read' without a "
                "hess_file; ORCA will fall back to its default model Hessian",
                output_name,
            )

        eff_method = method or self.method
        eff_basis = basis or self.basis

        input_coordinates = np.asarray(coordinates, dtype=float).reshape((-1, 3))
        if _mode_displacement is not None:
            if _mode_vector is None:
                raise ValueError(
                    "mode_displacement requires a mode_vector kwarg containing "
                    "an (N, 3) normal-mode array"
                )
            input_coordinates = _apply_mode_displacement(
                input_coordinates,
                np.asarray(_mode_vector, dtype=float),
                float(_mode_displacement),
                str(_mode_displacement_sign),
            )

        route_extras = list(input_options.pop("route_extras") or [])
        if _scf:
            route_extras.append(_scf)
        route, _ = self._build_input_blocks(
            "OptTS", method=eff_method, basis=eff_basis,
            route_extras=route_extras, grid=_grid, opt_level=_opt_level,
            solvent=_solvent, solvent_model=_solvent_model,
            scf_options=scf_options or None, symbols=symbols, nproc=_nproc, **input_options,
        )
        if calculate_frequencies:
            first_line, remainder = route.split("\n", 1)
            route = first_line + " NumFreq\n" + remainder
        blocks = "\n".join(
            part
            for part in (
                route,
                ts_geom_block(
                    initial_hessian,
                    recalc_hess,
                    trust_radius,
                    ts_mode=_ts_mode,
                    max_iter=geom_maxiter,
                    hess_file_name=staged_hessian.name if staged_hessian else None,
                ),
                freq_block_for_ts(),
            )
            if part
        )

        with open(input_file, "w", encoding="utf-8") as f:
            f.write(blocks + "\n")
            f.write(f"\n* xyz {charge} {multiplicity}\n")
            for symbol, coord in zip(symbols, input_coordinates):
                f.write(f"{symbol:2s} {coord[0]:15.10f} {coord[1]:15.10f} {coord[2]:15.10f}\n")
            f.write("*\n")

        success = (
            self._run_orca(input_file, output_file, output_callback=_output_callback)
            if _output_callback is not None
            else self._run_orca(input_file, output_file)
        )

        if not success:
            failure_class = classify_orca_failure(output_file)
            return TsOptResult(
                success=False,
                error_message=f"ORCA transition-state optimization failed [{failure_class}]",
                output_file=input_file,
                log_file=output_file,
            )

        output_text = output_file.read_text(encoding="utf-8", errors="replace")
        coords, syms, _ = LogParser.extract_last_converged_coords(output_file, "orca")
        energy = LogParser.extract_energy(output_file, "orca")
        # Initial/recalculated optimization Hessians are not final frequencies.
        frequency_map = parse_ts_frequency_map(output_text) if calculate_frequencies else {}
        frequencies = list(frequency_map.values())
        imaginary = [f for f in frequencies if f < 0.0]
        mode_vectors = parse_ts_mode_vectors(output_text)
        most_negative_mode_index = None
        mode_vector = None
        negative_pairs = [
            (mode_index, freq) for mode_index, freq in frequency_map.items() if freq < 0.0
        ]
        if negative_pairs:
            most_negative_mode_index, _ = min(negative_pairs, key=lambda item: item[1])
            mode_vector = mode_vectors.get(most_negative_mode_index)

        return TsOptResult(
            success=coords is not None,
            energy_hartree=energy,
            coordinates=coords,
            symbols=syms or symbols,
            converged=coords is not None,
            imaginary_frequencies=imaginary,
            all_frequencies=frequencies,
            output_file=input_file,
            log_file=output_file,
            mode_vector=mode_vector,
            metadata=_with_spin_metadata({"frequency_validation": calculate_frequencies}, output_file),
        )

    def irc(
        self,
        coordinates: NDArray[np.float64],
        symbols: list[str],
        charge: int = 0,
        multiplicity: int = 1,
        output_dir: Path = None,
        output_name: str = "irc",
        method: str = None,
        basis: str = None,
        direction: str = "both",
        max_iter: int = 100,
        hess_file: Path | None = None,
        output_callback: Callable[[str], None] | None = None,
        **kwargs,
    ) -> IrcResult:
        """Run an ORCA IRC from a converged transition state.

        Args:
            coordinates: Converged TS coordinates (N, 3).
            symbols: Element symbols.
            charge: Molecular charge.
            multiplicity: Spin multiplicity.
            output_dir: Output directory.
            output_name: Base name for output files.
            method: Override method (uses ``self.method`` if None).
            basis: Override basis (uses ``self.basis`` if None).
            direction: ``"forward"`` / ``"reverse"`` / ``"both"`` (default).
            max_iter: Maximum IRC steps.
            hess_file: Optional Hessian file to stage as ``<output_name>.hess``.
            output_callback: Optional per-line stdout hook for live trajectory
                capture (streams ORCA output while the IRC runs).
            **kwargs: ``solvent`` / ``solvent_model`` /
                ``irc_midpoint_reseed`` / ``geometry_source`` overrides.

        Returns:
            :class:`IrcResult` with endpoint paths and step counts.
        """
        output_dir = Path(output_dir) if output_dir else Path.cwd()
        ensure_dir(output_dir)

        input_file = output_dir / f"{output_name}.inp"
        output_file = output_dir / f"{output_name}.out"

        _solvent = kwargs.pop("solvent", None)
        _solvent_model = kwargs.pop("solvent_model", None)
        _irc_midpoint_reseed = bool(kwargs.pop("irc_midpoint_reseed", False))
        _geometry_source = kwargs.pop("geometry_source", None)
        if kwargs:
            logger.warning("Unused ORCA irc kwargs for %s: %s", output_name, sorted(kwargs))

        eff_method = method or self.method
        eff_basis = basis or self.basis

        staged_hessian = None
        if hess_file is not None:
            staged_hessian = _copy_irc_hessian(Path(hess_file), output_dir, output_name)
        elif not _irc_midpoint_reseed:
            sibling_hessian = _discover_sibling_hessian(
                Path(_geometry_source) if _geometry_source else None
            )
            if sibling_hessian is not None:
                staged_hessian = _copy_irc_hessian(sibling_hessian, output_dir, output_name)
            else:
                logger.warning(
                    "No IRC Hessian supplied for %s; omitting InitHess Read "
                    "from the ORCA %%irc block",
                    output_name,
                )

        route = irc_route(
            eff_method,
            eff_basis or "",
            solvent=_solvent,
            solvent_model=_solvent_model,
        )
        blocks = (
            route
            + "\n"
            + f"%maxcore {self.maxcore}\n%pal nprocs {self.nproc} end\n"
            + irc_block(
                direction,
                max_iter,
                hess_file_name=staged_hessian.name if staged_hessian is not None else None,
                irc_midpoint_reseed=_irc_midpoint_reseed,
            )
        )

        with open(input_file, "w", encoding="utf-8") as f:
            f.write(blocks + "\n")
            f.write(f"\n* xyz {charge} {multiplicity}\n")
            for symbol, coord in zip(symbols, coordinates):
                f.write(f"{symbol:2s} {coord[0]:15.10f} {coord[1]:15.10f} {coord[2]:15.10f}\n")
            f.write("*\n")

        success = self._run_orca(input_file, output_file, output_callback=output_callback)

        if not success:
            return IrcResult(
                success=False,
                error_message="ORCA IRC calculation failed",
                output_file=input_file,
                log_file=output_file,
                trajectory_files=discover_irc_trajectory_files(output_dir, stem=output_name)
                or None,
            )

        output_text = output_file.read_text(encoding="utf-8", errors="replace")
        endpoints = parse_irc_endpoints(output_text, output_dir)
        forward_points = output_text.count("IRC forward direction")
        reverse_points = output_text.count("IRC reverse direction")
        final_geometries: dict[str, np.ndarray] = {}
        for endpoint_direction, endpoint_file in endpoints.items():
            endpoint_coords = _read_endpoint_geometry(endpoint_file, symbols)
            if endpoint_coords is not None:
                final_geometries[endpoint_direction] = endpoint_coords

        if not endpoints and forward_points == 0 and reverse_points == 0:
            return IrcResult(
                success=False,
                error_message=(
                    "ORCA IRC produced no endpoints or path points "
                    "(the run likely aborted before the IRC stage)"
                ),
                output_file=input_file,
                log_file=output_file,
                trajectory_files=discover_irc_trajectory_files(output_dir, stem=output_name)
                or None,
            )

        return IrcResult(
            success=True,
            endpoints=endpoints or None,
            forward_points=forward_points,
            reverse_points=reverse_points,
            output_file=input_file,
            log_file=output_file,
            final_geometries=final_geometries,
            trajectory_files=discover_irc_trajectory_files(output_dir, stem=output_name) or None,
        )

    def _build_nmr_input_lines(
        self,
        symbols: list[str],
        method: str = None,
        basis: str = None,
        solvent: str = None,
        solvent_model: str = None,
        nuclei: list[str] | None = None,
    ) -> list[str]:
        """Construct the NMR input line list — pure render, no I/O (F7).

        Input-construction half of the ``_write_nmr_input`` boundary: GFN+NMR
        policy gate, level defaults, route line, solvent token, ``%eprnmr``
        and resource blocks.  Persistence and the xyz body belong to
        :meth:`_write_nmr_input`.
        """
        # Emission-layer alias only (T16): local import keeps the module
        # top untouched (Amendment L confines orca.py edits to these bodies).
        from cccp.qc.keyword_registry import orca_native_functional

        _method = method if method is not None else self.method
        if not _method:
            _method = "mPW1PW91"
        _gfn_nmr = _is_orca_gfn_xtb_method(_method)

        if _gfn_nmr:
            # T8 [Q9]: GFN+NMR is REJECTED by default. The xTB path produces
            # no artifact: ORCA terminates normally (rc=0) but the shielding
            # parser finds ZERO tensors (T22 case 11), so "ORCA exited 0" is
            # NOT acceptable evidence. The reserved switch
            # ``keyword_registry.GFN_NMR_DEFAULT_ALLOWED`` opens the path only
            # on artifact-level GIAO evidence (T17); opening it is a PLATFORM
            # POLICY decision and a probe verdict never auto-flips it.
            _family = method_family(_method)
            _implementation = resolve_implementation(_method, engine="orca")
            _nmr_decision = calculation_policy(
                "nmr", family=_family, implementation=_implementation
            )
            if not _nmr_decision.allowed:
                # Policy gate runs BEFORE any write — no half-written input.
                raise KeywordValueError(
                    "NMR 仅支持 DFT/复合方法 (NMR is supported for DFT/composite "
                    f"methods only): GFN method {_method!r} has no artifact-level "
                    f"GIAO shielding support. {_nmr_decision.reason}. "
                    f"Policy: {_nmr_decision.policy}"
                )

        _basis = basis if basis is not None else self.basis
        if not _basis and not _gfn_nmr:
            # DFT/composite NMR default level (Goodman DP4/DP5 reference).
            # The GFN family NEVER receives an implicit DFT basis (T8): it
            # consumes no basis, and the renderer would only strip it with a
            # warning. An EXPLICIT GFN basis is still stripped by the
            # renderer (T6).
            _basis = "6-311G(d)"
        _solvent = solvent if solvent is not None else self.solvent
        _solvent_model = (
            solvent_model if solvent_model is not None else self.solvent_model
        )
        if not _gfn_nmr:
            # "cpcm" is a DFT-only NMR default; for the GFN family an unset
            # model stays unset (never gains solvation by default). When the
            # reserved switch is open, GFN solvent routes through ALPB only
            # (:func:`orca_gfn_solvent_token` — never CPCM/SMD).
            _solvent_model = _solvent_model or "cpcm"

        target_elements = self._resolve_nmr_nuclei(nuclei, symbols)

        # T16: ORCA >= 6 rejects the legacy Goodman functional keyword
        # ("UNRECOGNIZED OR DUPLICATED KEYWORD(S) … MPW1PW91") and exposes
        # the same functional as mPW1PW — alias ONLY the emitted
        # simple-input token; the requested level name stays intact
        # everywhere else (METHOD_META, error-model binding, receipts).
        # Not silent: the input carries an alias comment and the NMR
        # workflow records requested+executed (ShieldingSegment).
        _emitted_method = orca_native_functional(_method)
        lines: list[str] = []
        if _emitted_method != _method:
            lines.append(f"# functional alias: requested={_method} executed={_emitted_method}")
        lines.append(
            render_route_line(
                [_emitted_method, RouteKeyword("basis", _basis), "TightSCF"],
                method=_method,
            )
        )
        if _gfn_nmr:
            # GFN solvent rule (T7): ALPB-only under ORCA (PLATFORM POLICY),
            # same shared rule as every other !-line site.
            _gfn_token = orca_gfn_solvent_token(_method, _solvent, _solvent_model)
            if _gfn_token:
                lines.append(render_route_line([_gfn_token]))
        elif _solvent and _solvent_model.lower() != "none":
            solv_name = orca_smd_solvent(_solvent)
            model = _solvent_model.lower()
            model_token = "SMD" if model == "smd" else "CPCM"
            lines.append(render_route_line([f"{model_token}({solv_name})"]))

        if target_elements:
            lines.append("%eprnmr")
            for element in target_elements:
                lines.append(f"  nuclei = all {element} {{shift}}")
            lines.append("end")

        lines.append(f"%maxcore {self.maxcore}")
        lines.append(f"%pal nprocs {self.nproc} end")
        return lines

    def _write_nmr_input(
        self,
        input_file: Path,
        coordinates: np.ndarray,
        symbols: list[str],
        charge: int = 0,
        multiplicity: int = 1,
        method: str = None,
        basis: str = None,
        solvent: str = None,
        solvent_model: str = None,
        nuclei: list[str] | None = None,
    ) -> None:
        """Write an ORCA GIAO NMR input with a ``%eprnmr`` block.

        Write half of the NMR boundary (F7): construction is delegated to
        :meth:`_build_nmr_input_lines`; this method only assembles the xyz
        body and persists the file.

        Defaults to ``mPW1PW91/6-311G(d)`` (Goodman DP4/DP5 reference level)
        when neither the override nor the instance default is set to an NMR
        level.  When the requested functional carries an ORCA-native alias
        (T16: ``mPW1PW91`` → ``mPW1PW``, rejected by ORCA >= 6 otherwise),
        the route line emits the native keyword plus a
        ``# functional alias: requested=… executed=…`` provenance comment —
        the requested level itself is unchanged.
        Solvent is emitted as the standalone ``CPCM(<name>)`` /
        ``SMD(<name>)`` route keyword per the DevDoc §9.2 convention for DFT;
        the GFN family follows the shared ALPB-only rule
        (:func:`cccp.qc.interfaces.route_render.orca_gfn_solvent_token`).
        """
        lines = self._build_nmr_input_lines(
            symbols,
            method=method,
            basis=basis,
            solvent=solvent,
            solvent_model=solvent_model,
            nuclei=nuclei,
        )

        # ORCA >= 6 resolves %eprnmr nuclear selections against the geometry
        # parsed so far and aborts when the block precedes the coordinates
        # ("nuclear properties are requested but no coordinates have been
        # read").  Move the rendered eprnmr block after the xyz body.
        eprnmr_lines: list[str] = []
        if "%eprnmr" in lines:
            start = lines.index("%eprnmr")
            end = start + 1
            while end < len(lines) and lines[end].strip() != "end":
                end += 1
            eprnmr_lines = lines[start : end + 1]
            del lines[start : end + 1]

        body = "\n".join(lines) + "\n"
        body += f"\n* xyz {charge} {multiplicity}\n"
        for symbol, coord in zip(symbols, coordinates):
            body += f"{symbol:2s} {coord[0]:15.10f} {coord[1]:15.10f} {coord[2]:15.10f}\n"
        body += "*\n"
        if eprnmr_lines:
            body += "\n" + "\n".join(eprnmr_lines) + "\n"

        ensure_dir(input_file.parent)
        input_file.write_text(body, encoding="utf-8")

    @staticmethod
    def _resolve_nmr_nuclei(
        nuclei: list[str] | None,
        symbols: list[str],
    ) -> list[str]:
        """Resolve the target NMR-active elements.

        Args:
            nuclei: Explicit element list (e.g. ``["C", "H"]``); when given,
                used as-is (order preserved, de-duplicated).
            symbols: Molecular element symbols (fallback to derive from).

        Returns:
            Distinct NMR-active elements present in the molecule, preserving
            user-given order. Falls back to the molecule's NMR-active
            elements (with a warning) when *nuclei* names elements outside
            the supported set — so ``--nuclei Si`` does not silently produce
            a plain single-point run with no shielding output.
        """
        active = {"H", "C", "N", "F", "P"}
        if nuclei:
            seen: set[str] = set()
            out: list[str] = []
            for n in nuclei:
                sym = _normalize_nmr_symbol(str(n))
                if sym in active and sym not in seen:
                    seen.add(sym)
                    out.append(sym)
            if not out:
                # All requested nuclei are outside the supported set —
                # fall back to the molecule's NMR-active elements rather
                # than emitting a GIAO-less plain SP job (silent data loss).
                logger.warning(
                    "Requested nuclei %s contain no supported NMR-active "
                    "element (H/C/N/F/P); falling back to molecule elements",
                    nuclei,
                )
                return ORCAInterface._resolve_nmr_nuclei(None, symbols)
            return out
        present = []
        for sym in symbols:
            norm = _normalize_nmr_symbol(sym)
            if norm in active and norm not in present:
                present.append(norm)
        return present
