"""
xTB Interface
=============

Interface for xTB semi-empirical calculations.

Author: QCcalc Team
"""

import logging
import os
import subprocess
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

import numpy as np

from cccp.qc.interfaces.base import QCResult
from cccp.qc.interfaces.constraints import CoordinateConstraint, CoordinateSpec, ReactionCoordinatePlan
from cccp.qc.interfaces.xtb_scan import (
    RelaxedScanPoint,
    RelaxedScanResult,
    plan_from_dict,
    xcontrol_constraint_block,
)
from cccp.qc.interfaces.xtb_thermo import XTBThermoResult, _xyz_to_coord, run_xtb_enso
from cccp.software import SoftwareNotFoundError, resolve_executable
from cccp.utils import ensure_dir
from cccp.utils.file_io import read_xyz, write_xyz
from cccp.utils.solvent_map import xtb_method_name, xtb_solvent_args

logger = logging.getLogger(__name__)


def _thread_env(nproc: int) -> Dict[str, str]:
    """Return an environment with xTB/BLAS thread counts pinned to *nproc*.

    LSF/OpenLava job environments inject ``OMP_NUM_THREADS`` set to the
    node's full core count, which overrides xTB's ``-T``/``-P`` flags and
    oversubscribes the node (a 4-core job then spawns 10 threads per xTB
    process).  Pinning the env vars keeps every xTB process within its
    allocated cores.
    """
    env = dict(os.environ)
    env["OMP_NUM_THREADS"] = str(nproc)
    env["MKL_NUM_THREADS"] = str(nproc)
    env["OPENBLAS_NUM_THREADS"] = str(nproc)
    return env


class XTBInterface:
    """
    Interface for xTB calculations.
    """

    def __init__(
        self,
        config: Dict[str, Any],
        gfn_level: int = 2,
        solvent: str = None,
        solvent_model: str = "none",
        **kwargs
    ):
        """
        Initialize xTB interface.

        Args:
            config: Configuration dictionary
            gfn_level: GFN-xTB level (0, 1, or 2)
            solvent: Solvent for xTB solvation
            solvent_model: Solvation model ("none", "alpb", "gbsa")
            **kwargs: Additional parameters
        """
        self.config = config
        executables = config.get('executables', {})

        xtb_config = executables.get('xtb', {})
        self.exe_path = Path(xtb_config.get('path', 'xtb'))
        self.executable = resolve_executable('xtb', configured_path=xtb_config.get('path', 'xtb'))

        self.gfn_level = gfn_level
        self.solvent = solvent
        self.solvent_model = (solvent_model or "none").lower()

        resources = config.get('resources', {})
        raw_nproc = kwargs.get('nproc', resources.get('nproc', 16))
        try:
            self.nproc = max(1, int(raw_nproc))
        except (TypeError, ValueError):
            # Never pass OMP_NUM_THREADS=0/negative/None to the subprocess.
            self.nproc = 1

    def _require_executable(self) -> str:
        if self.executable is None:
            raise SoftwareNotFoundError(
                "xTB executable not found. Add 'xtb' to PATH or configure executables.xtb.path."
            )
        return str(self.executable)

    def is_available(self) -> bool:
        return self.executable is not None

    def _solvent_args(
        self, solvent: Optional[str] = None, gfn_level: Optional[int] = None
    ) -> List[str]:
        """Return xTB solvation flags for the EFFECTIVE solvent/method/model."""
        sol = solvent if solvent is not None else self.solvent
        level = self.gfn_level if gfn_level is None else gfn_level
        return xtb_solvent_args(
            sol,
            method=xtb_method_name(level),
            solvent_model=self.solvent_model,
        )

    def optimize(
        self,
        coordinates: np.ndarray,
        symbols: List[str],
        output_dir: Path,
        charge: int = 0,
        multiplicity: int = 1,
        opt_level: str = "normal",
        **kwargs
    ) -> QCResult:
        """
        Run xTB optimization.

        Args:
            coordinates: Input coordinates
            symbols: Element symbols
            output_dir: Output directory
            charge: Molecular charge
            multiplicity: Spin multiplicity
            opt_level: Optimization level (crude, normal, tight)
            **kwargs: Additional parameters

        Returns:
            QCResult with optimized geometry
        """
        output_dir = Path(output_dir)
        ensure_dir(output_dir)

        input_xyz = output_dir / "xtb_input.xyz"
        output_file = output_dir / "xtbopt.xyz"
        log_file = output_dir / "xtb.log"

        write_xyz(input_xyz, coordinates, symbols, title="xTB input")
        executable = self._require_executable()

        xtb_args = [
            executable,
            str(input_xyz),
            "--opt", opt_level,
            "--gfn", str(self.gfn_level),
            "--charge", str(charge),
            "--uhf", str(multiplicity - 1),
            # xTB <= 6.7.1 rejects -T ("Unknown option"); -P plus the
            # OMP/MKL/OPENBLAS env pins in _thread_env control threading and
            # match the battle-tested path_search launch shape.
            "-P", str(self.nproc),
        ]

        xtb_args.extend(self._solvent_args())

        max_steps = kwargs.get('max_steps')
        if max_steps is not None:
            xcontrol_path = output_dir / ".xcontrol"
            xcontrol_path.write_text(
                f"$opt\n  maxcycle={int(max_steps)}\n$end\n",
                encoding="utf-8",
            )
            xtb_args.extend(["--input", str(xcontrol_path)])

        try:
            result = subprocess.run(
                xtb_args,
                cwd=output_dir,
                capture_output=True,
                text=True,
                timeout=kwargs.get('timeout', None),
                env=_thread_env(self.nproc),
            )

            with open(log_file, 'w', encoding='utf-8') as f:
                f.write(result.stdout)
                if result.stderr:
                    f.write("\nSTDERR:\n")
                    f.write(result.stderr)

            coords, syms = None, None
            energy = None

            if output_file.exists():
                coords, syms = read_xyz(output_file)

            for line in result.stdout.split('\n'):
                if 'TOTAL ENERGY' in line:
                    parts = line.split()
                    try:
                        energy = float(parts[3])
                    except (ValueError, IndexError):
                        pass

            return QCResult(
                success=coords is not None,
                coordinates=coords,
                symbols=syms or symbols,
                energy=energy,
                output_file=output_file,
                log_file=log_file
            )

        except Exception as e:
            logger.error(f"xTB optimization failed: {e}")
            return QCResult(
                success=False,
                error_message=str(e),
                output_file=input_xyz
            )

    def constrained_optimize(
        self,
        coordinates: np.ndarray,
        symbols: List[str],
        output_dir: Path,
        constraints: Sequence[CoordinateConstraint],
        charge: int = 0,
        multiplicity: int = 1,
        opt_level: str = "normal",
        max_steps: Optional[int] = None,
        timeout: Optional[int] = None,
        extra_control_text: str = "",
        **kwargs
    ) -> QCResult:
        """Optimize *coordinates* under internal-coordinate *constraints*.

        Writes the input XYZ plus an xcontrol ``$constrain`` block (1-based
        atom indices, xTB convention) and runs a constrained xTB
        optimization. The optimized geometry is returned as ``xtbopt.xyz``.

        Args:
            coordinates: Input coordinates.
            symbols: Element symbols.
            output_dir: Output directory.
            constraints: Internal-coordinate constraints (drive targets).
            charge: Molecular charge.
            multiplicity: Spin multiplicity.
            opt_level: Optimization level (crude, normal, tight, verytight).
            max_steps: Optional ``$opt maxcycle`` override.
            timeout: Subprocess timeout in seconds.
            extra_control_text: Additional xcontrol blocks (e.g. a ``$fix``
                block with 1-based atom indices) inserted verbatim between
                the constraint block and the ``$opt`` block.
            **kwargs: Additional parameters.

        Returns:
            QCResult with the constrained-optimized geometry.
        """
        output_dir = Path(output_dir)
        ensure_dir(output_dir)

        input_xyz = output_dir / "xtb_input.xyz"
        output_file = output_dir / "xtbopt.xyz"
        log_file = output_dir / "xtb.log"
        xcontrol_path = output_dir / ".xcontrol"

        write_xyz(input_xyz, coordinates, symbols, title="xTB constrained input")
        executable = self._require_executable()

        constraint_text = xcontrol_constraint_block(list(constraints))
        opt_block = f"  maxcycle={int(max_steps)}\n" if max_steps is not None else ""
        xcontrol_path.write_text(
            f"{constraint_text}\n{extra_control_text}\n$opt\n{opt_block}$end\n",
            encoding="utf-8",
        )

        xtb_args = [
            executable,
            str(input_xyz),
            "--opt", opt_level,
            "--gfn", str(self.gfn_level),
            "--charge", str(charge),
            "--uhf", str(multiplicity - 1),
            # xTB <= 6.7.1 rejects -T ("Unknown option"); -P plus the
            # OMP/MKL/OPENBLAS env pins in _thread_env control threading and
            # match the battle-tested path_search launch shape.
            "-P", str(self.nproc),
            "--input", str(xcontrol_path),
        ]
        xtb_args.extend(self._solvent_args())

        try:
            result = subprocess.run(
                xtb_args,
                cwd=output_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=_thread_env(self.nproc),
            )

            with open(log_file, 'w', encoding='utf-8') as f:
                f.write(result.stdout)
                if result.stderr:
                    f.write("\nSTDERR:\n")
                    f.write(result.stderr)

            coords, syms = None, None
            energy = None

            if output_file.exists():
                coords, syms = read_xyz(output_file)

            for line in result.stdout.split('\n'):
                if 'TOTAL ENERGY' in line:
                    parts = line.split()
                    try:
                        energy = float(parts[3])
                    except (ValueError, IndexError):
                        pass

            return QCResult(
                success=coords is not None,
                coordinates=coords,
                symbols=syms or symbols,
                energy=energy,
                output_file=output_file,
                log_file=log_file,
            )

        except Exception as e:
            logger.error(f"xTB constrained optimization failed: {e}")
            return QCResult(
                success=False,
                error_message=str(e),
                output_file=input_xyz,
            )

    def relaxed_scan(
        self,
        coordinates: np.ndarray,
        symbols: List[str],
        output_dir: Path,
        plan: Optional[ReactionCoordinatePlan] = None,
        charge: int = 0,
        multiplicity: int = 1,
        opt_level: str = "normal",
        fail_fast: bool = True,
        max_steps: Optional[int] = None,
        timeout: Optional[int] = None,
        scan_plan: Optional[dict] = None,
        point_callback: Optional[Callable[[RelaxedScanPoint], None]] = None,
        **kwargs
    ) -> RelaxedScanResult:
        """Run a sequential multi-frame relaxed scan along *plan*.

        Each frame constrains the drive coordinates to their synchronous
        target at that frame (``q_i(λ) = q_i,start + λ·(q_i,end − q_i,start)``)
        and optimizes, seeding each frame with the previous frame's optimized
        geometry. Freeze coordinates are pinned at their start value for every
        frame; monitor coordinates are never constrained.

        Args:
            coordinates: Starting geometry (frame 0 input).
            symbols: Element symbols.
            output_dir: Scan directory (per-frame subdirs ``frame_<i>``).
            plan: ReactionCoordinatePlan; when None, *scan_plan* (a JSON-style
                dict) is compiled via :func:`plan_from_dict`.
            charge: Molecular charge.
            multiplicity: Spin multiplicity.
            opt_level: Optimization level for each frame.
            fail_fast: Abort the scan on the first failed frame (default True).
            max_steps: Optional per-frame ``$opt maxcycle``.
            timeout: Per-frame subprocess timeout in seconds.
            scan_plan: JSON-style plan dict (fallback when *plan* is None).
            point_callback: Invoked with each terminal RelaxedScanPoint
                (success or failure) right after it is appended, so callers can
                publish live scan snapshots. Callback errors are logged and
                never abort the scan.
            **kwargs: Additional parameters.

        Returns:
            RelaxedScanResult with per-frame points.
        """
        output_dir = Path(output_dir)
        ensure_dir(output_dir)
        if plan is None:
            if scan_plan is None:
                raise ValueError("relaxed_scan requires a ReactionCoordinatePlan or scan_plan dict")
            plan = plan_from_dict(scan_plan)

        input_xyz = output_dir / "input.xyz"
        write_xyz(input_xyz, coordinates, symbols, title="xTB relaxed scan start")

        points: List[RelaxedScanPoint] = []
        prev_coordinates: Optional[np.ndarray] = coordinates
        all_success = True

        for index in range(plan.points):
            progress = index / (plan.points - 1)
            constraints = plan.frame_constraints(index)
            coordinate_values = plan.coordinate_targets(index)

            frame_dir = output_dir / f"frame_{index:03d}"
            frame_result = self.constrained_optimize(
                prev_coordinates,
                symbols,
                frame_dir,
                constraints,
                charge=charge,
                multiplicity=multiplicity,
                opt_level=opt_level,
                max_steps=max_steps,
                timeout=timeout,
                **kwargs,
            )

            points.append(
                RelaxedScanPoint(
                    frame_index=index,
                    progress=progress,
                    coordinates=frame_result.coordinates,
                    symbols=frame_result.symbols,
                    energy_hartree=frame_result.energy,
                    success=frame_result.success,
                    coordinate_values=coordinate_values,
                )
            )
            if point_callback is not None:
                try:
                    point_callback(points[-1])
                except Exception as exc:  # noqa: BLE001
                    logger.warning("relaxed-scan point_callback failed: %s", exc)

            if frame_result.success and frame_result.coordinates is not None:
                prev_coordinates = frame_result.coordinates
            else:
                all_success = False
                if fail_fast:
                    return RelaxedScanResult(
                        points=points,
                        input_xyz=input_xyz,
                        scan_dir=output_dir,
                        success=False,
                        message=f"frame {index} failed: {frame_result.error_message or 'no geometry'}",
                    )

        return RelaxedScanResult(
            points=points,
            input_xyz=input_xyz,
            scan_dir=output_dir,
            success=all_success,
        )

    def single_point(
        self,
        coordinates: np.ndarray,
        symbols: List[str],
        output_dir: Path,
        charge: int = 0,
        multiplicity: int = 1,
        **kwargs
    ) -> QCResult:
        """
        Run xTB single-point energy calculation.

        Args:
            coordinates: Input coordinates
            symbols: Element symbols
            output_dir: Output directory
            charge: Molecular charge
            multiplicity: Spin multiplicity
            **kwargs: Additional parameters

        Returns:
            QCResult with energy
        """
        output_dir = Path(output_dir)
        ensure_dir(output_dir)

        input_xyz = output_dir / "xtb_sp_input.xyz"
        log_file = output_dir / "xtb_sp.log"

        write_xyz(input_xyz, coordinates, symbols, title="xTB SP input")
        executable = self._require_executable()

        xtb_args = [
            executable,
            str(input_xyz),
            "--sp",
            "--gfn", str(self.gfn_level),
            "--charge", str(charge),
            "--uhf", str(multiplicity - 1),
            # xTB <= 6.7.1 rejects -T ("Unknown option"); -P plus the
            # OMP/MKL/OPENBLAS env pins in _thread_env control threading and
            # match the battle-tested path_search launch shape.
            "-P", str(self.nproc),
        ]

        xtb_args.extend(self._solvent_args())

        try:
            result = subprocess.run(
                xtb_args,
                cwd=output_dir,
                capture_output=True,
                text=True,
                timeout=kwargs.get('timeout', None),
                env=_thread_env(self.nproc),
            )

            with open(log_file, 'w', encoding='utf-8') as f:
                f.write(result.stdout)
                if result.stderr:
                    f.write("\nSTDERR:\n")
                    f.write(result.stderr)

            energy = None
            for line in result.stdout.split('\n'):
                if 'TOTAL ENERGY' in line:
                    parts = line.split()
                    try:
                        energy = float(parts[3])
                    except (ValueError, IndexError):
                        pass

            return QCResult(
                success=energy is not None,
                coordinates=coordinates,
                symbols=symbols,
                energy=energy,
                log_file=log_file
            )

        except Exception as e:
            logger.error(f"xTB SP calculation failed: {e}")
            return QCResult(
                success=False,
                error_message=str(e)
            )

    def enso_thermo(
        self,
        coordinates: np.ndarray,
        symbols: List[str],
        output_dir: Path,
        *,
        gfn_level: int = 2,
        temperature_k: float = 298.15,
        sthr: float = 50.0,
        imagthr: float = -100.0,
        charge: int = 0,
        multiplicity: int = 1,
        solvent: Optional[str] = None,
        timeout: int | None = None,
    ) -> XTBThermoResult:
        """
        Run xTB single-point Hessian + MRRHO (--bhess --enso) calculation.

        Writes the input geometry to XYZ, converts to xTB .coord format,
        then calls run_xtb_enso() which handles the xTB subprocess invocation
        and xtb_enso.json parsing.

        Args:
            coordinates: Atomic coordinates (N, 3) array.
            symbols: Element symbols list.
            output_dir: Output directory (xtb SPH files go in output_dir/xtb_enso/).
            gfn_level: GFN-xTB level (0, 1, 2). Default 2.
            temperature_k: Temperature in Kelvin. Default 298.15.
            sthr: Rotational/vibrational entropy threshold. Default 50.0.
            imagthr: Imaginary frequency threshold. Default -100.0.
            charge: Molecular charge. Default 0.
            multiplicity: Spin multiplicity (determines unpaired electrons).
            solvent: ALPB solvent name. Default None.
            timeout: Subprocess timeout in seconds. Default 600.

        Returns:
            XTBThermoResult with parsed thermochemical data.
        """
        output_dir = Path(output_dir)
        xtb_enso_dir = output_dir / "xtb_enso"
        xtb_enso_dir.mkdir(parents=True, exist_ok=True)

        # Step 1: Write XYZ input
        input_xyz = xtb_enso_dir / "xtb_input.xyz"
        write_xyz(input_xyz, coordinates, symbols, title="xTB SPH input")

        # Step 2: Convert XYZ to xTB .coord format
        coord_file = xtb_enso_dir / "xtb.coord"
        _xyz_to_coord(input_xyz, coord_file)

        # Step 3: Run xTB SPH + MRRHO
        unpaired = multiplicity - 1  # Convert multiplicity to unpaired electrons
        return run_xtb_enso(
            xtb_bin=Path(self._require_executable()),
            coord_file=coord_file,
            output_dir=xtb_enso_dir,
            nproc=self.nproc,
            gfn_level=gfn_level,
            temperature_k=temperature_k,
            sthr=sthr,
            imagthr=imagthr,
            charge=charge,
            unpaired=unpaired,
            solvent=solvent,
            timeout=timeout,
        )
