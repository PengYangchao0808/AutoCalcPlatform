/**
 * ACPJobEditor — 全任务「修改参数后重算」编辑链
 * (docs/archive/2026-10-16/history/ACP_Edit_And_Recalculate_Plan.md §8)。
 *
 * 职责：editorContext 管理、草稿加载（GET /jobs/{id}/edit-draft）、
 * 工作流适配 hydrate/serialize、基线脏状态、差异展示、预览与提交
 * （POST /jobs/{id}/edit-recalculate/preview → /edit-recalculate）。
 *
 * 设计原则（单一工作草稿 / 单一来源状态 / 单一提交入口）：
 * - 数据权威顺序：JobRecord.spec（originalSpec）→ effective_config 快照
 *   （仅展示/解析继承值）→ catalog 默认（仅旧任务缺字段时回退并标注）
 *   → 用户本次修改。
 * - serialize(hydrate(original)) ≡ original：未修改时预览差异必须为零。
 *   方法/资源一律「原值 + 用户实际修改字段的 patch」，绝不整体重建。
 * - 来源状态只有 editorContext.sourceSelection.kind 一个权威；界面只用
 *   任务结构/结构输入/上传三项，原输入、末次结构与其他任务结果投影为
 *   同一 StructureSourceItem 并共用 wizardStructures/previewViewer。
 * - 提交入口只有弹窗底部 #modal-submit 一个；编辑模式下由
 *   handleModalSubmit 分发到 checkAndSubmit。
 * - 共用 Workbench 现有创建表单与参数收集函数（提交请求经 api() 拦截
 *   进入本模块，不复制一套 HTML 表单）。
 * - 异步响应受 requestToken 保护，旧响应不得覆盖当前表单。
 */
(function () {
  "use strict";

  var editorContext = null;
  var tokenCounter = 0;
  var menuEl = null;

  // BatchOptimize 静态角色默认：共享工厂（FE-06，
  // js/workbench/contracts/batch_role_defaults.js，加载序先于本文件）。
  var batchRoleStaticDefaults = window.ACPWorkbench.contracts.batchRoleStaticDefaults;

  function isActive() { return !!editorContext; }
  function isCollecting() { return !!(editorContext && editorContext.collecting); }
  function currentMode() { return editorContext ? editorContext.mode : null; }
  function sourceJobId() { return editorContext ? editorContext.sourceJobId : ""; }

  function selectedWorkflow(ctx) {
    return (typeof wizardState !== "undefined" && wizardState.workflow && wizardState.workflow.id) ||
      (ctx && ctx.originalSpec && ctx.originalSpec.workflow) || "";
  }

  function workflowChanged(ctx) {
    return !!(ctx && ctx.originalSpec && ctx.originalSpec.workflow &&
      selectedWorkflow(ctx) !== ctx.originalSpec.workflow);
  }

  function workflowSelectionError(workflow) {
    var ctx = editorContext;
    return ctx && ctx.executionMode === "in_place" && ctx.originalSpec.workflow &&
      workflow !== ctx.originalSpec.workflow ? t("edit.workflow_locked") : "";
  }

  // ---------------------------------------------------------------------------
  // 纯工具（无 DOM 依赖；经 ACPJobEditorInternals 暴露给回归测试）
  // ---------------------------------------------------------------------------

  function deepCopy(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function deepEqual(a, b) {
    if (a === b) return true;
    if (a === null || b === null || typeof a !== "object" || typeof b !== "object") {
      return false;
    }
    try {
      return JSON.stringify(a) === JSON.stringify(b);
    } catch (e) {
      return false;
    }
  }

  // 「键是否存在」判断 —— 判断字段必须使用它，不能用 ||，否则破坏
  // null / false / 0 / "" 的语义。
  function has(obj, key) {
    return !!obj && typeof obj === "object" &&
      Object.prototype.hasOwnProperty.call(obj, key) && obj[key] !== undefined;
  }

  // 仅复制源对象中存在的键（保留 false/0/""/null）。
  function presenceCopy(src, keys) {
    var out = {};
    (keys || Object.keys(src || {})).forEach(function (k) {
      if (has(src, k)) out[k] = deepCopy(src[k]);
    });
    return out;
  }

  function inputKind(inp) {
    if (!inp || typeof inp !== "object") return "plain";
    if (inp.scan_request && typeof inp.scan_request === "object") return "scan_request";
    var st = String(inp.source_type || "");
    if (st) return st;
    if (inp.source_job_id || inp.from_artifact) return "stage_artifact";
    return "structured";
  }

  function structureSourceToWizard(item) {
    var xyz = String((item && item.xyz_text) || "");
    var available = !!xyz && (!item.geometry_status || item.geometry_status === "available");
    var declaredAtoms = parseInt((xyz.split(/\r?\n/, 1)[0] || "0").trim(), 10) || 0;
    return {
      source_id: item.source_id || "",
      source_uid: item.source_uid || (item.source_ref && item.source_ref.source_uid) || "",
      source_kind: item.source_kind || "original_input",
      item_id: item.item_id || "",
      candidate_id: item.candidate_id || "",
      name: item.name || item.item_id || "structure",
      molecule_name: item.name || item.item_id || "structure",
      tag: item.tag || "",
      xyz: xyz,
      molfile: "",
      has_3d: available,
      charge: has(item, "charge") ? item.charge : 0,
      multiplicity: has(item, "multiplicity") ? item.multiplicity : 1,
      atom_count: item.atom_count || declaredAtoms,
      formula: "",
      warnings: [],
      errors: available ? [] : [item.geometry_error || "该来源没有可用几何"],
      geometry_ref: deepCopy(item.geometry_ref || {}),
      source_ref: deepCopy(item.source_ref || {}),
      geometry_hash: item.geometry_hash || "",
      version_id: item.version_id || "",
      is_default_start: !!item.is_default_start,
    };
  }

  function sourceRequiresIndependentJob(ctx) {
    if (!ctx) return false;
    if (ctx.mode === "new_from_job") return true;
    if (workflowChanged(ctx)) return true;
    var selection = ctx.sourceSelection || {};
    if (ctx.originalSpec.workflow === "nmr" && selection.kind === "original_input" &&
      ctx.baselineFormState && Array.isArray(ctx.baselineFormState.nmr_candidates)) {
      var geometries = function (rows) {
        return rows.map(function (row) { return { item_id: row.item_id, xyz: row.xyz }; });
      };
      if (!deepEqual(geometries(nmrCandidatesProjection()),
        geometries(ctx.baselineFormState.nmr_candidates))) return true;
    }
    var ref = (selection.payload || {}).source_ref || {};
    if (["task_result", "last_structure", "job_result"].indexOf(selection.kind) >= 0 &&
        ref.job_id === ctx.sourceJobId && (selection.payload || {}).xyz) return false;
    return ["last_structure", "job_result", "task_result", "saved_candidate", "path_frame", "manual_input", "upload"].indexOf(
      ctx.sourceSelection && ctx.sourceSelection.kind
    ) >= 0;
  }

  function syncSourceExecutionMode(ctx) {
    if (!ctx) return;
    ctx.sourceRequiresNewJob = sourceRequiresIndependentJob(ctx);
    if (ctx.sourceRequiresNewJob) ctx.executionMode = "new_job";
    renderFooter();
    updateEditorUiState();
  }

  function selectedSourceSummary(ctx) {
    var selection = ctx && ctx.sourceSelection;
    var item = selection && selection.payload;
    if (!item) return t("edit.source_original");
    var ref = item.source_ref || {};
    var jobId = String(ref.job_id || item.job_id || "");
    var path = String(ref.path || "");
    var name = String(item.name || item.label || item.item_id || "");
    if (selection.kind === "path_frame") {
      var origin = item.edit_input_origin || {};
      var frameLabel = t("edit.path_frame", {
        number: String(Number(origin.frame_index) + 1),
      });
      var coordinate = origin.reaction_coordinate;
      return [name, jobId, frameLabel,
        coordinate === null || coordinate === undefined ? "" : Number(coordinate).toFixed(3) + " Å"]
        .filter(Boolean).join(" · ");
    }
    if (jobId) return [name, jobId, path].filter(Boolean).join(" · ");
    if (selection.kind === "last_structure") {
      return name || t("edit.source_last_structure");
    }
    if (selection.kind === "manual_input") return t("edit.source_manual");
    if (selection.kind === "upload") return t("edit.source_upload");
    return name || t("edit.source_original");
  }

  function addSourceIdentityKeys(target, value) {
    if (!value || typeof value !== "object") return;
    var checksum = String(value.content_checksum || value.checksum || value.geometry_hash || "");
    if (checksum.indexOf("unknown:") === 0) checksum = "";
    var sourceId = String(value.source_id || "").trim();
    var jobId = String(value.job_id || value.parent_job_id || "").trim();
    var path = String(value.path || "").trim();
    if (!sourceId && jobId && path) sourceId = "job_" + jobId + ":" + path;
    if (checksum && sourceId) target.add("geometry-source:" + sourceId + ":" + checksum);
    if (checksum && value.source_uid) target.add("geometry:" + value.source_uid + ":" + checksum);
    if (value.source_uid && value.version_id) target.add("version:" + value.source_uid + ":" + value.version_id);
    if (sourceId && !checksum && !value.version_id) target.add("source_id:" + sourceId);
    var frameIndex = value.frame_index;
    if (jobId && frameIndex !== undefined && frameIndex !== null && Number.isFinite(Number(frameIndex))) {
      target.add("source_id:job_" + jobId + ":s2/frame/" + Number(frameIndex));
      target.add("frame:" + jobId + ":" + Number(frameIndex));
    }
  }

  function sourceIdentityKeys(item) {
    var keys = new Set();
    if (!item || typeof item !== "object") return keys;
    addSourceIdentityKeys(keys, item);
    addSourceIdentityKeys(keys, item.source_ref);
    return keys;
  }

  function identityMatches(keys, target) {
    if (!keys || !target) return false;
    var found = false;
    keys.forEach(function (key) { if (target.has(key)) found = true; });
    return found;
  }

  function inputSourceKeys(input) {
    var keys = new Set();
    if (!input || typeof input !== "object") return keys;
    addSourceIdentityKeys(keys, input);
    addSourceIdentityKeys(keys, input.source_ref);
    ["items", "candidates"].forEach(function (field) {
      (Array.isArray(input[field]) ? input[field] : []).forEach(function (item) {
        addSourceIdentityKeys(keys, item);
        addSourceIdentityKeys(keys, item && item.source_ref);
      });
    });
    var scanSource = input.scan_request && input.scan_request.source;
    if (scanSource && typeof scanSource === "object") {
      addSourceIdentityKeys(keys, scanSource);
      addSourceIdentityKeys(keys, scanSource.source_ref);
    }
    return keys;
  }

  function buildRecalcFocus(ctx) {
    var input = (ctx.originalSpec && ctx.originalSpec.input) || {};
    var refs = (ctx.draft && ctx.draft.input_refs) || {};
    var lastResult = new Set();
    var previousSelection = new Set();
    var origin = input.edit_input_origin || {};
    addSourceIdentityKeys(previousSelection, origin);
    addSourceIdentityKeys(previousSelection, origin.source_ref);
    addSourceIdentityKeys(previousSelection, input.source_ref);
    (refs.previous_outputs || []).forEach(function(result) {
      addSourceIdentityKeys(lastResult, result);
      addSourceIdentityKeys(lastResult, result.source_ref);
    });
    ctx.recalcFocus = {
      defaultStart: inputSourceKeys(input),
      lastResult: lastResult,
      previousSelection: previousSelection,
    };
  }

  function getPinnedSources() {
    var ctx = editorContext;
    var inputs = (typeof wizardStructures !== "undefined" ? wizardStructures : []).map(function(e) {
      return Object.assign({}, e, {pin_kind:"input", label:e.name || "本次输入"});
    });
    var outputs = (((ctx && ctx.mode === "edit_recalculate" ? ctx.draft : {}) || {}).input_refs || {}).previous_outputs || [];
    outputs = outputs.map(function(e) {
      return Object.assign({}, e, e.source_ref || {}, {pin_kind:"output", resolved_name:e.label});
    });
    return inputs.concat(outputs);
  }

  function usePreviousOutput(output) {
    var ctx = editorContext;
    if (!ctx || !output.xyz_text || !wizardStructures.length) return;
    var index = wizardSelectedStructureIndex;
    if (output.item_id) {
      var matched = wizardStructures.findIndex(function(e) { return e.item_id === output.item_id; });
      if (matched >= 0) index = matched;
    }
    var current = wizardStructures[index];
    if (!current || !window.confirm("将「" + (current.name || "当前输入") + "」替换为「" + output.label + "」？")) return;
    var replacement = Object.assign({}, current, {
      xyz:output.xyz_text, source_ref:deepCopy(output.source_ref), source_uid:output.source_uid,
      source_id:output.source_ref.source_id, version_id:output.version_id,
      name:output.label, geometry_state:"ready", source_kind:"task_result", input_modified:false
    });
    wizardStructures[index] = replacement;
    ctx.sourceSelection = {kind:"task_result", payload:replacement};
    onTaskStructureChanged(index, replacement);
    selectPreviewStructure(index, true);
    if (typeof _syncPickerSelection === "function") _syncPickerSelection();
  }

  function updateDefaultStartBadge(ctx, structure) {
    var badge = document.getElementById("edit-default-start-badge");
    if (!badge) return;
    var isDefaultStart = !!(structure && structure.is_default_start);
    if (!isDefaultStart && ctx && ctx.recalcFocus && structure) {
      isDefaultStart = identityMatches(sourceIdentityKeys(structure), ctx.recalcFocus.defaultStart);
    }
    var show = !!(ctx && ctx.mode === "edit_recalculate" && isDefaultStart);
    badge.style.display = show ? "inline-flex" : "none";
  }

  function getRecalcSourceAnnotation(item) {
    var ctx = editorContext;
    if (!ctx || ctx.mode !== "edit_recalculate" || !ctx.recalcFocus) return null;
    var keys = sourceIdentityKeys(item);
    var current = typeof wizardStructures !== "undefined" ? wizardStructures : [];
    var isInput = current.some(function(e) { return identityMatches(keys, sourceIdentityKeys(e)); });
    var isFromSourceJob = !!(ctx.sourceJobId && (item.job_id === ctx.sourceJobId || item.job_name === ctx.sourceJobId));
    var isOutput = identityMatches(keys, ctx.recalcFocus.lastResult) || isFromSourceJob;
    var isCandidate = !!(item.candidate_id && item.candidate_id !== "--") || item.source_group === "candidate" ||
      (item.structure_facts && item.structure_facts.source_kind === "manual_frame");
    return {
      input: isInput,
      output: isOutput,
      previous_result: isOutput,
      is_candidate: isCandidate,
      previous: identityMatches(keys, ctx.recalcFocus.defaultStart)
    };
  }

  function onExternalSourcePreview(item) {
    var ctx = editorContext;
    if (!ctx || ctx.mode !== "edit_recalculate") return;
    updateDefaultStartBadge(ctx, item || null);
  }

  function hydrateTaskStructures(ctx, draft) {
    var refs = draft.input_refs || {};
    var items = Array.isArray(refs.structure_items) ? refs.structure_items.slice() : [];
    var originalInput = (ctx.originalSpec && ctx.originalSpec.input) || {};
    var rawRows = Array.isArray(originalInput.items) ? originalInput.items
      : Array.isArray(originalInput.candidates) ? originalInput.candidates
      : [originalInput.scan_request && originalInput.scan_request.source || originalInput];
    items.forEach(function (item, index) {
      if (!item) return;
      item.is_default_start = true;
      var raw = rawRows[index] || {};
      if (!item.source_ref && raw.source_ref) item.source_ref = deepCopy(raw.source_ref);
      item.source_id = item.source_id || raw.source_id ||
        (item.source_ref && item.source_ref.source_id) || "";
      item.source_uid = item.source_uid || raw.source_uid ||
        (item.source_ref && item.source_ref.source_uid) || "";
      item.geometry_hash = item.geometry_hash || raw.geometry_hash ||
        (item.source_ref && item.source_ref.geometry_hash) || "";
      item.version_id = item.version_id || raw.version_id ||
        (item.source_ref && item.source_ref.version_id) || "";
      if (!item.edit_input_origin && items.length === 1 && originalInput.edit_input_origin) {
        item.edit_input_origin = deepCopy(originalInput.edit_input_origin);
      }
    });
    ctx.taskStructureItems = items;
    if (typeof wizardStructures !== "undefined") {
      wizardStructures = items.map(structureSourceToWizard);
      wizardSelectedStructureIndex = 0;
      wizardParseWarnings = [];
      if (typeof renderStructurePreview === "function") {
        renderStructurePreview(wizardStructures, wizardParseWarnings);
      }
    }
    var first = items[0] || null;
    ctx.sourceSelection = {
      kind: first ? (first.source_kind || "original_input") : "original_input",
      payload: first,
    };
    updateDefaultStartBadge(ctx, first);
    syncSourceExecutionMode(ctx);
  }

  // 原地可复用的"简单结构"输入：表单重建等价于原输入。
  function isSimpleStructureInput(inp) {
    var kind = inputKind(inp);
    return kind === "xyz_text" || kind === "smiles" || kind === "plain" ||
      kind === "structure_asset";
  }

  function cleanLevels(stages) {
    var out = {};
    Object.keys(stages || {}).forEach(function (lid) {
      var st = stages[lid];
      if (!st || st._disabled === true) return;
      out[lid] = deepCopy(st);
      delete out[lid]._disabled;
    });
    return out;
  }

  // ---------------------------------------------------------------------------
  // BatchOptimize 纯逻辑：角色默认、旧版扁平字段重建、patch 序列化
  // ---------------------------------------------------------------------------

  // 与 ACP_Workbench_v2.html applyBatchOptimizeMethodFields 的 ROLE_KEYS 对齐。
  var BATCH_ROLE_KEYS = [
    "method", "basis", "sp_method", "sp_basis",
    "dispersion", "aux_j_basis", "aux_c_basis", "ri_approximation",
    "opt_max_iter", "opt_convergence", "opt_trust_radius", "opt_initial_hessian", "opt_recalc_hess",
    "scf_max_iter", "scf_convergence", "scf_strategy", "scf_orbital_inherit",
    "scf_damp", "scf_damp_fac", "scf_shift", "scf_shift_fac",
    "opt_rescue_policy", "opt_max_rescue",
    "temperature", "pressure", "scale_factor"
  ];

  // 静态角色默认改由共享工厂 batchRoleStaticDefaults 提供（IIFE 顶部别名，
  // js/workbench/contracts/batch_role_defaults.js）；这里仅消费。

  // 旧版公共扁平字段 → 角色键（公共：同时落到 int/ts）。
  var BATCH_FLAT_COMMON = {
    optimization_method: "method",
    optimization_basis: "basis",
    single_point_method: "sp_method",
    single_point_basis: "sp_basis",
    temperature: "temperature",
    pressure: "pressure",
    scale_factor: "scale_factor",
    dispersion: "dispersion",
    aux_j_basis: "aux_j_basis",
    aux_c_basis: "aux_c_basis",
    ri_approximation: "ri_approximation",
    scf_orbital_inherit: "scf_orbital_inherit",
  };

  // 旧版顶层 opt_*/scf_* 同样作用于两个角色。
  var BATCH_FLAT_SHARED = {
    opt_max_iter: "opt_max_iter",
    opt_convergence: "opt_convergence",
    opt_trust_radius: "opt_trust_radius",
    opt_initial_hessian: "opt_initial_hessian",
    opt_recalc_hess: "opt_recalc_hess",
    scf_max_iter: "scf_max_iter",
    scf_convergence: "scf_convergence",
    scf_strategy: "scf_strategy",
    opt_rescue_policy: "opt_rescue_policy",
    opt_max_rescue: "opt_max_rescue",
  };

  // 旧版角色前缀扁平字段。
  var BATCH_FLAT_ROLE = {
    int: {
      minimum_opt_max_iter: "opt_max_iter",
      minimum_opt_convergence: "opt_convergence",
      minimum_opt_trust_radius: "opt_trust_radius",
      minimum_opt_initial_hessian: "opt_initial_hessian",
      minimum_opt_recalc_hess: "opt_recalc_hess",
      minimum_scf_max_iter: "scf_max_iter",
      minimum_scf_convergence: "scf_convergence",
      minimum_scf_strategy: "scf_strategy",
      minimum_opt_rescue_policy: "opt_rescue_policy",
      minimum_opt_max_rescue: "opt_max_rescue",
    },
    ts: {
      transition_state_opt_max_iter: "opt_max_iter",
      transition_state_opt_convergence: "opt_convergence",
      transition_state_opt_trust_radius: "opt_trust_radius",
      transition_state_opt_initial_hessian: "opt_initial_hessian",
      transition_state_opt_recalc_hess: "opt_recalc_hess",
      transition_state_scf_max_iter: "scf_max_iter",
      transition_state_scf_convergence: "scf_convergence",
      transition_state_scf_strategy: "scf_strategy",
      transition_state_opt_rescue_policy: "opt_rescue_policy",
      transition_state_opt_max_rescue: "opt_max_rescue",
    },
  };

  /**
   * 合并优先级：profile/静态默认 → 旧版公共扁平字段（含角色前缀）→
   * method.batch_roles.int/ts（键存在才覆盖）。全部使用存在性判断。
   */
  function mergeBatchRoles(method, staticDefaults) {
    var m = method || {};
    var defaults = staticDefaults || batchRoleStaticDefaults();
    var roles = { int: deepCopy(defaults.int), ts: deepCopy(defaults.ts) };
    Object.keys(BATCH_FLAT_COMMON).forEach(function (flat) {
      if (!has(m, flat)) return;
      roles.int[BATCH_FLAT_COMMON[flat]] = deepCopy(m[flat]);
      roles.ts[BATCH_FLAT_COMMON[flat]] = deepCopy(m[flat]);
    });
    Object.keys(BATCH_FLAT_SHARED).forEach(function (flat) {
      if (!has(m, flat)) return;
      roles.int[BATCH_FLAT_SHARED[flat]] = deepCopy(m[flat]);
      roles.ts[BATCH_FLAT_SHARED[flat]] = deepCopy(m[flat]);
    });
    ["int", "ts"].forEach(function (role) {
      var map = BATCH_FLAT_ROLE[role];
      Object.keys(map).forEach(function (flat) {
        if (has(m, flat)) roles[role][map[flat]] = deepCopy(m[flat]);
      });
    });
    var br = m.batch_roles;
    if (br && typeof br === "object") {
      ["int", "ts"].forEach(function (role) {
        var src = br[role];
        if (!src || typeof src !== "object") return;
        if (!roles[role]) roles[role] = {};
        BATCH_ROLE_KEYS.forEach(function (k) {
          if (has(src, k)) roles[role][k] = deepCopy(src[k]);
        });
      });
    }
    return roles;
  }

  /**
   * BatchOptimize 方法 patch 序列化：原 method + 用户实际修改的字段。
   * unmodified（current ≡ baseline）时由调用方直接返回原 method 副本。
   */
  function buildBatchMethodFromPatch(originalMethod, baselineRoles, currentRoles,
    baselineProfileId, currentProfileId, staticDefaults) {
    var m = deepCopy(originalMethod || {});
    if (currentProfileId && currentProfileId !== baselineProfileId) {
      m.profile_id = currentProfileId;
      m.profile = currentProfileId;
    }
    var origRoles = (m.batch_roles && typeof m.batch_roles === "object" &&
      (m.batch_roles.int || m.batch_roles.ts))
      ? m.batch_roles
      : mergeBatchRoles(m, staticDefaults);
    var patched = deepCopy(origRoles);
    patched.int = patched.int || {};
    patched.ts = patched.ts || {};
    var intFlatPatched = {};
    ["int", "ts"].forEach(function (role) {
      var cur = (currentRoles || {})[role] || {};
      var base = (baselineRoles || {})[role] || {};
      BATCH_ROLE_KEYS.forEach(function (k) {
        if (!deepEqual(cur[k], base[k])) {
          patched[role][k] = has(cur, k) ? deepCopy(cur[k]) : null;
          if (role === "int") intFlatPatched[k] = true;
        }
      });
    });
    m.batch_roles = patched;
    // 旧版消费者兼容字段：仅当对应 INT 角色键被修改时同步。
    if (intFlatPatched.method) m.optimization_method = patched.int.method;
    if (intFlatPatched.basis) m.optimization_basis = patched.int.basis;
    if (intFlatPatched.sp_method) m.single_point_method = patched.int.sp_method;
    if (intFlatPatched.sp_basis) m.single_point_basis = patched.int.sp_basis;
    return m;
  }

  // ---------------------------------------------------------------------------
  // 工作流适配器：hydrateMethod / hydrateInput / methodProjection /
  // buildMethod / patchOriginalInput / preCollect / describe
  // ---------------------------------------------------------------------------

  function methodProfileById(profileId) {
    if (!profileId || profileId === "__custom__") return null;
    if (typeof getMethodProfileById === "function") return getMethodProfileById(profileId);
    return null;
  }

  // 通用 method 回填：profile_id（存在性判断）+ levels（原值优先，缺省回退
  // 到 catalog 中该 profile 的 levels；再缺失才保留当前默认并标注）。
  function hydrateMethodBase(ctx, draft) {
    var spec = draft.editable_spec || {};
    var m = draft.method_projection || spec.method || {};
    if (has(m, "profile_id")) wizardState.method.profile_id = m.profile_id;
    else if (has(m, "profile")) wizardState.method.profile_id = m.profile;
    var lv = m.levels;
    if (lv && typeof lv === "object" && Object.keys(lv).length) {
      wizardState.method.stages = deepCopy(lv);
    } else {
      var prof = methodProfileById(wizardState.method.profile_id);
      if (prof && prof.levels && Object.keys(prof.levels).length) {
        wizardState.method.stages = deepCopy(prof.levels);
      } else {
        ctx.methodBackfilled = true;
      }
    }
  }

  function baseMethodProjection() {
    return {
      profile_id: wizardState.method.profile_id || "",
      stages: cleanLevels(wizardState.method.stages),
    };
  }

  // 通用 buildMethod：原 method + levels/profile patch。
  function baseBuildMethod(ctx, body, current) {
    var m = deepCopy(ctx.originalSpec.method || {});
    if (current.profile_id && current.profile_id !== ctx.methodBaseline.profile_id) {
      m.profile_id = current.profile_id;
      m.levels = deepCopy(wizardState.method.stages || {});
      Object.keys(m.levels).forEach(function (id) {
        if (!m.levels[id]._disabled) m.levels[id]._disabled = false;
      });
      return m;
    }
    var before = ctx.methodBaseline.stages || {};
    var stages = wizardState.method.stages || {};
    m.levels = m.levels || {};
    Object.keys(m.levels).forEach(function (id) {
      Object.keys(m.levels[id] || {}).forEach(function (key) {
        if (has(before[id], key)) m.levels[id][key] = deepCopy(before[id][key]);
      });
    });
    Object.keys(Object.assign({}, before, current.stages || {})).forEach(function (id) {
      var oldLevel = before[id];
      var level = stages[id];
      if (deepEqual(oldLevel, (current.stages || {})[id])) return;
      if (!level || level._disabled) {
        m.levels[id] = Object.assign({}, m.levels[id] || {}, { _disabled: true });
      } else if (!oldLevel) {
        m.levels[id] = Object.assign({}, deepCopy(level), { _disabled: false });
      } else {
        var target = m.levels[id] || (m.levels[id] = { engine: level.engine });
        Object.keys(Object.assign({}, oldLevel, level)).forEach(function (key) {
          if (!deepEqual(oldLevel[key], level[key])) {
            target[key] = has(level, key) ? deepCopy(level[key]) : null;
          }
        });
      }
    });
    return m;
  }

  function makeBaseAdapter() {
    return {
      hydrateMethod: function (ctx, draft) { hydrateMethodBase(ctx, draft); },
      hydrateInput: function (ctx, draft) { hydrateSimpleInput(draft); },
      methodProjection: baseMethodProjection,
      buildMethod: baseBuildMethod,
      patchOriginalInput: patchOriginalChargeMult,
      preCollect: null,
      describe: function (ctx) { return inputKind((ctx.originalSpec || {}).input || {}); },
    };
  }

  var batchOptimizeAdapter = {
    hydrateMethod: function (ctx, draft) {
      var spec = draft.editable_spec || {};
      var m = spec.method || {};
      hydrateMethodBase(ctx, draft);
      // batch_roles：默认 → 旧扁平 → 原 batch_roles（存在性合并）。
      var staticDefaults = batchRoleStaticDefaults();
      wizardState.method.stages.batch_roles = mergeBatchRoles(m, staticDefaults);
    },
    hydrateInput: function (ctx, draft) {
      // 完整批量结构清单（顺序、名称、INT/TS 标签、电子态）进入批量面板；
      // 不把第一项 XYZ 塞进结构文本框。
      var spec = draft.editable_spec || {};
      var inp = spec.input || {};
      var items = Array.isArray(inp.items) ? inp.items : [];
      if (typeof batchPreviewItems !== "undefined") {
        batchPreviewItems = items.map(function (item, i) {
          return {
            key: "edit_" + i + "_" + Math.random().toString(36).slice(2, 8),
            itemId: String(item.item_id || item.candidate_id ||
              ("item_" + String(i + 1).padStart(3, "0"))),
            include: item.include !== false,
            name: item.name || item.candidate_id || "structure",
            tag: item.tag || "",
            tagAuto: !item.tag,
            xyz: item.xyz || "",
            charge: has(item, "charge") ? item.charge : 0,
            multiplicity: has(item, "multiplicity") ? item.multiplicity : 1,
            atomCount: 0,
            formula: "",
            sourceType: "upload",
            sourceRef: "",
          };
        });
        if (typeof renderStageBatchPreview === "function") renderStageBatchPreview();
      }
    },
    methodProjection: function () {
      return {
        profile_id: wizardState.method.profile_id || "",
        batch_roles: deepCopy((wizardState.method.stages || {}).batch_roles || {}),
        electronic_state: deepCopy(((wizardState.method.stages || {}).batch || {}).electronic_state),
      };
    },
    buildMethod: function (ctx, body, current) {
      var staticDefaults = batchRoleStaticDefaults();
      var method = buildBatchMethodFromPatch(
        ctx.originalSpec.method || {},
        (ctx.methodBaseline || {}).batch_roles || {},
        current.batch_roles || {},
        (ctx.methodBaseline || {}).profile_id || "",
        current.profile_id || "",
        staticDefaults
      );
      if (!deepEqual(current.electronic_state, (ctx.methodBaseline || {}).electronic_state)) {
        method.levels = method.levels || {};
        method.levels.batch = method.levels.batch || {};
        method.levels.batch.electronic_state = current.electronic_state || null;
      }
      return method;
    },
    patchOriginalInput: function (ctx, overlay, body) {
      // 批量条目：include/名称/标签/电子态以批量面板当前值为准（仅 patch
      // 与基线不同的条目；未改动条目逐字保留）。
      var cur = (typeof batchPreviewItems !== "undefined") ? batchPreviewItems : [];
      var base = ctx.baselineBatchItems || [];
      if (Array.isArray(overlay.items)) {
        var kept = [];
        overlay.items.forEach(function (item, i) {
          var itemId = String(item.item_id || item.candidate_id ||
            ("item_" + String(i + 1).padStart(3, "0")));
          var curItem = cur.find(function (candidate) {
            return candidate && candidate.itemId === itemId;
          }) || cur[i];
          if (curItem && curItem.include === false) return;
          if (!curItem && i >= base.length) return; // 新增行未提供 → 丢弃
          var copy = deepCopy(item);
          copy.include = true;
          if (curItem) {
            var baseItem = base[i] || {};
            if (!deepEqual(batchItemProjection(curItem), batchItemProjection(baseItem))) {
              if (has(curItem, "name")) copy.name = curItem.name;
              if (has(curItem, "tag")) copy.tag = curItem.tag;
              if (has(curItem, "charge")) copy.charge = curItem.charge;
              if (has(curItem, "multiplicity")) copy.multiplicity = curItem.multiplicity;
              if (has(curItem, "xyz") && curItem.xyz !== baseItem.xyz) {
                copy.xyz = curItem.xyz;
                delete copy.xyz_path;
                if (curItem.source_ref) {
                  copy.source_ref = deepCopy(curItem.source_ref);
                  copy.source_id = curItem.source_ref.source_id;
                }
              }
            }
          }
          kept.push(copy);
        });
        if (!kept.length) throw new Error(t("edit.batch_items_empty"));
        overlay.items = kept;
      } else {
        // Older one-structure BatchOptimize jobs store a flat xyz_text input.
        // If its structure metadata/geometry was edited in the shared input
        // form, convert that one row to the current batch_structures contract
        // so TAG, charge, multiplicity, name, and edited coordinates reach the
        // BatchOptimize loader instead of silently keeping the old XYZ only.
        var currentStructure = selectedOriginalTaskStructure(ctx);
        var currentProjection = originalTaskStructureProjection(ctx);
        var baseStructure = (ctx.baselineFormState || {}).original_task_structure;
        if (currentStructure && currentProjection && baseStructure &&
          !deepEqual(currentProjection, baseStructure)) {
          overlay = {
            source_type: "batch_structures",
            charge: has(currentStructure, "charge") ? currentStructure.charge : 0,
            multiplicity: currentStructure.multiplicity || 1,
            items: [{
              item_id: currentStructure.item_id || currentStructure.candidate_id || "item_001",
              candidate_id: currentStructure.candidate_id || currentStructure.item_id || "item_001",
              name: currentStructure.name || currentStructure.molecule_name || "structure",
              tag: currentStructure.tag || currentStructure.role || "",
              xyz: currentStructure.xyz || currentStructure.xyz_text || "",
              charge: has(currentStructure, "charge") ? currentStructure.charge : 0,
              multiplicity: currentStructure.multiplicity || 1,
              include: true,
            }],
          };
          if (currentStructure.source_ref) overlay.items[0].source_ref = deepCopy(currentStructure.source_ref);
        }
      }
      return patchOriginalChargeMult(ctx, overlay, body);
    },
    preCollect: function (ctx) {
      // 替换来源 + 已解析新结构：让收集器从新解析结构重建批量清单。
      var kind = ctx.sourceSelection.kind;
      if (kind === "original_input" || kind === "last_structure") return;
      if (typeof batchPreviewItems === "undefined" || typeof wizardStructures === "undefined") return;
      if (!wizardStructures.length) return;
      if (deepEqual(batchItemsProjection(), ctx.baselineBatchItems)) {
        batchPreviewItems = [];
      }
    },
    describe: function (ctx) {
      var inp = (ctx.originalSpec || {}).input || {};
      var items = Array.isArray(inp.items) ? inp.items : [];
      return "batch_structures(" + items.length + ")";
    },
  };

  var confsearchAdapter = {
    hydrateMethod: function (ctx, draft) { hydrateMethodBase(ctx, draft); },
    hydrateInput: function (ctx, draft) { hydrateSimpleInput(draft); },
    methodProjection: baseMethodProjection,
    buildMethod: function (ctx, body, current) {
      var m = baseBuildMethod(ctx, body, current);
      var cs = ((current.stages || {}).confsearch) || {};
      var oldCs = (((ctx.methodBaseline || {}).stages || {}).confsearch) || {};
      [["protocol", "protocol"], ["confsearch_profile", "profile"],
        ["refinement_policy", "refinement_policy"], ["ewin", "ewin"]].forEach(function (pair) {
        if (has(cs, pair[0]) && !deepEqual(cs[pair[0]], oldCs[pair[0]])) m[pair[1]] = cs[pair[0]];
      });
      ["refinement_sp", "dft_opt"].some(function (id) {
        var level = (current.stages || {})[id];
        var before = ((ctx.methodBaseline || {}).stages || {})[id] || {};
        if (!level || (deepEqual(level.solvent, before.solvent) &&
          deepEqual(level.solvent_model, before.solvent_model))) return false;
        m.solvent = level.solvent_model === "none" ? "" : (level.solvent || "");
        return true;
      });
      return m;
    },
    patchOriginalInput: patchOriginalChargeMult,
    preCollect: null,
    describe: function (ctx) { return inputKind((ctx.originalSpec || {}).input || {}); },
  };

  var nmrAdapter = {
    hydrateMethod: function (ctx, draft) { hydrateMethodBase(ctx, draft); },
    hydrateInput: function (ctx, draft) {
      // assigned 文本可恢复；bruker 资产失效要求替换。
      var spec = draft.editable_spec || {};
      var inp = spec.input || {};
      var toggle = document.getElementById("nmr-enumerate-toggle");
      if (toggle) toggle.checked = !!inp.enumerate;
      setFieldValue("nmr-enumerate-centers", Array.isArray(inp.stereocenters)
        ? inp.stereocenters.join(",") : (inp.stereocenters || ""));
      if (inp.experiment && inp.experiment.mode === "assigned" &&
        typeof nmrExperimentMode !== "undefined") {
        nmrExperimentMode = "assigned";
        var ta = document.getElementById("nmr-experiment-text");
        if (ta && inp.experiment.content) ta.value = String(inp.experiment.content);
      }
    },
    methodProjection: baseMethodProjection,
    buildMethod: baseBuildMethod,
    patchOriginalInput: function (ctx, overlay, body) {
      overlay = patchOriginalChargeMult(ctx, overlay, body);
      var currentCandidates = nmrCandidatesProjection();
      var baselineCandidates = (ctx.baselineFormState || {}).nmr_candidates || [];
      if (!deepEqual(currentCandidates, baselineCandidates)) {
        var originalCandidates = Array.isArray(overlay.candidates) ? overlay.candidates : [overlay];
        overlay.candidates = currentCandidates.map(function (current) {
          var index = baselineCandidates.findIndex(function (candidate) {
            return candidate.item_id === current.item_id;
          });
          var baseline = baselineCandidates[index] || {};
          var candidate = deepCopy(originalCandidates[index] || {});
          if (index < 0 || current.xyz !== baseline.xyz) {
            candidate = { source_type: "xyz_text", source: current.xyz };
            if (!current.xyz) throw new Error(t("edit.no_payload_collected"));
          }
          candidate.name = current.name;
          candidate.charge = current.charge;
          candidate.multiplicity = current.multiplicity;
          return candidate;
        });
        if (!overlay.candidates.length) throw new Error(t("edit.no_payload_collected"));
      }
      ["charge", "multiplicity"].forEach(function (key) {
        var baselineKey = key === "charge" ? "charge" : "mult";
        if (body && body.input && has(body.input, key) &&
          String(body.input[key]) !== String((ctx.baselineFormState || {})[baselineKey])) {
          (overlay.candidates || []).forEach(function (candidate) { candidate[key] = body.input[key]; });
        }
      });
      var enumToggle = document.getElementById("nmr-enumerate-toggle");
      var enumerate = !!(enumToggle && enumToggle.checked);
      if (enumerate !== (ctx.baselineFormState || {}).nmr_enumerate) overlay.enumerate = enumerate;
      var centers = fieldVal("nmr-enumerate-centers").trim();
      if (centers !== (ctx.baselineFormState || {}).nmr_stereocenters) overlay.stereocenters = centers;
      if (overlay.experiment && overlay.experiment.mode === "assigned" &&
        typeof nmrExperimentMode !== "undefined" && nmrExperimentMode === "assigned") {
        var ta = document.getElementById("nmr-experiment-text");
        var text = ta ? String(ta.value || "") : "";
        if (text !== (ctx.baselineFormState || {}).nmr_experiment_text) {
          overlay.experiment = { mode: "assigned", content: text };
        }
      }
      return overlay;
    },
    preCollect: null,
    describe: function (ctx) {
      var inp = (ctx.originalSpec || {}).input || {};
      var cands = Array.isArray(inp.candidates) ? inp.candidates : [];
      return "candidates(" + cands.length + ")";
    },
  };

  var pesSearchAdapter = {
    hydrateMethod: function (ctx, draft) {
      hydrateMethodBase(ctx, draft);
      // ── Legacy hydration (Item 6): fill missing scan_optimizer fields ──
      // Old PESsearch tasks may lack the new DFT-scan fields in their
      // scan_optimizer level.  Fill wizardState display values from schema
      // defaults so the method-config modal renders correctly.  Submission
      // must reflect only actual user changes — these are display-layer only.
      var so = (wizardState.method.stages || {}).scan_optimizer || {};
      var _newFields = [
        "scan_optimizer_basis", "scan_optimizer_dispersion",
        "scan_optimizer_solvent_model", "scan_optimizer_solvent",
        "scan_optimizer_grid", "scan_optimizer_scf_convergence",
        "scan_optimizer_scf_max_iterations", "scan_optimizer_ri_approximation",
      ];
      var _schemaDefaults = {
        scan_optimizer_basis: "",
        scan_optimizer_dispersion: "none",
        scan_optimizer_solvent_model: "none",
        scan_optimizer_solvent: "",
        scan_optimizer_grid: "",
        scan_optimizer_scf_convergence: "",
        scan_optimizer_scf_max_iterations: 200,
        scan_optimizer_ri_approximation: "none",
      };
      for (var _fi = 0; _fi < _newFields.length; _fi++) {
        var _fk = _newFields[_fi];
        if (so[_fk] === undefined || so[_fk] === null) {
          so[_fk] = _schemaDefaults[_fk];
        }
      }
      // Also ensure scan_optimizer_method exists (default to GFN2-xTB)
      if (!so.scan_optimizer_method) so.scan_optimizer_method = "GFN2-xTB";
    },
    hydrateInput: function (ctx, draft) {
      var spec = draft.editable_spec || {};
      var inp = spec.input || {};
      if (inputKind(inp) === "stage_artifact") {
        setFieldValue("stage-source-job", inp.source_job_id);
        setFieldValue("stage-artifact", inp.from_artifact);
        setFieldValue("stage-product", inp.product);
        setFieldValue("stage-ts-guess", inp.ts_guess);
        if (inp.coordinate_plan) {
          setFieldValue("stage-plan", JSON.stringify(inp.coordinate_plan));
        }
        var m = spec.method || {};
        if (Array.isArray(m.select)) setFieldValue("stage-select", m.select.join(","));
      }
    },
    methodProjection: baseMethodProjection,
    buildMethod: baseBuildMethod,
    patchOriginalInput: function (ctx, overlay, body) {
      overlay = patchOriginalChargeMult(ctx, overlay, body);
      var m = ctx.originalSpec.method || {};
      if (Array.isArray(m.select) && has(overlay, "select") === false && m.select.length) {
        overlay.select = deepCopy(m.select);
      }
      if (m.mode === "bond_length_scan" && typeof pesSelectionState !== "undefined") {
        var selected = pesSelectionState.selectedAtoms || [];
        var originalSelection = (overlay.selection || (overlay.scan_request || {}).selection || {});
        var originalAtoms = originalSelection.atom_indices ||
          ((overlay.coordinate || (overlay.scan_request || {}).coordinate || {}).atoms || []);
        var oldCoordinate = overlay.coordinate || (overlay.scan_request || {}).coordinate || {};
        var oldKind = originalSelection.kind || (oldCoordinate.kind === "angle" ? "angle" :
          oldCoordinate.kind === "dihedral" ? "dihedral" : "bond_stretch");
        if (!deepEqual(selected, originalAtoms) || pesSelectionState.selectionKind !== oldKind) {
          if (!selected.length) throw new Error(t("edit.pes_selection_required"));
          overlay.coordinate = deepCopy(overlay.coordinate || (overlay.scan_request || {}).coordinate || {});
          var kind = pesSelectionState.selectionKind;
          overlay.coordinate.kind = kind === "angle" ? "angle" : kind === "dihedral" ? "dihedral" : "distance";
          overlay.coordinate.unit = overlay.coordinate.kind === "distance" ? "angstrom" : "degree";
          overlay.coordinate.atoms = kind === "double_bond_scan" ? selected.slice(0, 2) : selected.slice();
          overlay.selection = Object.assign({}, originalSelection, { kind: kind, atom_indices: selected.slice() });
          if (kind === "double_bond_scan") {
            overlay.coordinates = [deepCopy(overlay.coordinate), deepCopy(overlay.coordinate)];
            overlay.coordinates[1].atoms = selected.slice(2, 4);
            overlay.selection.groups = [selected.slice(0, 2), selected.slice(2, 4)];
          } else {
            overlay.coordinates = null;
            overlay.scan_request = null;
            overlay.selection.groups = [];
          }
        }
      }
      return overlay;
    },
    preCollect: null,
    describe: function (ctx) { return inputKind((ctx.originalSpec || {}).input || {}); },
  };

  var workflowAdapters = {
    BatchOptimize: batchOptimizeAdapter,
    Confsearch: confsearchAdapter,
    PESsearch: pesSearchAdapter,
    nmr: nmrAdapter,
    scan: makeBaseAdapter(),
    default: makeBaseAdapter(),
  };

  function adapterFor(workflow) {
    return workflowAdapters[workflow] || workflowAdapters.default;
  }

  // ---------------------------------------------------------------------------
  // 输入回填辅助
  // ---------------------------------------------------------------------------

  function setFieldValue(id, value) {
    if (value === undefined || value === null) return;
    var el = document.getElementById(id);
    if (el) el.value = String(value);
  }

  // 简单结构输入：单结构进结构框并解析（3D 预览）。复杂输入不塞文本框，
  // 由「上次输入」只读摘要面板展示。
  function hydrateSimpleInput(draft) {
    var spec = draft.editable_spec || {};
    var inp = spec.input || {};
    var kind = inputKind(inp);
    var box = document.getElementById("modal-structure-input");
    var previewText = "";
    if (kind === "xyz_text" || kind === "plain") {
      previewText = String(has(inp, "source") ? inp.source :
        (has(inp, "input_artifact") ? inp.input_artifact :
          (has(inp, "smiles") ? inp.smiles : "")));
    } else if (kind === "smiles") {
      previewText = String(has(inp, "source") ? inp.source : "");
    } else if (kind === "structure_asset") {
      previewText = String(has(inp, "source") ? inp.source : "");
    } else if (kind === "scan_request") {
      var src = (inp.scan_request && inp.scan_request.source) || {};
      previewText = String(src.xyz_text || src.source || "");
    }
    if (previewText && box) {
      box.value = previewText;
      if (typeof scheduleParseStructures === "function") scheduleParseStructures();
    }
  }

  // kind=original 时 charge/multiplicity 的最小 patch（仅当用户实际改动）。
  function patchOriginalChargeMult(ctx, overlay, body) {
    var bi = (body && body.input) || {};
    var base = ctx.baselineFormState || {};
    if (has(bi, "charge") && String(bi.charge) !== String(base.charge) &&
      overlay && !Array.isArray(overlay.items)) {
      overlay.charge = parseInt(bi.charge, 10);
    }
    if (has(bi, "multiplicity") && String(bi.multiplicity) !== String(base.mult) &&
      overlay && !Array.isArray(overlay.items)) {
      overlay.multiplicity = parseInt(bi.multiplicity, 10);
    }
    return overlay;
  }

  function nmrCandidatesProjection() {
    return (typeof wizardStructures !== "undefined" ? wizardStructures : []).map(function (item) {
      return {
        item_id: item.item_id || item.input_id || "",
        name: item.name || "", xyz: item.xyz || "",
        charge: item.charge, multiplicity: item.multiplicity,
      };
    });
  }

  function batchItemProjection(item) {
    if (!item) return null;
    return {
      item_id: item.itemId || "",
      name: item.name || "",
      tag: item.tag || "",
      charge: item.charge,
      multiplicity: item.multiplicity,
      include: item.include !== false,
      xyz: item.xyz || "",
    };
  }

  function batchItemsProjection() {
    if (typeof batchPreviewItems === "undefined") return [];
    return batchPreviewItems.map(batchItemProjection);
  }

  function selectedOriginalTaskStructure(ctx) {
    if (!ctx || ctx.activeSourceTab !== "task" || ctx.sourceSelection.kind !== "original_input") return null;
    var structures = typeof wizardStructures !== "undefined" ? wizardStructures : [];
    var selected = structures[wizardSelectedStructureIndex] || ctx.sourceSelection.payload;
    if (!selected || (selected.source_kind && selected.source_kind !== "original_input")) return null;
    return selected;
  }

  function originalTaskStructureProjection(ctx) {
    var input = (ctx && ctx.originalSpec && ctx.originalSpec.input) || {};
    if (!ctx || ctx.originalSpec.workflow !== "BatchOptimize" || Array.isArray(input.items)) return null;
    var structure = selectedOriginalTaskStructure(ctx);
    if (!structure) return null;
    return {
      item_id: structure.item_id || structure.candidate_id || "",
      name: structure.name || structure.molecule_name || "",
      tag: structure.tag || structure.role || "",
      charge: has(structure, "charge") ? structure.charge : 0,
      multiplicity: structure.multiplicity || 1,
      xyz: structure.xyz || structure.xyz_text || "",
    };
  }

  function findOriginalBatchRow(structure, index) {
    var ctx = editorContext;
    if (!ctx || !structure || ctx.originalSpec.workflow !== "BatchOptimize" ||
      ctx.activeSourceTab !== "task") return null;
    var itemId = String(structure.item_id || structure.candidate_id || "");
    var source = (ctx.taskStructureItems || []).find(function (candidate) {
      return candidate && candidate.source_kind === "original_input" &&
        String(candidate.item_id || candidate.candidate_id || "") === itemId;
    });
    if (!source) return null;
    var row = batchPreviewItems.find(function (candidate) {
      return candidate && candidate.itemId === String(source.item_id || source.candidate_id || "");
    });
    // Compatibility fallback for an older draft without stable item ids.
    if (!row && batchPreviewItems[index] && source === ctx.taskStructureItems[index]) {
      row = batchPreviewItems[index];
    }
    return row || null;
  }

  function onTaskStructureChanged(index, structure) {
    var ctx = editorContext;
    if (!ctx || !structure) return;
    if (ctx.activeSourceTab === "task" && structure.source_kind === "original_input" &&
      Number(index) === Number(wizardSelectedStructureIndex)) {
      ctx.sourceSelection = { kind: "original_input", payload: structure };
    }
    var row = findOriginalBatchRow(structure, index);
    if (row) {
      if (structure.xyz !== undefined) row.xyz = structure.xyz;
      if (structure.source_ref) row.source_ref = deepCopy(structure.source_ref);
      if (structure.name !== undefined) row.name = structure.name;
      row.tag = structure.tag || "";
      row.tagAuto = false;
      if (structure.charge !== undefined) row.charge = structure.charge;
      if (structure.multiplicity !== undefined) row.multiplicity = structure.multiplicity;
      if (typeof renderStageBatchPreview === "function") renderStageBatchPreview();
    }
    syncSourceExecutionMode(ctx);
  }

  function onTaskStructureRemoved(index, structure) {
    var row = findOriginalBatchRow(structure, index);
    if (row) {
      row.include = false;
      if (typeof renderStageBatchPreview === "function") renderStageBatchPreview();
    }
    if (editorContext) syncSourceExecutionMode(editorContext);
  }

  function onBatchItemChanged(row) {
    var ctx = editorContext;
    if (!ctx || !row || ctx.originalSpec.workflow !== "BatchOptimize" ||
      ctx.activeSourceTab !== "task") return;
    var itemId = String(row.itemId || "");
    if (!itemId) return;
    var source = (ctx.taskStructureItems || []).find(function (candidate) {
      return candidate && candidate.source_kind === "original_input" &&
        String(candidate.item_id || candidate.candidate_id || "") === itemId;
    });
    if (!source) return;
    var structure = (typeof wizardStructures !== "undefined" ? wizardStructures : []).find(function (candidate) {
      return candidate && candidate.source_kind === "original_input" &&
        String(candidate.item_id || candidate.candidate_id || "") === itemId;
    });
    if (!structure) return;
    structure.name = row.name || structure.name;
    structure.tag = row.tag || "";
    structure.charge = row.charge;
    structure.multiplicity = row.multiplicity;
    structure.input_modified = true;
    if (typeof renderLoadedStructuresList === "function") renderLoadedStructuresList();
    updateEditorUiState();
  }

  // ---------------------------------------------------------------------------
  // 入口：重算菜单（队列 ↻ 按钮与详情页共用）
  // ---------------------------------------------------------------------------

  function closeRerunMenu() {
    if (menuEl && menuEl.parentNode) menuEl.parentNode.removeChild(menuEl);
    menuEl = null;
    document.removeEventListener("click", closeRerunMenu, true);
    document.removeEventListener("keydown", onMenuKey, true);
  }

  function onMenuKey(ev) {
    if (ev.key === "Escape") { closeRerunMenu(); return; }
    if (!menuEl) return;
    var focusables = Array.prototype.slice.call(menuEl.querySelectorAll("button"));
    if (!focusables.length) return;
    var idx = focusables.indexOf(document.activeElement);
    if (ev.key === "ArrowDown") {
      ev.preventDefault();
      focusables[(idx + 1 + focusables.length) % focusables.length].focus();
    } else if (ev.key === "ArrowUp") {
      ev.preventDefault();
      focusables[(idx - 1 + focusables.length) % focusables.length].focus();
    }
  }

  function openRerunMenu(job, anchor) {
    if (!job) return;
    closeRerunMenu();
    var jobId = String(job.id || job.job_id || "");
    var recovery = (typeof resolveJobRecovery === "function")
      ? resolveJobRecovery(job) : { can_rerun: true };
    menuEl = document.createElement("div");
    menuEl.className = "rerun-action-menu";
    menuEl.setAttribute("role", "menu");
    [
      {
        key: "edit.menu.rerun_direct",
        icon: "↻",
        enabled: !!recovery.can_rerun,
        reason: "edit.menu.rerun_direct_disabled",
        action: function () { closeRerunMenu(); rerunJob(jobId, null); },
      },
      {
        key: "edit.menu.edit_recalculate",
        icon: "✎",
        enabled: true,
        reason: "",
        action: function () { closeRerunMenu(); openJobEditor(job, "edit_recalculate"); },
      },
      {
        key: "edit.menu.new_from_job",
        icon: "⧉",
        enabled: true,
        reason: "",
        action: function () { closeRerunMenu(); openJobEditor(job, "new_from_job"); },
      },
    ].forEach(function (item) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.setAttribute("role", "menuitem");
      btn.innerHTML = '<span class="rerun-menu-icon">' + item.icon + "</span><span>" +
        t(item.key) + "</span>";
      if (!item.enabled) {
        btn.disabled = true;
        btn.title = item.reason ? t(item.reason) : "";
      } else {
        btn.addEventListener("click", function (ev) { ev.stopPropagation(); item.action(); });
      }
      menuEl.appendChild(btn);
    });
    var rect = anchor.getBoundingClientRect();
    menuEl.style.left = Math.max(8, Math.min(window.innerWidth - 230, rect.left)) + "px";
    menuEl.style.top = (rect.bottom + 4 + window.scrollY) + "px";
    menuEl.style.position = "absolute";
    document.body.appendChild(menuEl);
    // 菜单打开不触发卡片选择/展开：容器级捕获关闭 + stopPropagation。
    menuEl.addEventListener("click", function (ev) { ev.stopPropagation(); });
    setTimeout(function () {
      document.addEventListener("click", closeRerunMenu, true);
      document.addEventListener("keydown", onMenuKey, true);
      var first = menuEl.querySelector("button:not([disabled])");
      if (first) first.focus();
    }, 0);
  }

  // ---------------------------------------------------------------------------
  // 打开编辑器：openModal 全量重置 → 并行等待草稿与目录 → hydrate → 基线
  // ---------------------------------------------------------------------------

  function ensureCatalogsLoaded() {
    var tasks = [];
    if (typeof loadWorkflowCatalog === "function" &&
      typeof workflowCatalogCache !== "undefined" && !workflowCatalogCache.length) {
      tasks.push(loadWorkflowCatalog().catch(function () { /* 目录失败不阻断草稿 */ }));
    }
    if (typeof loadMethodCatalog === "function" &&
      typeof methodCatalogCache !== "undefined" && !methodCatalogCache.method_schemas) {
      tasks.push(loadMethodCatalog().catch(function () { /* 同上 */ }));
    }
    return Promise.all(tasks);
  }

  function supportsReactionPathInput(workflow) {
    return ["BatchOptimize", "Confsearch", "singlepoint", "optimize", "frequency", "xtb-optimize"]
      .indexOf(String(workflow || "")) >= 0;
  }

  function reactionPathRoleMap(payload) {
    var roles = {};
    function mark(rows, role, selected) {
      (Array.isArray(rows) ? rows : []).forEach(function (row, index) {
        if (!row || row.frame_index === undefined || row.frame_index === null) return;
        var frameIndex = parseInt(row.frame_index, 10);
        if (!Number.isFinite(frameIndex)) return;
        var entry = roles[frameIndex] || (roles[frameIndex] = {});
        entry.role = role;
        entry.selected = entry.selected || !!selected;
        entry.label = row.display_label || row.name || row.candidate_id ||
          (role === "ts" ? "TS-" : "INT-") + String(index + 1).padStart(2, "0");
      });
    }

    var review = (payload && payload.review) || {};
    var selectedRows = Array.isArray(review.selected) ? review.selected : [];
    var selectedIds = new Set();
    selectedRows.forEach(function (row) {
      if (typeof row === "string") {
        selectedIds.add(row);
        return;
      }
      if (!row || typeof row !== "object") return;
      if (row.candidate_id) selectedIds.add(String(row.candidate_id));
      if (row.frame_index === undefined || row.frame_index === null) return;
      var role = String(row.role || "").toLowerCase();
      mark([row], role === "ts" ? "ts" : "intermediate", true);
    });
    ["selected_ts", "selected_intermediates"].forEach(function (field) {
      (Array.isArray(review[field]) ? review[field] : []).forEach(function (item) {
        if (typeof item === "string") selectedIds.add(item);
        else if (item && item.candidate_id) selectedIds.add(String(item.candidate_id));
      });
    });
    (Array.isArray(review.candidates) ? review.candidates : []).forEach(function (row) {
      if (!row || typeof row !== "object") return;
      var id = String(row.candidate_id || row.id || "");
      if (!id || !selectedIds.has(id) || row.frame_index === undefined || row.frame_index === null) return;
      var role = String(row.role || "").toLowerCase();
      mark([row], role === "ts" ? "ts" : "intermediate", true);
    });
    return roles;
  }

  function pathFrameText(ctx, frame, roles, source) {
    var index = Number(frame.index);
    var roleInfo = roles[index] || {};
    var input = (ctx.originalSpec && ctx.originalSpec.input) || {};
    var origin = input.edit_input_origin || {};
    var originJobId = String(origin.parent_job_id || origin.job_id || "");
    var samePreviousFrame = origin.mode === "reaction_path_frame" &&
      originJobId === source.job_id && Number(origin.frame_index) === index;
    var lastSelected = !!roleInfo.selected || samePreviousFrame;
    var lastIndex = source.frameCount - 1;
    var isEndpoint = index === 0 || index === lastIndex;
    var role = roleInfo.role || (isEndpoint ? "endpoint" : "");
    var roleKey = role === "ts" ? "edit.path_role_ts"
      : role === "intermediate" ? "edit.path_role_int"
      : role === "endpoint" ? "edit.path_role_endpoint" : "";
    var badges = [];
    if (roleKey) badges.push('<span class="edit-path-frame-badge ' +
      (role === "ts" ? "ts" : role === "intermediate" ? "int" : "") + '">' +
      escapeHtml(t(roleKey)) + "</span>");
    if (lastSelected) {
      badges.push('<span class="edit-path-frame-badge">' +
        escapeHtml(t("edit.path_role_last_selected")) + "</span>");
    }
    var name = roleInfo.label || t("edit.path_frame", { number: String(index + 1) });
    var coordinate = frame.target_coordinate;
    var energy = frame.single_point_energy_hartree;
    if (energy === null || energy === undefined) energy = frame.scan_energy_hartree;
    var meta = [];
    if (coordinate !== null && coordinate !== undefined) {
      meta.push(t("edit.path_coordinate", { value: Number(coordinate).toFixed(3) }));
    }
    if (energy !== null && energy !== undefined) {
      meta.push(t("edit.path_energy", { value: Number(energy).toFixed(6) }));
    }
    meta.push(frame.optimization_converged
      ? t("edit.path_status_converged") : t("edit.path_status_partial"));
    return '<button type="button" class="edit-path-frame' +
      (lastSelected ? " is-last-selected" : "") + '"' +
      ' data-edit-path-job="' + escapeHtml(source.job_id) + '"' +
      ' data-edit-path-frame="' + escapeHtml(index) + '"' +
      ' data-edit-path-role="' + escapeHtml(role) + '"' +
      ' data-edit-path-meta="' + escapeHtml(meta.join(" · ")) + '">' +
      '<span class="edit-path-frame-main"><span class="edit-path-frame-name">' +
      escapeHtml(name) + badges.join("") + '</span><span class="edit-path-frame-meta">' +
      escapeHtml(meta.join(" · ")) + '</span></span><span aria-hidden="true">›</span></button>';
  }

  function renderReactionPathSources(ctx, groups) {
    var panel = document.getElementById("edit-path-structures");
    var list = document.getElementById("edit-path-structures-list");
    if (!panel || !list || !ctx) return;
    if (!groups || !groups.length) {
      panel.style.display = "none";
      list.innerHTML = "";
      return;
    }
    panel.style.display = ctx.activeSourceTab === "task" && ctx.mode === "edit_recalculate" &&
      supportsReactionPathInput(ctx.originalSpec && ctx.originalSpec.workflow) ? "flex" : "none";
    list.innerHTML = groups.map(function (group) {
      var frames = Array.isArray(group.frames) ? group.frames.slice() : [];
      var roles = reactionPathRoleMap(group.candidates || {});
      group.frameCount = frames.length;
      frames.sort(function (a, b) {
        var ar = roles[Number(a.index)] || {};
        var br = roles[Number(b.index)] || {};
        var ap = ar.selected ? 0 : 1;
        var bp = br.selected ? 0 : 1;
        return ap - bp || Number(a.index) - Number(b.index);
      });
      var source = { job_id: group.job_id, frameCount: group.frameCount };
      return '<div class="edit-path-source-title">' + escapeHtml(group.name || group.job_id) +
        ' · ' + escapeHtml(group.job_id) + '</div>' +
        frames.map(function (frame) {
          return pathFrameText(ctx, frame, roles, source);
        }).join("");
    }).join("");
    if (!list._acpWired) {
      list._acpWired = true;
      list.addEventListener("click", function (event) {
        var button = event.target && event.target.closest
          ? event.target.closest(".edit-path-frame") : null;
        if (button) selectReactionPathFrame(button);
      });
    }
  }

  function loadEditReactionPaths(ctx) {
    var panel = document.getElementById("edit-path-structures");
    var list = document.getElementById("edit-path-structures-list");
    if (!panel || !list || !ctx || ctx.mode !== "edit_recalculate" ||
      !supportsReactionPathInput(ctx.originalSpec && ctx.originalSpec.workflow)) return;
    panel.style.display = "none";
    list.innerHTML = "";
    var sources = (((ctx.draft || {}).input_refs || {}).reaction_path_sources) || [];
    if (!sources.length) return;
    var read = typeof apiRemote === "function" ? apiRemote : api;
    Promise.all(sources.map(function (source) {
      var jobId = String(source.job_id || "");
      var base = "/jobs/" + encodeURIComponent(jobId);
      return Promise.all([
        read(base + "/s2/profile").catch(function () { return null; }),
        read(base + "/s2/candidates").catch(function () { return null; }),
      ]).then(function (responses) {
        var profile = responses[0];
        var frames = profile && Array.isArray(profile.frames) ? profile.frames : [];
        var availableFrames = frames.filter(function (frame) {
          return frame && frame.geometry_path;
        });
        return availableFrames.length ? {
          job_id: jobId,
          name: source.name || jobId,
          charge: source.charge !== undefined ? source.charge : 0,
          multiplicity: source.multiplicity || 1,
          frames: availableFrames,
          candidates: responses[1] || { review: profile && profile.selection },
        } : null;
      });
    })).then(function (groups) {
      if (!editorContext || editorContext.requestToken !== ctx.requestToken) return;
      var available = groups.filter(Boolean);
      available.forEach(function (group) {
        group.frames.forEach(function (frame) { frame._source_job_id = group.job_id; });
      });
      ctx.pathFrameSources = available;
      renderReactionPathSources(ctx, available);
    }).catch(function (error) {
      if (!editorContext || editorContext.requestToken !== ctx.requestToken) return;
      ctx.pathFrameLoadError = (error && error.message) || String(error);
      renderReactionPathSources(ctx, []);
    });
  }

  function selectReactionPathFrame(button) {
    var ctx = editorContext;
    if (!ctx || !button || button.disabled) return;
    var jobId = button.getAttribute("data-edit-path-job") || "";
    var frameIndex = parseInt(button.getAttribute("data-edit-path-frame"), 10);
    var role = button.getAttribute("data-edit-path-role") || "";
    var source = (ctx.pathFrameSources || []).find(function (item) {
      return item.job_id === jobId;
    });
    if (!source || !Number.isFinite(frameIndex)) return;
    var token = ctx.requestToken;
    var read = typeof apiRemote === "function" ? apiRemote : api;
    var metaEl = button.querySelector(".edit-path-frame-meta");
    button.disabled = true;
    button.classList.add("is-selected");
    if (metaEl) metaEl.textContent = t("edit.path_selecting");
    read("/jobs/" + encodeURIComponent(jobId) + "/s2/frame/" + encodeURIComponent(frameIndex))
      .then(function (frame) {
        if (!editorContext || editorContext.requestToken !== token) return;
        var xyz = String((frame && frame.xyz) || "");
        var atomCount = parseInt((xyz.split(/\r?\n/, 1)[0] || "0").trim(), 10) || 0;
        if (!atomCount || xyz.split(/\r?\n/).length < atomCount + 2) {
          throw new Error("路径帧没有完整 XYZ 几何");
        }
        var roleTag = role === "ts" ? "TS" : "INT";
        var label = button.querySelector(".edit-path-frame-name").childNodes[0].textContent.trim();
        var origin = {
          mode: "reaction_path_frame",
          parent_job_id: jobId,
          frame_index: frameIndex,
          view_type: "s2",
          label: label,
          role: roleTag || role,
          reaction_coordinate: frame.target_coordinate,
          actual_coordinate: frame.actual_coordinate,
          scan_energy_hartree: frame.scan_energy_hartree,
          single_point_energy_hartree: frame.single_point_energy_hartree,
        };
        var sourceRef = {
          origin: "reaction_path_frame",
          job_id: jobId,
          frame_index: frameIndex,
          source_id: "job_" + jobId + ":s2/frame/" + frameIndex,
        };
        var item = {
          source_id: sourceRef.source_id,
          source_kind: "path_frame",
          item_id: "s2_frame_" + String(frameIndex + 1).padStart(3, "0"),
          candidate_id: "s2_frame_" + String(frameIndex + 1).padStart(3, "0"),
          name: label,
          molecule_name: label,
          tag: roleTag,
          role: roleTag,
          xyz: xyz,
          xyz_text: xyz,
          charge: source.charge,
          multiplicity: source.multiplicity,
          atom_count: atomCount,
          has_3d: true,
          geometry_ref: { kind: "reaction_path_frame", job_id: jobId, frame_index: frameIndex },
          source_ref: sourceRef,
          edit_input_origin: origin,
        };
        wizardInputMode = "task";
        wizardStructures = [item];
        wizardSelectedStructureIndex = 0;
        wizardParseWarnings = [];
        document.getElementById("modal-charge").value = String(source.charge);
        document.getElementById("modal-mult").value = String(source.multiplicity);
        renderStructurePreview(wizardStructures, wizardParseWarnings);
        ctx.sourceSelection = { kind: "path_frame", payload: item };
        ctx.pathSourceDraft = deepCopy(item);
        updateDefaultStartBadge(ctx, item);
        syncSourceExecutionMode(ctx);
        button.parentNode.querySelectorAll(".edit-path-frame").forEach(function (entry) {
          entry.classList.toggle("is-selected", entry === button);
          var entryMeta = entry.querySelector(".edit-path-frame-meta");
          if (entryMeta) entryMeta.textContent = entry === button
            ? t("edit.path_selected_short")
            : entry.getAttribute("data-edit-path-meta") || entryMeta.textContent;
        });
      }).catch(function (error) {
        if (!editorContext || editorContext.requestToken !== token) return;
        button.classList.remove("is-selected");
        if (metaEl) metaEl.textContent = t("edit.path_load_failed", {
          message: (error && error.message) || String(error),
        });
      }).then(function () {
        if (editorContext && editorContext.requestToken === token) button.disabled = false;
      });
  }

  function openJobEditor(job, mode) {
    var jobId = String(job.id || job.job_id || "");
    var token = ++tokenCounter;
    editorContext = {
      mode: mode,
      sourceJobId: jobId,
      sourceJob: job,
      requestToken: token,
      draft: null,
      originalSpec: {},
      editStep: 1,
      effectiveConfig: null,
      adapter: null,
      methodBaseline: null,
      baselineFormState: null,
      baselineBatchItems: [],
      methodBackfilled: false,
      sourceSelection: { kind: "original_input", payload: null },
      activeSourceTab: "task",
      sourceDrafts: {
        structure: { applied: false, structures: [], selectedIndex: 0 },
        upload: { applied: false, structures: [], selectedIndex: 0 },
      },
      executionMode: mode === "new_from_job" ? "new_job" : "in_place",
      fingerprint: null,
      submitting: false,
      collecting: false,
      collectedBodies: null,
      pendingPreviewBody: null,
      pathSourceDraft: null,
    };
    // Apply edit-mode styling before openModal restores any saved create-wizard
    // state; the edit form must not inherit the last create step's visibility.
    updateEditModeTabs();
    openModal();
    renderBanner("loading");
    hideFooter();
    updateModalSubmitButton();
    Promise.all([
      apiRemote("/jobs/" + encodeURIComponent(jobId) + "/edit-draft"),
      ensureCatalogsLoaded(),
    ]).then(function (results) {
      if (!editorContext || editorContext.requestToken !== token) return;
      var draft = results[0];
      editorContext.draft = draft;
      hydrate(draft);
      renderBanner("ready");
      renderFooter();
      updateEditorUiState();
      loadEditReactionPaths(editorContext);
      startBadgeWatch();
    }, function (err) {
      if (!editorContext || editorContext.requestToken !== token) return;
      renderBanner("error", (err && err.message) || String(err));
    });
  }

  function cancelEditor(force) {
    if (!editorContext) return;
    if (!force && countLocalChanges() > 0) {
      if (!window.confirm(t("edit.discard_confirm"))) return;
    }
    editorContext = null;
    stopBadgeWatch();
    hideSummary();
    renderBanner("hidden");
    hideFooter();
    hideOriginalPanelExtras();
    var pathPanel = document.getElementById("edit-path-structures");
    var pathList = document.getElementById("edit-path-structures-list");
    if (pathPanel) pathPanel.style.display = "none";
    if (pathList) pathList.innerHTML = "";
    updateDefaultStartBadge(null, null);
    restoreBatchItems([]);  // 清空编辑态批量镜像（新建语义由下一次 openModal 重置）
    updateModalSubmitButton();
    closeModal();
  }

  // ---------------------------------------------------------------------------
  // hydrate：挂载工作流表单 → 回填参数 → 回填输入 → 建立基线 → 刷新摘要
  // ---------------------------------------------------------------------------

  function hydrate(draft) {
    var ctx = editorContext;
    var spec = draft.editable_spec || {};
    ctx.originalSpec = spec;
    ctx.effectiveConfig = draft.effective_config || null;
    buildRecalcFocus(ctx);
    ctx.adapter = adapterFor(spec.workflow);
    ctx.methodBackfilled = false;
    // 1) 工作流预选走现有 pendingNewTask 通道（含 catalog 自愈 + 默认档位）。
    window._pendingNewTask = { workflow: spec.workflow, projectId: spec.project_id || "" };
    applyPendingNewTask();
    // 2) 工作流适配器回填方法参数（覆盖 openModal 载入的当前默认值）。
    ctx.adapter.hydrateMethod(ctx, draft);
    // 3) 表单公共字段。
    document.getElementById("modal-remark").value = spec.remark || "";
    document.getElementById("modal-task-name").value =
      spec.task_name && spec.task_name !== spec.workflow ? spec.task_name : "";
    var res = spec.resources || {};
    if (res.nproc) document.getElementById("modal-nproc").value = String(res.nproc);
    if (res.mem !== undefined && res.mem !== null && res.mem !== "") {
      ACPMemoryInput.set("modal-mem", "modal-mem-unit", res.mem);
    }
    if (res.parallelism && document.getElementById("modal-parallelism")) {
      document.getElementById("modal-parallelism").value = String(res.parallelism);
    }
    var inp = spec.input || {};
    var charge = inp.charge, mult = inp.multiplicity;
    if (inputKind(inp) === "scan_request" && inp.scan_request && inp.scan_request.source) {
      charge = inp.scan_request.source.charge; mult = inp.scan_request.source.multiplicity;
    }
    if (Array.isArray(inp.items) && inp.items.length &&
      has(inp.items[0], "charge")) {
      charge = inp.items[0].charge;
      mult = has(inp.items[0], "multiplicity") ? inp.items[0].multiplicity : mult;
    }
    if (Array.isArray(inp.candidates) && inp.candidates.length) {
      charge = inp.candidates[0].charge;
      mult = inp.candidates[0].multiplicity;
    }
    if (charge !== undefined && charge !== null) document.getElementById("modal-charge").value = String(charge);
    if (mult !== undefined && mult !== null) document.getElementById("modal-mult").value = String(mult);
    // 4) 项目与节点。
    var ps = document.getElementById("modal-project-select");
    if (ps && spec.project_id) {
      var hasOption = Array.prototype.some.call(ps.options, function (o) { return o.value === spec.project_id; });
      if (hasOption) ps.value = spec.project_id;
    }
    if (spec.node_tags && spec.node_tags.length && typeof nodeMatchingState !== "undefined") {
      nodeMatchingState.selectedTags = spec.node_tags.slice();
    }
    // 5) 工作流适配器回填输入。
    ctx.adapter.hydrateInput(ctx, draft);
    ctx.baselineBatchItems = batchItemsProjection();
    // 6) 所有原输入结构进入共享 wizardStructures/previewViewer；默认选中
    //    第一项（BatchOptimize 保留完整输入顺序），界面只显示「任务结构」。
    hydrateTaskStructures(ctx, draft);
    ctx.activeSourceTab = "task";
    setWizardInputMode("task");
    updateEditModeTabs();
    updateConfigCards();
    if (spec.workflow === "scan" && typeof syncScanSelectionFromWizard === "function") {
      syncScanSelectionFromWizard(false);
    }
    if (spec.workflow === "PESsearch" && spec.method.mode === "bond_length_scan" &&
      typeof pesSelectionState !== "undefined") {
      if (typeof syncPESSelectionFromWizard === "function") syncPESSelectionFromWizard(false);
      var request = inp.scan_request || {};
      var coordinate = inp.coordinate || request.coordinate || {};
      var selection = inp.selection || request.selection || {};
      pesSelectionState.selectionKind = selection.kind ||
        (coordinate.kind === "angle" ? "angle" : coordinate.kind === "dihedral" ? "dihedral" : "bond_stretch");
      pesSelectionState.selectedAtoms = deepCopy(selection.atom_indices || coordinate.atoms || []);
      if (typeof syncPESSelectionFromWizard === "function") syncPESSelectionFromWizard(false);
    }
    ctx.methodBaseline = ctx.adapter.methodProjection();
    ctx.baselineFormState = formProjection();
    renderOriginalInputPanel();
    setEditStep(1);
  }

  // ---------------------------------------------------------------------------
  // 序列化：originalSpec + 用户实际修改字段的 patch（复用页面收集函数）
  // ---------------------------------------------------------------------------

  function serializeFromCollectedBody(body) {
    var ctx = editorContext;
    var spec = ctx.originalSpec;
    var workflow = selectedWorkflow(ctx);
    var changedWorkflow = workflowChanged(ctx);
    var selectionError = workflowSelectionError(workflow);
    if (selectionError) throw new Error(selectionError);
    if (changedWorkflow && (!body || body.workflow !== workflow || !body.input || !body.method)) {
      throw new Error(t("edit.no_payload_collected"));
    }
    // A different workflow is a new calculation contract. Use its existing
    // submit builder instead of merging the source workflow's frozen input.
    var method = changedWorkflow ? deepCopy(body.method) : serializeMethod(ctx, body);
    var out = {
      mode: ctx.executionMode,
      workflow: workflow,
      input: changedWorkflow ? deepCopy(body.input) : serializeInput(ctx, body),
      method: method,
      method_projection_changed: changedWorkflow || !deepEqual(ctx.adapter.methodProjection(), ctx.methodBaseline),
      resources: serializeResources(ctx, body),
      // molecule_name 不是表单可编辑字段：原值优先，保证未修改 diff 为零。
      molecule_name: spec.molecule_name || (body && body.molecule_name) || "",
      task_name: (body && body.task_name) || (changedWorkflow ? workflow : ""),
      remark: (body && body.remark) || "",
      tags: (body && body.tags && body.tags.length) ? body.tags : deepCopy(spec.tags || []),
      request_id: ctx.requestId || newRequestId(),
      expected_source_revision: ctx.draft.source_revision,
    };
    if (ctx.executionMode === "new_job") {
      out.project_id = (body && body.project_id) || spec.project_id;
      if (body && body.name) out.name = String(body.name);
    }
    if (typeof applyNodeSelectionToBody === "function") applyNodeSelectionToBody(out);
    if (ctx.fingerprint) out.preview_fingerprint = ctx.fingerprint;
    return out;
  }

  // 未修改 → 原 method 逐字返回；修改 → 原 method + patch。
  function serializeMethod(ctx, body) {
    var current = ctx.adapter.methodProjection();
    if (deepEqual(current, ctx.methodBaseline)) {
      return deepCopy(ctx.originalSpec.method || {});
    }
    return ctx.adapter.buildMethod(ctx, body, current);
  }

  // 资源同理：未修改 → 原资源逐字返回（防止表单未覆盖的键被误删）。
  function serializeResources(ctx, body) {
    var original = deepCopy((ctx.originalSpec.resources || {}));
    var r = deepCopy(body && body.resources) || {};
    delete r.batch_id;
    delete r.batch_index;
    delete r.batch_total;
    var base = ctx.baselineFormState || {};
    var changed = false;
    ["nproc", "mem", "parallelism"].forEach(function (k) {
      var cur = (k === "nproc" || k === "parallelism")
        ? String(parseInt(String(r[k] !== undefined ? r[k] : ""), 10) || "")
        : String(r[k] !== undefined ? r[k] : "");
      if (cur && cur !== String(base[k] !== undefined ? base[k] : "")) changed = true;
    });
    if (!changed) return original;
    var out = original;
    if (has(r, "nproc")) out.nproc = parseInt(String(r.nproc), 10) || original.nproc;
    if (has(r, "mem")) out.mem = r.mem;
    if (has(r, "parallelism")) out.parallelism = parseInt(String(r.parallelism), 10) || original.parallelism;
    return out;
  }

  function serializeInput(ctx, body) {
    var spec = ctx.originalSpec;
    var orig = spec.input || {};
    var kind = ctx.sourceSelection.kind;
    if (kind === "last_structure") {
      var ls = ((ctx.draft && ctx.draft.input_refs) || {}).last_structure;
      if (!ls || !ls.xyz_text) throw new Error(t("edit.last_structure_missing"));
      var selectedLast = ctx.sourceSelection.payload || {};
      var sourceRef = deepCopy(selectedLast.source_ref || ls.source_ref || {});
      return patchOriginalChargeMult(ctx, {
        source_type: "xyz_text",
        source: selectedLast.xyz || selectedLast.xyz_text || ls.xyz_text,
        charge: orig.charge,
        multiplicity: orig.multiplicity,
        source_ref: sourceRef,
        edit_input_origin: {
          mode: "last_structure",
          entry_id: ls.entry_id,
          source_id: sourceRef.source_id || "",
        },
      }, body);
    }
    if (kind === "path_frame") {
      var selectedPath = ctx.sourceSelection.payload || {};
      var xyz = String(selectedPath.xyz || selectedPath.xyz_text || "");
      if (!xyz.trim()) throw new Error(t("edit.path_geometry_missing"));
      var charge = has(selectedPath, "charge") ? selectedPath.charge : 0;
      var multiplicity = has(selectedPath, "multiplicity") ? selectedPath.multiplicity : 1;
      var pathOrigin = deepCopy(selectedPath.edit_input_origin || {});
      var pathRef = deepCopy(selectedPath.source_ref || {});
      if (spec.workflow === "BatchOptimize") {
        return {
          source_type: "batch_structures",
          charge: charge,
          multiplicity: multiplicity,
          items: [{
            item_id: selectedPath.item_id || "path_frame_001",
            candidate_id: selectedPath.candidate_id || selectedPath.item_id || "path_frame_001",
            name: selectedPath.name || "Reaction path frame",
            tag: selectedPath.tag || "INT",
            xyz: xyz,
            charge: charge,
            multiplicity: multiplicity,
            include: true,
            source_ref: pathRef,
          }],
          edit_input_origin: pathOrigin,
        };
      }
      return {
        source_type: "xyz_text",
        source: xyz,
        charge: charge,
        multiplicity: multiplicity,
        source_ref: pathRef,
        edit_input_origin: pathOrigin,
      };
    }
    if (kind === "original_input") {
      var overlay = deepCopy(orig);
      if (ctx.adapter.patchOriginalInput) {
        overlay = ctx.adapter.patchOriginalInput(ctx, overlay, body);
      }
      return overlay;
    }
    // structure / results / upload → 替换输入：使用新解析/选择的载荷。
    if (!(body && body.input)) throw new Error(t("edit.no_payload_collected"));
    return body.input;
  }

  function newRequestId() {
    return "ed_" + editorContext.sourceJobId + "_" + Date.now().toString(36) +
      "_" + Math.random().toString(36).slice(2, 8);
  }

  // ---------------------------------------------------------------------------
  // api() 拦截：编辑模式下 POST /jobs 进入收集/预览，而不是真创建。
  // 正常用户路径（#modal-submit → checkAndSubmit）总是 collecting=true；
  // 此拦截保留为安全防护。
  // ---------------------------------------------------------------------------

  function interceptJobCreate(body) {
    var ctx = editorContext;
    if (!ctx || !ctx.collecting) {
      return Promise.reject(new Error(t("edit.create_blocked_in_editor")));
    }
    ctx.collectedBodies.push(deepCopy(body));
    return Promise.resolve({ job_id: "__edit_collected__", status: "collected", __editCollected: true });
  }

  // ---------------------------------------------------------------------------
  // 检查并提交（唯一提交入口，由 #modal-submit 分发）→ 预览 → 摘要确认 → 提交
  // ---------------------------------------------------------------------------

  function withModalHeld(fn) {
    var original = window.closeModal;
    window.closeModal = function () { /* held during collection */ };
    return Promise.resolve().then(fn).then(function (v) {
      window.closeModal = original;
      return v;
    }, function (e) {
      window.closeModal = original;
      throw e;
    });
  }

  function modalSubmitBtn() { return document.getElementById("modal-submit"); }

  function currentStep() {
    return editorContext ? (Number(editorContext.editStep) || 1) : 1;
  }

  function setEditStep(step) {
    var ctx = editorContext;
    var modal = document.getElementById("job-modal");
    if (!ctx || !modal) return false;
    var requested = Math.max(1, Math.min(3, Number(step) || 1));
    var current = currentStep();
    // Keep forward navigation sequential; the stepper remains a shortcut back
    // to sections the user has already reached.
    if (requested > current + 1) return false;
    ctx.editStep = requested;
    if (typeof createWizardStep !== "undefined") createWizardStep = requested;
    modal.setAttribute("data-create-step", String(requested));
    modal.querySelectorAll(".create-step").forEach(function (button) {
      var buttonStep = Number(button.getAttribute("data-create-step"));
      button.classList.toggle("active", buttonStep === requested);
      button.classList.toggle("completed", buttonStep < requested);
      if (buttonStep === requested) button.setAttribute("aria-current", "step");
      else button.removeAttribute("aria-current");
    });
    var back = document.getElementById("modal-back");
    if (back) back.style.display = requested > 1 ? "inline-flex" : "none";
    var taskInfo = modal.querySelector(".task-info-details");
    if (taskInfo) taskInfo.open = requested === 2;
    if (typeof _closeInputListOverlay === "function") _closeInputListOverlay();
    if (typeof updatePESSelectionVisibility === "function") updatePESSelectionVisibility();
    renderEditStepCompactSummary(ctx);
    if (requested === 3) renderEditStepReview(ctx);
    updateModalSubmitButton();
    updateEditorUiState();
    var body = modal.querySelector(".modal-body");
    if (body) body.scrollTop = 0;
    if (previewViewer && requested < 3) {
      requestAnimationFrame(function () {
        try { previewViewer.resize(); previewViewer.render(); } catch (e) {}
      });
    }
    return true;
  }

  function renderEditStepCompactSummary(ctx) {
    var summary = document.getElementById("wizard-step-summary");
    var inner = document.getElementById("wizard-step-summary-inner");
    if (!summary || !inner || !ctx) return;
    if (ctx.editStep < 2) {
      summary.style.display = "none";
      return;
    }
    var isBatch = ctx.originalSpec.workflow === "BatchOptimize";
    var rows = isBatch && typeof batchPreviewItems !== "undefined"
      ? batchPreviewItems.filter(function (item) { return item && item.include !== false; })
      : [];
    var names = rows.length
      ? rows.map(function (item) {
        var role = item.tag === "TS" ? "TS" : (item.tag === "INT" ? "INT" : "—");
        return (item.name || "structure") + " · " + role;
      })
      : (typeof wizardStructures !== "undefined" ? wizardStructures : []).map(function (item) {
        return (item.name || item.molecule_name || "structure") +
          (item.tag ? " · " + item.tag : "");
      });
    var zh = typeof currentLang !== "undefined" && currentLang === "zh-CN";
    var listHtml = names.slice(0, 20).map(function (name) {
      return '<div class="wizard-step-summary-item">' + escapeHtml(name) + "</div>";
    }).join("");
    inner.innerHTML = '<div class="wizard-step-summary-label">' +
      (zh ? "本次重算输入" : "Inputs for recalculation") +
      '</div><div class="wizard-step-summary-count">' + names.length +
      '</div><div class="wizard-step-summary-label">' +
      (names.length === 1 ? (zh ? "个结构" : "structure") : (zh ? "个结构" : "structures")) +
      '</div>' + (listHtml ? '<div class="wizard-step-summary-list">' + listHtml + "</div>" : "");
    summary.style.display = "flex";
  }

  function renderEditStepReview(ctx) {
    var target = document.getElementById("create-review-summary");
    if (!target || !ctx) return;
    var zh = typeof currentLang !== "undefined" && currentLang === "zh-CN";
    var workflow = (wizardState.workflow && wizardState.workflow.label) || ctx.originalSpec.workflow || "—";
    var methodTitle = (document.getElementById("method-card-title") || {}).textContent || "—";
    var methodDesc = (document.getElementById("method-card-desc") || {}).textContent || "";
    var projectSelect = document.getElementById("modal-project-select");
    var projectName = projectSelect && projectSelect.selectedOptions.length
      ? projectSelect.selectedOptions[0].textContent : "—";
    var isBatch = ctx.originalSpec.workflow === "BatchOptimize";
    var batchRows = isBatch && typeof batchPreviewItems !== "undefined"
      ? batchPreviewItems.filter(function (item) { return item && item.include !== false; })
      : [];
    var inputRows = batchRows.length
      ? batchRows.map(function (item, index) {
        var name = item.name || item.itemId || ("#" + (index + 1));
        var role = item.tag === "TS" ? "TS" : (item.tag === "INT" ? "INT" : "—");
        var charge = has(item, "charge") ? item.charge : 0;
        var mult = has(item, "multiplicity") ? item.multiplicity : 1;
        return name + " [" + role + "] q" + charge + "/m" + mult;
      })
      : (typeof wizardStructures !== "undefined" ? wizardStructures : []).map(function (item, index) {
        var role = item.tag === "TS" ? "TS" : (item.tag === "INT" ? "INT" : (zh ? "普通" : "Normal"));
        return (item.name || item.molecule_name || ("#" + (index + 1))) +
          " [" + role + "] q" + (item.charge === undefined ? 0 : item.charge) +
          "/m" + (item.multiplicity || 1);
      });
    var inputSummary = inputRows.length ? inputRows.join("；") : (zh ? "沿用原任务输入" : "Original task input");
    var sourceSummary = selectedSourceSummary(ctx);
    var resources = fieldVal("modal-nproc") + " " + (zh ? "核" : "cores") +
      " · " + (ACPMemoryInput.format("modal-mem", "modal-mem-unit") || "—") + " · " + (zh ? "并行" : "parallel") + " " +
      (fieldVal("modal-parallelism") || "1");
    var changedCount = countLocalChanges();
    var taskName = fieldVal("modal-task-name").trim() || ctx.originalSpec.task_name || "—";
    var remark = fieldVal("modal-remark").trim() || "—";
    var checkHint = zh
      ? "点击“检查并提交”后会生成服务端参数差异与风险检查；确认后才会开始重算。"
      : "Check and submit generates the server-side parameter diff and risk review; recalculation starts only after confirmation.";
    var changedLabel = zh ? "已修改项目" : "Changed items";
    var modeLabel = ctx.executionMode === "new_job"
      ? (zh ? "创建新任务" : "Create a new task")
      : (zh ? "原地重算" : "Recalculate in place");
    target.innerHTML = '<div class="create-review-grid">' +
      '<span class="muted">' + (zh ? "目标项目" : "Target project") + '</span><strong>' + escapeHtml(projectName) + '</strong>' +
      '<span class="muted">' + (zh ? "输入结构" : "Input structures") + '</span><div>' + escapeHtml(inputSummary) + '</div>' +
      '<span class="muted">' + t("edit.source_label") + '</span><div>' + escapeHtml(sourceSummary) + '</div>' +
      '<span class="muted">' + (zh ? "工作流" : "Workflow") + '</span><strong>' + escapeHtml(workflow) + '</strong>' +
      '<span class="muted">' + (zh ? "计算方案" : "Calculation method") + '</span><div><strong>' + escapeHtml(methodTitle) + '</strong>' +
      (methodDesc ? '<div class="muted">' + escapeHtml(methodDesc) + '</div>' : "") + '</div>' +
      '<span class="muted">' + (zh ? "资源" : "Resources") + '</span><div>' + escapeHtml(resources) + '</div>' +
      '<span class="muted">' + (zh ? "任务名" : "Task name") + '</span><div>' + escapeHtml(taskName) + '</div>' +
      '<span class="muted">' + (zh ? "备注" : "Remark") + '</span><div>' + escapeHtml(remark) + '</div>' +
      '<span class="muted">' + (zh ? "执行方式" : "Execution mode") + '</span><div>' + escapeHtml(modeLabel) + '</div>' +
      '<span class="muted">' + changedLabel + '</span><strong>' + changedCount + '</strong>' +
      '</div><div class="edit-banner-hint">' + escapeHtml(checkHint) + '</div>';
  }

  function setFooterBusy(busy) {
    var btn = modalSubmitBtn();
    if (btn) btn.disabled = !!busy;
  }

  // kind=original / last_structure 的收集通道：serializeInput 不消费
  // body.input（原样透传或服务端快照），页面收集器的结构前置校验
  // （解析结构 / PES 选原子 / NMR 实验谱）不应阻断无修改重算 —— 表单
  // 公共字段直接读取，不路由 submitJobModal。
  function collectFormOnlyBody(ctx) {
    var spec = (ctx || editorContext).originalSpec;
    var taskName = fieldVal("modal-task-name").trim()
      .replace(/[/\\:*?"<>|]/g, "")
      .replace(/\s+/g, "_")
      .replace(/^_+|_+$/g, "");
    var body = {
      workflow: spec.workflow,
      remark: fieldVal("modal-remark").trim(),
      task_name: taskName,
      molecule_name: spec.molecule_name || "",
      input: {
        charge: Number(fieldVal("modal-charge")),
        multiplicity: Number(fieldVal("modal-mult")),
      },
      resources: {
        nproc: parseInt(fieldVal("modal-nproc"), 10) || 4,
        mem: ACPMemoryInput.read("modal-mem", "modal-mem-unit"),
      },
      tags: [],
    };
    var parEl = document.getElementById("modal-parallelism");
    if (parEl) body.resources.parallelism = Math.max(1, parseInt(fieldVal("modal-parallelism"), 10) || 1);
    var ps = document.getElementById("modal-project-select");
    if (ps && ps.value) body.project_id = ps.value;
    return body;
  }

  function collectViaPageCollectors(ctx) {
    return withModalHeld(function () {
      if (ctx.adapter.preCollect) ctx.adapter.preCollect(ctx);
      return submitJobModal();
    }).then(function () {
      ctx.collecting = false;
      if (!editorContext || editorContext.requestToken !== ctx.requestToken) return null;
      if (!ctx.collectedBodies.length) {
        throw new Error(t("edit.no_payload_collected"));
      }
      if (ctx.collectedBodies.length > 1) {
        throw new Error(t("edit.multi_structure_not_supported"));
      }
      return ctx.collectedBodies[0];
    });
  }

  function checkAndSubmit() {
    var ctx = editorContext;
    if (!ctx || ctx.submitting || ctx.collecting) return;
    if (!ctx.draft) return;
    if (!(ctx.draft.capabilities || {}).can_edit) return;
    var selectionError = workflowSelectionError(selectedWorkflow(ctx));
    if (selectionError) {
      window.alert(t("edit.preview_failed") + ": " + selectionError);
      return;
    }
    if (!ACPMemoryInput.read("modal-mem", "modal-mem-unit")) return;
    if (ctx.editStep < 3) {
      setEditStep(ctx.editStep + 1);
      return;
    }
    ctx.requestId = null;
    var passiveKind = !workflowChanged(ctx) && (ctx.sourceSelection.kind === "original_input" ||
      ctx.sourceSelection.kind === "last_structure" ||
      ctx.sourceSelection.kind === "path_frame");
    var collecting = passiveKind ? Promise.resolve(collectFormOnlyBody()) : null;
    if (passiveKind) {
      ctx.collecting = false;
    } else {
      ctx.collecting = true;
      ctx.collectedBodies = [];
    }
    setFooterBusy(true);
    var bodyPromise = passiveKind ? collecting : collectViaPageCollectors(ctx);
    bodyPromise.then(function (collectedBody) {
      if (!editorContext || editorContext.requestToken !== ctx.requestToken) return;
      if (!collectedBody) return;
      return runPreview(collectedBody);
    }).then(function (preview) {
      if (!editorContext || editorContext.requestToken !== ctx.requestToken) return;
      if (!preview) return;
      ctx.pendingPreviewBody = passiveKind ? collectFormOnlyBody() : ctx.collectedBodies[0];
      ctx.fingerprint = preview.preview_fingerprint;
      showSummary(preview);
    }).catch(function (err) {
      ctx.collecting = false;
      window.alert(t("edit.preview_failed") + ": " + ((err && err.message) || err));
    }).then(function () {
      if (editorContext && editorContext.requestToken === ctx.requestToken && !ctx.submitting) {
        setFooterBusy(false);
        updateEditorUiState();
      }
    });
  }

  function runPreview(collectedBody) {
    var ctx = editorContext;
    var payload = serializeFromCollectedBody(collectedBody);
    return apiRemote("/jobs/" + encodeURIComponent(ctx.sourceJobId) + "/edit-recalculate/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }).then(function (preview) {
      if (preview && preview.blocking_reasons && preview.blocking_reasons.length) {
        throw new Error(preview.blocking_reasons.join("\n"));
      }
      return preview;
    });
  }

  function finalSubmit() {
    var ctx = editorContext;
    if (!ctx || !ctx.pendingPreviewBody || ctx.submitting) return;
    ctx.submitting = true;
    setFooterBusy(true);
    var okBtn = document.getElementById("edit-summary-confirm");
    if (okBtn) okBtn.disabled = true;
    var payload = serializeFromCollectedBody(ctx.pendingPreviewBody);
    ctx.requestId = payload.request_id;
    apiRemote("/jobs/" + encodeURIComponent(ctx.sourceJobId) + "/edit-recalculate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }).then(function (result) {
      editorContext = null;
      stopBadgeWatch();
      hideSummary();
      renderBanner("hidden");
      hideFooter();
      hideOriginalPanelExtras();
      updateModalSubmitButton();
      closeModal();
      if (typeof setDetailActionMessage === "function") {
        setDetailActionMessage(
          result.job_id,
          t(result.operation === "new_job" ? "edit.submit_new_ok" : "edit.submit_inplace_ok",
            { attempt: String(result.attempt) }),
          "ok"
        );
      }
      return refreshJobs();
    }, function (err) {
      // 请求失败保留草稿与错误（计划 §4.2）。
      ctx.submitting = false;
      setFooterBusy(false);
      if (okBtn) okBtn.disabled = false;
      var el = document.getElementById("edit-summary-error");
      if (el) {
        el.style.display = "block";
        el.textContent = t("edit.submit_failed") + ": " + ((err && err.message) || err);
      } else {
        window.alert(t("edit.submit_failed") + ": " + ((err && err.message) || err));
      }
    });
  }

  // ---------------------------------------------------------------------------
  // 脏状态：回填完成后的表单基线 vs 当前表单（权威差异以服务端预览为准）
  // ---------------------------------------------------------------------------

  function fieldVal(id) {
    var el = document.getElementById(id);
    return el ? String(el.value || "") : "";
  }

  function formProjection() {
    var ctx = editorContext;
    var nmrText = "";
    if (ctx && ctx.originalSpec && ctx.originalSpec.workflow === "nmr") {
      var ta = document.getElementById("nmr-experiment-text");
      nmrText = ta ? String(ta.value || "") : "";
    }
    // BatchOptimize 电子态按条目在批量表中维护（batch_items 已覆盖）；
    // 全局 charge/mult 只是"应用到全部"的辅助输入，单独改动不构成脏状态。
    var isBatch = !!(ctx && ctx.originalSpec &&
      ctx.originalSpec.workflow === "BatchOptimize");
    return {
      workflow: selectedWorkflow(ctx),
      remark: fieldVal("modal-remark"),
      task_name: fieldVal("modal-task-name").trim(),
      nproc: fieldVal("modal-nproc"),
      mem: ACPMemoryInput.format("modal-mem", "modal-mem-unit"),
      parallelism: fieldVal("modal-parallelism"),
      charge: isBatch ? null : fieldVal("modal-charge"),
      mult: isBatch ? null : fieldVal("modal-mult"),
      project_id: fieldVal("modal-project-select"),
      method: ctx && ctx.adapter ? ctx.adapter.methodProjection() : null,
      source_kind: ctx ? ctx.sourceSelection.kind : null,
      original_task_structure: originalTaskStructureProjection(ctx),
      batch_items: ctx ? batchItemsProjection() : null,
      nmr_experiment_text: nmrText,
      nmr_candidates: ctx && ctx.originalSpec.workflow === "nmr" ? nmrCandidatesProjection() : null,
      nmr_enumerate: !!(document.getElementById("nmr-enumerate-toggle") || {}).checked,
      nmr_stereocenters: fieldVal("nmr-enumerate-centers").trim(),
      pes_selection: ctx && ctx.originalSpec.workflow === "PESsearch" &&
        typeof pesSelectionState !== "undefined" ? {
          kind: pesSelectionState.selectionKind,
          atoms: pesSelectionState.selectedAtoms.slice(),
        } : null,
    };
  }

  function countLocalChanges() {
    var ctx = editorContext;
    if (!ctx || !ctx.draft || !ctx.baselineFormState) return 0;
    var base = ctx.baselineFormState;
    var proj = formProjection();
    var count = 0;
    Object.keys(proj).forEach(function (key) {
      if (key === "nmr_experiment_text") {
        if (proj[key] !== base[key]) count++;
        return;
      }
      if (key === "batch_items") {
        if (!deepEqual(proj[key], ctx.baselineBatchItems)) count++;
        return;
      }
      if (!deepEqual(proj[key], base[key])) count++;
    });
    return count;
  }

  // ---------------------------------------------------------------------------
  // 来源页签联动：界面始终只有任务结构 / 结构输入 / 上传三个入口。
  // ---------------------------------------------------------------------------

  var SOURCE_TAB_KINDS = { task: 1, structure: 1, upload: 1 };

  function saveActiveSourceDraft(ctx) {
    var tab = ctx.activeSourceTab;
    if (tab === "task") {
      if (ctx.sourceSelection.kind === "path_frame" && ctx.sourceSelection.payload) {
        ctx.pathSourceDraft = deepCopy(ctx.sourceSelection.payload);
      }
      return;
    }
    if (tab !== "structure" && tab !== "upload") return;
    var draft = ctx.sourceDrafts[tab] || {};
    draft.text = tab === "structure" ? fieldVal("modal-structure-input") : "";
    draft.structures = typeof wizardStructures !== "undefined" ? deepCopy(wizardStructures) : [];
    draft.selectedIndex = typeof wizardSelectedStructureIndex !== "undefined"
      ? wizardSelectedStructureIndex : 0;
    draft.applied = ctx.sourceSelection.kind === (tab === "structure" ? "manual_input" : "upload");
    ctx.sourceDrafts[tab] = draft;
  }

  function restoreSourceDraft(ctx, tab) {
    var draft = ctx.sourceDrafts[tab];
    if (!draft || !draft.applied || !draft.structures.length) return;
    wizardStructures = deepCopy(draft.structures);
    wizardSelectedStructureIndex = Math.min(
      draft.selectedIndex || 0, Math.max(wizardStructures.length - 1, 0)
    );
    wizardParseWarnings = [];
    renderStructurePreview(wizardStructures, wizardParseWarnings);
    ctx.sourceSelection = {
      kind: tab === "structure" ? "manual_input" : "upload",
      payload: wizardStructures[wizardSelectedStructureIndex] || wizardStructures[0] || null,
    };
  }

  function onSourceTabChange(kind) {
    var ctx = editorContext;
    if (!ctx || !SOURCE_TAB_KINDS[kind]) return;
    var pathPanel = document.getElementById("edit-path-structures");
    if (pathPanel && kind !== "task") pathPanel.style.display = "none";
    if (ctx.activeSourceTab === kind) return;
    var prev = ctx.sourceSelection.kind;
    saveActiveSourceDraft(ctx);
    ctx.activeSourceTab = kind;
    if (kind === "task") {
      if (ctx.pathSourceDraft) {
        wizardStructures = [deepCopy(ctx.pathSourceDraft)];
        wizardSelectedStructureIndex = 0;
        wizardParseWarnings = [];
        renderStructurePreview(wizardStructures, wizardParseWarnings);
        ctx.sourceSelection = { kind: "path_frame", payload: wizardStructures[0] };
      } else {
        hydrateTaskStructures(ctx, ctx.draft);
      }
    } else {
      restoreSourceDraft(ctx, kind);
    }
    updateDefaultStartBadge(ctx, ctx.sourceSelection.payload);
    // BatchOptimize：仅在返回任务结构时恢复基线。单纯查看“结构输入/上传”
    // 不改变批量清单，避免页签切换被误判为一次结构修改。
    if (ctx.originalSpec.workflow === "BatchOptimize" &&
      typeof batchPreviewItems !== "undefined") {
      if (kind === "task" && prev !== "original_input" && prev !== "last_structure") {
        restoreBatchItems(ctx.baselineBatchItems);
      }
    }
    syncSourceExecutionMode(ctx);
    updateEditorUiState();
  }

  function onParsedSourceApplied(kind, structures) {
    var ctx = editorContext;
    if (!ctx || (kind !== "structure" && kind !== "upload") || !structures || !structures.length) return;
    var semanticKind = kind === "structure" ? "manual_input" : "upload";
    structures.forEach(function (structure) { structure.source_kind = semanticKind; });
    ctx.activeSourceTab = kind;
    ctx.sourceSelection = {
      kind: semanticKind,
      payload: structures[wizardSelectedStructureIndex] || structures[0] || null,
    };
    updateDefaultStartBadge(ctx, ctx.sourceSelection.payload);
    ctx.sourceDrafts[kind] = {
      applied: true,
      text: kind === "structure" ? fieldVal("modal-structure-input") : "",
      structures: deepCopy(structures),
      selectedIndex: wizardSelectedStructureIndex || 0,
    };
    syncSourceExecutionMode(ctx);
    updateEditorUiState();
  }

  function onPreviewStructureSelected(structure) {
    var ctx = editorContext;
    if (!ctx || !structure) return;
    var kind = structure.source_kind || "";
    if (kind === "last_structure") {
      ctx.sourceSelection = { kind: "last_structure", payload: structure };
    } else if (kind === "job_result" || kind === "task_result" || kind === "saved_candidate") {
      ctx.sourceSelection = { kind: "job_result", payload: structure };
    } else if (kind === "path_frame") {
      ctx.sourceSelection = { kind: "path_frame", payload: structure };
    } else if (wizardInputMode === "task") {
      ctx.sourceSelection = { kind: "original_input", payload: structure };
    }
    updateDefaultStartBadge(ctx, structure);
    syncSourceExecutionMode(ctx);
    updateEditorUiState();
  }

  function onJobResultLoaded(structure) {
    var ctx = editorContext;
    if (!ctx) return;
    if (structure) structure.source_kind = "job_result";
    ctx.activeSourceTab = "task";
    ctx.sourceSelection = { kind: "job_result", payload: structure || null };
    updateDefaultStartBadge(ctx, structure);
    syncSourceExecutionMode(ctx);
    updateEditorUiState();
  }

  function restoreBatchItems(projection) {
    if (typeof batchPreviewItems === "undefined") return;
    batchPreviewItems = (projection || []).map(function (p) {
      return {
        key: "edit_" + Math.random().toString(36).slice(2, 10),
        itemId: p.item_id || "",
        include: p.include !== false,
        name: p.name,
        tag: p.tag,
        tagAuto: false,
        xyz: p.xyz,
        charge: p.charge !== undefined ? p.charge : 0,
        multiplicity: p.multiplicity !== undefined ? p.multiplicity : 1,
        atomCount: 0,
        formula: "",
        sourceType: "upload",
        sourceRef: "",
      };
    });
    if (typeof renderStageBatchPreview === "function") renderStageBatchPreview();
  }

  function updateEditModeTabs() {
    var ctx = editorContext;
    var modal = document.getElementById("job-modal");
    updateDefaultStartBadge(ctx, ctx && ctx.sourceSelection && ctx.sourceSelection.payload);
    var pathPanel = document.getElementById("edit-path-structures");
    if (pathPanel) {
      pathPanel.style.display = ctx && Array.isArray(ctx.pathFrameSources) && ctx.pathFrameSources.length &&
        ctx.activeSourceTab === "task" &&
        ctx.mode === "edit_recalculate" &&
        supportsReactionPathInput(ctx.originalSpec && ctx.originalSpec.workflow) ? "flex" : "none";
    }
    if (modal) modal.classList.toggle("edit-mode", !!ctx);
    var stepper = document.getElementById("create-stepper");
    if (stepper) stepper.setAttribute("aria-label", ctx ? "修改参数后重算步骤" : "新建任务步骤");
    var copyButton = document.getElementById("edit-original-copy");
    if (copyButton) copyButton.style.display = ctx ? "" : "none";
    var title = document.getElementById("job-modal-title");
    if (!title) return;
    if (ctx) {
      title.removeAttribute("data-i18n");
      title.textContent = t("edit.title");
    } else {
      title.setAttribute("data-i18n", "modal.title");
      title.textContent = t("modal.title");
    }
  }

  function hideOriginalPanelExtras() {
    updateEditModeTabs();
  }

  // 「上次输入」只读摘要面板。
  function renderOriginalInputPanel() {
    var ctx = editorContext;
    if (!ctx || !ctx.draft) return;
    var panel = document.getElementById("edit-original-summary");
    if (!panel) return;
    var spec = ctx.originalSpec;
    var inp = spec.input || {};
    var kind = inputKind(inp);
    var html = [];
    html.push('<div class="edit-banner-hint"><b>' + escapeHtml(t("edit.input_original")) +
      "</b> · " + escapeHtml(kind) + "</div>");
    if (ctx.originalSpec.workflow === "BatchOptimize" && Array.isArray(inp.items)) {
      var int = 0, ts = 0;
      inp.items.forEach(function (item) {
        if (item.tag === "TS") ts++;
        else int++;
      });
      html.push('<div class="edit-banner-hint">' +
        escapeHtml(t("edit.original_items_summary", {
          total: String(inp.items.length), int: String(int), ts: String(ts),
        })) + "</div>");
      html.push('<div class="edit-items"><details open><summary>' +
        escapeHtml(t("edit.batch_items_summary", { total: String(inp.items.length) })) +
        '</summary><div class="edit-items-list">');
      inp.items.forEach(function (item, i) {
        var name = item.name || item.candidate_id || ("#" + (i + 1));
        var tag = item.tag ? " [" + item.tag + "]" : "";
        var cm = (has(item, "charge") || has(item, "multiplicity"))
          ? " · q" + (has(item, "charge") ? item.charge : 0) +
            "/m" + (has(item, "multiplicity") ? item.multiplicity : 1)
          : "";
        html.push('<div class="edit-radio">' + escapeHtml(name + tag + cm) + "</div>");
      });
      html.push("</div></details></div>");
      html.push('<div class="edit-banner-hint">' +
        escapeHtml(t("edit.batch_panel_hint")) + "</div>");
      html.push('<div class="edit-banner-hint edit-warn">' +
        escapeHtml(t("edit.batch_reaction_scope")) + "</div>");
    } else if (kind === "stage_artifact") {
      html.push('<div class="edit-banner-hint edit-banner-source">source_job_id: ' +
        escapeHtml(String(inp.source_job_id || "—")) + "</div>");
      html.push('<div class="edit-banner-hint">from_artifact: ' +
        escapeHtml(String(inp.from_artifact || "—")) + "</div>");
    } else if (kind === "candidates" && Array.isArray(inp.candidates)) {
      html.push('<div class="edit-banner-hint">candidates: ' +
        String(inp.candidates.length) + "</div>");
      if (inp.experiment) {
        html.push('<div class="edit-banner-hint">experiment: ' +
          escapeHtml(String(inp.experiment.mode || "")) + "</div>");
      }
    } else if (kind === "scan_request" && inp.scan_request) {
      html.push('<div class="edit-banner-hint">scan_request · source: ' +
        escapeHtml(String((inp.scan_request.source || {}).source_type ||
          inputKind(inp.scan_request.source))) + "</div>");
    } else {
      var text = String(has(inp, "source") ? inp.source :
        (has(inp, "smiles") ? inp.smiles : ""));
      if (text) {
        var truncated = text.length > 600 ? text.slice(0, 600) + "\n…" : text;
        html.push('<pre class="edit-original-preview">' + escapeHtml(truncated) + "</pre>");
      }
      if (has(inp, "charge") || has(inp, "multiplicity")) {
        html.push('<div class="edit-banner-hint">charge: ' +
          (has(inp, "charge") ? String(inp.charge) : "—") +
          " · multiplicity: " +
          (has(inp, "multiplicity") ? String(inp.multiplicity) : "—") + "</div>");
      }
    }
    panel.innerHTML = html.join("");
  }

  // 「复制到结构输入并修改」：原始 XYZ 复制进结构框并切换为替换来源。
  function copyOriginalToStructureInput() {
    var ctx = editorContext;
    if (!ctx || !ctx.draft) return;
    var box = document.getElementById("modal-structure-input");
    var selected = (typeof wizardStructures !== "undefined")
      ? (wizardStructures[wizardSelectedStructureIndex] || wizardStructures[0]) : null;
    var text = selected ? String(selected.xyz || "") : "";
    if (!text || !box) return;
    box.value = text;
    setWizardInputMode("structure");
    if (typeof scheduleParseStructures === "function") scheduleParseStructures();
  }

  // ---------------------------------------------------------------------------
  // Banner（只保留上下文）/ Footer（执行方式 + 修改计数）
  // ---------------------------------------------------------------------------

  function bannerEl() { return document.getElementById("edit-recalc-banner"); }
  function footerEl() { return document.getElementById("edit-recalc-footer"); }

  function renderBanner(state, errorMessage) {
    var el = bannerEl();
    if (!el) return;
    if (state === "hidden") { el.style.display = "none"; el.innerHTML = ""; return; }
    el.style.display = "block";
    var ctx = editorContext;
    if (state === "loading") {
      el.innerHTML = '<div class="edit-banner edit-banner-loading">' + t("edit.loading_draft") + "</div>";
      return;
    }
    if (state === "error") {
      el.innerHTML = '<div class="edit-banner edit-banner-error">' +
        t("edit.load_failed", { message: errorMessage || "" }) + "</div>";
      return;
    }
    var d = ctx.draft;
    var caps = d.capabilities || {};
    if (!caps.can_edit) {
      renderViewOnlyBanner(d);
      return;
    }
    var sourceName = (ctx.sourceJob && (ctx.sourceJob.resolved_name || ctx.sourceJob.custom_name)) ||
      ctx.sourceJobId;
    var htmlParts = ['<div class="edit-banner edit-banner-ready">'];
    htmlParts.push('<div class="edit-banner-source">' +
      t("edit.banner_source", {
        name: sourceName,
        status: t("status." + d.job_status) || d.job_status,
        attempt: String(d.attempt),
      }));
    var effKey = effectiveConfigHintKey(ctx.effectiveConfig);
    if (effKey) htmlParts.push('<span class="edit-context-meta">' + t(effKey) + "</span>");
    htmlParts.push("</div>");
    if (d.migration_hint) {
      htmlParts.push('<div class="edit-banner-hint">' + t("edit.migration_hint", { hint: d.migration_hint }) + "</div>");
    }
    if ((d.missing_fields || []).length) {
      htmlParts.push('<div class="edit-banner-hint edit-warn">' +
        t("edit.missing_fields", { fields: d.missing_fields.join(", ") }) + "</div>");
    }
    if (ctx.methodBackfilled) {
      htmlParts.push('<div class="edit-banner-hint edit-warn">' +
        t("edit.method_backfilled") + "</div>");
    }
    (d.notes || []).forEach(function (note) {
      htmlParts.push('<div class="edit-banner-hint edit-warn">' +
        escapeHtml(String(note)) + "</div>");
    });
    htmlParts.push("</div>");
    el.innerHTML = htmlParts.join("");
  }

  function effectiveConfigHintKey(effectiveConfig) {
    if (!effectiveConfig || !effectiveConfig.status) return "";
    if (effectiveConfig.status === "snapshot") return "edit.effective_snapshot";
    if (effectiveConfig.status === "recomputed") return "edit.effective_recomputed";
    return "";
  }

  function hideFooter() {
    var el = footerEl();
    if (el) { el.style.display = "none"; el.innerHTML = ""; }
  }

  // 执行方式与修改计数移入弹窗底部区域（提交/取消用标准 footer 按钮）。
  function renderFooter() {
    var ctx = editorContext;
    var el = footerEl();
    if (!el || !ctx || !ctx.draft) return;
    var caps = ctx.draft.capabilities || {};
    var requiresNewJob = sourceRequiresIndependentJob(ctx);
    var htmlParts = ['<div class="edit-banner-row"><span class="edit-row-label">' +
      t("edit.execution_mode") + "</span>"];
    htmlParts.push('<label class="edit-radio' + (caps.can_in_place && !requiresNewJob ? "" : " disabled") + '">' +
      '<input type="radio" name="edit-exec-mode" value="in_place"' +
      (ctx.executionMode === "in_place" ? " checked" : "") +
      (caps.can_in_place && !requiresNewJob ? "" : " disabled") + "> " + t("edit.exec_in_place") + "</label>");
    htmlParts.push('<label class="edit-radio' + (caps.can_new_job ? "" : " disabled") + '"><input type="radio" name="edit-exec-mode" value="new_job"' +
      (ctx.executionMode === "new_job" ? " checked" : "") +
      (caps.can_new_job ? "" : " disabled") + "> " + t("edit.exec_new_job") + "</label>");
    htmlParts.push('<span class="flex-spacer"></span>');
    htmlParts.push('<span class="edit-changed-badge" id="edit-changed-badge"></span>');
    htmlParts.push("</div>");
    if (workflowChanged(ctx)) {
      htmlParts.push('<div class="edit-banner-hint">' +
        escapeHtml(t("edit.workflow_changed")) + "</div>");
    } else if (requiresNewJob && ctx.mode !== "new_from_job") {
      htmlParts.push('<div class="edit-banner-hint">' +
        escapeHtml(t("edit.source_requires_new_job")) + "</div>");
    }
    el.innerHTML = htmlParts.join("");
    el.style.display = "block";
    el.querySelectorAll('input[name="edit-exec-mode"]').forEach(function (radio) {
      radio.addEventListener("change", function () {
        if (!radio.checked) return;
        if (radio.value === "in_place" && sourceRequiresIndependentJob(ctx)) {
          ctx.executionMode = "new_job";
          renderFooter();
          updateEditorUiState();
          return;
        }
        ctx.executionMode = radio.value;
        ctx.pendingPreviewBody = null;
        ctx.fingerprint = null;
        renderFooter();
        updateEditorUiState();
      });
    });
  }

  // 历史退役/planned 任务：识别 + 查看旧参数 + 解释兼容性（计划 §5.1），
  // 不重新开放已退休的执行入口。
  function renderViewOnlyBanner(d) {
    var el = bannerEl();
    if (!el) return;
    var spec = d.editable_spec || {};
    var methodKeys = (d.preserved_fields || []).join(", ") || "—";
    var reasons = (d.capabilities.disabled_reasons || [])
      .map(function (r) { return '<div class="edit-banner-hint edit-warn">' + escapeHtml(r) + "</div>"; })
      .join("");
    el.style.display = "block";
    el.innerHTML =
      '<div class="edit-banner edit-banner-ready"><div class="edit-banner-source">' +
      escapeHtml(t("edit.view_only_title", { workflow: d.workflow })) + "</div>" + reasons +
      '<div class="edit-banner-hint"><b>' + escapeHtml(t("edit.view_only_params")) + ":</b> " +
      escapeHtml(methodKeys) + "</div>" +
      '<div class="edit-banner-hint"><b>' + escapeHtml(t("edit.view_only_input")) + ":</b> " +
      escapeHtml(t("edit.view_only_input_kind", { kind: inputKind(spec.input) })) + "</div>" +
      (d.migration_hint ? '<div class="edit-banner-hint"><b>' + escapeHtml(t("edit.migration_hint", { hint: d.migration_hint })) + "</b></div>" : "") +
      "</div>";
  }

  function updateEditorUiState() {
    var ctx = editorContext;
    if (!ctx || !ctx.draft) return;
    var badge = document.querySelector("#edit-changed-badge");
    if (badge) {
      var n = countLocalChanges();
      badge.textContent = t("edit.changed_n", { n: String(n) });
      badge.classList.toggle("has-changes", n > 0);
    }
    var btn = modalSubmitBtn();
    if (btn && !ctx.collecting && !ctx.submitting) {
      var caps = ctx.draft.capabilities || {};
      btn.disabled = !caps.can_edit || (ctx.executionMode === "in_place" ?
        (!caps.can_in_place || sourceRequiresIndependentJob(ctx)) : !caps.can_new_job);
      btn.title = btn.disabled ? t("edit.in_place_blocked") : "";
    }
  }

  // 编辑模式下底部主按钮文案 = 检查并提交；取消/提交后恢复「提交」。
  // 移除 data-i18n 以防 applyI18n 语言切换时覆盖回「提交」。
  function updateModalSubmitButton() {
    var btn = modalSubmitBtn();
    if (!btn) return;
    if (editorContext) {
      btn.removeAttribute("data-i18n");
      btn.textContent = currentStep() === 3 ? t("edit.check_and_submit") : t("wizard.next_step");
    } else {
      btn.setAttribute("data-i18n", "modal.submit");
      btn.textContent = t("modal.submit");
      btn.disabled = false;
      btn.title = "";
    }
  }

  // 语言切换后的编辑器 UI 刷新（由 applyI18n 调用）。
  function refreshUi() {
    if (!editorContext) return;
    updateEditModeTabs();
    updateModalSubmitButton();
    renderFooter();
    updateEditorUiState();
    renderBanner("ready");
    renderOriginalInputPanel();
  }

  // Badge refresh: cheap interval while the editor is open — covers every
  // mutation path (resource inputs, method-config-modal saves, structure
  // re-parse) without hooking each page collector individually.
  var badgeTimer = null;

  function startBadgeWatch() {
    stopBadgeWatch();
    badgeTimer = setInterval(function () {
      if (!editorContext) { stopBadgeWatch(); return; }
      updateEditorUiState();
    }, 800);
  }

  function stopBadgeWatch() {
    if (badgeTimer !== null) { clearInterval(badgeTimer); badgeTimer = null; }
  }

  function showSummary(preview) {
    hideSummary();
    var overlay = document.createElement("div");
    overlay.className = "modal-overlay";
    overlay.id = "edit-summary-overlay";
    var diffRows = (preview.diff || []).map(function (entry) {
      var oldV = formatDiffValue(entry, entry.old);
      var newV = formatDiffValue(entry, entry.new);
      return '<tr><td class="edit-diff-path">' + escapeHtml(entry.path) + "</td><td>" +
        escapeHtml(oldV) + "</td><td>" + escapeHtml(newV) + "</td><td>" + escapeHtml(entry.kind) + "</td></tr>";
    }).join("");
    var warns = (preview.warnings || []).map(function (w) {
      return '<div class="edit-banner-hint edit-warn">' + escapeHtml(w) + "</div>";
    }).join("");
    var isRemote = editorContext && editorContext.executionMode === "new_job";
    var batchRoleSummary = renderBatchRoleSummary(editorContext);
    var sourceSummary = selectedSourceSummary(editorContext);
    overlay.innerHTML =
      '<div class="modal-dialog"><div class="modal-header"><h2>' + t("edit.summary_title") +
      '</h2><button class="modal-close" id="edit-summary-x">X</button></div><div class="modal-body">' +
      '<div class="edit-summary-meta">' +
      "<div><b>" + t("edit.summary_workflow") + ":</b> " + escapeHtml(preview.workflow) + "</div>" +
      "<div><b>" + t("edit.summary_mode") + ":</b> " +
      t(isRemote ? "edit.exec_new_job" : "edit.exec_in_place") + "</div>" +
      "<div><b>" + t("edit.source_label") + ":</b> " + escapeHtml(sourceSummary) + "</div>" +
      (isRemote ? "" : '<div class="edit-warn">' + t("edit.summary_cleanup_warning") + "</div>") +
      "</div>" + warns + batchRoleSummary +
      (diffRows ? '<table class="edit-diff-table"><thead><tr><th>' + t("edit.diff_field") +
        "</th><th>" + t("edit.diff_old") + "</th><th>" + t("edit.diff_new") + "</th><th>" +
        t("edit.diff_kind") + "</th></tr></thead><tbody>" + diffRows + "</tbody></table>"
        : '<div class="edit-banner-hint">' + t("edit.no_changes") + "</div>") +
      '<div class="edit-summary-error" id="edit-summary-error" style="display:none;"></div>' +
      '</div><div class="modal-footer">' +
      '<button type="button" class="btn ghost" id="edit-summary-cancel">' + t("edit.summary_back") + "</button>" +
      '<button type="button" class="btn primary" id="edit-summary-confirm">' +
      t(isRemote ? "edit.confirm_new_job" : "edit.confirm_in_place") + "</button></div></div>";
    overlay.style.display = "flex";
    document.body.appendChild(overlay);
    overlay.querySelector("#edit-summary-cancel").addEventListener("click", hideSummary);
    overlay.querySelector("#edit-summary-x").addEventListener("click", hideSummary);
    overlay.querySelector("#edit-summary-confirm").addEventListener("click", finalSubmit);
  }

  function formatDiffValue(entry, value) {
    if (entry && entry.path === "input.items" && Array.isArray(value)) {
      return value.map(function (item, index) {
        item = item || {};
        var name = item.name || item.candidate_id || item.item_id || ("#" + (index + 1));
        var role = item.tag === "TS" ? "TS" : "INT";
        var charge = has(item, "charge") ? item.charge : 0;
        var multiplicity = has(item, "multiplicity") ? item.multiplicity : 1;
        return name + " [" + role + "] q" + charge + "/m" + multiplicity;
      }).join("\n");
    }
    if (typeof value === "object") return JSON.stringify(value);
    return String(value);
  }

  function renderBatchRoleSummary(ctx) {
    if (!ctx || !ctx.originalSpec || ctx.originalSpec.workflow !== "BatchOptimize") return "";
    var input = (ctx.pendingPreviewBody || {}).input || {};
    var items = Array.isArray(input.items) ? input.items : [];
    if (!items.length) return "";
    var zh = typeof currentLang !== "undefined" && currentLang === "zh-CN";
    var rows = items.map(function (item, index) {
      item = item || {};
      var name = item.name || item.candidate_id || item.item_id || ("#" + (index + 1));
      var role = item.tag === "TS" ? "TS" : "INT";
      var charge = has(item, "charge") ? item.charge : 0;
      var multiplicity = has(item, "multiplicity") ? item.multiplicity : 1;
      return '<div class="edit-banner-hint"><b>' + escapeHtml(name) +
        '</b> · ' + escapeHtml(role) + ' · q' + escapeHtml(charge) +
        '/m' + escapeHtml(multiplicity) + '</div>';
    }).join("");
    return '<section class="edit-batch-role-summary"><b>' +
      (zh ? "本次提交的结构角色" : "Structure roles in this submission") +
      '</b>' + rows + '</section>';
  }

  function hideSummary() {
    var el = document.getElementById("edit-summary-overlay");
    if (el && el.parentNode) el.parentNode.removeChild(el);
  }

  function escapeHtml(text) {
    return String(text === undefined || text === null ? "" : text)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // 导出：Workbench 只保留入口绑定（计划 §8）。
  window.ACPJobEditor = {
    isActive: isActive,
    isCollecting: isCollecting,
    workflowSelectionError: workflowSelectionError,
    currentStep: currentStep,
    setStep: setEditStep,
    currentMode: currentMode,
    sourceJobId: sourceJobId,
    openJobEditor: openJobEditor,
    openRerunMenu: openRerunMenu,
    closeRerunMenu: closeRerunMenu,
    interceptJobCreate: interceptJobCreate,
    cancelEditor: cancelEditor,
    checkAndSubmit: checkAndSubmit,
    onSourceTabChange: onSourceTabChange,
    onPreviewStructureSelected: onPreviewStructureSelected,
    onExternalSourcePreview: onExternalSourcePreview,
    onJobResultLoaded: onJobResultLoaded,
    onParsedSourceApplied: onParsedSourceApplied,
    onTaskStructureChanged: onTaskStructureChanged,
    onTaskStructureRemoved: onTaskStructureRemoved,
    onBatchItemChanged: onBatchItemChanged,
    copyOriginalToStructureInput: copyOriginalToStructureInput,
    updateEditModeTabs: updateEditModeTabs,
    getRecalcSourceAnnotation: getRecalcSourceAnnotation,
    getPinnedSources: getPinnedSources,
    usePreviousOutput: usePreviousOutput,
    refreshUi: refreshUi,
  };

  // 纯逻辑测试钩子（node 回归测试；生产代码不应依赖）。
  window.ACPJobEditorInternals = {
    deepCopy: deepCopy,
    deepEqual: deepEqual,
    has: has,
    presenceCopy: presenceCopy,
    inputKind: inputKind,
    isSimpleStructureInput: isSimpleStructureInput,
    cleanLevels: cleanLevels,
    batchRoleStaticDefaults: batchRoleStaticDefaults,
    mergeBatchRoles: mergeBatchRoles,
    buildBatchMethodFromPatch: buildBatchMethodFromPatch,
    adapterFor: adapterFor,
    collectFormOnlyBody: collectFormOnlyBody,
  };
})();
