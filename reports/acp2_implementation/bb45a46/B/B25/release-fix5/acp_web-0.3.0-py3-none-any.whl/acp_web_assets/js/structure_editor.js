/**
 * ACP Structure Editor — edits + transactions + asset save (Wave 6, todos 32-37)
 * @version 0.9.0
 *
 * Namespace: window.ACPStructureEditor
 *
 * Exposes:
 *   - setLocked(true|false) / isLocked()  (animation mutual exclusion, todo 30)
 *   - editorState                         ({graph, provenance, pendingEdit})
 *   - buildGraphFromCurrentEntry(explicitBonds?)  (reads ACPStructureViewer.state;
 *                                          null when locked or no coordinates)
 *   - buildAdjacency(symbols, coords, explicitBonds) (PURE graph build)
 *   - connectedComponents(edges, atomCount)          (PURE fragment partition)
 *   - fragmentsAfterCut(edges, atomCount, cutA, cutB) (PURE — move-side logic)
 *   - parseMolBonds(molText)               (minimal V2000 bond-block reader)
 *   - COVALENT_RADII / BOND_TOLERANCE / DEFAULT_RADIUS (named constants)
 *   - editBondLength(symbols, coords, edges, a, b, target, moveSide) (PURE)
 *   - editBondAngle(symbols, coords, edges, a, b, c, targetDeg, moveSide) (PURE)
 *   - editDihedral(symbols, coords, edges, a, b, c, d, targetDeg, moveSide) (PURE)
 *   - dihedralDeg(a, b, c, d) / normalizeDihedral(deg)  (PURE helpers)
 *   - angleDeg(p, q, r) / _principalAxis(points)   (PURE helpers)
 *   - resolveMoveSide(fragments, a, b, preferred) / defaultMoveSide(...) (PURE)
 *   - applyBondLengthEdit(a, b, targetLength, moveSide) (orchestration)
 *   - applyBondAngleEdit(a, b, c, targetDeg, moveSide) (orchestration)
 *   - applyDihedralEdit(a, b, c, d, targetDeg, moveSide) (orchestration)
 *   - applyMeasuredEdit(kind, atomIds, target, measurementId?) (measurement-tool hook)
 *   - validateEditableCoordinate(type, atomIds)  (measurement-time editability)
 *   - REASON_MESSAGES / reasonMessage(reason)    (internal reason -> user message)
 *   - checkCollisions(symbols, coords, edges)   (PURE post-edit safety check)
 *   - bindEntry(entryId, symbols, coords) / confirmSwitch(action)
 *   - undoEdit() / redoEdit() / resetEdits() / isDirty() / syncDirtyFlag()
 *   - buildEditedXyz(symbols, coords, originalComment, provenanceInfo) (PURE)
 *   - exportEditedXyz()                       (download; Node: returns text)
 *   - saveEditedAsset(name?) / requestSaveEditedAsset()  (POST /structure-assets)
 *   - prefillNewCalculation()                 (new-task wizard, NO submit)
 *
 * Contract (doc §6.1-§6.3): edits are INTERNAL-COORDINATE ONLY — a bond
 * edit rigidly TRANSLATES one fragment, an angle edit rigidly ROTATES the
 * C-side fragment (never the A-B side; never deformed); bond topology,
 * elements, and atom count never change.  Length targets outside
 * [0.4, 5.0] Å and angle targets outside [1, 179]° are rejected; ring
 * bonds (graph still connected after the cut) are rejected; collinear
 * angle input falls back to the most stable orthonormal axis with a
 * warning; dihedral targets normalize to (-180, 180] and rotate the
 * C-side by the SHORTEST rotation.  Accepted edits run through the
 * transaction engine: every apply* validates, applies the new coordinates
 * to the displayed entry, records {type, atom_ids, before, after,
 * moved_atom_ids, collision_warnings}, and syncs the viewer dirty flag.
 * Edits are scoped to the bound entry (bindEntry) — an apply against a
 * different displayed entry rejects entry_mismatch; switching entries
 * while dirty raises a pendingSwitch prompt (放弃 / 另存为 / 取消) instead
 * of silently discarding.  Collision check: non-bonded pairs closer than
 * COLLISION_FACTOR*(r_a+r_b) warn (severe) but stay undoable.  Edits touch
 * COORDINATES ONLY — never bond orders, elements, or hydrogens.  The
 * save-as-asset POST (todo 37): saveEditedAsset posts the edited XYZ with
 * parent job/entry ids, the full edit_operations list, and provenance to
 * /api/v1/structure-assets; requestSaveEditedAsset completes a pending
 * dirty-switch after a successful save.  prefillNewCalculation copies the
 * in-memory XYZ into the new-task wizard WITHOUT submitting (anti-pattern
 * #29) — the user confirms method/charge/multiplicity.  Nothing ever
 * writes into task directories (results, work scratch, or source files):
 * in-memory edits + API POST only.
 *
 * TODO(todo-37b/Wave 8): asset library surfacing + wizard structure-source
 * panel listing saved edit assets.
 */
(function () {
  "use strict";

  /** Version tag — bump on every structural change. */
  var VERSION = "0.9.0";

  /* ---- user-visible strings (zh fallback; i18n dictionary keys land in todo 36) ---- */
  var STR = {
    PROV_EXPLICIT: "\u6587\u4ef6\u663e\u5f0f\u952e",                       // 文件显式键
    PROV_INFERRED: "\u5171\u4ef7\u534a\u5f84\u63a8\u65ad (tolerance {tol})", // 共价半径推断 (tolerance 1.3)
    MOVE_LEFT: "\u79fb\u52a8\u5de6\u4fa7",                                 // 移动左侧
    MOVE_RIGHT: "\u79fb\u52a8\u53f3\u4fa7",                               // 移动右侧
    COLLINEAR_WARNING: "\u5171\u7ebf\u89d2\u5ea6\u8f93\u5165\uff0c\u65cb\u8f6c\u8f74\u53d6\u6700\u7a33\u5b9a\u6b63\u4ea4\u8f74", // 共线角度输入，旋转轴取最稳定正交轴
    DIRTY: "\u5df2\u4fee\u6539\uff0c\u672a\u4fdd\u5b58",                           // 已修改，未保存
    UNDO: "\u64a4\u9500",                                                           // 撤销
    REDO: "\u91cd\u505a",                                                           // 重做
    RESET: "\u91cd\u7f6e",                                                           // 重置
    DISCARD: "\u653e\u5f03",                                                         // 放弃
    SAVE_AS: "\u53e6\u5b58\u4e3a",                                                 // 另存为
    CANCEL: "\u53d6\u6d88",                                                         // 取消
    COLLISION: "\u4e25\u91cd\u78b0\u649e",                                         // 严重碰撞
    ENTRY_MISMATCH: "\u7f16\u8f91\u4f1a\u8bdd\u4e0e\u5f53\u524d\u7ed3\u6784\u4e0d\u4e00\u81f4", // 编辑会话与当前结构不一致
    EXPORT_XYZ: "\u5bfc\u51fa XYZ",                                       // 导出 XYZ
    SAVE_ASSET: "\u53e6\u5b58\u4e3a\u7ed3\u6784\u8d44\u4ea7",             // 另存为结构资产
    NEW_CALC: "\u4ee5\u6b64\u7ed3\u6784\u65b0\u5efa\u8ba1\u7b97",         // 以此结构新建计算
    SAVE_ERROR: "\u4fdd\u5b58\u5931\u8d25",                               // 保存失败
    SAVED_ASSET: "\u5df2\u4fdd\u5b58",                                   // 已保存
    EDITED_SUFFIX: "\u5df2\u7f16\u8f91",                                 // 已编辑
  };

  /**
   * Internal rejection reason -> user-visible Chinese message (plan §3.3).
   * Program strings like "no_bond" must never be shown directly; the UI
   * translates them through reasonMessage() before rendering.
   *
   * @type {Object<string, string>}
   */
  var REASON_MESSAGES = {
    no_bond: "\u6240\u9009\u539f\u5b50\u4e0d\u662f\u8fde\u7eed\u6210\u952e\u8def\u5f84\uff0c\u53ea\u80fd\u6d4b\u91cf\uff0c\u4e0d\u80fd\u8fd9\u6837\u4fee\u6539",
    ring_bond: "\u4e2d\u5fc3\u952e\u4f4d\u4e8e\u73af\u4e2d\uff0c\u8f7b\u91cf\u7f16\u8f91\u5668\u6682\u4e0d\u652f\u6301\u65cb\u8f6c\u8be5\u7247\u6bb5",
    degenerate: "\u5f53\u524d\u51e0\u4f55\u5171\u7ebf\u6216\u91cd\u5408\uff0c\u65e0\u6cd5\u5b9a\u4e49\u7a33\u5b9a\u65cb\u8f6c\u8f74",
    out_of_range: "\u76ee\u6807\u503c\u8d85\u51fa\u5141\u8bb8\u8303\u56f4",
    locked: "\u8bf7\u5148\u6682\u505c\u632f\u52a8\u52a8\u753b\u6216\u9000\u51fa\u51b2\u7a81\u6a21\u5f0f",
    entry_mismatch: "\u5f53\u524d\u7ed3\u679c\u5df2\u5207\u6362\uff0c\u8bf7\u91cd\u65b0\u9009\u62e9\u539f\u5b50",
    invalid_move_side: "\u4e0d\u652f\u6301\u7684\u79fb\u52a8\u4fa7\u8bbe\u7f6e",
    no_structure: "\u5f53\u524d\u6ca1\u6709\u53ef\u7f16\u8f91\u7684\u7ed3\u6784",
    nothing_to_undo: "\u6ca1\u6709\u53ef\u64a4\u9500\u7684\u64cd\u4f5c",
    nothing_to_redo: "\u6ca1\u6709\u53ef\u91cd\u505a\u7684\u64cd\u4f5c",
    dirty_switch: "\u5f53\u524d\u7ed3\u6784\u6709\u672a\u5e94\u7528\u7684\u4fee\u6539",
    overlay_active: "\u53e0\u5408\u6a21\u5f0f\u4e0b\u4e0d\u80fd\u4fee\u6539\u7ed3\u6784",
    irc_playing: "\u8f68\u8ff9\u64ad\u653e\u4e2d\u4e0d\u80fd\u4fee\u6539\u7ed3\u6784",
    vibration_active: "\u8bf7\u5148\u6682\u505c\u632f\u52a8\u52a8\u753b",
  };

  /**
   * Translate an internal edit/validation reason into a user-visible
   * message; unknown reasons fall back to the raw string (never empty for
   * truthy input).
   *
   * @param {string|null|undefined} reason
   * @returns {string} localized message; "" for null/undefined/empty input
   */
  function reasonMessage(reason) {
    if (Object.prototype.hasOwnProperty.call(REASON_MESSAGES, reason)) {
      return REASON_MESSAGES[reason];
    }
    return reason ? String(reason) : "";
  }

  /**
   * Covalent radii in Å (Cordero 2008 subset used by this project's
   * chemistry surface).  Unknown elements fall back to DEFAULT_RADIUS.
   */
  var COVALENT_RADII = {
    H: 0.31, C: 0.76, N: 0.71, O: 0.66, F: 0.57,
    P: 1.07, S: 1.05, Cl: 1.02, Br: 1.20, I: 1.39,
    B: 0.84, Si: 1.11, Na: 1.66, K: 2.03, Mg: 1.41,
    Ca: 1.76, Zn: 1.22, Fe: 1.32, Cu: 1.32,
  };

  /** Fallback radius for elements missing from the table. */
  var DEFAULT_RADIUS = 1.0;

  /** Inferred-bond distance cutoff multiplier: dist <= 1.3*(r_i + r_j). */
  var BOND_TOLERANCE = 1.3;

  /** Allowed bond-length edit range in Å (inclusive; doc §6.3). */
  var BOND_LENGTH_MIN = 0.4;
  var BOND_LENGTH_MAX = 5.0;

  /** Allowed bond-angle edit range in degrees (inclusive; doc §6.3). */
  var ANGLE_MIN = 1;
  var ANGLE_MAX = 179;

  /** |cross(u_BA, u_BC)| below this counts as collinear A-B-C. */
  var COLLINEAR_EPS = 1e-6;

  /** Non-bonded pairs closer than this fraction of (r_a + r_b) collide. */
  var COLLISION_FACTOR = 0.55;

  /** @typedef {Object} EditorState @property {Object|null} graph @property {string|null} provenance */
  var editorState = {
    graph: null,
    provenance: null,
    pendingEdit: null,
    entryId: null,
    originalCoords: null,
    transactions: [],
    redoStack: [],
    pendingSwitch: null,
    saveRequested: false,
    savedAssetId: null,
    saveError: null,
  };

  /** Animation mutual-exclusion flag (todo 30; Wave 6 edits check this). */
  var locked = false;

  /**
   * Covalent radius lookup with case normalization; DEFAULT_RADIUS when
   * the element is unknown.
   *
   * @param {string} symbol
   * @returns {number}
   */
  function _radiusOf(symbol) {
    var s = String(symbol == null ? "" : symbol).trim();
    if (!s) return DEFAULT_RADIUS;
    var r = COVALENT_RADII[s];
    if (r !== undefined) return r;
    var norm = s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
    r = COVALENT_RADII[norm];
    return r !== undefined ? r : DEFAULT_RADIUS;
  }

  /**
   * Build the edit-only adjacency graph.  When `explicitBonds` is a
   * non-empty array (an upstream SDF/MOL bond block — see parseMolBonds)
   * ONLY those edges are used (source "explicit"); otherwise edges are
   * inferred for every pair i<j with dist(i,j) <= BOND_TOLERANCE*(r_i+r_j)
   * (strictly at-or-below; source "inferred").  Disconnected fragments
   * are left disconnected.  PURE: `coords` is read-only and neither the
   * displayed model nor the stored structure is touched.
   *
   * @param {Array<string>|null} symbols
   * @param {Array<Array<number>>|null} coords
   * @param {Array<{a: number, b: number, order?: number}>|null} [explicitBonds]
   * @returns {{edges: Array<{a: number, b: number, order: number, source: string}>,
   *            provenance: string}}
   */
  function buildAdjacency(symbols, coords, explicitBonds) {
    if (!symbols || !coords || symbols.length !== coords.length || !symbols.length) {
      return { edges: [], provenance: "" };
    }

    if (explicitBonds && explicitBonds.length) {
      var explicit = [];
      for (var ei = 0; ei < explicitBonds.length; ei++) {
        var bond = explicitBonds[ei];
        if (!bond) continue;
        var a = bond.a | 0;
        var b = bond.b | 0;
        if (a < 0 || b < 0 || a >= symbols.length || b >= symbols.length || a === b) {
          continue;
        }
        explicit.push({
          a: a,
          b: b,
          order: (typeof bond.order === "number" && isFinite(bond.order)) ? bond.order : 1,
          source: "explicit",
        });
      }
      return { edges: explicit, provenance: STR.PROV_EXPLICIT };
    }

    var inferred = [];
    for (var i = 0; i < coords.length; i++) {
      var ci = coords[i];
      if (!ci || ci.length < 3) continue;
      var ri = _radiusOf(symbols[i]);
      for (var j = i + 1; j < coords.length; j++) {
        var cj = coords[j];
        if (!cj || cj.length < 3) continue;
        var dx = +ci[0] - +cj[0];
        var dy = +ci[1] - +cj[1];
        var dz = +ci[2] - +cj[2];
        var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (!isFinite(dist)) continue;
        var cutoff = BOND_TOLERANCE * (ri + _radiusOf(symbols[j]));
        if (dist <= cutoff) {
          inferred.push({ a: i, b: j, order: 1, source: "inferred" });
        }
      }
    }
    return {
      edges: inferred,
      provenance: STR.PROV_INFERRED.replace("{tol}", String(BOND_TOLERANCE)),
    };
  }

  /**
   * Partition atoms into connected components (fragment list), ordered by
   * smallest atom index; each component's indices are ascending.
   *
   * @param {Array<{a: number, b: number}>|null} edges
   * @param {number} atomCount
   * @returns {Array<Array<number>>}
   */
  function connectedComponents(edges, atomCount) {
    var n = atomCount | 0;
    if (!(n > 0)) return [];
    var parent = [];
    for (var i = 0; i < n; i++) parent.push(i);
    function find(x) {
      while (parent[x] !== x) {
        parent[x] = parent[parent[x]];
        x = parent[x];
      }
      return x;
    }
    if (edges && edges.length) {
      for (var e = 0; e < edges.length; e++) {
        var edge = edges[e];
        if (!edge) continue;
        var ra = find(edge.a | 0);
        var rb = find(edge.b | 0);
        if (ra !== rb) parent[ra] = rb;
      }
    }
    var byRoot = {};
    for (var k = 0; k < n; k++) {
      var root = find(k);
      if (!byRoot[root]) byRoot[root] = [];
      byRoot[root].push(k);
    }
    var components = [];
    var keys = Object.keys(byRoot);
    for (var c = 0; c < keys.length; c++) {
      var members = byRoot[keys[c]];
      members.sort(function (x, y) { return x - y; });
      components.push(members);
    }
    components.sort(function (x, y) { return x[0] - y[0]; });
    return components;
  }

  /**
   * Fragments after temporarily cutting one bond (todo 33 move-side
   * logic): connectedComponents with edge (cutA, cutB) removed, in either
   * orientation.  PURE — the input edge list is not mutated.
   *
   * @param {Array<{a: number, b: number}>|null} edges
   * @param {number} atomCount
   * @param {number} cutA
   * @param {number} cutB
   * @returns {Array<Array<number>>}
   */
  function fragmentsAfterCut(edges, atomCount, cutA, cutB) {
    var kept = [];
    if (edges && edges.length) {
      for (var i = 0; i < edges.length; i++) {
        var edge = edges[i];
        if (!edge) continue;
        var isCut = (edge.a === cutA && edge.b === cutB) ||
          (edge.a === cutB && edge.b === cutA);
        if (!isCut) kept.push(edge);
      }
    }
    return connectedComponents(kept, atomCount);
  }

  /* ---- authoritative geometry resolution + measurement editability ---- */

  /** Atom-count arity per measurement type (mirrors ACPGeometryStore). */
  var MEASUREMENT_ARITY = { distance: 2, angle: 3, dihedral: 4 };

  /** Required bond/axis lengths below this count as degenerate geometry. */
  var DEGENERATE_EPS = 1e-9;

  /** Inferred-edge cache for validation, keyed by store entry + revision. */
  var _validationGraphCache = { key: null, edges: null };

  /** Store object whose change notifications invalidate the edge cache. */
  var _validationSubscribedStore = null;

  /**
   * Resolve the geometry-store API when the module is loaded.
   *
   * @returns {Object|null}
   */
  function _storeApi() {
    return (typeof window !== "undefined" && window.ACPGeometryStore)
      ? window.ACPGeometryStore
      : null;
  }

  /**
   * Resolve the geometry store when it owns a loaded entry (entryId set).
   *
   * @returns {Object|null}
   */
  function _activeStore() {
    var store = _storeApi();
    if (!store || !store.state) return null;
    var entryId = store.state.entryId;
    return (entryId === null || entryId === undefined) ? null : store;
  }

  /**
   * Extract usable geometry from a store's live state.
   *
   * @param {Object|null} store
   * @returns {{symbols: Array<string>, coords: Array<Array<number>>}|null}
   */
  function _storeGeometry(store) {
    if (!store || !store.state) return null;
    var symbols = store.state.symbols;
    var coords = store.state.coordinates;
    if (!Array.isArray(symbols) || !Array.isArray(coords)) return null;
    if (!symbols.length || symbols.length !== coords.length) return null;
    return { symbols: symbols, coords: coords };
  }

  /**
   * Extract usable geometry from the structure viewer's displayed state.
   *
   * @returns {{symbols: Array<string>, coords: Array<Array<number>>}|null}
   */
  function _viewerGeometry() {
    var svState = (typeof window !== "undefined" && window.ACPStructureViewer)
      ? window.ACPStructureViewer.state
      : null;
    if (!svState || !Array.isArray(svState.displayedSymbols) ||
        !Array.isArray(svState.displayedCoords)) {
      return null;
    }
    if (!svState.displayedSymbols.length ||
        svState.displayedSymbols.length !== svState.displayedCoords.length) {
      return null;
    }
    return { symbols: svState.displayedSymbols, coords: svState.displayedCoords };
  }

  /**
   * Resolve the authoritative geometry: ACPGeometryStore first (when it
   * owns a loaded entry), structure-viewer displayed state as fallback.
   *
   * @returns {{store: Object|null, symbols: Array<string>,
   *            coords: Array<Array<number>>}|null}
   */
  function _currentGeometry() {
    var store = _activeStore();
    var fromStore = _storeGeometry(store);
    if (fromStore) {
      return { store: store, symbols: fromStore.symbols, coords: fromStore.coords };
    }
    var fromViewer = _viewerGeometry();
    if (fromViewer) {
      return { store: null, symbols: fromViewer.symbols, coords: fromViewer.coords };
    }
    return null;
  }

  /**
   * Normalize one atom id; integers >= 0 only.
   *
   * @param {*} value
   * @returns {number|null}
   */
  function _toAtomId(value) {
    var n = (typeof value === "string" && value !== "") ? Number(value) : value;
    return (typeof n === "number" && Number.isInteger(n) && n >= 0) ? n : null;
  }

  /**
   * Finite xyz point for one atom id; null when missing or non-finite.
   *
   * @param {Array<Array<number>>} coords
   * @param {number} atomId
   * @returns {Array<number>|null}
   */
  function _point3(coords, atomId) {
    if (!Array.isArray(coords) || atomId >= coords.length) return null;
    var row = coords[atomId];
    if (!Array.isArray(row) || row.length < 3) return null;
    var x = +row[0], y = +row[1], z = +row[2];
    return (isFinite(x) && isFinite(y) && isFinite(z)) ? [x, y, z] : null;
  }

  /**
   * Euclidean distance between two xyz points.
   *
   * @param {Array<number>} p
   * @param {Array<number>} q
   * @returns {number}
   */
  function _dist3(p, q) {
    var dx = p[0] - q[0], dy = p[1] - q[1], dz = p[2] - q[2];
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  /**
   * Subscribe once per store object so "load"/"coordinates" mutations
   * invalidate the validation edge cache (load() resets revision to 1, so
   * entryId+revision alone can collide across frames of the same entry).
   *
   * @param {Object|null} store
   * @returns {void}
   */
  function _ensureValidationInvalidation(store) {
    if (!store || typeof store.subscribe !== "function") return;
    if (_validationSubscribedStore === store) return;
    _validationSubscribedStore = store;
    store.subscribe(function (_snapshot, change) {
      if (change === "load" || change === "coordinates") {
        _validationGraphCache.key = null;
        _validationGraphCache.edges = null;
      }
    });
  }

  /**
   * Cheap O(N) topology fingerprint (rounded coordinates) guarding the
   * cache against any coordinate change that did not bump the revision.
   *
   * @param {Array<string>} symbols
   * @param {Array<Array<number>>} coords
   * @returns {number} 32-bit integer hash
   */
  function _geometryFingerprint(symbols, coords) {
    var h = symbols.length | 0;
    for (var i = 0; i < coords.length; i++) {
      var row = coords[i];
      if (!row) {
        h = (h * 31 + 7) | 0;
        continue;
      }
      h = (h * 31 + (Math.round((+row[0] || 0) * 1e6) | 0)) | 0;
      h = (h * 31 + (Math.round((+row[1] || 0) * 1e6) | 0)) | 0;
      h = (h * 31 + (Math.round((+row[2] || 0) * 1e6) | 0)) | 0;
    }
    return h;
  }

  /**
   * Build (or reuse) the inferred adjacency edges used for validation.  The
   * cache is keyed by store entryId + revision + geometry fingerprint and is
   * invalidated on every store load/coordinates notification, so repeated
   * calls during one pick session skip the O(N^2) inference; viewer-only
   * geometry has no stable revision and is always rebuilt.
   *
   * @param {{store: Object|null, symbols: Array<string>,
   *          coords: Array<Array<number>>}} geometry
   * @returns {Array<{a: number, b: number, order: number, source: string}>}
   */
  function _validationEdges(geometry) {
    var key = null;
    if (geometry.store && geometry.store.state) {
      _ensureValidationInvalidation(geometry.store);
      key = String(geometry.store.state.entryId) + "@" +
        String(geometry.store.state.revision) + "#" + String(geometry.symbols.length) +
        ":" + String(_geometryFingerprint(geometry.symbols, geometry.coords));
    }
    if (key !== null && _validationGraphCache.key === key &&
        _validationGraphCache.edges) {
      return _validationGraphCache.edges;
    }
    var built = buildAdjacency(geometry.symbols, geometry.coords);
    if (key !== null) {
      _validationGraphCache.key = key;
      _validationGraphCache.edges = built.edges;
    }
    return built.edges;
  }

  /**
   * Not-editable verdict carrying the user-visible message.
   *
   * @param {string} reason
   * @returns {{editable: boolean, reason: string, message: string}}
   */
  function _notEditable(reason) {
    return { editable: false, reason: reason, message: reasonMessage(reason) };
  }

  /**
   * Measurement-time editability check for an internal coordinate.  A
   * measurement itself is always allowed; this verdict only decides whether
   * the measured value may be MODIFIED, and explains why not in Chinese.
   *
   * Geometry comes from ACPGeometryStore.state when loaded, else from
   * ACPStructureViewer.state.displayedSymbols/displayedCoords.  Edges are
   * inferred with buildAdjacency() (explicit bond blocks are not consulted),
   * so the check works before bindEntry() and never mutates any state.
   *
   * Rules: every required edge must exist ("no_bond"); cutting the central
   * bond must separate the two sides ("ring_bond" when it does not);
   * required bond/axis lengths must be >= 1e-9 and every coordinate finite
   * ("degenerate").  Missing geometry yields "no_structure"; unknown type
   * or wrong arity yields "no_bond".
   *
   * @param {string} type - "distance" | "angle" | "dihedral"
   * @param {Array<number>} atomIds - 2 / 3 / 4 canonical atom ids
   * @returns {{editable: boolean, reason: string|null, message: string|null}}
   */
  function validateEditableCoordinate(type, atomIds) {
    var arity = MEASUREMENT_ARITY[type];
    if (arity === undefined) return _notEditable("no_bond");
    if (!Array.isArray(atomIds) || atomIds.length !== arity) {
      return _notEditable("no_bond");
    }
    var ids = [];
    for (var i = 0; i < atomIds.length; i++) {
      var id = _toAtomId(atomIds[i]);
      if (id === null) return _notEditable("no_bond");
      ids.push(id);
    }

    var geometry = _currentGeometry();
    if (!geometry) return _notEditable("no_structure");

    var points = [];
    for (var p = 0; p < ids.length; p++) {
      var point = _point3(geometry.coords, ids[p]);
      if (!point) return _notEditable("degenerate");
      points.push(point);
    }

    var edges = _validationEdges(geometry);
    var required = [];
    if (type === "dihedral") {
      required.push([ids[0], ids[1]], [ids[1], ids[2]], [ids[2], ids[3]]);
    } else if (type === "angle") {
      required.push([ids[0], ids[1]], [ids[1], ids[2]]);
    } else {
      required.push([ids[0], ids[1]]);
    }
    for (var r = 0; r < required.length; r++) {
      if (!_hasEdge(edges, required[r][0], required[r][1])) {
        return _notEditable("no_bond");
      }
    }
    for (var b = 1; b < points.length; b++) {
      if (_dist3(points[b - 1], points[b]) < DEGENERATE_EPS) {
        return _notEditable("degenerate");
      }
    }

    var cutA = (type === "distance") ? ids[0] : ids[1];
    var cutB = (type === "distance") ? ids[1] : ids[2];
    var sideLeftId = ids[0];
    var sideRightId = (type === "distance") ? ids[1] : ids[2];
    var fragments = fragmentsAfterCut(edges, geometry.symbols.length, cutA, cutB);
    var sideLeft = _componentOf(fragments, sideLeftId);
    var sideRight = _componentOf(fragments, sideRightId);
    if (sideLeft && sideRight && sideLeft === sideRight) {
      return _notEditable("ring_bond");
    }
    return { editable: true, reason: null, message: null };
  }

  /**
   * Minimal V2000 molfile/SDF bond-block reader: parses the counts line
   * (atoms cols 0-3, bonds cols 3-6) and the bond lines (atom1 cols 0-3,
   * atom2 cols 3-6, order cols 6-9; whitespace-split fallback), returning
   * 0-based {a, b, order} records.  Malformed lines are skipped.
   *
   * @param {string} molText
   * @returns {Array<{a: number, b: number, order: number}>}
   */
  function parseMolBonds(molText) {
    if (!molText) return [];
    var lines = String(molText).trim().split(/\r?\n/);
    if (lines.length < 5) return [];
    var counts = lines[3] || "";
    var nAtoms = parseInt(counts.substring(0, 3), 10);
    var nBonds = parseInt(counts.substring(3, 6), 10);
    if (isNaN(nAtoms) || isNaN(nBonds) || nAtoms < 0 || nBonds < 0) return [];
    var bonds = [];
    for (var i = 0; i < nBonds; i++) {
      var line = lines[4 + nAtoms + i];
      if (!line) break;
      var a = parseInt(line.substring(0, 3), 10);
      var b = parseInt(line.substring(3, 6), 10);
      var order = parseInt(line.substring(6, 9), 10);
      if (isNaN(a) || isNaN(b)) {
        var parts = line.trim().split(/\s+/);
        a = parseInt(parts[0], 10);
        b = parseInt(parts[1], 10);
        order = parts.length > 2 ? parseInt(parts[2], 10) : 1;
      }
      if (isNaN(a) || isNaN(b)) continue;
      bonds.push({
        a: a - 1,
        b: b - 1,
        order: isNaN(order) || order < 1 ? 1 : order,
      });
    }
    return bonds;
  }

  /* ---- bond-length edit (todo 33) ---- */

  /**
   * Default move side for a cut bond: the fragment with FEWER atoms
   * moves; ties go to side A (the fragment containing atomA).
   *
   * @param {Array<Array<number>>} fragments - connectedComponents output
   * @param {number} atomA
   * @param {number} atomB
   * @returns {string} "A" | "B"
   */
  function defaultMoveSide(fragments, atomA, atomB) {
    var sideA = _componentOf(fragments, atomA);
    var sideB = _componentOf(fragments, atomB);
    var sizeA = sideA ? sideA.length : 0;
    var sizeB = sideB ? sideB.length : 0;
    return sizeB < sizeA ? "B" : "A";
  }

  /**
   * Resolve the move side: an explicit "A"/"B" preference is honored,
   * null/undefined falls back to defaultMoveSide, anything else is
   * invalid (returns null).
   *
   * @param {Array<Array<number>>} fragments
   * @param {number} atomA
   * @param {number} atomB
   * @param {string|null} [preferred]
   * @returns {string|null}
   */
  function resolveMoveSide(fragments, atomA, atomB, preferred) {
    if (preferred === "A" || preferred === "B") return preferred;
    if (preferred == null) return defaultMoveSide(fragments, atomA, atomB);
    return null;
  }

  function _componentOf(fragments, atomIndex) {
    if (!fragments) return null;
    for (var i = 0; i < fragments.length; i++) {
      if (fragments[i].indexOf(atomIndex) >= 0) return fragments[i];
    }
    return null;
  }

  /**
   * Edit the A-B bond length to `targetLength` by rigidly translating ONE
   * side of the temporarily cut bond.  PURE: a NEW coords array is
   * returned; the input is never mutated and the non-moved rows keep
   * byte-identical values.
   *
   * Math (u = (r_B - r_A)/L, the unit vector A -> B, L = current length,
   * T = target):
   *   moving side B: every side-B atom shifts by (T - L) * u, so
   *     r_B' - r_A = T*u  ->  |A-B'| = T.
   *   moving side A: every side-A atom shifts by s*u with s = L - T (the
   *     near-root of |L - s| = T; s = L + T would push A AWAY past B and
   *     invert the bond direction), so
   *     r_B - r_A' = (L - s)*u = T*u  ->  |A'-B| = T.
   * Both cases are pure translations: internal geometry of the moved
   * fragment and every non-moved atom are exactly preserved.
   *
   * Rejections: target outside [BOND_LENGTH_MIN, BOND_LENGTH_MAX] ->
   * "out_of_range"; a-b not bonded -> "no_bond"; graph still connected
   * after the cut (ring bond) -> "ring_bond"; zero-length bond (no unit
   * vector) -> "degenerate"; invalid moveSide -> "invalid_move_side".
   *
   * @param {Array<string>} symbols
   * @param {Array<Array<number>>} coords
   * @param {Array<{a: number, b: number}>} edges
   * @param {number} atomA
   * @param {number} atomB
   * @param {number} targetLength
   * @param {string|null} [moveSide] - "A" | "B" | null (default smaller side)
   * @returns {{ok: boolean, reason?: string, coords?: Array<Array<number>>}}
   */
  function editBondLength(symbols, coords, edges, atomA, atomB, targetLength, moveSide) {
    var t = +targetLength;
    if (!isFinite(t) || t < BOND_LENGTH_MIN || t > BOND_LENGTH_MAX) {
      return { ok: false, reason: "out_of_range" };
    }
    if (!symbols || !coords || !edges) {
      return { ok: false, reason: "no_bond" };
    }
    var hasBond = false;
    for (var e = 0; e < edges.length; e++) {
      var edge = edges[e];
      if ((edge.a === atomA && edge.b === atomB) ||
          (edge.a === atomB && edge.b === atomA)) {
        hasBond = true;
        break;
      }
    }
    if (!hasBond) return { ok: false, reason: "no_bond" };

    var fragments = fragmentsAfterCut(edges, coords.length, atomA, atomB);
    var sideA = _componentOf(fragments, atomA);
    var sideB = _componentOf(fragments, atomB);
    if (sideA && sideB && sideA === sideB) {
      return { ok: false, reason: "ring_bond" };
    }
    if (!sideA || !sideB) {
      return { ok: false, reason: "no_bond" };
    }

    var side = resolveMoveSide(fragments, atomA, atomB, moveSide);
    if (side !== "A" && side !== "B") {
      return { ok: false, reason: "invalid_move_side" };
    }

    var ra = coords[atomA];
    var rb = coords[atomB];
    var dx = +rb[0] - +ra[0];
    var dy = +rb[1] - +ra[1];
    var dz = +rb[2] - +ra[2];
    var len = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (!isFinite(len) || len < 1e-12) {
      return { ok: false, reason: "degenerate" };
    }
    var ux = dx / len, uy = dy / len, uz = dz / len;
    var shift = (side === "B") ? (t - len) : (len - t);

    var moving = (side === "B") ? sideB : sideA;
    var movingSet = {};
    for (var m = 0; m < moving.length; m++) movingSet[moving[m]] = true;

    var out = [];
    for (var i = 0; i < coords.length; i++) {
      if (movingSet[i]) {
        out.push([+coords[i][0] + shift * ux, +coords[i][1] + shift * uy, +coords[i][2] + shift * uz]);
      } else {
        out.push(coords[i]);
      }
    }
    return { ok: true, coords: out };
  }

  /* ---- bond-angle edit (todo 34) ---- */

  function _dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

  function _cross(a, b) {
    return [
      a[1] * b[2] - a[2] * b[1],
      a[2] * b[0] - a[0] * b[2],
      a[0] * b[1] - a[1] * b[0],
    ];
  }

  function _normalize(v) {
    var n = Math.sqrt(_dot(v, v));
    if (!isFinite(n) || n < 1e-12) return null;
    return [v[0] / n, v[1] / n, v[2] / n];
  }

  /**
   * Angle p-q-r at vertex q, in degrees [0, 180] via
   * atan2(|u1 x u2|, u1 . u2).  0 when either arm is degenerate.
   *
   * @param {Array<number>} p
   * @param {Array<number>} q
   * @param {Array<number>} r
   * @returns {number}
   */
  function angleDeg(p, q, r) {
    var u1 = _normalize([p[0] - q[0], p[1] - q[1], p[2] - q[2]]);
    var u2 = _normalize([r[0] - q[0], r[1] - q[1], r[2] - q[2]]);
    if (!u1 || !u2) return 0;
    var c = _cross(u1, u2);
    return Math.atan2(Math.sqrt(_dot(c, c)), _dot(u1, u2)) * 180 / Math.PI;
  }

  /**
   * Principal axis of a point set: the eigenvector of the unit-mass
   * covariance (inertia) tensor with the LARGEST eigenvalue — the
   * fragment's long axis.  Deterministic power iteration (fixed start
   * vector, 50 iterations); falls back to (1,0,0) for degenerate input.
   *
   * @param {Array<Array<number>>} points
   * @returns {Array<number>} unit vector
   */
  function _principalAxis(points) {
    if (!points || !points.length) return [1, 0, 0];
    var cx = 0, cy = 0, cz = 0;
    for (var i = 0; i < points.length; i++) {
      cx += +points[i][0]; cy += +points[i][1]; cz += +points[i][2];
    }
    cx /= points.length; cy /= points.length; cz /= points.length;
    var xx = 0, xy = 0, xz = 0, yy = 0, yz = 0, zz = 0;
    for (var j = 0; j < points.length; j++) {
      var dx = +points[j][0] - cx, dy = +points[j][1] - cy, dz = +points[j][2] - cz;
      xx += dx * dx; xy += dx * dy; xz += dx * dz;
      yy += dy * dy; yz += dy * dz; zz += dz * dz;
    }
    var v = [0.577, 0.577, 0.577];
    for (var it = 0; it < 50; it++) {
      var nv = [
        xx * v[0] + xy * v[1] + xz * v[2],
        xy * v[0] + yy * v[1] + yz * v[2],
        xz * v[0] + yz * v[1] + zz * v[2],
      ];
      var unit = _normalize(nv);
      if (!unit) break;
      v = unit;
    }
    return v;
  }

  /**
   * Collinear fallback axis: of the two unit vectors orthogonal to u_BC,
   * pick the one with the SMALLER |dot| against the C-side fragment's
   * principal axis p (least aligned with the fragment's long axis — the
   * best-conditioned rotation).
   *
   * @param {Array<number>} uBC      - unit vector B -> C
   * @param {Array<number>} p        - fragment principal axis (unit)
   * @returns {Array<number>} unit rotation axis orthogonal to uBC
   */
  function _stableOrthogonalAxis(uBC, p) {
    var ref = Math.abs(uBC[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0];
    var e1 = _normalize(_cross(uBC, ref));
    var e2 = _cross(uBC, e1);
    return Math.abs(_dot(p, e1)) <= Math.abs(_dot(p, e2)) ? e1 : e2;
  }

  /**
   * Rotate vector v about the unit axis k by radians theta (Rodrigues):
   *   v' = v cos(theta) + (k x v) sin(theta) + k (k . v)(1 - cos(theta))
   */
  function _rotateRodrigues(v, k, theta) {
    var cos = Math.cos(theta);
    var sin = Math.sin(theta);
    var kxv = _cross(k, v);
    var kdv = _dot(k, v);
    return [
      v[0] * cos + kxv[0] * sin + k[0] * kdv * (1 - cos),
      v[1] * cos + kxv[1] * sin + k[1] * kdv * (1 - cos),
      v[2] * cos + kxv[2] * sin + k[2] * kdv * (1 - cos),
    ];
  }

  /**
   * Edit the A-B-C bond angle (vertex B) to `targetDeg` by rigidly
   * rotating the C-side fragment about the axis through B perpendicular
   * to the A-B-C plane.  The A-B side is NEVER moved — for angle edits
   * the C side is the only rotatable side by definition, so a `moveSide`
   * argument of "A"/"B" is normalized to "C" (documented; anything else
   * rejects with invalid_move_side).
   *
   * Sign convention: axis n = normalize(u_BA x u_BC) (u_BA points B -> A,
   * u_BC points B -> C); rotating the C side about +n by
   * delta = target - current (degrees) moves u_BC away from u_BA exactly
   * when delta > 0 (opens the angle) and toward it when delta < 0 (closes).
   *
   * Collinear A-B-C (|u_BA x u_BC| < COLLINEAR_EPS): the plane normal is
   * undefined, so the axis is the unit vector orthogonal to u_BC that is
   * least aligned with the C-side fragment's principal axis (most stable
   * against the inertia axis), and the result carries `warning`
   * (STR.COLLINEAR_WARNING).  From collinearity, rotating by |delta|
   * yields exactly |delta| degrees (parallel case) or 180 - |delta|
   * (anti-parallel case) — both equal the target.
   *
   * Rejections: target outside [ANGLE_MIN, ANGLE_MAX] -> "out_of_range";
   * missing A-B or B-C edge -> "no_bond"; ring containing B-C ->
   * "ring_bond"; degenerate |A-B| or |B-C| -> "degenerate".
   *
   * PURE: NEW coords array; non-C-side rows keep byte-identical
   * references, the C side is rigid (Rodrigues rotation about B preserves
   * every internal distance), the input is never mutated.
   *
   * @param {Array<string>} symbols
   * @param {Array<Array<number>>} coords
   * @param {Array<{a: number, b: number}>} edges
   * @param {number} atomA
   * @param {number} atomB
   * @param {number} atomC
   * @param {number} targetDeg
   * @param {string|null} [moveSide] - normalized to "C" for angle edits
   * @returns {{ok: boolean, reason?: string, coords?: Array<Array<number>>,
   *            warning?: string}}
   */
  function editBondAngle(symbols, coords, edges, atomA, atomB, atomC, targetDeg, moveSide) {
    var t = +targetDeg;
    if (!isFinite(t) || t < ANGLE_MIN || t > ANGLE_MAX) {
      return { ok: false, reason: "out_of_range" };
    }
    if (moveSide != null && moveSide !== "A" && moveSide !== "B" && moveSide !== "C") {
      return { ok: false, reason: "invalid_move_side" };
    }
    if (!symbols || !coords || !edges) {
      return { ok: false, reason: "no_bond" };
    }
    if (!_hasEdge(edges, atomA, atomB) || !_hasEdge(edges, atomB, atomC)) {
      return { ok: false, reason: "no_bond" };
    }

    var fragments = fragmentsAfterCut(edges, coords.length, atomB, atomC);
    var sideA = _componentOf(fragments, atomA);
    var sideC = _componentOf(fragments, atomC);
    if (sideA && sideC && sideA === sideC) {
      return { ok: false, reason: "ring_bond" };
    }
    if (!sideA || !sideC) {
      return { ok: false, reason: "no_bond" };
    }

    var rb = coords[atomB];
    var uBA = _normalize([
      +coords[atomA][0] - +rb[0],
      +coords[atomA][1] - +rb[1],
      +coords[atomA][2] - +rb[2],
    ]);
    var uBC = _normalize([
      +coords[atomC][0] - +rb[0],
      +coords[atomC][1] - +rb[1],
      +coords[atomC][2] - +rb[2],
    ]);
    if (!uBA || !uBC) {
      return { ok: false, reason: "degenerate" };
    }

    var crossBA_BC = _cross(uBA, uBC);
    var crossNorm = Math.sqrt(_dot(crossBA_BC, crossBA_BC));
    var warning = null;
    var axis;
    if (crossNorm < COLLINEAR_EPS) {
      var cSide = [];
      for (var si = 0; si < sideC.length; si++) {
        cSide.push(coords[sideC[si]]);
      }
      axis = _stableOrthogonalAxis(uBC, _principalAxis(cSide));
      warning = STR.COLLINEAR_WARNING;
    } else {
      axis = [crossBA_BC[0] / crossNorm, crossBA_BC[1] / crossNorm, crossBA_BC[2] / crossNorm];
    }

    var current = angleDeg(coords[atomA], rb, coords[atomC]);
    var delta = (t - current) * Math.PI / 180;

    var movingSet = {};
    for (var mi = 0; mi < sideC.length; mi++) movingSet[sideC[mi]] = true;

    var out = [];
    for (var i = 0; i < coords.length; i++) {
      if (movingSet[i]) {
        var v = [+coords[i][0] - +rb[0], +coords[i][1] - +rb[1], +coords[i][2] - +rb[2]];
        var rotated = _rotateRodrigues(v, axis, delta);
        out.push([rotated[0] + +rb[0], rotated[1] + +rb[1], rotated[2] + +rb[2]]);
      } else {
        out.push(coords[i]);
      }
    }
    var result = { ok: true, coords: out };
    if (warning) result.warning = warning;
    return result;
  }

  function _hasEdge(edges, x, y) {
    for (var i = 0; i < edges.length; i++) {
      var e = edges[i];
      if ((e.a === x && e.b === y) || (e.a === y && e.b === x)) return true;
    }
    return false;
  }

  /* ---- dihedral edit (todo 35) ---- */

  /**
   * Signed dihedral A-B-C-D in degrees, normalized to (-180, 180]
   * (praxeolitic formula).  Convention: the angle between plane A-B-C and
   * plane B-C-D measured looking down the B -> C axis; POSITIVE when the
   * far bond (C-D) appears rotated CLOCKWISE relative to the near bond
   * (B-A)... equivalently, with b1 = normalize(C - B), the projection of
   * the B -> A direction onto the plane orthogonal to b1 is v, the
   * projection of the C -> D direction is w, and
   *   dihedral = atan2((b1 x v) . w, v . w)
   * Rotating the C-side about +b1 by delta ADDS delta to the dihedral
   * (verified numerically in the todo-35 tests).
   *
   * @param {Array<number>} pA
   * @param {Array<number>} pB
   * @param {Array<number>} pC
   * @param {Array<number>} pD
   * @returns {number} degrees in (-180, 180]; 0 for degenerate input
   */
  function dihedralDeg(pA, pB, pC, pD) {
    var b0 = [+pA[0] - +pB[0], +pA[1] - +pB[1], +pA[2] - +pB[2]];
    var b1 = _normalize([+pC[0] - +pB[0], +pC[1] - +pB[1], +pC[2] - +pB[2]]);
    var b2 = [+pD[0] - +pC[0], +pD[1] - +pC[1], +pD[2] - +pC[2]];
    if (!b1) return 0;
    var d0 = _dot(b0, b1);
    var d2 = _dot(b2, b1);
    var v = [b0[0] - d0 * b1[0], b0[1] - d0 * b1[1], b0[2] - d0 * b1[2]];
    var w = [b2[0] - d2 * b1[0], b2[1] - d2 * b1[1], b2[2] - d2 * b1[2]];
    var b1xv = _cross(b1, v);
    return Math.atan2(_dot(b1xv, w), _dot(v, w)) * 180 / Math.PI;
  }

  /**
   * Normalize an angle to (-180, 180] degrees.  -180 maps to +180 (the
   * interval is half-open on the negative side).
   *
   * @param {number} deg
   * @returns {number}
   */
  function normalizeDihedral(deg) {
    var d = +deg;
    if (!isFinite(d)) return 0;
    d = d % 360;
    if (d > 180) d -= 360;
    else if (d <= -180) d += 360;
    return d;
  }

  /**
   * Edit the A-B-C-D dihedral to `targetDeg` by rigidly rotating the
   * C-side fragment about the B-C axis.  The target is normalized to
   * (-180, 180] first; the rotation delta = normalizeDihedral(target -
   * current) is the SHORTEST rotation (|delta| <= 180, never a 340°
   * scenic route).  The A-side (atoms A and B) NEVER moves — for dihedral
   * edits the C/D side is the only rotatable side, so `moveSide` is
   * normalized to "C" exactly like the angle edit (anything but
   * "A"/"B"/"C"/null rejects invalid_move_side).
   *
   * Atom ordering and bond topology are untouched: the returned array has
   * the same length and index mapping, unmoved rows are the SAME
   * references, and no edge data is modified.
   *
   * Rejections: missing A-B, B-C, or C-D edge -> "no_bond"; ring
   * containing B-C (graph still connected after the cut) -> "ring_bond";
   * degenerate |B-C| -> "degenerate".
   *
   * PURE: NEW coords array; C-side rigid (rotation about the B-C line
   * preserves every internal distance; C itself lies ON the axis), input
   * never mutated.
   *
   * @param {Array<string>} symbols
   * @param {Array<Array<number>>} coords
   * @param {Array<{a: number, b: number}>} edges
   * @param {number} atomA
   * @param {number} atomB
   * @param {number} atomC
   * @param {number} atomD
   * @param {number} targetDeg
   * @param {string|null} [moveSide] - normalized to "C" for dihedral edits
   * @returns {{ok: boolean, reason?: string, coords?: Array<Array<number>>}}
   */
  function editDihedral(symbols, coords, edges, atomA, atomB, atomC, atomD, targetDeg, moveSide) {
    var target = normalizeDihedral(targetDeg);
    if (moveSide != null && moveSide !== "A" && moveSide !== "B" && moveSide !== "C") {
      return { ok: false, reason: "invalid_move_side" };
    }
    if (!symbols || !coords || !edges) {
      return { ok: false, reason: "no_bond" };
    }
    if (!_hasEdge(edges, atomA, atomB) || !_hasEdge(edges, atomB, atomC) ||
        !_hasEdge(edges, atomC, atomD)) {
      return { ok: false, reason: "no_bond" };
    }

    var fragments = fragmentsAfterCut(edges, coords.length, atomB, atomC);
    var sideA = _componentOf(fragments, atomA);
    var sideC = _componentOf(fragments, atomC);
    if (sideA && sideC && sideA === sideC) {
      return { ok: false, reason: "ring_bond" };
    }
    if (!sideA || !sideC) {
      return { ok: false, reason: "no_bond" };
    }

    var rb = coords[atomB];
    var rc = coords[atomC];
    var axis = _normalize([+rc[0] - +rb[0], +rc[1] - +rb[1], +rc[2] - +rb[2]]);
    if (!axis) {
      return { ok: false, reason: "degenerate" };
    }

    var current = dihedralDeg(coords[atomA], rb, rc, coords[atomD]);
    /* shortest rotation taking current -> target: |delta| <= 180 */
    var delta = normalizeDihedral(target - current) * Math.PI / 180;

    var movingSet = {};
    for (var mi = 0; mi < sideC.length; mi++) movingSet[sideC[mi]] = true;

    var out = [];
    for (var i = 0; i < coords.length; i++) {
      if (movingSet[i]) {
        var v = [+coords[i][0] - +rb[0], +coords[i][1] - +rb[1], +coords[i][2] - +rb[2]];
        var rotated = _rotateRodrigues(v, axis, delta);
        out.push([rotated[0] + +rb[0], rotated[1] + +rb[1], rotated[2] + +rb[2]]);
      } else {
        out.push(coords[i]);
      }
    }
    return { ok: true, coords: out };
  }

  /**
   * Orchestration for a dihedral edit on the currently displayed entry
   * (mirrors applyBondAngleEdit; viewer push deferred to todo 36).
   *
   * @param {number} atomA
   * @param {number} atomB
   * @param {number} atomC
   * @param {number} atomD
   * @param {number} targetDeg
   * @param {string|null} [moveSide] - normalized to "C"
   * @returns {{ok: boolean, reason?: string, coords?: Array<Array<number>>}}
   */
  function applyDihedralEdit(atomA, atomB, atomC, atomD, targetDeg, moveSide) {
    if (locked) return { ok: false, reason: "locked" };
    var guard = _entryScopeGuard();
    if (!guard.ok) return guard;
    var geometry = _currentGeometry();
    if (!geometry) return { ok: false, reason: "no_structure" };
    var graph = editorState.graph || buildGraphFromCurrentEntry();
    if (!graph) return { ok: false, reason: "no_structure" };

    var result = editDihedral(
      geometry.symbols, geometry.coords, graph.edges,
      atomA, atomB, atomC, atomD, targetDeg, moveSide
    );
    if (result.ok) {
      editorState.pendingEdit = {
        type: "dihedral",
        atomA: atomA,
        atomB: atomB,
        atomC: atomC,
        atomD: atomD,
        target: normalizeDihedral(targetDeg),
        moveSide: "C",
        coords: result.coords,
      };
      _commitEdit("dihedral", [atomA, atomB, atomC, atomD], result.coords);
    }
    return result;
  }

  /**
   * Orchestration for a bond-angle edit on the currently displayed entry
   * (mirrors applyBondLengthEdit; viewer push deferred to todo 36).
   *
   * @param {number} atomA
   * @param {number} atomB
   * @param {number} atomC
   * @param {number} targetDeg
   * @param {string|null} [moveSide] - normalized to "C"
   * @returns {{ok: boolean, reason?: string, coords?: Array<Array<number>>,
   *            warning?: string}}
   */
  function applyBondAngleEdit(atomA, atomB, atomC, targetDeg, moveSide) {
    if (locked) return { ok: false, reason: "locked" };
    var guard = _entryScopeGuard();
    if (!guard.ok) return guard;
    var geometry = _currentGeometry();
    if (!geometry) return { ok: false, reason: "no_structure" };
    var graph = editorState.graph || buildGraphFromCurrentEntry();
    if (!graph) return { ok: false, reason: "no_structure" };

    var result = editBondAngle(
      geometry.symbols, geometry.coords, graph.edges,
      atomA, atomB, atomC, targetDeg, moveSide
    );
    if (result.ok) {
      editorState.pendingEdit = {
        type: "bond_angle",
        atomA: atomA,
        atomB: atomB,
        atomC: atomC,
        target: +targetDeg,
        moveSide: "C",
        coords: result.coords,
      };
      if (result.warning) {
        editorState.pendingEdit.warning = result.warning;
      }
      _commitEdit("bond_angle", [atomA, atomB, atomC], result.coords);
    }
    return result;
  }

  /**
   * Orchestration for a bond-length edit on the currently displayed
   * entry: respects the animation lock, reads displayed coords/symbols +
   * the cached graph, runs the pure edit, and STAGES the result in
   * editorState.pendingEdit (the viewer preview/apply pipeline lands in
   * todo 36 — nothing is pushed to the display here).
   *
   * @param {number} atomA
   * @param {number} atomB
   * @param {number} targetLength
   * @param {string|null} [moveSide]
   * @returns {{ok: boolean, reason?: string, coords?: Array<Array<number>>}}
   */
  function applyBondLengthEdit(atomA, atomB, targetLength, moveSide) {
    if (locked) return { ok: false, reason: "locked" };
    var guard = _entryScopeGuard();
    if (!guard.ok) return guard;
    var geometry = _currentGeometry();
    if (!geometry) return { ok: false, reason: "no_structure" };
    var graph = editorState.graph || buildGraphFromCurrentEntry();
    if (!graph) return { ok: false, reason: "no_structure" };

    var result = editBondLength(
      geometry.symbols, geometry.coords, graph.edges,
      atomA, atomB, targetLength, moveSide
    );
    if (result.ok) {
      var fragments = fragmentsAfterCut(graph.edges, geometry.coords.length, atomA, atomB);
      editorState.pendingEdit = {
        type: "bond_length",
        atomA: atomA,
        atomB: atomB,
        target: +targetLength,
        moveSide: resolveMoveSide(fragments, atomA, atomB, moveSide),
        coords: result.coords,
      };
      _commitEdit("bond_length", [atomA, atomB], result.coords);
    }
    return result;
  }

  /* ---- transactions + collision validation + entry scoping (todo 36) ---- */

  /**
   * Post-edit safety check (doc §6.3): every NON-bonded pair (no shared
   * edge) with distance < COLLISION_FACTOR*(r_a + r_b) (strictly) is a
   * severe collision.  PURE; nothing is mutated.  Warnings never block —
   * the edit stays applied and undoable.
   *
   * @param {Array<string>} symbols
   * @param {Array<Array<number>>} coords
   * @param {Array<{a: number, b: number}>|null} edges
   * @returns {Array<{a: number, b: number, distance: number, severity: string}>}
   */
  function checkCollisions(symbols, coords, edges) {
    var hits = [];
    if (!symbols || !coords) return hits;
    var bonded = {};
    if (edges && edges.length) {
      for (var e = 0; e < edges.length; e++) {
        var lo = Math.min(edges[e].a, edges[e].b);
        var hi = Math.max(edges[e].a, edges[e].b);
        bonded[lo + "-" + hi] = true;
      }
    }
    for (var i = 0; i < coords.length; i++) {
      var ci = coords[i];
      if (!ci) continue;
      for (var j = i + 1; j < coords.length; j++) {
        if (bonded[i + "-" + j]) continue;
        var cj = coords[j];
        if (!cj) continue;
        var dx = +ci[0] - +cj[0], dy = +ci[1] - +cj[1], dz = +ci[2] - +cj[2];
        var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (!isFinite(dist)) continue;
        if (dist < COLLISION_FACTOR * (_radiusOf(symbols[i]) + _radiusOf(symbols[j]))) {
          hits.push({ a: i, b: j, distance: dist, severity: "severe" });
        }
      }
    }
    return hits;
  }

  /**
   * Bind the edit session to an entry (called by structure_viewer when
   * geometry loads).  Binding a DIFFERENT entry while dirty does NOT
   * auto-discard: it records editorState.pendingSwitch and returns
   * {ok:false, reason:"dirty_switch"} — the UI shows the 放弃/另存为/取消
   * prompt and confirmSwitch finishes the switch.
   *
   * @param {string} entryId
   * @param {Array<string>} symbols
   * @param {Array<Array<number>>} coords
   * @returns {{ok: boolean, reason?: string}}
   */
  function bindEntry(entryId, symbols, coords) {
    if (editorState.entryId !== null && editorState.entryId !== entryId && isDirty()) {
      editorState.pendingSwitch = {
        targetEntryId: entryId,
        targetSymbols: symbols,
        targetCoords: coords,
      };
      return { ok: false, reason: "dirty_switch" };
    }
    _rebind(entryId, symbols, coords);
    return { ok: true };
  }

  function _rebind(entryId, symbols, coords, keepGraph) {
    editorState.entryId = entryId;
    editorState.originalCoords = coords
      ? coords.map(function (row) { return [+row[0], +row[1], +row[2]]; })
      : null;
    editorState.transactions = [];
    editorState.redoStack = [];
    editorState.pendingEdit = null;
    editorState.pendingSwitch = null;
    if (!keepGraph) {
      editorState.graph = null;
      editorState.provenance = null;
    }
    syncDirtyFlag();
  }

  /**
   * Resolve a pending dirty-switch prompt.
   * "discard" -> drop transactions and rebind to the pending entry;
   * "save"    -> set saveRequested, call the todo-37 hook
   *              (window.ACPStructureViewer.requestSaveEditedAsset) when
   *              present, then rebind exactly like discard;
   * "cancel"  -> stay on the current entry (prompt cleared, edits kept).
   *
   * @param {string} action - "discard" | "save" | "cancel"
   * @returns {{switched: boolean}|null} null for invalid actions
   */
  function confirmSwitch(action) {
    var pending = editorState.pendingSwitch;
    if (!pending) return null;
    if (action === "cancel") {
      editorState.pendingSwitch = null;
      return { switched: false };
    }
    if (action !== "discard" && action !== "save") return null;
    if (action === "save") {
      editorState.saveRequested = true;
      var sv = (typeof window !== "undefined" && window.ACPStructureViewer)
        ? window.ACPStructureViewer
        : null;
      if (sv && typeof sv.requestSaveEditedAsset === "function") {
        try { sv.requestSaveEditedAsset(); } catch (_) { /* hook is best-effort */ }
      }
    }
    _rebind(pending.targetEntryId, pending.targetSymbols, pending.targetCoords);
    return { switched: true };
  }

  /**
   * Net applied transaction count > 0 (undos pop the stack, so the length
   * is the live dirty state).
   *
   * @returns {boolean}
   */
  function isDirty() {
    return editorState.transactions.length > 0;
  }

  /**
   * Mirror isDirty() into the structure viewer store (todo 15's dirty
   * guard in refreshIfChanged goes live through this) and refresh the
   * inspector edit panel when a DOM is present.
   */
  function syncDirtyFlag() {
    if (typeof window !== "undefined" && window.ACPStructureViewer &&
        window.ACPStructureViewer.state) {
      window.ACPStructureViewer.state.dirty = isDirty();
    }
    if (typeof document !== "undefined" && window.ACPStructureViewer &&
        typeof window.ACPStructureViewer.renderInspector === "function") {
      try { window.ACPStructureViewer.renderInspector(); } catch (_) { /* render is best-effort */ }
    }
  }

  /**
   * Shared commit path for every apply*: entry scoping, transaction record
   * {type, atom_ids, before, after, moved_atom_ids, collision_warnings},
   * live application to the authoritative coordinates, and a best-effort
   * refresh of the 3D model.  When ACPGeometryStore owns the entry the
   * coordinates go through updateCoordinates() (selection + measurements
   * survive, revision bumps); otherwise the legacy displayedCoords + xyz
   * bridge path is kept.  Edits touch coordinates ONLY — symbols, bond
   * orders, and topology never change.
   *
   * @param {string} type - "bond_length" | "bond_angle" | "dihedral"
   * @param {Array<number>} atomIds
   * @param {Array<Array<number>>} afterCoords
   * @returns {void}
   */
  function _commitEdit(type, atomIds, afterCoords) {
    var geometry = _currentGeometry();
    var svState = (typeof window !== "undefined" && window.ACPStructureViewer)
      ? window.ACPStructureViewer.state
      : null;
    var before = geometry ? geometry.coords
      : (svState ? svState.displayedCoords : []);
    var symbols = geometry ? geometry.symbols
      : (svState ? svState.displayedSymbols : []);
    var moved = [];
    for (var i = 0; i < afterCoords.length; i++) {
      if (_coordsDiffer(afterCoords[i], before ? before[i] : undefined)) moved.push(i);
    }
    var warnings = checkCollisions(symbols, afterCoords, _graphEdges());
    editorState.transactions.push({
      type: type,
      atom_ids: atomIds.slice(),
      before: before,
      after: afterCoords,
      moved_atom_ids: moved,
      collision_warnings: warnings,
    });
    editorState.redoStack = [];
    var viaStore = _writeCoordinates(afterCoords);
    syncDirtyFlag();
    if (!viaStore) _pushModelToViewer();
  }

  /**
   * Value comparison for transaction moved_atom_ids: rows count as equal
   * when all three components match, so store-owned rows and viewer rows
   * carrying identical geometry never count as moved.
   *
   * @param {Array<number>|undefined} rowA
   * @param {Array<number>|undefined} rowB
   * @returns {boolean}
   */
  function _coordsDiffer(rowA, rowB) {
    if (rowA === rowB) return false;
    if (!rowA || !rowB) return true;
    return +rowA[0] !== +rowB[0] || +rowA[1] !== +rowB[1] || +rowA[2] !== +rowB[2];
  }

  /**
   * Write committed coordinates to the authoritative owner: the geometry
   * store when loaded (measurements/selection survive; the store emits
   * "coordinates"), otherwise the legacy viewer field.
   *
   * @param {Array<Array<number>>} coords
   * @returns {boolean} true when the store accepted the coordinates
   */
  function _writeCoordinates(coords) {
    var geometry = _currentGeometry();
    if (geometry && geometry.store) {
      geometry.store.updateCoordinates(coords);
      return true;
    }
    if (typeof window !== "undefined" && window.ACPStructureViewer &&
        window.ACPStructureViewer.state) {
      window.ACPStructureViewer.state.displayedCoords = coords;
    }
    return false;
  }

  function _graphEdges() {
    var graph = editorState.graph || buildGraphFromCurrentEntry();
    return graph ? graph.edges : [];
  }

  function _xyzText(symbols, coords) {
    var out = String(coords.length) + "\n\n";
    for (var i = 0; i < coords.length; i++) {
      out += symbols[i] + " " + (+coords[i][0]).toFixed(6) + " " +
        (+coords[i][1]).toFixed(6) + " " + (+coords[i][2]).toFixed(6) + "\n";
    }
    return out;
  }

  /**
   * Best-effort refresh of the displayed 3D model through the app's
   * existing xyz bridge (no new viewer, no re-framing contract change).
   * When ACPGeometryStore owns the loaded entry this is a no-op: the store
   * subscription re-renders the canvas asynchronously and calling the bridge
   * would reload the model (clearing selection + measurements).
   */
  function _pushModelToViewer() {
    if (typeof window === "undefined") return;
    if (_activeStore()) return;
    var svState = window.ACPStructureViewer ? window.ACPStructureViewer.state : null;
    if (!svState || !svState.displayedCoords || !svState.displayedSymbols) return;
    if (typeof window._svLoadXyzToViewer === "function") {
      try {
        window._svLoadXyzToViewer(
          _xyzText(svState.displayedSymbols, svState.displayedCoords),
          svState.displayedEntryId
        );
      } catch (_) { /* display refresh is best-effort */ }
    }
  }

  /**
   * Entry-scope guard shared by the apply* paths: rejects when the edit
   * session is bound to a different entry than the authoritative geometry
   * (the ACPGeometryStore entry when loaded, else the viewer's displayed
   * entry — "must NOT apply an edit outside the current entry"); auto-binds
   * on the first edit of a session.
   *
   * @returns {{ok: boolean, reason?: string}}
   */
  function _entryScopeGuard() {
    var store = _activeStore();
    var storeGeometry = store ? _storeGeometry(store) : null;
    if (storeGeometry) {
      if (editorState.entryId === null) {
        /* first edit of a session: adopt the store entry; a graph already
           built/seeded for it stays valid */
        _rebind(store.state.entryId, storeGeometry.symbols, storeGeometry.coords, true);
      } else if (editorState.entryId !== store.state.entryId) {
        return { ok: false, reason: "entry_mismatch" };
      }
      return { ok: true };
    }
    var svState = (typeof window !== "undefined" && window.ACPStructureViewer)
      ? window.ACPStructureViewer.state
      : null;
    if (!svState || !svState.displayedCoords || !svState.displayedSymbols ||
        !svState.displayedEntryId) {
      return { ok: false, reason: "no_structure" };
    }
    if (editorState.entryId === null) {
      /* first edit of a session: adopt the displayed entry; a graph
         already built/seeded for it stays valid */
      _rebind(svState.displayedEntryId, svState.displayedSymbols,
        svState.displayedCoords, true);
    } else if (editorState.entryId !== svState.displayedEntryId) {
      return { ok: false, reason: "entry_mismatch" };
    }
    return { ok: true };
  }

  /**
   * Undo the last transaction: coordinates revert to `before` (through
   * ACPGeometryStore.updateCoordinates when loaded, else the legacy viewer
   * field; byte-identical row references are preserved), the transaction
   * moves to the redo stack.
   *
   * @returns {{ok: boolean, reason?: string}}
   */
  function undoEdit() {
    if (locked) return { ok: false, reason: "locked" };
    var guard = _entryScopeGuard();
    if (!guard.ok) return guard;
    if (!editorState.transactions.length) return { ok: false, reason: "nothing_to_undo" };
    var txn = editorState.transactions.pop();
    editorState.redoStack.push(txn);
    var viaStore = _writeCoordinates(txn.before);
    syncDirtyFlag();
    if (!viaStore) _pushModelToViewer();
    return { ok: true, transaction: txn };
  }

  /**
   * Redo the last undone transaction (store-routed exactly like undo).
   *
   * @returns {{ok: boolean, reason?: string}}
   */
  function redoEdit() {
    if (locked) return { ok: false, reason: "locked" };
    var guard = _entryScopeGuard();
    if (!guard.ok) return guard;
    if (!editorState.redoStack.length) return { ok: false, reason: "nothing_to_redo" };
    var txn = editorState.redoStack.pop();
    editorState.transactions.push(txn);
    var viaStore = _writeCoordinates(txn.after);
    syncDirtyFlag();
    if (!viaStore) _pushModelToViewer();
    return { ok: true, transaction: txn };
  }

  /**
   * Revert ALL transactions: coordinates return to the originalCoords
   * snapshot captured when the entry was bound (store-routed when loaded).
   *
   * @returns {{ok: boolean, reason?: string}}
   */
  function resetEdits() {
    if (locked) return { ok: false, reason: "locked" };
    if (!editorState.originalCoords) return { ok: false, reason: "no_structure" };
    editorState.transactions = [];
    editorState.redoStack = [];
    var viaStore = _writeCoordinates(editorState.originalCoords);
    syncDirtyFlag();
    if (!viaStore) _pushModelToViewer();
    return { ok: true };
  }

  /**
   * Measurement-tool hook: the app's 键长/键角/二面角 measurement UI
   * raises edit intent through this dispatcher (kind + selected atom ids
   * + target).  On success the optional store measurement is marked applied
   * — its value has already been recomputed by updateCoordinates().
   *
   * @param {string} kind - "bond_length" | "bond_angle" | "dihedral"
   * @param {Array<number>} atomIds - 2 / 3 / 4 atom indices
   * @param {number} target
   * @param {string} [measurementId] - store measurement id to mark applied
   * @returns {{ok: boolean, reason?: string, coords?: Array, warning?: string}}
   */
  function applyMeasuredEdit(kind, atomIds, target, measurementId) {
    var result;
    if (!atomIds || !atomIds.length) return { ok: false, reason: "no_bond" };
    if (kind === "bond_length" && atomIds.length >= 2) {
      result = applyBondLengthEdit(atomIds[0], atomIds[1], target, null);
    } else if (kind === "bond_angle" && atomIds.length >= 3) {
      result = applyBondAngleEdit(atomIds[0], atomIds[1], atomIds[2], target, null);
    } else if (kind === "dihedral" && atomIds.length >= 4) {
      result = applyDihedralEdit(atomIds[0], atomIds[1], atomIds[2], atomIds[3], target, null);
    } else {
      return { ok: false, reason: "no_bond" };
    }
    if (result && result.ok && measurementId) {
      var store = _activeStore();
      if (store && typeof store.markApplied === "function") {
        store.markApplied(measurementId, true);
      }
    }
    return result;
  }

  /* ---- export + save-as-asset + wizard handoff (todo 37) ---- */

  /**
   * Provenance comment line for exported/edited XYZ:
   * "ACP edit: parent={jobId} entry={entryId} ops={n} ({summary})" where
   * summary counts operations by type, e.g. "bond_length:1, dihedral:2".
   *
   * @param {{jobId: string|null, entryId: string|null,
   *          transactions: Array<Object>}|null} provenanceInfo
   * @returns {string}
   */
  function provenanceComment(provenanceInfo) {
    var txns = (provenanceInfo && provenanceInfo.transactions) || [];
    var counts = {};
    var order = [];
    for (var i = 0; i < txns.length; i++) {
      var t = txns[i].type;
      if (counts[t] === undefined) {
        counts[t] = 0;
        order.push(t);
      }
      counts[t] += 1;
    }
    var summary = order.map(function (t) { return t + ":" + counts[t]; }).join(", ");
    return "ACP edit: parent=" + (provenanceInfo ? provenanceInfo.jobId : "") +
      " entry=" + (provenanceInfo ? provenanceInfo.entryId : "") +
      " ops=" + txns.length + " (" + summary + ")";
  }

  /**
   * Build the edited XYZ text.  Line 2 carries the provenance comment
   * (doc §6.3: parent job, parent entry, edit summary); the original
   * comment is kept only when no provenance info is supplied.  PURE.
   *
   * @param {Array<string>} symbols
   * @param {Array<Array<number>>} coords
   * @param {string} [originalComment]
   * @param {{jobId: string|null, entryId: string|null,
   *          transactions: Array<Object>}|null} [provenanceInfo]
   * @returns {string}
   */
  function buildEditedXyz(symbols, coords, originalComment, provenanceInfo) {
    if (!symbols || !coords || symbols.length !== coords.length || !symbols.length) {
      return "";
    }
    var comment = provenanceInfo
      ? provenanceComment(provenanceInfo)
      : (originalComment || "");
    var out = String(coords.length) + "\n" + comment + "\n";
    for (var i = 0; i < coords.length; i++) {
      var c = coords[i];
      if (!c || c.length < 3) return "";
      out += symbols[i] + " " + (+c[0]).toFixed(6) + " " +
        (+c[1]).toFixed(6) + " " + (+c[2]).toFixed(6) + "\n";
    }
    return out;
  }

  function _currentProvenanceInfo() {
    var svState = (typeof window !== "undefined" && window.ACPStructureViewer)
      ? window.ACPStructureViewer.state
      : null;
    return {
      jobId: svState ? svState.jobId : null,
      entryId: editorState.entryId,
      transactions: editorState.transactions,
    };
  }

  /**
   * Export the edited structure as an XYZ download (Blob + a.click).  In
   * Node (no DOM) the text is returned without any download attempt.
   * Coordinates come from the authoritative geometry (store first).
   *
   * @returns {string|null} the exported XYZ text
   */
  function exportEditedXyz() {
    var geometry = _currentGeometry();
    if (!geometry) return null;
    var text = buildEditedXyz(
      geometry.symbols, geometry.coords, "",
      _currentProvenanceInfo()
    );
    if (!text) return null;
    if (typeof document === "undefined" || typeof Blob === "undefined") {
      return text;
    }
    try {
      var blob = new Blob([text], { type: "chemical/x-xyz" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = (editorState.entryId || "edited") + "_edited.xyz";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    } catch (_) { /* download is best-effort; the text is still returned */ }
    return text;
  }

  function _getFetchImpl() {
    if (typeof window !== "undefined" && window.ACPStructureEditor &&
        typeof window.ACPStructureEditor._fetchImpl === "function") {
      return window.ACPStructureEditor._fetchImpl;
    }
    if (typeof window !== "undefined" && typeof window.fetch === "function") {
      return window.fetch.bind(window);
    }
    return null;
  }

  /**
   * POST the edited structure to /api/v1/structure-assets with the four
   * extended fields (parent_job_id, parent_entry_id, edit_operations —
   * the FULL transaction list — and provenance).  Edits stay in memory;
   * success records editorState.savedAssetId, failure records saveError
   * and keeps everything.  Task directories are never written.
   *
   * @param {string} [name]
   * @returns {Promise<{ok: boolean, assetId?: string, error?: string}>}
   */
  function saveEditedAsset(name) {
    var geometry = _currentGeometry();
    if (!geometry) {
      return Promise.resolve({ ok: false, error: "no_structure" });
    }
    var svState = (typeof window !== "undefined" && window.ACPStructureViewer)
      ? window.ACPStructureViewer.state
      : null;
    var fetchFn = _getFetchImpl();
    if (!fetchFn) {
      return Promise.resolve({ ok: false, error: "fetch not available" });
    }
    var xyzText = buildEditedXyz(
      geometry.symbols, geometry.coords, "",
      _currentProvenanceInfo()
    );
    var body = {
      name: name || ((editorState.entryId || "structure") + " " + STR.EDITED_SUFFIX),
      xyz_text: xyzText,
      charge: 0,
      multiplicity: 1,
      parent_job_id: svState ? svState.jobId : null,
      parent_entry_id: editorState.entryId,
      edit_operations: editorState.transactions,
      provenance: {
        comment: provenanceComment(_currentProvenanceInfo()),
        created_at: new Date().toISOString(),
        op_count: editorState.transactions.length,
      },
    };
    return fetchFn("/api/v1/structure-assets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
      .then(function (resp) {
        if (!resp.ok) {
          throw new Error("HTTP " + resp.status + " " + resp.statusText);
        }
        return resp.json();
      })
      .then(function (data) {
        editorState.savedAssetId = data.asset_id || null;
        editorState.saveError = null;
        return { ok: true, assetId: data.asset_id };
      })
      .catch(function (err) {
        editorState.saveError = (err && err.message) ? err.message : String(err);
        return { ok: false, error: editorState.saveError };
      });
  }

  /**
   * Todo-36 dirty-switch hook: save the edited asset; on success complete
   * the pending switch (rebind to the target entry per confirmSwitch
   * semantics).  Never discards edits on failure.
   *
   * @returns {Promise<{ok: boolean, assetId?: string, error?: string}>}
   */
  function requestSaveEditedAsset() {
    editorState.saveRequested = true;
    return saveEditedAsset().then(function (res) {
      if (res.ok && editorState.pendingSwitch) {
        var pending = editorState.pendingSwitch;
        _rebind(pending.targetEntryId, pending.targetSymbols, pending.targetCoords);
      }
      return res;
    });
  }

  /**
   * 以此结构新建计算: copy the current in-memory edited XYZ into the
   * new-task wizard via the app bridge (window._svPrefillNewCalculation —
   * opens the modal and prefills the structure textarea).  The user still
   * confirms method/charge/multiplicity; NO submission is ever triggered
   * here (anti-pattern #29).  No parent-job files are modified.
   *
   * @returns {{ok: boolean, xyz?: string, error?: string}}
   */
  function prefillNewCalculation() {
    var geometry = _currentGeometry();
    if (!geometry) {
      return { ok: false, error: "no_structure" };
    }
    var xyzText = buildEditedXyz(
      geometry.symbols, geometry.coords, "",
      _currentProvenanceInfo()
    );
    if (!xyzText) {
      return { ok: false, error: "no_structure" };
    }
    if (typeof window !== "undefined" &&
        typeof window._svPrefillNewCalculation === "function") {
      try {
        window._svPrefillNewCalculation(xyzText);
      } catch (_) { /* wizard bridge is best-effort */ }
      return { ok: true, xyz: xyzText };
    }
    return { ok: false, error: "wizard bridge unavailable", xyz: xyzText };
  }

  /**
   * Build the graph for the currently displayed entry (reads
   * ACPGeometryStore.state first, falls back to
   * ACPStructureViewer.state.displayedCoords/Symbols).  Explicit bonds may
   * be passed by the SDF wiring (todo 33+); otherwise bonds are inferred.
   * No-op returning null when the animation lock is held (todo 30) or no
   * coordinates are displayed.  The result is cached on editorState for the
   * inspector provenance line.
   *
   * @param {Array<{a: number, b: number, order?: number}>|null} [explicitBonds]
   * @returns {{edges: Array, provenance: string}|null}
   */
  function buildGraphFromCurrentEntry(explicitBonds) {
    if (locked) return null;
    var geometry = _currentGeometry();
    if (!geometry) return null;
    var result = buildAdjacency(geometry.symbols, geometry.coords, explicitBonds);
    editorState.graph = result;
    editorState.provenance = result.provenance;
    return result;
  }

  /* ---- public namespace ---- */
  window.ACPStructureEditor = {
    version: VERSION,
    STR: STR,
    COVALENT_RADII: COVALENT_RADII,
    BOND_TOLERANCE: BOND_TOLERANCE,
    DEFAULT_RADIUS: DEFAULT_RADIUS,
    editorState: editorState,
    /**
     * Set the animation mutual-exclusion lock and broadcast the new
     * interaction state ("acp:interaction-state") so the app can disable
     * measurement/edit affordances; also pokes the viewer refresh hook.
     *
     * @param {boolean} value
     * @returns {void}
     */
    setLocked: function (value) {
      locked = value === true;
      try {
        if (typeof window !== "undefined" && window.dispatchEvent &&
            typeof CustomEvent === "function") {
          window.dispatchEvent(new CustomEvent("acp:interaction-state", {
            detail: { source: "editor", locked: value === true }
          }));
        }
      } catch (_) { /* broadcast is best-effort */ }
      try {
        if (typeof window !== "undefined" &&
            typeof window._svRefreshInteractionState === "function") {
          window._svRefreshInteractionState();
        }
      } catch (_) { /* broadcast is best-effort */ }
    },
    isLocked: function () {
      return locked;
    },
    buildGraphFromCurrentEntry: buildGraphFromCurrentEntry,
    buildAdjacency: buildAdjacency,
    connectedComponents: connectedComponents,
    fragmentsAfterCut: fragmentsAfterCut,
    parseMolBonds: parseMolBonds,
    editBondLength: editBondLength,
    editBondAngle: editBondAngle,
    editDihedral: editDihedral,
    dihedralDeg: dihedralDeg,
    normalizeDihedral: normalizeDihedral,
    angleDeg: angleDeg,
    _principalAxis: _principalAxis,
    resolveMoveSide: resolveMoveSide,
    defaultMoveSide: defaultMoveSide,
    applyBondLengthEdit: applyBondLengthEdit,
    applyBondAngleEdit: applyBondAngleEdit,
    applyDihedralEdit: applyDihedralEdit,
    applyMeasuredEdit: applyMeasuredEdit,
    validateEditableCoordinate: validateEditableCoordinate,
    REASON_MESSAGES: REASON_MESSAGES,
    reasonMessage: reasonMessage,
    checkCollisions: checkCollisions,
    bindEntry: bindEntry,
    confirmSwitch: confirmSwitch,
    undoEdit: undoEdit,
    redoEdit: redoEdit,
    resetEdits: resetEdits,
    isDirty: isDirty,
    syncDirtyFlag: syncDirtyFlag,
    COLLISION_FACTOR: COLLISION_FACTOR,
    buildEditedXyz: buildEditedXyz,
    provenanceComment: provenanceComment,
    exportEditedXyz: exportEditedXyz,
    saveEditedAsset: saveEditedAsset,
    requestSaveEditedAsset: requestSaveEditedAsset,
    prefillNewCalculation: prefillNewCalculation,
    _fetchImpl: null,
  };
})();
