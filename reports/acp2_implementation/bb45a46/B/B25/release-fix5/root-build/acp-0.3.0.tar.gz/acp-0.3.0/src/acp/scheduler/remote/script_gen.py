"""
LSF Script Generator
====================

Generates OpenLAVA/LSF submission scripts and the equivalent
``python -m acp.cli run <workflow>`` command for remote execution.

The CLI command mapping mirrors :meth:`JobRunner._build_cmd` so that a
remote job runs exactly the same workflow logic as a local subprocess job.
BSUB directive formatting follows :class:`LSFClusterAdapter._generate_lsf_script`.

Author: QCcalc Team
"""

from __future__ import annotations

import json
import logging
import math
import posixpath
import shlex
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

from acp.scheduler.jobs import (
    SCAN_CONFIG_FILENAME,
    JobSpec,
    batchoptimize_method_flags,
    censo_ewin_from_method,
    censo_preset_from_method,
    censo_solvent_from_method,
    confsearch_method_flags,
    electronic_state_from_method,
    input_chemistry_flags,
    nmr_candidate_metadata_flags,
    nmr_flag_config,
    nmr_method_flags,
    scan_method_flags,
    xtbmd_method_flags,
)
from acp.scheduler.remote.config import RemoteNode
from acp.scheduler.resources import resolve_job_resources, with_job_resources
from acp_services.runtime.execution_chain import (
    EXECUTION_ENTRY_ENVELOPE,
    ExecutionLaunch,
    worker_argv,
)
from acp_services.runtime.method_flags import method_levels_to_cli_flags
from cccp.utils.resource_utils import mem_to_mb

logger = logging.getLogger(__name__)


def _looks_like_smiles(s: str) -> bool:
    """Heuristic: is *s* a SMILES token rather than a file path?"""
    stripped = s.strip()
    if not stripped or "\n" in stripped or len(stripped) > 200:
        return False
    if stripped[0].isdigit():
        return False
    return True


__all__ = [
    "LSFScriptSpec",
    "build_lsf_script_spec",
    "build_remote_cli_command",
    "build_remote_nmr_cmd_tail",
    "build_remote_scan_config_payload",
    "build_remote_stage_cmd_tail",
    "build_remote_worker_command",
    "derive_lsf_resources",
    "generate_lsf_script",
]

_REMOTE_CHECKPOINT_PATH = "WORK/00_RUNTIME/checkpoint.json"
_REMOTE_RESULT_MANIFEST_PATH = "RESULT/result_manifest.json"

_DEFAULT_QUEUE = "normal"
_DEFAULT_WALLTIME = ""

_GFN_DISPLAY_TO_INT: dict[str, int] = {
    "GFN0-xTB": 0,
    "GFN1-xTB": 1,
    "GFN2-xTB": 2,
    "0": 0,
    "1": 1,
    "2": 2,
}


@dataclass(frozen=True)
class LSFScriptSpec:
    """Parameters describing a remote LSF submission.

    Attributes:
        job_name: BSUB ``-J`` job name.
        queue: BSUB ``-q`` queue name.
        nproc: BSUB ``-n`` number of CPU cores.
        mem_mb_per_core: Rounded-up per-core share of the total budget in MB.
        mem_total_mb: Exact task memory in MB, used for the per-process
            ``-M`` RLIMIT_AS with the existing 5% margin and MB→KB conversion.
            Older direct constructors fall back to mem_mb_per_core * nproc.
            Chosen over ``rusage[mem=...]`` to avoid OpenLava's
            double-counting of reserved vs. actually-used memory, which
            caused jobs to PEND unnecessarily.
        walltime: BSUB ``-W`` wall-clock limit (e.g. ``"24:00"``).
        remote_code_dir: Directory where ACP source is synced; used to
            build ``PYTHONPATH={remote_code_dir}/src``.
        remote_job_dir: The remote job working directory; the script
            ``cd``\\ s here before launching the CLI.
        cli_command: Argv list (e.g.
            ``["python", "-m", "acp.cli", "run", ...]``).
        pre_cmds: Shell lines injected verbatim into the script body
            before the CLI runs (after the exit-code traps).  Used for
            ``module load`` / environment setup on module-based clusters.
        extra_flags: Additional raw BSUB flags (e.g. ``"-R span[hosts=1]"``).
        pythonpath_code_root: Add the release root itself to ``PYTHONPATH``.
            True for an installed-wheel release (packages live at the
            release root, no ``src`` layer); False for a source checkout.
    """

    job_name: str
    queue: str
    nproc: int
    mem_mb_per_core: int
    walltime: str
    remote_code_dir: str
    remote_job_dir: str
    cli_command: list[str]
    pre_cmds: list[str] = field(default_factory=list)
    extra_flags: str = ""
    mem_total_mb: int | None = None
    pythonpath_code_root: bool = False


# ── Allowed remote workflows ────────────────────────────────────────────

_ALLOWED_REMOTE_WORKFLOWS: frozenset[str] = frozenset(
    {
        "Confsearch",
        "PESsearch",
        "BatchOptimize",
        "ensemble",
        "energy",
        "nmr",
        "xtbmd_censo_energy",
        "singlepoint",
        "optimize",
        "frequency",
        "scan",
        "irc",
        "tsmode",
        "xtb_optimize",
    }
)


def build_remote_cli_command(
    spec: JobSpec,
    input_path: str = "inputs/input.xyz",
    python_executable: str = "python",
    config_path: str | None = None,
    *,
    execution: ExecutionLaunch | None = None,
) -> list[str]:
    """Build the argv a remote node runs for *spec*.

    When *execution* selects the frozen-envelope entry the argv is the Services
    worker bootstrap (``python -m acp_services.worker_bootstrap``); otherwise the
    legacy CLI mapping is built. The two entries are mutually exclusive — the
    dispatcher freezes the choice on the attempt, and this function emits only
    the selected one.

    Args:
        python_executable: Interpreter to use on the node.
        config_path: Optional path to a job-level YAML config on the remote
            node.
        execution: The attempt's frozen execution launch (``None`` = legacy).
    """
    py = python_executable or "python"
    if execution is not None and execution.entry == EXECUTION_ENTRY_ENVELOPE:
        return worker_argv(py, execution)
    spec = with_job_resources(spec)
    wf = spec.workflow
    if wf not in _ALLOWED_REMOTE_WORKFLOWS:
        raise ValueError(f"No remote subprocess mapping for workflow: {wf}")

    cmd: list[str] = [py, "-m", "acp.cli", "run", wf]

    inp = spec.input
    method = spec.method
    res = spec.resources

    # NMR has a distinct multi-candidate + spectrum payload shape.
    if wf == "nmr":
        cmd += build_remote_nmr_cmd_tail(spec, input_path)
        return _append_resources_and_return(cmd, wf, inp, method, res, config_path)

    # Stage workflows (PESsearch) use the stage tail.
    if wf == "PESsearch":
        cmd += build_remote_pessearch_tail(spec)
        return _append_resources_and_return(cmd, wf, inp, method, res, config_path)

    source = ""
    if wf == "BatchOptimize":
        artifact = inp.get("from_artifact")
        items_file = inp.get("items_file")
        if artifact:
            source = str(artifact)
            cmd += ["--from-artifact", str(artifact), "--output", "."]
        elif items_file:
            source = str(items_file)
            cmd += ["--items-file", str(items_file), "--output", "."]
        elif inp.get("source_type") == "batch_structures" and input_path:
            # Batch structures are staged as a JSON request file. Preserve
            # its suffix so the CLI dispatches to the JSON request loader.
            source = str(input_path)
            cmd += ["--items-file", str(input_path), "--output", "."]
        elif input_path:
            # RemoteJobRunner stages one structure as input.xyz for each
            # independent scheduler job.  Treat that file as a one-item
            # BatchOptimize request rather than as an artifact path, and use
            # the same flat task layout as local scheduler execution.
            source = str(input_path)
            cmd += ["--items-file", str(input_path), "--output", "."]
        else:
            raise ValueError(
                "BatchOptimize job requires a batch artifact, items file, or staged structure"
            )
        # One structure per scheduler task (layout spec §1a): every dispatch
        # shape uses the flat WORK/<stage> layout, matching runner._build_cmd.
        cmd += ["--layout-mode", "single_flat"]
        cmd += batchoptimize_method_flags(method, inp)
    else:
        source = (
            input_path
            or inp.get("input_artifact")
            or inp.get("source")
            or inp.get("input")
            or inp.get("smiles")
            or ""
        )

    if not source:
        raise ValueError(f"{wf} job requires a valid input structure")

    if wf == "Confsearch":
        cmd += ["--input", str(source), "--output", "."]
        if spec.name:
            cmd += ["--name", spec.name]
        cmd += confsearch_method_flags(method)
        solvent = censo_solvent_from_method(method)
        if solvent:
            cmd += ["--solvent", solvent]
        ewin = censo_ewin_from_method(method)
        if ewin is not None:
            cmd += ["--ewin", str(ewin)]
    elif wf in {"ensemble", "energy"}:
        cmd += ["--input", str(source), "--output", "."]
        preset = censo_preset_from_method(method)
        if preset:
            cmd += ["--preset", preset]
        if spec.name:
            cmd += ["--name", spec.name]
        if wf == "energy" and method.get("no_opt"):
            cmd += ["--no-opt"]
        if wf == "energy" and method.get("rank1_only"):
            cmd += ["--rank1-only"]
        if wf == "energy" and method.get("rank1_only") is False:
            cmd += ["--full-ensemble"]
        if wf == "energy" and method.get("threshold") is not None:
            cmd += ["--threshold", str(method["threshold"])]
        if wf == "energy" and method.get("levels"):
            cmd += ["--levels", json.dumps(method["levels"])]
        if wf == "ensemble" and method.get("keep_all"):
            cmd += ["--keep-all"]
        solvent = censo_solvent_from_method(method)
        if solvent:
            cmd += ["--solvent", solvent]
        ewin = censo_ewin_from_method(method)
        if ewin is not None:
            cmd += ["--ewin", str(ewin)]
    elif wf == "xtbmd_censo_energy":
        cmd += ["--input", str(source), "--output", "."]
        preset = censo_preset_from_method(method)
        if preset:
            cmd += ["--preset", preset]
        if spec.name:
            cmd += ["--name", spec.name]
        if method.get("levels"):
            cmd += ["--levels", json.dumps(method["levels"])]
        cmd += xtbmd_method_flags(method)
        solvent = censo_solvent_from_method(method)
        if solvent:
            cmd += ["--solvent", solvent]
        ewin = censo_ewin_from_method(method)
        if ewin is not None:
            cmd += ["--ewin", str(ewin)]
    elif wf in ("singlepoint", "optimize", "frequency", "scan"):
        cmd += ["--input", str(source), "--output", "."]
        if spec.name:
            cmd += ["--name", spec.name]
        levels = method.get("levels", {})
        if levels:
            cmd += method_levels_to_cli_flags(levels, workflow=wf)
            if electronic_state_from_method(method):
                cmd += ["--spin-config", "electronic_state.json"]
        if wf == "scan":
            cmd += scan_method_flags(method, inp)
    elif wf == "irc":
        cmd += build_remote_irc_tail(spec, source)
    elif wf == "tsmode":
        cmd += build_remote_tsmode_tail(spec, source)
    elif wf == "xtb_optimize":
        cmd += ["--input", str(source), "--output", "."]
        if spec.name:
            cmd += ["--name", spec.name]
        xtb_level = (method.get("levels") or {}).get("xtb_opt", {})
        gfn_val = xtb_level.get("gfn")
        if gfn_val is not None:
            gfn_int = _GFN_DISPLAY_TO_INT.get(str(gfn_val), gfn_val)
            cmd += ["--gfn", str(gfn_int)]
        if xtb_level.get("opt_level"):
            cmd += ["--opt-level", str(xtb_level["opt_level"])]
        if xtb_level.get("max_steps") is not None:
            cmd += ["--max-steps", str(xtb_level["max_steps"])]
        if xtb_level.get("solvent"):
            cmd += ["--solvent", str(xtb_level["solvent"])]
        sm = xtb_level.get("solvent_model")
        if sm and str(sm).lower() not in ("", "none"):
            cmd += ["--solvent-model", str(sm)]

    return _append_resources_and_return(cmd, wf, inp, method, res, config_path)


def build_remote_worker_command(
    *,
    envelope_path: str,
    plan_path: str,
    work_dir: str,
    receipt_path: str | None = None,
    binding_path: str | None = None,
    python_executable: str = "python",
    probe_executor: str | None = None,
) -> list[str]:
    """Build the Services worker-bootstrap argv for remote execution (B06-6).

    Unlike :func:`build_remote_cli_command` (legacy ``python -m acp.cli``), the
    frozen-envelope worker runs the synced Services composition root directly:
    ``python -m acp_services.worker_bootstrap ...``.  The node consumer never
    hops through the legacy CLI; every dependency is reconstructed from the
    frozen envelope / plan / storage binding shipped alongside the work dir.

    Args:
        envelope_path: Remote path to the frozen envelope JSON.
        plan_path: Remote path to the frozen plan JSON.
        work_dir: Remote task work dir holding the read-only artifacts.
        receipt_path: Receipt output path (defaults inside the worker).
        binding_path: Optional frozen StorageBinding JSON path.
        python_executable: Interpreter on the node.
        probe_executor: Worker-independence probe only (``ok``/``fail``).
    """
    py = python_executable or "python"
    launch = ExecutionLaunch(
        entry=EXECUTION_ENTRY_ENVELOPE,
        protocol="lsf",
        closure="integrated",
        work_dir=str(work_dir),
        envelope_path=str(envelope_path),
        plan_path=str(plan_path),
        binding_path=str(binding_path) if binding_path else None,
    )
    return worker_argv(
        py,
        launch,
        work_dir=str(work_dir),
        receipt_path=str(receipt_path) if receipt_path else None,
        probe_executor=str(probe_executor) if probe_executor else None,
    )


def _append_resources_and_return(
    cmd: list[str],
    wf: str,
    inp: dict[str, Any],
    method: dict[str, Any],
    res: dict[str, Any],
    config_path: str | None,
) -> list[str]:
    if config_path:
        cmd += ["--config", config_path]
    if res.get("nproc") is not None:
        cmd += ["--nproc", str(res["nproc"])]
    if res.get("mem"):
        cmd += ["--mem", str(res["mem"])]
    cmd += input_chemistry_flags(inp)
    return cmd


# ──⑧ new-workflow remote tail generators ────────────────────────────────


def build_remote_pessearch_tail(spec: JobSpec) -> list[str]:
    """Generate argv tail for PESsearch remote execution."""
    inp = spec.input
    method = spec.method
    flags: list[str] = ["--output", "."]
    bond_scan_mode = str(method.get("mode") or "") == "bond_length_scan"
    if bond_scan_mode:
        flags += ["--mode", "bond_length_scan"]
        flags += ["--scan-config", SCAN_CONFIG_FILENAME]
        return flags + input_chemistry_flags(inp)
    from_manifest = inp.get("from")
    if from_manifest:
        flags += ["--from", str(from_manifest)]
    if method.get("strategy"):
        flags += ["--strategy", str(method["strategy"])]
    select = method.get("select")
    if isinstance(select, (list, tuple)) and select:
        flags += ["--select", ",".join(str(item) for item in select)]
    elif isinstance(select, str) and select.strip():
        flags += ["--select", select.strip()]
    plan = inp.get("coordinate_plan") or method.get("coordinate_plan")
    if plan is not None:
        flags += ["--plan", json.dumps(plan)]
    product = inp.get("product")
    if product:
        flags += ["--product", str(product)]
    ts_guess = inp.get("ts_guess")
    if ts_guess:
        flags += ["--ts-guess", str(ts_guess)]
    flags += input_chemistry_flags(inp)
    return flags


def build_remote_irc_tail(spec: JobSpec, source: str) -> list[str]:
    """Generate argv tail for IRC remote execution."""
    inp = spec.input
    method = spec.method
    cmd: list[str] = ["--input", str(source), "--output", "."]
    provenance = inp.get("ts_source")
    if not isinstance(provenance, dict) or provenance.get("schema") != "irc_ts_source_v1":
        raise ValueError("IRC requires verified TS source provenance")
    cmd += ["--ts-provenance-json", json.dumps(provenance, sort_keys=True)]
    if spec.name:
        cmd += ["--name", spec.name]
    input_role = inp.get("input_role")
    if input_role:
        cmd += ["--input-role", str(input_role)]
    directions = inp.get("directions") or ["both"]
    direction_names = {str(d).strip().lower() for d in directions}
    if direction_names == {"forward"}:
        cmd += ["--direction", "forward"]
    elif direction_names == {"reverse"}:
        cmd += ["--direction", "reverse"]
    elif direction_names in ({"forward", "reverse"}, {"both"}):
        cmd += ["--direction", "both"]
    elif direction_names:
        raise ValueError("irc directions must be forward, reverse, or both")
    levels = method.get("levels")
    irc_level = levels.get("irc", {}) if isinstance(levels, Mapping) else {}
    if not isinstance(irc_level, Mapping):
        irc_level = {}
    irc_method = method.get("method") or method.get("functional") or irc_level.get("method")
    if irc_method:
        cmd += ["--method", str(irc_method)]
    irc_basis = method.get("basis") or irc_level.get("basis")
    if irc_basis:
        cmd += ["--basis", str(irc_basis)]
    cmd += ["--charge", str(inp["charge"]), "--multiplicity", str(inp["multiplicity"])]
    maxpoints = method.get("maxpoints") or irc_level.get("maxpoints")
    if maxpoints is not None:
        cmd += ["--maxpoints", str(maxpoints)]
    irc_step = method.get("step") or irc_level.get("step")
    if irc_step is not None:
        cmd += ["--step", str(irc_step)]
    return cmd


# ── Stage tail (PESsearch bond-scan only) ───────────────────────────────


def build_remote_tsmode_tail(spec: JobSpec, source: str) -> list[str]:
    """Generate argv tail for TS Mode remote execution.

    The scheduler materializes ``INPUT/tsmode/bundle.json`` (with relative
    file references) into the synced work dir, so the remote command
    consumes the same staged snapshot as the local runner (plan §11).
    """
    inp = spec.input
    bundle_reference = str(inp.get("bundle_path") or "INPUT/tsmode/bundle.json")
    cmd: list[str] = ["--source-bundle", bundle_reference, "--output", "."]
    mode_index = inp.get("source_mode_index")
    if not isinstance(mode_index, int) or isinstance(mode_index, bool):
        raise ValueError("tsmode remote job requires an integer source_mode_index")
    cmd += ["--source-mode-index", str(mode_index)]
    if spec.name:
        cmd += ["--name", spec.name]
    return cmd


def build_remote_scan_config_payload(spec: JobSpec) -> dict[str, Any] | None:
    """Bond-scan scan_request payload staged as ``scan_config.json``."""
    wf = spec.workflow
    if not (wf == "PESsearch" and str(spec.method.get("mode") or "") == "bond_length_scan"):
        return None
    scan_request = dict(spec.input.get("scan_request") or spec.method.get("scan_request") or {})
    return scan_request


def build_remote_stage_cmd_tail(spec: JobSpec) -> list[str]:
    """E7 parity helper: append the stage-workflow argv for remote execution.

    Handles PESsearch bond-scan mode only (ships scan_config.json).
    """
    wf = spec.workflow
    inp = spec.input
    method = spec.method
    flags: list[str] = ["--output", "."]
    bond_scan_mode = wf == "PESsearch" and str(method.get("mode") or "") == "bond_length_scan"
    if bond_scan_mode:
        flags += ["--mode", "bond_length_scan"]
        flags += ["--scan-config", SCAN_CONFIG_FILENAME]
        return flags + input_chemistry_flags(inp)
    from_manifest = inp.get("from")
    if from_manifest:
        flags += ["--from", str(from_manifest)]
    if wf == "PESsearch":
        if method.get("strategy"):
            flags += ["--strategy", str(method["strategy"])]
        select = method.get("select")
        if isinstance(select, (list, tuple)) and select:
            flags += ["--select", ",".join(str(item) for item in select)]
        elif isinstance(select, str) and select.strip():
            flags += ["--select", select.strip()]
        plan = inp.get("coordinate_plan") or method.get("coordinate_plan")
        if plan is not None:
            flags += ["--plan", json.dumps(plan)]
        product = inp.get("product")
        if product:
            flags += ["--product", str(product)]
        ts_guess = inp.get("ts_guess")
        if ts_guess:
            flags += ["--ts-guess", str(ts_guess)]
    flags += input_chemistry_flags(inp)
    return flags


def build_remote_nmr_cmd_tail(
    spec: JobSpec,
    input_path: str = "inputs/input.xyz",
) -> list[str]:
    """E7 parity helper: append the NMR-specific argv for remote execution."""
    cmd: list[str] = ["--output", "."]
    inp = spec.input
    method = spec.method
    enumerate_mode = bool(inp.get("enumerate"))

    candidates = inp.get("candidates") if isinstance(inp.get("candidates"), list) else None
    if candidates:
        for idx, cand in enumerate(candidates):
            remote_input_path = cand.get("remote_input_path") if isinstance(cand, dict) else None
            if remote_input_path:
                cmd += ["--input", str(remote_input_path)]
                continue
            cand_source = (
                (cand.get("source") or cand.get("smiles") or cand.get("input"))
                if isinstance(cand, dict)
                else None
            )
            if enumerate_mode and cand_source and _looks_like_smiles(str(cand_source)):
                cmd += ["--input", str(cand_source)]
                continue
            cmd += ["--input", f"inputs/input_{idx}.xyz"]
    else:
        cmd += ["--input", str(input_path)]

    experiment = inp.get("experiment") or method.get("experiment")
    if isinstance(experiment, dict):
        exp_mode = (experiment or {}).get("mode", "assigned")
    else:
        exp_mode = "assigned"
    if exp_mode == "bruker":
        cmd += ["--bruker", "inputs/bruker"]
        refs = experiment.get("references") if isinstance(experiment, dict) else None
        if isinstance(refs, dict):
            for key, value in refs.items():
                cmd += ["--bruker-ref", f"{key}={value}"]
    else:
        exp_content = (experiment or {}).get("content") if isinstance(experiment, dict) else None
        if not exp_content:
            raise ValueError("nmr remote job requires experiment.content (spectrum text)")
        cmd += ["--spectrum", "inputs/experiment.txt"]

    if inp.get("enumerate"):
        cmd += ["--enumerate"]
        stereocenters = inp.get("stereocenters")
        if isinstance(stereocenters, str) and stereocenters.strip():
            cmd += ["--stereocenters", stereocenters.strip()]
        elif isinstance(stereocenters, list) and stereocenters:
            cmd += ["--stereocenters", ",".join(str(s) for s in stereocenters)]

    # --name intentionally not emitted: the nmr parser never accepted it
    # (G06) — task naming is manager-owned (spec.name → work_dir name).
    # INVARIANT (E7): all nmr flags come from the single resolver-backed
    # group — byte-identical call to JobRunner._build_nmr_cmd; no
    # caller-side censo_preset/solvent/ewin here (duplicate emission; and
    # the nmr wizard nests ewin under levels.conformer, which
    # censo_ewin_from_method never reads).
    cmd += nmr_method_flags(method, nmr_flag_config(spec.config_path))
    cmd += nmr_candidate_metadata_flags(inp)
    return cmd


def derive_lsf_resources(
    spec: JobSpec,
    queue: str = _DEFAULT_QUEUE,
    walltime: str = _DEFAULT_WALLTIME,
    extra_flags: str = "",
) -> tuple[int, int, str, str, str]:
    """Derive LSF resource parameters from a :class:`JobSpec`."""
    res = resolve_job_resources(spec)
    nproc = res["nproc"]
    total_mem_mb = mem_to_mb(res["mem"])
    mem_mb_per_core = math.ceil(total_mem_mb / nproc)
    return nproc, mem_mb_per_core, queue, walltime, extra_flags


def build_lsf_script_spec(
    spec: JobSpec,
    job_id: str,
    node: RemoteNode,
    queue: str = _DEFAULT_QUEUE,
    walltime: str = _DEFAULT_WALLTIME,
    extra_flags: str = "",
    input_path: str = "inputs/input.xyz",
    config_path: str | None = None,
    remote_dir_name: str | None = None,
    remote_job_dir: str | None = None,
    python_executable: str | None = None,
    pre_cmds: list[str] | None = None,
    submission_id: str | None = None,
    code_release: str | None = None,
    execution: ExecutionLaunch | None = None,
) -> tuple[LSFScriptSpec, list[str]]:
    """Build both the CLI command and :class:`LSFScriptSpec` for a job.

    Args:
        spec: The scheduler job specification.
        job_id: The ACP job identifier (used for the BSUB job name).
        node: The target remote compute node.
        queue: LSF queue name.
        walltime: LSF wall-clock limit.
        extra_flags: Additional BSUB flags.
    input_path: Relative path to the uploaded input file (default
        ``inputs/input.xyz``).
    submission_id: Contract-A submission id — the LSF job name becomes
        ``acp_<submission_id>`` (attempt-digested, unique per attempt).
        When omitted a deterministic id is derived from *job_id* with
        attempt 1 (bare/test callers); the runner always passes the
        persisted id.
        config_path: Optional path to a job-level YAML config on the remote
            node (e.g. ``cccp.yaml`` in the job directory).
        remote_dir_name: Leaf directory name used only for display/LSF
            job-name derivation when *remote_job_dir* is not given.
        remote_job_dir: Already-resolved absolute remote job directory
            (from ``resolve_remote_dir``).  When given it is used verbatim —
            the caller owns storage identity; this function never re-joins.
        python_executable: Interpreter to use on the node.  When given it
            overrides ``node.python_executable`` — callers pass a
            probe-resolved (Python 3.10+) interpreter here so LSF scripts
            never fall back to a too-old default ``python``.
        pre_cmds: Shell lines injected into the generated script before
            the CLI runs (cluster-level environment setup).
        code_release: Verified content-hash release id the job is bound to
            (D03, todo 8).  Reuses the existing
            ``LSFScriptSpec.remote_code_dir`` field — no parallel code-dir
            key: when given, it is set to
            ``<node.remote_code_dir>/releases/<code_release>`` so the
            PYTHONPATH line points at the immutable snapshot
            ``releases/<id>/src``.  ``None`` keeps the shared directory
            (unversioned dev-hatch mode only).

    Returns:
        ``(lsf_spec, cli_command)``.
    """
    spec = with_job_resources(spec)
    if remote_job_dir is None:
        remote_job_dir = posixpath.join(node.remote_work_dir, remote_dir_name or job_id)
    effective_code_dir = (
        posixpath.join(node.remote_code_dir, "releases", code_release)
        if code_release
        else node.remote_code_dir
    )
    cli_command = build_remote_cli_command(
        spec,
        input_path=input_path,
        python_executable=python_executable or node.python_executable,
        config_path=config_path,
        execution=execution,
    )
    nproc, mem_mb_per_core, queue, walltime, extra_flags = derive_lsf_resources(
        spec, queue=queue, walltime=walltime, extra_flags=extra_flags
    )
    # Contract A: ``-J acp_<submission_id>`` (attempt-digested) replaces the
    # former ``acp_<job_id>`` name so reconcile can query it unambiguously.
    from acp.scheduler.remote.submission import submission_id_for
    from acp.scheduler.remote.sync import _is_source_tree, _project_root

    lsf_spec = LSFScriptSpec(
        job_name=f"acp_{submission_id or submission_id_for(job_id, 1)}",
        queue=queue,
        nproc=nproc,
        mem_mb_per_core=mem_mb_per_core,
        walltime=walltime,
        remote_code_dir=effective_code_dir,
        remote_job_dir=remote_job_dir,
        cli_command=cli_command,
        pre_cmds=list(pre_cmds or []),
        extra_flags=extra_flags,
        mem_total_mb=mem_to_mb(spec.resources["mem"]),
        pythonpath_code_root=not _is_source_tree(_project_root()),
    )
    return lsf_spec, cli_command


def generate_lsf_script(s: LSFScriptSpec) -> str:
    """Render a complete ``bsub`` submission script."""
    cli_str = " ".join(shlex.quote(arg) for arg in s.cli_command)
    total_mem_mb = s.mem_total_mb if s.mem_total_mb is not None else s.mem_mb_per_core * s.nproc
    lines: list[str] = [
        "#!/bin/bash",
        f"#BSUB -J {s.job_name}",
        f"#BSUB -q {s.queue}",
        f"#BSUB -n {s.nproc}",
        f"#BSUB -M {int(total_mem_mb * 1024 * 1.05)}",
    ]
    if s.walltime:
        lines.append(f"#BSUB -W {s.walltime}")
    lines += [
        f"#BSUB -o {s.remote_job_dir}/stdout.log",
        f"#BSUB -e {s.remote_job_dir}/stderr.log",
    ]
    if s.extra_flags:
        lines.append(f"#BSUB {s.extra_flags}")
    lines += [
        "",
        '_acp_record_exit() { [ -f .exit_code ] || echo "$?" > .exit_code; }',
        "trap 'exit $?' USR2 TERM INT HUP",
        "trap _acp_record_exit EXIT",
    ]
    # Cluster-level environment setup (module load, spack, ...) — injected
    # verbatim so module-based HPC clusters work without script surgery.
    if s.pre_cmds:
        lines.append("")
        lines.append("# cluster.pre_cmds (module/environment setup)")
        lines.extend(s.pre_cmds)
    lines += ["", f'export PYTHONPATH="{s.remote_code_dir}/src:$PYTHONPATH"']
    if s.pythonpath_code_root:
        # Installed-wheel release: packages live at the release root.
        lines.append(f'export PYTHONPATH="{s.remote_code_dir}:$PYTHONPATH"')
    lines += [
        f'cd "{s.remote_job_dir}"',
        cli_str,
        "echo $? > .exit_code",
        "",
    ]
    return "\n".join(lines)


# ── Remote artifact pull helpers ────────────────────────────────────────


def remote_artifact_pull_list() -> list[str]:
    """Standard remote artifact paths to fetch after job completion."""
    return [_REMOTE_RESULT_MANIFEST_PATH, _REMOTE_CHECKPOINT_PATH]
