"""Job Edit & Recalculate (docs/archive/2026-10-16/history/ACP_Edit_And_Recalculate_Plan.md).

Draft restoration, workflow edit-coverage registry, editable-spec diffing,
preview fingerprints, idempotency operation records, and last-valid-structure
resolution.  Execution stays in :mod:`acp.scheduler.manager`; this module owns
everything editable-spec shaped so the manager does not keep growing.

Key contracts (plan §6/§9):

* The server-side ``JobRecord.spec`` is the authoritative source for the
  original submission parameters; the draft is a projection of it.
* ``source_revision`` binds the draft to ``{spec semantics, attempt, input
  hash}`` so ordinary progress updates never fabricate edit conflicts.
* ``request_id`` + payload hash give exactly-once submission semantics that
  survive network retries and service restarts (SQLite-backed operation log).
"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

from acp.scheduler.jobs import JobRecord, JobSpec, scan_method_flags
from acp_services.runtime.helpers import utc_now_iso as _utc_now_iso

logger = logging.getLogger(__name__)

__all__ = [
    "EDIT_ACTIVE_WORKFLOWS",
    "EditConflictError",
    "EditValidationError",
    "JobEditOperationStore",
    "attempt_number",
    "audit_workflow_edit_coverage",
    "build_edit_draft",
    "compute_payload_hash",
    "compute_preview_fingerprint",
    "compute_source_revision",
    "diff_editable_specs",
    "editable_spec_from_parts",
    "editable_spec_from_record",
    "effective_config_info",
    "input_structure_changed",
    "normalize_for_compare",
    "resolve_last_structure",
    "resolve_previous_outputs",
    "workflow_edit_status",
]


class EditConflictError(RuntimeError):
    """409-class conflict: stale source_revision / replayed request_id payload."""


class EditValidationError(ValueError):
    """422-class error: the submitted editable spec is not usable."""


# --- workflow edit coverage registry (plan §1/§5) --------------------------
# Every catalog entry with status "active" MUST appear here.  The coverage
# audit (and its test) fails when a newly added active workflow forgets to
# register edit support — the entry point must never silently go missing.
EDIT_ACTIVE_WORKFLOWS: frozenset[str] = frozenset(
    {
        "singlepoint",
        "optimize",
        "frequency",
        "scan",
        "irc",
        "tsmode",
        "casscf",
        "xtb_optimize",
        "nmr",
        "Confsearch",
        "PESsearch",
        "BatchOptimize",
        "XtbPathSearch",
        "OrcaGradient",
        "XtbConstrainedOpt",
    }
)

# Registered active workflows with immutable or dedicated input contracts.
# Their generic editor must not advertise changes that execution cannot read.
_DEDICATED_EDIT_HINTS: dict[str, str] = {
    "tsmode": "TS Mode 参数继承频率证据；请使用 TS Mode 专用向导选择模式并创建新任务。",
    "XtbPathSearch": "XtbPathSearch 使用冻结 path_request；请在 PES2TS 中修改请求并创建新任务。",
    "OrcaGradient": "OrcaGradient 使用冻结 gradient_request；请在 PES2TS 中修改请求并创建新任务。",
    "XtbConstrainedOpt": (
        "XtbConstrainedOpt 使用冻结 constrained_opt_request；请在 PES2TS 中修改请求并创建新任务。"
    ),
}

# Retired/planned workflows never re-open their execution entry; the draft
# only offers read-only parameter viewing plus a migration hint (plan §5.1).
RETIRED_MIGRATION_HINTS: dict[str, str] = {
    "optfreq": "BatchOptimize --profile opt_freq（或 optimize + frequency）",
    "optfreqsp": "BatchOptimize --profile opt_freq_sp",
    "Lowconfirm": "BatchOptimize --profile opt_freq",
    "Highconfirm": "BatchOptimize --profile opt_freq_sp_thermo",
    "ensemble": "Confsearch --protocol censo-crest --refinement-policy screen",
    "energy": "Confsearch --protocol censo-crest --refinement-policy rank1/cumulative-99",
    "xtbmd_censo_energy": "Confsearch --protocol xtbmd-censo",
    "conformer": "Confsearch",
    "benchmark": "—（基准执行器已退役，可提取兼容输入另建有效任务）",
    "mechanism": "PESsearch → BatchOptimize → irc 分阶段入口",
    "mech-conf": "BatchOptimize",
    "mech-step": "PESsearch / BatchOptimize / irc",
    "mech-confirm": "BatchOptimize",
    "mech-chain": "irc",
}


def _catalog_status_map() -> dict[str, str]:
    try:
        from acp.catalog import WORKFLOW_CATALOG
    except ImportError:  # pragma: no cover - catalog is always importable
        return {}
    return {str(w.get("id")): str(w.get("status") or "unknown") for w in WORKFLOW_CATALOG}


def audit_workflow_edit_coverage() -> dict[str, list[str]]:
    """Return ``{"missing": [...], "stale": [...]}`` coverage audit.

    ``missing``: catalog-active workflows without edit registration (the plan
    requires the entry point to fail loudly, not silently).  ``stale``:
    registered workflows that are no longer catalog-active.
    """
    statuses = _catalog_status_map()
    active = {wid for wid, status in statuses.items() if status == "active"}
    missing = sorted(active - EDIT_ACTIVE_WORKFLOWS)
    stale = sorted(EDIT_ACTIVE_WORKFLOWS - active)
    return {"missing": missing, "stale": stale}


def workflow_edit_status(workflow_id: str) -> dict[str, Any]:
    """Edit capability projection for one workflow id."""
    status = _catalog_status_map().get(workflow_id, "unknown")
    editable = (workflow_id in EDIT_ACTIVE_WORKFLOWS and status == "active"
                and workflow_id not in _DEDICATED_EDIT_HINTS)
    return {
        "status": status,
        "editable": editable,
        "migration_hint": None if editable else (
            _DEDICATED_EDIT_HINTS.get(workflow_id) or RETIRED_MIGRATION_HINTS.get(workflow_id)
        ),
    }


# --- canonicalisation / revision fingerprints -------------------------------


def _canonicalize(value: Any) -> Any:
    """Recursively normalise a JSON-ish value for order-insensitive compare."""
    if isinstance(value, dict):
        return {str(k): _canonicalize(value[k]) for k in sorted(value, key=str)}
    if isinstance(value, (list, tuple)):
        return [_canonicalize(v) for v in value]
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (int, float, str)):
        return value
    return str(value)


def normalize_for_compare(*sections: Any) -> str:
    """Canonical JSON string over the given spec sections (sorted keys)."""
    payload = [_canonicalize(section) for section in sections]
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def attempt_number(record: JobRecord) -> int:
    """1-based attempt number; the ``jobs.attempt`` column is authoritative.

    Falls back to the legacy ``result['attempts']`` counter only while the
    column still sits at its untouched default (pre-migration rows and
    in-memory records).
    """
    column = int(record.attempt or 1)
    if column > 1:
        return column
    legacy = int((record.result or {}).get("attempts") or 1)
    return max(column, legacy)


def compute_source_revision(record: JobRecord) -> str:
    """Version the *configuration identity* of a job for optimistic editing.

    Covers the spec's computational semantics (workflow/input/method/
    resources), the current attempt number, and the recorded input hash.
    Runtime-only fields (status, progress, pid, timestamps, result payload)
    are deliberately excluded so normal progress updates cannot fabricate a
    conflict (plan §9).
    """
    spec = record.spec
    payload = {
        "workflow": spec.workflow,
        "input": spec.input,
        "method": spec.method,
        "resources": spec.resources,
        "attempt": attempt_number(record),
        "input_hash": record.input_hash or "",
    }
    canonical = normalize_for_compare(payload)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return f"sr_{digest[:24]}"


def compute_payload_hash(payload: dict[str, Any]) -> str:
    """Hash a submit request payload for request_id idempotency comparison."""
    canonical = normalize_for_compare(payload)
    return "ph_" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:32]


def _structure_input_identity(value: Any) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Return stable geometry and source identities embedded in an input."""
    geometries: list[str] = []
    sources: list[str] = []

    def visit(item: Any) -> None:
        if isinstance(item, dict):
            source_ref = item.get("source_ref")
            if isinstance(source_ref, dict):
                source_id = str(source_ref.get("source_id") or "").strip()
                if not source_id:
                    job_id = str(source_ref.get("job_id") or "").strip()
                    rel_path = str(source_ref.get("path") or "").strip()
                    source_id = f"job_{job_id}:{rel_path}" if job_id and rel_path else ""
                source_identity = (
                    source_id,
                    str(source_ref.get("source_uid") or "").strip(),
                    str(source_ref.get("version_id") or "").strip(),
                    str(source_ref.get("geometry_hash") or "").strip(),
                    str(source_ref.get("checksum") or "").strip(),
                )
                if any(source_identity):
                    sources.append("|".join(source_identity))
            source_id = str(item.get("source_id") or "").strip()
            if source_id:
                sources.append(source_id)

            source_type = str(item.get("source_type") or "").lower()
            source = item.get("source")
            if source_type in {"xyz_text", "smiles"} and isinstance(source, str) and source.strip():
                geometries.append(
                    hashlib.sha256(source.strip().encode("utf-8")).hexdigest()
                )
            for key in ("xyz", "xyz_text"):
                geometry = item.get(key)
                if isinstance(geometry, str) and geometry.strip():
                    geometries.append(
                        hashlib.sha256(geometry.strip().encode("utf-8")).hexdigest()
                    )
            for key, child in item.items():
                if key == "scan_request" and isinstance(child, dict):
                    # The serialized PES mirror carries the same source,
                    # not an additional starting structure.
                    if not isinstance(item.get("source"), (dict, str)):
                        visit(child.get("source"))
                    continue
                if isinstance(child, (dict, list, tuple)):
                    visit(child)
        elif isinstance(item, (list, tuple)):
            for child in item:
                visit(child)

    visit(value)
    return tuple(geometries), tuple(sources)


def input_structure_changed(original: dict[str, Any], updated: dict[str, Any]) -> bool:
    """Whether an edit changes the supplied geometry or its saved source."""
    return _structure_input_identity(original) != _structure_input_identity(updated)


def compute_preview_fingerprint(
    job_id: str,
    source_revision: str,
    workflow: str,
    input_spec: dict,
    method: dict,
    resources: dict,
) -> str:
    """Bind a preview to the server-normalised configuration/input version."""
    canonical = normalize_for_compare(
        {
            "job_id": job_id,
            "source_revision": source_revision,
            "workflow": workflow,
            "input": input_spec,
            "method": method,
            "resources": resources,
        }
    )
    return "pf_" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:32]


# --- editable spec projection -------------------------------------------------


def editable_spec_from_parts(
    *,
    workflow: str,
    input_spec: dict[str, Any],
    method: dict[str, Any],
    resources: dict[str, Any],
    molecule_name: str = "",
    task_name: str = "",
    remark: str = "",
    tags: list[str] | None = None,
    node_tags: list[str] | None = None,
    project_id: str | None = None,
    execution_mode: str | None = None,
    target_node: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """Wire-level editable spec built from raw parts (draft/submit parity)."""
    return {
        "workflow": workflow,
        "input": json.loads(json.dumps(input_spec or {}, default=str)),
        "method": json.loads(json.dumps(method or {}, default=str)),
        "resources": json.loads(json.dumps(resources or {}, default=str)),
        "molecule_name": molecule_name,
        "task_name": task_name,
        "remark": remark,
        "tags": list(tags or []),
        "node_tags": list(node_tags or []),
        "project_id": project_id,
        "execution_mode": execution_mode,
        "target_node": target_node,
        "config_path": config_path,
    }


def editable_spec_from_record(record: JobRecord) -> dict[str, Any]:
    """Project a JobRecord into the wire-level editable spec (plan §9).

    Runtime fields (status/pid/remote_job_id/work_dir/result) are excluded on
    purpose — the client can never write them through an edit submission.
    """
    spec = record.spec
    return editable_spec_from_parts(
        workflow=spec.workflow,
        input_spec=spec.input,
        method=spec.method,
        resources=spec.resources,
        molecule_name=spec.molecule_name,
        task_name=spec.task_name,
        remark=spec.remark,
        tags=spec.tags,
        node_tags=spec.node_tags,
        project_id=record.project_id or spec.project_id,
        execution_mode=getattr(spec.execution_mode, "value", None) or spec.execution_mode,
        target_node=spec.target_node,
        config_path=spec.config_path,
    )


def _input_kind(inp: Any) -> str:
    if not isinstance(inp, dict):
        return "plain"
    if isinstance(inp.get("scan_request"), dict):
        return "scan_request"
    source_type = str(inp.get("source_type") or "")
    if source_type:
        return source_type
    if inp.get("source_job_id") or inp.get("from_artifact"):
        return "stage_artifact"
    return "structured"


def _describe_original_input(record: JobRecord, run_root: Path | None = None) -> dict[str, Any]:
    """Summarise the original input dependencies (plan §6.2)."""
    spec = record.spec
    inp = spec.input
    work_dir = Path(record.work_dir) if record.work_dir else None
    desc: dict[str, Any] = {
        "kind": _input_kind(inp),
        "charge": inp.get("charge") if isinstance(inp, dict) else None,
        "multiplicity": inp.get("multiplicity") if isinstance(inp, dict) else None,
        "materialized_input_xyz": bool(work_dir and (work_dir / "input.xyz").is_file()),
    }
    if isinstance(inp, dict):
        items = inp.get("items")
        if isinstance(items, list):
            desc["items_count"] = len(items)
        source_job_id = inp.get("source_job_id")
        if source_job_id:
            desc["source_job_id"] = str(source_job_id)
        artifact = inp.get("from_artifact")
        if artifact:
            desc["from_artifact"] = str(artifact)
            desc["from_artifact_available"] = bool(
                work_dir and (work_dir / str(artifact)).is_file()
            )
        candidates = inp.get("candidates")
        if isinstance(candidates, list):
            desc["candidates_count"] = len(candidates)
        # SMILES provenance recorded at submit time.
        if work_dir is not None:
            source_json = work_dir / "input_source.json"
            if source_json.is_file():
                try:
                    desc["input_source"] = json.loads(source_json.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    desc["input_source"] = None
    return desc


def _xyz_atom_count(xyz_text: str) -> int | None:
    """Return the declared XYZ atom count when the payload is usable."""
    lines = xyz_text.lstrip("\ufeff \t\r\n").splitlines()
    if not lines:
        return None
    try:
        count = int(lines[0].strip())
    except (TypeError, ValueError):
        return None
    return count if count > 0 and len(lines) >= count + 2 else None


def _structure_source_item(
    record: JobRecord,
    *,
    item_id: str,
    name: str,
    xyz_text: str,
    tag: str = "",
    charge: Any = 0,
    multiplicity: Any = 1,
    source_kind: str = "original_input",
) -> dict[str, Any]:
    """Project inline task geometry to the shared frontend source contract."""
    atom_count = _xyz_atom_count(xyz_text)
    available = atom_count is not None
    return {
        "source_id": f"edit-{source_kind}:{record.id}:{item_id}",
        "source_kind": source_kind,
        "job_id": record.id,
        "item_id": item_id,
        "name": name or item_id,
        "tag": tag if tag in {"INT", "TS"} else "",
        "atom_count": atom_count or 0,
        "charge": charge if charge is not None else 0,
        "multiplicity": multiplicity if multiplicity is not None else 1,
        "geometry_ref": {"kind": "inline_xyz", "item_id": item_id},
        "geometry_status": "available" if available else "missing",
        "geometry_error": None if available else "该来源没有可用几何",
        "xyz_text": xyz_text if available else "",
    }


def project_original_structure_items(record: JobRecord) -> list[dict[str, Any]]:
    """Return every reusable geometry from the submitted task input.

    Stable identifiers prefer persisted ``item_id``/``candidate_id`` values
    and otherwise use the input-order index. Geometry is inline-only here, so
    the draft never exposes an arbitrary filesystem path.
    """
    inp = record.spec.input if isinstance(record.spec.input, dict) else {}
    default_charge = inp.get("charge", 0)
    default_mult = inp.get("multiplicity", 1)
    projected: list[dict[str, Any]] = []

    items = inp.get("items")
    if isinstance(items, list):
        for index, raw in enumerate(items, start=1):
            if not isinstance(raw, dict):
                continue
            item_id = str(raw.get("item_id") or raw.get("candidate_id") or f"item_{index:03d}")
            projected.append(
                _structure_source_item(
                    record,
                    item_id=item_id,
                    name=str(raw.get("name") or raw.get("candidate_id") or item_id),
                    xyz_text=str(raw.get("xyz") or raw.get("xyz_text") or raw.get("source") or ""),
                    tag=str(raw.get("tag") or ""),
                    charge=raw.get("charge", default_charge),
                    multiplicity=raw.get("multiplicity", default_mult),
                )
            )
        return projected

    candidates = inp.get("candidates")
    if isinstance(candidates, list):
        for index, raw in enumerate(candidates, start=1):
            if not isinstance(raw, dict):
                continue
            item_id = str(raw.get("item_id") or raw.get("candidate_id") or f"candidate_{index:03d}")
            projected.append(
                _structure_source_item(
                    record,
                    item_id=item_id,
                    name=str(raw.get("name") or raw.get("candidate_id") or item_id),
                    xyz_text=str(raw.get("xyz") or raw.get("xyz_text") or raw.get("source") or ""),
                    tag=str(raw.get("tag") or ""),
                    charge=raw.get("charge", default_charge),
                    multiplicity=raw.get("multiplicity", default_mult),
                )
            )
        return projected

    source = inp
    scan_request = inp.get("scan_request")
    if isinstance(scan_request, dict) and isinstance(scan_request.get("source"), dict):
        source = scan_request["source"]
    xyz_text = str(source.get("xyz_text") or source.get("xyz") or source.get("source") or "")
    if _xyz_atom_count(xyz_text) is None and record.work_dir:
        materialized = Path(record.work_dir) / "input.xyz"
        try:
            xyz_text = materialized.read_text(encoding="utf-8")
        except OSError:
            pass
    projected.append(
        _structure_source_item(
            record,
            item_id="input_001",
            name=str(inp.get("name") or record.spec.molecule_name or "上次运行输入"),
            xyz_text=xyz_text,
            tag=str(inp.get("tag") or inp.get("input_role") or "")
            .upper()
            .replace("TRANSITION_STATE", "TS"),
            charge=source.get("charge", default_charge),
            multiplicity=source.get("multiplicity", default_mult),
        )
    )
    return projected


def resolve_previous_outputs(
    work_dir: Path | str, *, job_id: str = "", project_id: str | None = None,
    attempt: int = 0, strict: bool = False,
    skipped: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Project every reusable single geometry with stable provenance.

    ``skipped`` is an optional out-parameter: when supplied, multi-frame
    collection products (historical ``all_conformers`` /
    ``confsearch_final_conformers`` ids and the new ``auto_reusable=false``
    marker) are appended as ``{"id", "path", "reason"}`` instead of aborting a
    strict recalc.  Callers that only need the reusable list are unaffected.
    """
    from acp.results.manifest import load_result_manifest
    from acp.results.structure_policy import collection_product, reusable_product, single_geometry
    from acp.scheduler.files import resolve_safe
    from acp.scheduler.structure_source_store import source_uid_for

    root = Path(work_dir)
    manifest = load_result_manifest(root)
    from acp.confsearch.manifest import (
        find_confsearch_manifest,
        read_manifest,
        resolve_manifest_geometry,
    )
    from acp.storage.manifest import ResultManifest
    conformer_manifest = find_confsearch_manifest(root)
    if conformer_manifest is not None:
        manifest = manifest or ResultManifest(workflow="Confsearch")
        try:
            payload = read_manifest(conformer_manifest)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            if strict:
                raise ValueError("正式构象清单不可读取，已阻断重算") from exc
            payload = {}
        for conf in payload.get("conformers") or []:
            try:
                geometry = resolve_manifest_geometry(conformer_manifest, str(conf.get("geometry") or ""))
                rel = geometry.resolve().relative_to((root / "RESULT").resolve()).as_posix()
            except ValueError:
                continue
            cid = str(conf.get("conf_id") or "conformer")
            manifest.add_product("confsearch_" + cid, "Conformer (" + cid + ")", rel, "structure",
                metadata={"source_kind":"conformer", "rank":conf.get("rank")})
    if manifest is None:
        if strict and (root / "RESULT" / "result_manifest.json").exists():
            raise ValueError("旧结果清单不可读取，已阻断重算")
        return []
    outputs = []
    for product in manifest.products:
        if manifest.workflow in {"frequency", "singlepoint"}:
            continue
        if manifest.workflow in {"scan", "PESsearch"} and product.metadata.get("selection_source") not in {"manual", "manual_frame"}:
            continue
        collection_reason = collection_product(product.to_dict())
        if collection_reason is not None:
            if skipped is not None:
                skipped.append({
                    "id": product.id, "path": product.path, "reason": collection_reason,
                })
            continue
        if not reusable_product(product.to_dict()):
            continue
        relative = f"RESULT/{product.path}"
        path = resolve_safe(root, relative)
        if path is None or not path.is_file():
            # Old executor products were rooted at the task directory.
            relative = product.path
            path = resolve_safe(root, relative)
        if path is None or not path.is_file():
            if strict:
                raise ValueError(f"旧结构产物缺失，已阻断重算: {product.path}")
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            if strict:
                raise ValueError(f"旧结构不可读取，已阻断重算: {product.path}") from exc
            continue
        geometry = single_geometry(text)
        if geometry is None:
            if strict:
                raise ValueError(f"旧结构不是有效单帧，已阻断重算: {product.path}")
            continue
        checksum = geometry["content_checksum"]
        uid = source_uid_for(job_id, relative)
        direction = product.metadata.get("direction")
        if product.kind.value == "irc_endpoint":
            direction = "forward" if "forward" in product.id else "reverse"
        outputs.append({
            **product.metadata, **geometry,
            "available": True, "availability": "available", "entry_id": product.id,
            "product_id": product.id, "label": product.label, "path": relative,
            "xyz_text": text, "source_uid": uid, "version_id": checksum,
            "attempt": attempt, "direction": direction,
            "source_ref": {"origin": "job_artifact", "job_id": job_id,
                "source_uid": uid, "source_id": f"job_{job_id}:{relative}",
                "path": relative, "checksum": checksum, "version_id": checksum,
                "attempt": attempt, "project_id": project_id or ""},
        })
    return outputs


def resolve_last_structure(work_dir: Path | str, *, job_id: str = "",
                           project_id: str | None = None) -> dict[str, Any] | None:
    """Compatibility projection of the complete output list."""
    outputs = resolve_previous_outputs(work_dir, job_id=job_id, project_id=project_id)
    return outputs[0] if outputs else None


def effective_config_info(record: JobRecord) -> dict[str, Any]:
    """Last-effective-config availability for the edit draft.

    Authority order for edit hydration (plan §6.3): ``JobRecord.spec`` is the
    authoritative *submission*; ``effective_config.json`` captures what the
    engine actually resolved last run (inherited defaults included) and is
    display/reference only.  ``status`` tells the frontend which case holds:

    * ``snapshot``   — effective_config.json exists in the work dir.
    * ``recomputed`` — no snapshot; the effective config was recomputed from
      the submitted method dict (BatchOptimize, and nmr via the T17 resolver
      — todo 25 syncs functional/basis/solvent_model/ewin/max_conformers).
    * ``unavailable``— neither is available (other non-batch workflows
      without a snapshot; the draft hydrates from the spec alone).
    """
    work_dir = Path(record.work_dir) if record.work_dir else None
    if work_dir is not None:
        try:
            from acp.calculations.batch.effective_config import (
                read_effective_config,
            )

            snapshot = read_effective_config(work_dir)
        except ImportError:  # pragma: no cover - module is always importable
            snapshot = None
        if snapshot is not None:
            return {
                "status": "snapshot",
                "source": "effective_config.json",
                "config": snapshot,
            }
    if record.spec.workflow == "BatchOptimize":
        try:
            from acp.calculations.batch.effective_config import (
                compute_effective_from_method,
            )

            recomputed = compute_effective_from_method(dict(record.spec.method))
            return {"status": "recomputed", "source": "spec.method", "config": recomputed}
        except Exception:  # noqa: BLE001 - degrade to unavailable, never block the draft
            logger.debug("effective-config recompute failed", exc_info=True)
    if record.spec.workflow == "nmr":
        config, _problem = _resolve_nmr_effective_config(record)
        if config is not None:
            return {"status": "recomputed", "source": "spec.method", "config": config}
    return {"status": "unavailable", "source": None, "config": None}


def _resolve_nmr_effective_config(record: JobRecord) -> tuple[dict[str, Any] | None, str | None]:
    """Resolve the nmr method payload through the T17 resolver (todo 25).

    Returns ``(config_dict, None)`` on success or ``(None, problem)`` when
    the payload is rejected (e.g. a method outside the NMR/GIAO metadata).
    Rejection degrades the draft's effective-config block to ``unavailable``
    and is surfaced as a note by :func:`build_edit_draft` — the review/view
    semantics of the draft itself never change.
    """
    from acp.nmr.method_config import resolve_nmr_method
    from acp.scheduler.jobs import nmr_flag_config

    method = record.spec.method if isinstance(record.spec.method, dict) else {}
    try:
        # NmrMethodConfigError is a ValueError; OSError covers config reads.
        resolved = resolve_nmr_method(dict(method), nmr_flag_config(record.spec.config_path))
    except (ValueError, OSError) as exc:
        logger.debug("nmr effective-config resolve failed", exc_info=True)
        return None, str(exc)
    return resolved.to_dict(), None


def _missing_fields(record: JobRecord) -> list[str]:
    """Required-but-absent dependencies, surfaced as blocking draft fields."""
    spec = record.spec
    inp = spec.input if isinstance(spec.input, dict) else {}
    method = spec.method if isinstance(spec.method, dict) else {}
    missing: list[str] = []
    work_dir = Path(record.work_dir) if record.work_dir else None

    kind = _input_kind(inp)
    has_source = bool(
        inp.get("input_artifact")
        or inp.get("source")
        or inp.get("input")
        or inp.get("smiles")
        or inp.get("xyz_text")
        or inp.get("items")
        or inp.get("candidates")
        or inp.get("scan_request")
    )
    if not has_source:
        missing.append("input.source")

    if spec.workflow == "casscf":
        casscf = method.get("casscf") if isinstance(method.get("casscf"), dict) else {}
        if not casscf.get("active_electrons"):
            missing.append("method.casscf.active_electrons")
        if not casscf.get("active_orbitals"):
            missing.append("method.casscf.active_orbitals")

    if spec.workflow == "BatchOptimize" and kind == "stage_artifact":
        artifact = str(inp.get("from_artifact") or "")
        if artifact and work_dir is not None and not (work_dir / artifact).is_file():
            missing.append("input.from_artifact")

    if spec.workflow == "nmr":
        experiment = inp.get("experiment")
        if isinstance(experiment, dict):
            path = experiment.get("path") or experiment.get("file")
            if isinstance(path, str) and path and not Path(path).is_file():
                missing.append("input.experiment.path")

    return missing


def build_edit_draft(
    record: JobRecord,
    *,
    run_root: Path | None = None,
) -> dict[str, Any]:
    """Build the full edit-draft payload for GET ``/jobs/{id}/edit-draft``."""
    spec = record.spec
    edit_status = workflow_edit_status(spec.workflow)
    editable = bool(edit_status["editable"])
    terminal = record.status.is_terminal
    reasons: list[str] = []
    if not editable:
        reasons.append(
            f"工作流 {spec.workflow}：" + (edit_status.get("migration_hint") or
            f"状态为 {edit_status['status']}；通用编辑重算已禁用")
        )
    can_in_place = editable and terminal
    if editable and not terminal:
        reasons.append(f"任务状态 {record.status.value} 非终态；请先取消并等待终态后再原地重算")
    can_new_job = editable

    input_refs: dict[str, Any] = {
        "mode": "original",
        "original": _describe_original_input(record, run_root=run_root),
        "structure_items": project_original_structure_items(record),
        "last_structure": (
            resolve_last_structure(
                record.work_dir,
                job_id=record.id,
                project_id=record.project_id or spec.project_id,
            )
            if editable
            else None
        ),
    }
    input_refs["previous_outputs"] = resolve_previous_outputs(
        record.work_dir, job_id=record.id, project_id=record.project_id or spec.project_id,
        attempt=attempt_number(record),
    ) if editable else []
    method = spec.method if isinstance(spec.method, dict) else {}
    notes: list[str] = []
    if not editable and edit_status.get("migration_hint"):
        notes.append(f"迁移建议：{edit_status['migration_hint']}")
    if editable and spec.workflow == "scan":
        try:
            coordinate_count = scan_method_flags(method, spec.input).count("--coordinate")
        except (ValueError, TypeError, KeyError):
            coordinate_count = 0
        if coordinate_count > 1:
            notes.append(
                f"此任务有 {coordinate_count} 个联动扫描坐标；面板显示首个坐标。"
                "此处可修改点数和计算方法；坐标组需整体重新配置。"
            )
    if editable and spec.workflow == "nmr":
        # todo 25: unregistered/invalid method fields are rejected by the
        # resolver — surface the reason at draft time (hint only; the
        # review/view and submission semantics are unchanged).
        _config, problem = _resolve_nmr_effective_config(record)
        if problem:
            notes.append(f"NMR 方法参数未通过编辑校验（提交前请修正）：{problem}")
    from acp.scheduler.edit_parameters import method_projection_for_edit

    return {
        "job_id": record.id,
        "workflow": spec.workflow,
        "workflow_status": edit_status["status"],
        "job_status": record.status.value,
        "attempt": attempt_number(record),
        "source_revision": compute_source_revision(record),
        "editable_spec": editable_spec_from_record(record),
        "method_projection": method_projection_for_edit(spec),
        "input_refs": input_refs,
        "effective_config": effective_config_info(record),
        "capabilities": {
            "can_edit": editable,
            "can_in_place": can_in_place,
            "can_new_job": can_new_job,
            "disabled_reasons": reasons,
        },
        "preserved_fields": sorted(str(k) for k in method.keys()),
        "missing_fields": _missing_fields(record),
        "migration_hint": edit_status.get("migration_hint"),
        "notes": notes,
    }


# --- diffing -------------------------------------------------------------------

_KIND_BY_TOP = {
    "method": "method",
    "resources": "resource",
    "input": "input",
    "tags": "meta",
    "node_tags": "execution",
    "remark": "meta",
    "task_name": "meta",
    "molecule_name": "meta",
    "execution_mode": "execution",
    "target_node": "execution",
    "project_id": "meta",
}


def _diff_values(path: str, old: Any, new: Any, out: list[dict[str, Any]]) -> None:
    if isinstance(old, dict) and isinstance(new, dict):
        for key in sorted(set(old) | set(new), key=str):
            _diff_values(f"{path}.{key}" if path else str(key), old.get(key), new.get(key), out)
        return
    if isinstance(old, list) and isinstance(new, list):
        if _canonicalize(old) != _canonicalize(new):
            out.append({"path": path or "(root)", "kind": _kind_for(path), "old": old, "new": new})
        return
    if _canonicalize(old) != _canonicalize(new):
        out.append({"path": path or "(root)", "kind": _kind_for(path), "old": old, "new": new})


def _kind_for(path: str) -> str:
    top = path.split(".", 1)[0] if path else "meta"
    return _KIND_BY_TOP.get(top, "meta")


def diff_editable_specs(old: dict[str, Any], new: dict[str, Any]) -> list[dict[str, Any]]:
    """Structural diff between two editable-spec projections.

    Omits-vs-null distinctions are preserved (plan §6.1 rule 4): ``None`` and
    a missing key both normalise to ``None`` on purpose — the wire contract
    treats them identically — while ``false``/``0``/``[]`` compare unequal to
    ``None``.
    """
    out: list[dict[str, Any]] = []
    _diff_values("", old or {}, new or {}, out)
    return out


# --- idempotency operation store (plan §9/§10) --------------------------------


class JobEditOperationStore:
    """SQLite-backed exactly-once operation log for edit-recalculate.

    ``request_id`` is the primary key: the same request_id with the same
    payload hash replays the stored result; the same request_id with a
    different payload is a conflict.  The row also marks the ``prepared``
    phase so an interrupted operation is identifiable and can be re-driven
    with the same request_id (plan §10 recovery contract).
    """

    def __init__(self, db_path: Path | str) -> None:
        self.db_path = Path(db_path)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def get(self, request_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM job_edit_operations WHERE request_id = ?", (request_id,)
            ).fetchone()
        return dict(row) if row is not None else None

    def insert_prepared(
        self,
        *,
        request_id: str,
        job_id: str,
        mode: str,
        payload_hash: str,
        payload_json: str,
    ) -> bool:
        """Record the prepared phase; ``False`` when request_id already exists."""
        now = _utc_now_iso()
        with self._connect() as conn:
            try:
                conn.execute(
                    "INSERT INTO job_edit_operations "
                    "(request_id, job_id, operation, mode, status, payload_hash, payload_json, "
                    "created_at, updated_at) VALUES (?, ?, 'edit_recalculate', ?, 'prepared', "
                    "?, ?, ?, ?)",
                    (request_id, job_id, mode, payload_hash, payload_json, now, now),
                )
            except sqlite3.IntegrityError:
                return False
            conn.commit()
        return True

    def complete(self, request_id: str, result_json: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE job_edit_operations SET status = 'completed', result_json = ?, "
                "updated_at = ? WHERE request_id = ?",
                (result_json, _utc_now_iso(), request_id),
            )
            conn.commit()

    def fail(self, request_id: str, error: str) -> None:
        try:
            with self._connect() as conn:
                conn.execute(
                    "UPDATE job_edit_operations SET status = 'failed', error = ?, "
                    "updated_at = ? WHERE request_id = ?",
                    (error[:2000], _utc_now_iso(), request_id),
                )
                conn.commit()
        except sqlite3.Error:  # pragma: no cover - failure logging is best-effort
            logger.warning("Could not record failure for edit operation %s", request_id)


def spec_semantics_hash(spec: JobSpec) -> str:
    """Hash only the computational semantics of a spec (compare helper)."""
    canonical = normalize_for_compare(
        {
            "workflow": spec.workflow,
            "input": spec.input,
            "method": spec.method,
            "resources": spec.resources,
        }
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()
