"""Shared energy-workflow helpers (E4 extraction).

Public home of the helpers that the ``energy`` and ``xtbmd_censo_energy``
workflows share: levels resolution, the ACP standard DFT handoff, Boltzmann
selection, final-output writers, the censo-zero xTB passthrough, and the
solvent / CREST-ewin resolvers.  These were originally private functions in
``energy.py`` / ``ensemble.py``; they are imported from here by both
workflows (and kept as private-name aliases in the origin modules so existing
importers keep working, behaviour unchanged).

T08b: also the shared home of the per-stage solvent-model split
(:func:`resolve_sampling_solvent` — moved from ``workflows/nmr.py`` so the
retired Confsearch engines and the NMR workflow reuse ONE rule without an
import cycle; ``nmr.py`` keeps private-name aliases) and the engine-facing
composition :func:`resolve_stage_solvent_models` (sampling vs CENSO/DFT).

The module has no dependency on ``acp.workflows.energy``,
``acp.workflows.ensemble`` or ``acp.workflows.nmr`` (no import cycle): it
only imports shared lower layers (backends, core models, ensemble_thermo,
cccp interfaces).
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Mapping
from dataclasses import dataclass
from importlib import import_module  # noqa: F401 — used by retired workflows
from pathlib import Path
from typing import Any, Final

import numpy as np

from acp.backends.censo_backend import CensoConformerRecord, CensoRunResult
from acp.chem.composition import normalize_recalc_hess
from acp.core.models import HARTREE_TO_KCAL, Structure, StructureEnsemble, StructureRecord
from acp.storage.layout import TaskStorage
from acp.storage.manifest import ResultManifest
from acp.workflows._helpers import write_result_summary
from acp.workflows.ensemble_thermo import (
    EnsembleThermoSummary,
    ensemble_total_gibbs,
    ensemble_total_gibbs_from_values,
    s_mix_cal_per_mol_kelvin,
    s_mix_kcal_per_mol_kelvin,
    t_s_mix_kcal_per_mol,
)
from cccp.backends.crest import CrestBackend
from cccp.calculation.context import TaskContext
from cccp.calculation.requests import (
    ConformerSearchOptions,
    MethodSpec,
    OptimizeOptions,
    RescueSpec,
    StructureInput,
    TaskKind,
    TaskRequest,
    TaskResources,
    ThermochemistryOptions,
)
from cccp.calculation.results import ConformerSearchPayload, TaskResult
from cccp.calculation.tasks.censo_refine import run_censo_refine
from cccp.calculation.tasks.conformer_search import run_conformer_search
from cccp.calculation.tasks.frequency import run_frequency
from cccp.calculation.tasks.optimize import run_optimize
from cccp.calculation.tasks.singlepoint import run_singlepoint
from cccp.calculation.tasks.thermochemistry import run_thermochemistry
from cccp.qc.interfaces.censo import CensoInterface, part_index
from cccp.qc.translation import render_censo_template_lines
from cccp.software import get_configured_path
from cccp.utils.file_io import read_xyz_multiframe, write_xyz
from cccp.utils.solvent_map import LEGAL_SOLVENT_MODELS, SolventValueError

logger = logging.getLogger(__name__)

_K_B_HARTREE_PER_KELVIN = 3.166811563e-6

_DEFAULT_OPT_FUNCTIONAL = "r2SCAN-3c"
_DEFAULT_SP_FUNCTIONAL = "wB97M-V"
_DEFAULT_SP_BASIS = "def2-TZVPP"


def _handoff_stage_dir(conf_dir: Path, stage: str, engine: str) -> Path:
    """Sibling stage dir for the same conformer (design §6: 04_FREQ/05_SP/06_THERMO).

    *conf_dir* is ``<mol>/WORK/03_OPT/<engine>/conf_NNN``; the sibling keeps
    the conf index but moves to its own stage root. Falls back to *conf_dir*
    itself when the shape does not match, so non-scheduler callers keep a
    working (if undivided) layout.
    """
    parts = conf_dir.parts
    if len(parts) >= 4 and parts[-4] == "WORK":
        work_root = conf_dir.parents[2]
        target = work_root / stage / engine / conf_dir.name
        target.mkdir(parents=True, exist_ok=True)
        return target
    return conf_dir


def v2_stage_dir(mol_dir: Path, stage: str, engine: str | None = None) -> Path:
    """Resolve (and create) ``WORK/<stage>/<engine>`` under *mol_dir* (v2 layout)."""
    storage = TaskStorage(mol_dir)
    path = storage.stage_dir(stage, engine)
    path.mkdir(parents=True, exist_ok=True)
    return path


def v2_result_category(mol_dir: Path, category: str) -> Path:
    """Resolve (and create) ``RESULT/<category>`` under *mol_dir* (v2 layout)."""
    storage = TaskStorage(mol_dir)
    path = storage.result_category_dir(category)
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_v2_manifest(
    mol_dir: Path,
    workflow: str,
    products: list[dict[str, Any]],
) -> None:
    """Write ``RESULT/result_manifest.json`` (v2 §8) with RESULT-relative paths."""
    manifest = ResultManifest(task_id="", workflow=workflow, status="completed")
    for item in products:
        if not isinstance(item, dict) or not item.get("path"):
            continue
        manifest.add_product(
            id=str(item.get("id") or item["path"]),
            label=str(item.get("label") or item["path"]),
            path=str(item["path"]),
            kind=str(item.get("kind") or "file"),
            metadata=item.get("metadata"),
        )
    manifest.write(TaskStorage(mol_dir).result_dir())


# Route-keyword maps for advanced level fields (catalog enum → ORCA keyword).
# "Fine" maps to ORCA's default DEFGRID2 and "Normal" to the default SCF
# convergence — both are omitted so default inputs stay byte-identical.
_GRID_ROUTE_MAP = {
    "sg1": "DEFGRID1",
    "ultrafine": "DEFGRID3",
    "superfine": "DEFGRID3",
}
_SCF_ROUTE_MAP = {
    "tight": "TightSCF",
    "verytight": "VeryTightSCF",
}
_OPT_CONV_ROUTE_MAP = {
    "loose": "LooseOpt",
    "tight": "TightOpt",
    "verytight": "VeryTightOpt",
}

#: First-float matcher for xTB title energies (censo-zero passthrough).
_FLOAT_RE = re.compile(r"[-+]?\d+\.\d+")


def _base_route_extras(level: dict[str, Any]) -> list[str]:
    """Build ORCA route keywords from a level's advanced fields.

    Whitelisted fields only (§10.1): dispersion, ri_approximation,
    aux_j_basis, aux_c_basis, grid, scf_convergence. Values outside the catalog enums are
    passed through verbatim in upper case where conventional.
    """
    extras: list[str] = []

    dispersion = str(level.get("dispersion") or "").strip()
    if dispersion and dispersion.lower() != "none":
        extras.append(dispersion.upper())

    ri = str(level.get("ri_approximation") or "").strip()
    if ri and ri.lower() != "none":
        extras.append(ri.upper())

    aux_j_basis = str(level.get("aux_j_basis") or "").strip()
    if aux_j_basis:
        extras.append(aux_j_basis)

    aux_c_basis = str(level.get("aux_c_basis") or "").strip()
    if aux_c_basis:
        extras.append(aux_c_basis)

    grid_kw = _GRID_ROUTE_MAP.get(str(level.get("grid") or "").strip().lower())
    if grid_kw:
        extras.append(grid_kw)

    scf_kw = _SCF_ROUTE_MAP.get(str(level.get("scf_convergence") or "").strip().lower())
    if scf_kw:
        extras.append(scf_kw)

    return extras


def _solvent_from_level(level: dict[str, Any]) -> tuple[str | None, str | None]:
    """Extract an explicit per-level solvent override.

    Returns ``(solvent, model)`` only when the level explicitly sets a
    non-empty solvent with a model other than ``none``; otherwise
    ``(None, None)`` so the workflow-global solvent applies.
    """
    model = str(level.get("solvent_model") or "").strip().lower()
    solvent = str(level.get("solvent") or "").strip()
    if not solvent or model in ("", "none"):
        return None, None
    return solvent, model


# ---------------------------------------------------------------------------
# Levels resolution (dft_opt / refinement_sp / screening_sp / thermo)
# ---------------------------------------------------------------------------


def resolve_levels(
    cfg: dict[str, Any],
    levels: dict[str, Any] | None,
) -> dict[str, Any]:
    """Merge config defaults with user ``--levels`` overrides.

    Consumes the full §10.1 field sets: ``dft_opt`` (functional, basis,
    dispersion, solvent_model, solvent, grid, scf_convergence,
    opt_convergence, max_steps), ``refinement_sp`` (functional, basis,
    aux_j_basis, aux_c_basis, dispersion, ri_approximation, solvent_model, solvent, grid,
    scf_convergence), ``screening_sp`` (same set, applied to the CENSO
    screening part) and ``thermo`` (temperature, pressure, scale_factor).

    Advanced ORCA fields are converted to route keywords for the ACP
    handoff; for CENSO-executed parts they become template lines injected
    via the per-run HOME mechanism (§6.4).
    """
    levels = levels or {}
    censo_cfg = cfg.get("censo", {})
    opt_cfg = censo_cfg.get("optimization", {})
    thermo_cfg = cfg.get("thermo", {})

    dft_opt = levels.get("dft_opt", {}) or {}
    refinement_sp = levels.get("refinement_sp", {}) or {}
    screening_sp = levels.get("screening_sp", {}) or {}
    thermo = levels.get("thermo", {}) or {}
    censo_level = levels.get("censo", {}) or {}

    opt_method = dft_opt.get("functional") or opt_cfg.get("functional", _DEFAULT_OPT_FUNCTIONAL)
    opt_basis = dft_opt.get("basis")

    # Hessian policy for the opt stage (plan §10.2): route through the
    # shared normaliser so invalid values surface here rather than
    # silently falling through to ORCA. ``None`` ⇒ follow config.
    try:
        opt_recalc_hess = normalize_recalc_hess(dft_opt.get("recalc_hess"))
    except ValueError as exc:
        raise ValueError(f"dft_opt.recalc_hess: {exc}") from exc

    sp_method = refinement_sp.get("functional") or censo_cfg.get(
        "refinement_func", _DEFAULT_SP_FUNCTIONAL
    )
    sp_basis = refinement_sp.get("basis") or censo_cfg.get("refinement_basis", _DEFAULT_SP_BASIS)

    # --- ACP handoff route extras (opt / freq / SP) ------------------------
    opt_base_extras = _base_route_extras(dft_opt)
    opt_route_extras = list(opt_base_extras)
    opt_conv_kw = _OPT_CONV_ROUTE_MAP.get(str(dft_opt.get("opt_convergence") or "").strip().lower())
    if opt_conv_kw:
        opt_route_extras.append(opt_conv_kw)

    opt_geom_maxiter: int | None = None
    max_steps = dft_opt.get("max_steps")
    if isinstance(max_steps, (int, float)) and int(max_steps) > 0:
        opt_geom_maxiter = int(max_steps)

    sp_route_extras = _base_route_extras(refinement_sp)

    opt_solvent, opt_solvent_model = _solvent_from_level(dft_opt)
    sp_solvent, sp_solvent_model = _solvent_from_level(refinement_sp)

    # --- CENSO rcfile overrides + advanced-field templates ------------------
    screening_overrides: dict[str, Any] = {}
    if screening_sp.get("functional"):
        screening_overrides["func"] = str(screening_sp["functional"]).lower()
    if screening_sp.get("basis"):
        screening_overrides["basis"] = str(screening_sp["basis"]).lower()

    refinement_overrides: dict[str, Any] = {}
    if refinement_sp.get("functional"):
        refinement_overrides["func"] = str(refinement_sp["functional"]).lower()
    if refinement_sp.get("basis"):
        refinement_overrides["basis"] = str(refinement_sp["basis"]).lower()

    screening_extras = _base_route_extras(screening_sp)
    screening_template_lines = render_censo_template_lines(screening_extras)
    refinement_template_lines = render_censo_template_lines(sp_route_extras)

    # Workflow-global solvent fallback derived from levels (UI wizard path):
    # refinement_sp takes precedence over dft_opt.
    levels_solvent = sp_solvent or opt_solvent
    levels_solvent_model = sp_solvent_model or opt_solvent_model

    try:
        refinement_threshold = float(
            levels.get(
                "refinement_threshold",
                censo_cfg.get("refinement_threshold", 0.99),
            )
        )
    except (TypeError, ValueError):
        refinement_threshold = 0.99
    if not 0.0 < refinement_threshold <= 1.0:
        logger.warning(
            "refinement_threshold %.4f outside (0, 1] — falling back to 0.99",
            refinement_threshold,
        )
        refinement_threshold = 0.99

    crest_ewin_level: float | None = None
    raw_ewin = censo_level.get("ewin")
    if raw_ewin is not None:
        try:
            candidate_ewin = float(raw_ewin)
        except (TypeError, ValueError):
            candidate_ewin = None
        if candidate_ewin is not None and candidate_ewin > 0:
            crest_ewin_level = candidate_ewin

    return {
        "opt_method": opt_method,
        "opt_basis": opt_basis,
        "opt_route_extras": opt_route_extras,
        "opt_freq_route_extras": opt_base_extras,
        "opt_geom_maxiter": opt_geom_maxiter,
        "opt_recalc_hess": opt_recalc_hess,
        "opt_solvent": opt_solvent,
        "opt_solvent_model": opt_solvent_model,
        "sp_method": sp_method,
        "sp_basis": sp_basis,
        "sp_route_extras": sp_route_extras,
        "sp_solvent": sp_solvent,
        "sp_solvent_model": sp_solvent_model,
        "screening_overrides": screening_overrides,
        "refinement_overrides": refinement_overrides,
        "screening_template_lines": screening_template_lines,
        "refinement_template_lines": refinement_template_lines,
        "levels_solvent": levels_solvent,
        "levels_solvent_model": levels_solvent_model,
        "refinement_threshold": refinement_threshold,
        "crest_ewin_level": crest_ewin_level,
        "temperature_k": thermo.get("temperature", thermo_cfg.get("temperature_k", 298.15)),
        "pressure_atm": thermo.get("pressure", thermo_cfg.get("pressure_atm", 1.0)),
        "scl_zpe": thermo.get("scale_factor", thermo_cfg.get("scl_zpe", 0.9905)),
        "ilowfreq": thermo_cfg.get("shermo_ilowfreq", 2),
        "imagreal": thermo_cfg.get("shermo_imagreal", 0),
        "conc": thermo_cfg.get("shermo_conc"),
    }


# ---------------------------------------------------------------------------
# ACP standard handoff (opt → freq → SP → Shermo), consistency-enforced
# ---------------------------------------------------------------------------


_TAG_UNSAFE_RE = re.compile(r"[^A-Za-z0-9._-]+")


def conformer_tag(source: str | None, index: int) -> str:
    """Stable filesystem tag identifying one conformer across all artifacts.

    Derived from the screening ``conf_id`` (e.g. ``CONF12``) so the DFT stage
    directory, calculation file basenames, ``conformer_thermo.csv`` source
    column, xyz frame ``conf_id=`` markers and Boltzmann-table rows all carry
    the same name regardless of the (post-DFT) rank order.  Falls back to the
    legacy positional ``conf_NNN`` when no screening id is available.
    """
    cleaned = _TAG_UNSAFE_RE.sub("_", str(source).strip()) if source else ""
    return cleaned if cleaned and cleaned != "rank1" else f"conf_{index:03d}"


# ---------------------------------------------------------------------------
# cccp task-core adapters (todo 26a): CREST / CENSO / ORCA / Shermo seams
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _TaskQcView:
    """QCResult-like projection of one ``TaskResult`` (legacy handoff view)."""

    success: bool
    error_message: str | None
    coordinates: Any
    symbols: list[str] | None
    log_file: Path | None
    energy: float | None


def _task_log_file(result: TaskResult, *, prefer_freq_log: bool = False) -> Path | None:
    """Return the log artifact path (freq results prefer ``frequency_log``)."""
    by_type = {artifact.type: Path(artifact.path) for artifact in result.artifacts}
    if prefer_freq_log:
        return by_type.get("frequency_log") or by_type.get("log")
    return by_type.get("log") or by_type.get("frequency_log")


def _task_qc_view(result: TaskResult, *, prefer_freq_log: bool = False) -> _TaskQcView:
    """Map one typed ``TaskResult`` onto the legacy QCResult view."""
    coordinates = (
        np.asarray(result.coordinates, dtype=float) if result.coordinates is not None else None
    )
    symbols = list(result.symbols) if result.symbols is not None else None
    return _TaskQcView(
        success=result.status == "completed",
        error_message="; ".join(result.errors) or None,
        coordinates=coordinates,
        symbols=symbols,
        log_file=_task_log_file(result, prefer_freq_log=prefer_freq_log),
        energy=result.energy_hartree,
    )


def crest_search_via_task(
    cfg: dict[str, Any],
    input_xyz: Path,
    output_dir: Path,
    *,
    charge: int,
    multiplicity: int,
    energy_window: float,
    output_name: str,
    gfn_level: int = 2,
    solvent: str | None = None,
    solvent_model: str | None = "none",
) -> Path:
    """Run one CREST conformer search via ``run_conformer_search`` (D1).

    The task core builds its backend without constructor kwargs, so the
    legacy ``gfn_level``/``solvent``/``solvent_model`` ride through the
    sanctioned ``TaskContext.backend`` runtime seam.  Returns the ensemble
    XYZ path from the payload artifact; raises ``RuntimeError`` on failure
    (the legacy ``CrestBackend.search`` contract).
    """
    crest = CrestBackend(
        config=cfg,
        gfn_level=gfn_level,
        solvent=solvent,
        solvent_model=solvent_model,
    )
    result = run_conformer_search(
        TaskRequest(
            task=TaskKind.CONFORMER_SEARCH,
            structure=StructureInput(path=Path(input_xyz)),
            charge=charge,
            multiplicity=multiplicity,
            output_dir=Path(output_dir),
            options=ConformerSearchOptions(energy_window=energy_window),
        ),
        context=TaskContext(
            backend=crest,
            config=cfg,
            capability_extras={"output_name": output_name},
        ),
    )
    payload = result.payload
    ensemble_ref = payload.ensemble_ref if isinstance(payload, ConformerSearchPayload) else None
    if result.status != "completed" or ensemble_ref is None:
        detail = "; ".join(result.errors) or "no CREST ensemble produced"
        raise RuntimeError(f"CREST search failed: {detail}")
    return Path(ensemble_ref.path)


def _part_template_tokens(part_templates: dict[str, list[str]] | None) -> dict[str, list[str]]:
    """Rendered CENSO template lines → raw per-part route keywords (D2).

    ``render_censo_template_lines`` assembles ``["! k1 k2 …"]`` from literal
    keywords, so stripping the leading ``"! "`` and splitting recovers the
    raw tokens; re-rendering them by the translation layer is idempotent for
    these literal tokens.
    """
    extras: dict[str, list[str]] = {}
    for part, lines in (part_templates or {}).items():
        tokens: list[str] = []
        for line in lines or ():
            text = str(line)
            if text.startswith("! "):
                text = text[len("! ") :]
            tokens.extend(text.split())
        if tokens:
            extras[str(part)] = tokens
    return extras


def censo_refine_via_task(
    cfg: dict[str, Any],
    ensemble_xyz: Path,
    run_dir: Path,
    *,
    preset: str,
    charge: int,
    multiplicity: int,
    temperature: float | None = None,
    solvent: str | None = None,
    solvent_model: str | None = None,
    nproc: int | None = None,
    include_refinement: bool | None = None,
    nconf: int | None = None,
    part_overrides: dict[str, dict[str, Any]] | None = None,
    part_templates: dict[str, list[str]] | None = None,
    keep_all: bool | None = None,
) -> CensoRunResult:
    """Run one CENSO refinement via ``run_censo_refine`` (D2).

    Legacy capability kwargs ride in ``capability_extras`` verbatim except
    pre-rendered ``part_templates`` (rejected by the task): raw per-part
    tokens go under ``part_template_extras`` and are re-rendered by the
    translation layer.  The legacy ``CensoRunResult`` data contract
    (gsolv/grrho/coordinates preserved) is reconstructed from the
    final-part ``<idx>_<FINAL_PART>.json``/``.xyz`` artifacts (the
    ``censo_refine`` naming convention); missing artifacts raise
    ``RuntimeError`` like the legacy backend did.
    """
    extras: dict[str, Any] = {"preset": preset}
    for key, value in (
        ("temperature", temperature),
        ("solvent", solvent),
        ("solvent_model", solvent_model),
        ("include_refinement", include_refinement),
        ("nconf", nconf),
        ("keep_all", keep_all),
    ):
        if value is not None:
            extras[key] = value
    if part_overrides:
        extras["part_overrides"] = part_overrides
    template_extras = _part_template_tokens(part_templates)
    if template_extras:
        extras["part_template_extras"] = template_extras

    run_dir = Path(run_dir)
    result = run_censo_refine(
        TaskRequest(
            task=TaskKind.CENSO_REFINE,
            structure=StructureInput(path=Path(ensemble_xyz)),
            charge=charge,
            multiplicity=multiplicity,
            resources=TaskResources(nproc=nproc),
            output_dir=run_dir,
        ),
        context=TaskContext(config=cfg, capability_extras=extras),
    )
    metadata = result.metadata or {}
    final_part = str(metadata.get("final_part") or "")
    json_path = run_dir / f"{part_index(final_part)}_{final_part.upper()}.json"
    xyz_path = run_dir / f"{part_index(final_part)}_{final_part.upper()}.xyz"
    if not json_path.is_file() or not xyz_path.is_file():
        detail = "; ".join(result.errors) or (
            f"missing CENSO artifacts {json_path.name}/{xyz_path.name}"
        )
        raise RuntimeError(f"CENSO refine failed: {detail}")
    records = CensoInterface({}).parse_censo_json(json_path, xyz_path)
    if not records:
        detail = "; ".join(result.errors) or "no conformer records parsed"
        raise RuntimeError(f"CENSO refine failed: {detail}")
    run_result = CensoRunResult(
        preset=str(metadata.get("preset") or preset or "censo-light"),
        records=list(records),
        final_part=final_part,
        work_dir=run_dir,
        temperature=float(metadata.get("temperature_k") or temperature or 298.15),
    )
    run_result.sort_by_gtot()
    return run_result


def shermo_via_task(
    cfg: dict[str, Any],
    *,
    freq_log: str,
    sp_energy: float,
    thermo_dir: Path,
    output_file: str,
    shermo_bin: str,
    temperature_k: float,
    pressure_atm: float,
    scl_zpe: float | None,
    ilowfreq: int | None,
    imagreal: int | None,
    conc: float | None,
) -> dict[str, Any] | None:
    """Run Shermo thermochemistry via ``run_thermochemistry`` (D4).

    Returns the legacy value dict (``g_sum``/``h_sum``/``u_sum``/
    ``s_total``/``g_conc``) or ``None`` on failure so the caller's
    ``if not raw_shermo: raise`` path fires unchanged.
    """
    result = run_thermochemistry(
        TaskRequest(
            task=TaskKind.THERMOCHEMISTRY,
            options=ThermochemistryOptions(
                freq_log_path=Path(freq_log),
                sp_energy_hartree=sp_energy,
                temperature_k=temperature_k,
                pressure_atm=pressure_atm,
                scl_zpe=scl_zpe,
                ilowfreq=ilowfreq,
                imagreal=imagreal,
                conc=conc,
            ),
            output_dir=Path(thermo_dir),
        ),
        context=TaskContext(
            config=cfg,
            capability_extras={"output_file": str(output_file), "shermo_bin": shermo_bin},
        ),
    )
    if result.status != "completed":
        return None
    metadata = result.metadata or {}
    return {key: metadata.get(key) for key in ("g_sum", "h_sum", "u_sum", "s_total", "g_conc")}


def run_rank1_handoff(
    cfg: dict[str, Any],
    coordinates: np.ndarray[Any, Any],
    symbols: list[str],
    charge: int,
    multiplicity: int,
    work_dir: Path,
    resolved: dict[str, Any],
    solvent: str | None,
    solvent_model: str,
    index: int = 0,
    source: str = "rank1",
    sp_energy_precomputed: float | None = None,
    skip_opt_sp: bool = False,
) -> dict[str, Any]:
    """Run the ACP standard DFT handoff on one conformer.

    Enforces the v7 consistency rule: the frequency calculation uses the
    same method/basis as the geometry optimization (ORCA freq + Shermo).

    Args:
        skip_opt_sp: When True (censo-default survivors), skip the opt and
            SP steps and only run freq + Shermo on the given geometry with
            ``sp_energy_precomputed`` as electronic energy.

    Returns:
        Candidate record dict (index/coordinates/symbols/energy/gibbs/...).
    """
    work_dir.mkdir(parents=True, exist_ok=True)
    tag = conformer_tag(source, index)

    opt_solvent = resolved.get("opt_solvent") or solvent
    opt_solvent_model = (
        resolved.get("opt_solvent_model")
        if resolved.get("opt_solvent")
        else (solvent_model if solvent else "none")
    ) or "none"
    opt_level = MethodSpec(
        method=resolved["opt_method"],
        basis=resolved["opt_basis"] or "def2-TZVPP",
        solvent=opt_solvent,
        solvent_model=opt_solvent_model if opt_solvent else "none",
    )

    if skip_opt_sp:
        opt_coords = coordinates
        opt_symbols = symbols
        sp_energy = sp_energy_precomputed
        opt_log = None
        sp_log = None
        logger.info("  [freq] same-level frequency on pre-optimized geometry")
    else:
        logger.info("  [opt] geometry optimization (%s)", resolved["opt_method"])

        opt_result = run_optimize(
            TaskRequest(
                task=TaskKind.OPTIMIZE,
                structure=StructureInput(
                    coordinates=np.asarray(coordinates, dtype=float),
                    symbols=list(symbols),
                ),
                charge=charge,
                multiplicity=multiplicity,
                level=opt_level,
                backend="orca",
                options=OptimizeOptions(rescue=RescueSpec(policy="off")),
                output_dir=work_dir,
            ),
            context=TaskContext(
                config=cfg,
                workdir=work_dir,
                capability_extras={
                    "output_name": f"{tag}_opt",
                    "route_extras": resolved.get("opt_route_extras"),
                    "geom_maxiter": resolved.get("opt_geom_maxiter"),
                    "recalc_hess": resolved.get("opt_recalc_hess"),
                },
            ),
        )
        opt_view = _task_qc_view(opt_result)
        if not opt_view.success:
            raise RuntimeError(f"rank1 geometry optimization failed: {opt_view.error_message}")
        opt_coords = opt_view.coordinates
        opt_symbols = opt_view.symbols or symbols
        opt_log = str(opt_view.log_file) if opt_view.log_file else None
        sp_energy = None
        sp_log = None

    # Frequency at the SAME method/basis as the optimization (v7 rule)
    logger.info(
        "  [freq] frequency calculation (%s, same level as opt)",
        resolved["opt_method"],
    )
    freq_dir = _handoff_stage_dir(work_dir, "04_FREQ", "ORCA")
    freq_result = run_frequency(
        TaskRequest(
            task=TaskKind.FREQUENCY,
            structure=StructureInput(
                coordinates=np.asarray(opt_coords, dtype=float),
                symbols=list(opt_symbols),
            ),
            charge=charge,
            multiplicity=multiplicity,
            level=opt_level,
            backend="orca",
            output_dir=freq_dir,
        ),
        context=TaskContext(
            config=cfg,
            workdir=freq_dir,
            capability_extras={
                "output_name": f"{tag}_freq",
                "route_extras": resolved.get("opt_freq_route_extras"),
            },
        ),
    )
    freq_view = _task_qc_view(freq_result, prefer_freq_log=True)
    if not freq_view.success:
        raise RuntimeError(f"rank1 frequency calculation failed: {freq_view.error_message}")

    if not skip_opt_sp:
        logger.info(
            "  [sp] high-level single point (%s/%s)",
            resolved["sp_method"],
            resolved["sp_basis"],
        )
        sp_solvent = resolved.get("sp_solvent") or solvent
        sp_solvent_model = (
            resolved.get("sp_solvent_model")
            if resolved.get("sp_solvent")
            else (solvent_model if solvent else "none")
        ) or "none"
        sp_dir = _handoff_stage_dir(work_dir, "05_SP", "ORCA")
        sp_result = run_singlepoint(
            TaskRequest(
                task=TaskKind.SINGLEPOINT,
                structure=StructureInput(
                    coordinates=np.asarray(opt_coords, dtype=float),
                    symbols=list(opt_symbols),
                ),
                charge=charge,
                multiplicity=multiplicity,
                level=MethodSpec(
                    method=resolved["sp_method"],
                    basis=resolved["sp_basis"] or "def2-TZVPP",
                    solvent=sp_solvent,
                    solvent_model=sp_solvent_model if sp_solvent else "none",
                ),
                backend="orca",
                output_dir=sp_dir,
            ),
            context=TaskContext(
                config=cfg,
                workdir=sp_dir,
                capability_extras={
                    "output_name": f"{tag}_sp",
                    "route_extras": resolved.get("sp_route_extras"),
                },
            ),
        )
        sp_view = _task_qc_view(sp_result)
        if not sp_view.success:
            raise RuntimeError(f"rank1 single-point failed: {sp_view.error_message}")
        sp_energy = sp_view.energy
        sp_log = str(sp_view.log_file) if sp_view.log_file else None

    if sp_energy is None:
        raise RuntimeError("No electronic energy available for Shermo handoff")

    thermo_dir = _handoff_stage_dir(work_dir, "06_THERMO", "Shermo")
    logger.info("  [thermo] thermodynamic correction")
    standard_state = _resolve_standard_state(cfg)
    raw_shermo = shermo_via_task(
        cfg,
        freq_log=str(freq_view.log_file),
        sp_energy=sp_energy,
        thermo_dir=thermo_dir,
        output_file=str(thermo_dir / f"{tag}_Shermo.sum"),
        shermo_bin=get_configured_path(cfg, "shermo"),
        temperature_k=resolved["temperature_k"],
        pressure_atm=resolved["pressure_atm"],
        scl_zpe=resolved.get("scl_zpe", 1.0),
        ilowfreq=resolved.get("ilowfreq", 0),
        imagreal=resolved.get("imagreal", 0),
        conc=resolved.get("conc"),
    )
    if not raw_shermo:
        raise RuntimeError("Shermo thermochemistry failed for rank1 conformer")
    gibbs = raw_shermo.get("g_sum")
    if gibbs is None:
        raise RuntimeError("Shermo thermochemistry failed for rank1 conformer")
    if standard_state == "1M" and raw_shermo.get("g_conc") is not None:
        gibbs = raw_shermo["g_conc"]

    return {
        "index": index,
        "coordinates": np.asarray(opt_coords),
        "symbols": list(opt_symbols),
        "energy": sp_energy,
        "gibbs": gibbs,
        "gibbs_correction": raw_shermo.get("g_sum"),
        "h_correction": raw_shermo.get("h_sum"),
        "u_correction": raw_shermo.get("u_sum"),
        "s_total": raw_shermo.get("s_total"),
        "g_conc": raw_shermo.get("g_conc"),
        "source": source,
        "opt_log": opt_log,
        "sp_log": sp_log,
    }


def _resolve_standard_state(cfg: dict[str, Any]) -> str:
    thermo = cfg.get("thermo", {})
    if isinstance(thermo, dict):
        ss = thermo.get("standard_state", "1atm")
        if isinstance(ss, str):
            return ss
    return "1atm"


# ---------------------------------------------------------------------------
# Boltzmann selection
# ---------------------------------------------------------------------------


def boltzmann_weights(gibbs_values: list[float], temperature_k: float) -> list[float]:
    if not gibbs_values:
        return []
    kt = _K_B_HARTREE_PER_KELVIN * temperature_k
    g_min = min(gibbs_values)
    raw = [float(np.exp(-(g - g_min) / kt)) for g in gibbs_values]
    total = sum(raw)
    if total <= 0:
        return [0.0 for _ in raw]
    return [w / total for w in raw]


def select_cumulative_boltzmann(
    records: list[Any],
    temperature_k: float,
    threshold: float,
) -> list[Any]:
    """Select the lowest-gtot conformers up to a cumulative Boltzmann cutoff.

    Records (``.gtot``-bearing, e.g. :class:`CensoConformerRecord`) are
    sorted by ascending ``gtot``; conformers are accumulated until their
    cumulative Boltzmann population reaches ``threshold`` (the conformer
    crossing the threshold is included). Rank1 is always selected.
    """
    if not records:
        return []
    ordered = sorted(records, key=lambda r: r.gtot)
    weights = boltzmann_weights([r.gtot for r in ordered], temperature_k)
    selected: list[Any] = []
    cumulative = 0.0
    for rec, weight in zip(ordered, weights):
        selected.append(rec)
        cumulative += weight
        if cumulative >= threshold:
            break
    return selected


# ---------------------------------------------------------------------------
# Ensemble total-Gibbs summary + final output writers
# ---------------------------------------------------------------------------


def build_ensemble_summary(
    candidates: list[dict[str, Any]],
    dft_weights: list[float],
    temperature_k: float,
    external_weights: dict[str, float] | None = None,
    external_total_gibbs: float | None = None,
    external_total_gibbs_censo: float | None = None,
    population_weights: dict[str, float] | None = None,
    external_table_source: str = "censo",
) -> EnsembleThermoSummary:
    """Assemble the ensemble total-Gibbs summary for an output batch.

    Workflow 1 (no external table): the DFT table of the selected
    candidates drives p₁ and S_mix; ``population_coverage`` is the
    cumulative weight of the selected set inside the full screening table
    (``population_weights``), disclosing the ≥99% truncation.

    Workflow 2 (external table): the complete CENSO/xTB table drives p₁
    and S_mix while G₁ is the fine rank1 Gibbs value (or the CENSO gtot on
    cheap paths); the coverage is 1.0 by construction of the table.
    """
    if external_weights is not None:
        method = "censo_table_rank1" if external_table_source == "censo" else "xtb_table_rank1"
        p1 = 0.0
        for cand in candidates:
            p1 = external_weights.get(str(cand.get("source", "")), 0.0)
            if p1 > 0.0:
                break
        if p1 <= 0.0 and external_weights:
            p1 = max(external_weights.values())
        rank1_source = str(candidates[0].get("source", "")) if candidates else ""
        rank1_gibbs = candidates[0].get("gibbs") if candidates else None
        rank1_gibbs = float(rank1_gibbs) if rank1_gibbs is not None else 0.0
        total = (
            external_total_gibbs
            if external_total_gibbs is not None
            else ensemble_total_gibbs(rank1_gibbs, p1, temperature_k)
        )
        rows: list[dict[str, Any]] = []
        ordered_ext = sorted(external_weights.items(), key=lambda kv: (-float(kv[1]), str(kv[0])))
        for row_rank, (conf_id, w) in enumerate(ordered_ext, start=1):
            g = rank1_gibbs if conf_id == rank1_source else None
            rows.append(
                {
                    "conf_id": conf_id,
                    "rank": row_rank,
                    "gibbs_hartree": g,
                    "delta_gibbs_kcal_mol": None,
                    "weight": round(float(w), 6),
                }
            )
        weights_values = list(external_weights.values())
        coverage = 1.0
    else:
        method = "dft_table"
        gibbs_values = [
            c["gibbs"] if c.get("gibbs") is not None else c.get("energy", 0.0) for c in candidates
        ]
        rank1_gibbs = gibbs_values[0] if gibbs_values else 0.0
        total = ensemble_total_gibbs_from_values(gibbs_values, temperature_k)
        p1 = dft_weights[0] if dft_weights else 0.0
        rows = [
            {
                "conf_id": c.get("source", f"conf{c.get('index', i)}"),
                "rank": i + 1,
                "gibbs_hartree": c.get("gibbs"),
                "delta_gibbs_kcal_mol": (
                    (float(c["gibbs"]) - float(rank1_gibbs)) * HARTREE_TO_KCAL
                    if c.get("gibbs") is not None and rank1_gibbs is not None
                    else None
                ),
                "weight": round(float(w), 6),
            }
            for i, (c, w) in enumerate(zip(candidates, dft_weights))
        ]
        weights_values = dft_weights
        coverage = 1.0
        if population_weights:
            selected = sum(
                population_weights.get(str(c.get("source", "")), 0.0) for c in candidates
            )
            if selected > 0.0:
                coverage = round(min(selected, 1.0), 6)

    return EnsembleThermoSummary(
        method=method,
        temperature_k=temperature_k,
        total_gibbs_hartree=total,
        total_gibbs_kcal_mol=total * HARTREE_TO_KCAL,
        rank1_gibbs_hartree=rank1_gibbs,
        rank1_weight=round(p1, 6),
        mixing_entropy_kcal_per_mol_kelvin=s_mix_kcal_per_mol_kelvin(weights_values),
        mixing_entropy_cal_per_mol_kelvin=s_mix_cal_per_mol_kelvin(weights_values),
        t_s_mix_kcal_per_mol=t_s_mix_kcal_per_mol(weights_values, temperature_k),
        population_coverage=coverage,
        conformers=rows,
        censo_reference_gibbs_hartree=external_total_gibbs_censo,
        censo_reference_gibbs_kcal_mol=(
            external_total_gibbs_censo * HARTREE_TO_KCAL
            if external_total_gibbs_censo is not None
            else None
        ),
    )


def _ensemble_xyz_frames(
    candidates: list[dict[str, Any]],
    external_weights: dict[str, float] | None,
    screening_records: list[Any] | None,
) -> list[dict[str, Any]]:
    """Frames to serialize into ``all_conformers.xyz``.

    Workflow 1 (no external table): the refined candidates themselves —
    already 1:1 with the DFT Boltzmann table rows.

    Workflow 2 (external CENSO/xTB table): *every* screened conformer,
    ordered exactly like the table rows in :func:`build_ensemble_summary`
    (weight descending, ``conf_id`` as tie-break). The refined ``conf_id``
    contributes its fine (DFT) geometry and energy while the remaining
    rows contribute their screening geometry, so the file stays 1:1 with
    ``ensemble_thermo.json`` / ``boltzmann_table.json``.

    Records are duck-typed (``.conf_id`` / ``.coordinates`` / ``.symbols``
    / ``.energy`` / ``.gtot``, e.g. :class:`CensoConformerRecord`).  When
    no *screening_records* are available the writer degrades to the old
    candidates-only behaviour so the file never disappears.
    """
    if external_weights is None or not screening_records:
        return list(candidates)

    def record_id(rec: Any) -> str:
        return str(getattr(rec, "conf_id", ""))

    refined = {str(c.get("source", "")): c for c in candidates}
    ordered = sorted(
        screening_records,
        key=lambda r: (-float(external_weights.get(record_id(r), 0.0)), record_id(r)),
    )
    frames: list[dict[str, Any]] = []
    for rank, rec in enumerate(ordered, start=1):
        conf_id = record_id(rec)
        weight = float(external_weights.get(conf_id, 0.0))
        cand = refined.get(conf_id)
        if cand is not None:
            frame = dict(cand)
            frame["rank"] = rank
            frame["weight"] = weight
            frames.append(frame)
            continue
        coordinates = getattr(rec, "coordinates", None)
        symbols = getattr(rec, "symbols", None)
        if coordinates is None or symbols is None:
            logger.warning(
                "Screening record %s has no geometry — skipped in all_conformers.xyz",
                conf_id,
            )
            continue
        frames.append(
            {
                "index": rank - 1,
                "coordinates": np.asarray(coordinates, dtype=float),
                "symbols": list(symbols),
                "energy": getattr(rec, "energy", None),
                "gibbs": getattr(rec, "gtot", None),
                "rank": rank,
                "weight": weight,
                "source": conf_id,
            }
        )
    # A refined conformer whose id is missing from the screening table
    # (frame-based id mismatch) must not silently vanish from the file.
    record_ids = {record_id(rec) for rec in ordered}
    for cand in candidates:
        if str(cand.get("source", "")) not in record_ids:
            frame = dict(cand)
            frame["rank"] = len(frames) + 1
            frames.append(frame)
    return frames


def write_final_outputs(
    candidates: list[dict[str, Any]],
    mol_dir: Path,
    mol_name: str,
    temperature_k: float,
    external_weights: dict[str, float] | None = None,
    external_total_gibbs: float | None = None,
    external_total_gibbs_censo: float | None = None,
    population_weights: dict[str, float] | None = None,
    external_table_source: str = "censo",
    screening_records: list[Any] | None = None,
) -> dict[str, Any]:
    """Write categorized final results under ``RESULT/``.

    File formats match the legacy engine's ``_finalize_results`` products
    field-for-field so downstream consumers (NMR, benchmark, frontend) work
    without modification.  New scheduler tasks store the products in
    ``RESULT/structures`` / ``RESULT/energies`` / ``RESULT/ensembles``.  The
    legacy ``finalDFT/`` directory is read-only compatibility for historical
    tasks and is no longer created here.  When *external_weights* is given
    (workflow 2), the Boltzmann table is written to ``RESULT/ensembles``;
    the thermo CSV keeps its legacy header and receives a TOTAL row.  In
    that mode ``all_conformers.xyz`` covers every conformer of the
    Boltzmann table (see :func:`_ensemble_xyz_frames`) — not just the
    refined candidates — so structures and weights stay 1:1.

    Args:
        external_weights: Full-ensemble weight table (conf_id → p) driving
            workflow 2 (CENSO or xTB table).
        external_total_gibbs: Pre-computed G_total (fine G₁ + kT·ln p₁).
        external_total_gibbs_censo: CENSO-level reference total for the
            workflow-2 cross-check (gtot₁ + kT·ln p₁).
        population_weights: Full screening-table weights used to disclose
            the cumulative population coverage of the workflow-1 DFT table.
        external_table_source: ``"censo"`` (default) or ``"xtb"`` for the
            workflow-2 weight-table provenance.
        screening_records: Full post-screening conformer records backing
            *external_weights* (``.conf_id`` / ``.coordinates`` /
            ``.symbols`` / ``.energy`` / ``.gtot``); required for the
            workflow-2 1:1 xyz ↔ Boltzmann-table output.
    """
    result_structures = v2_result_category(mol_dir, "structures")
    result_energies = v2_result_category(mol_dir, "energies")
    result_ensembles = v2_result_category(mol_dir, "ensembles")

    candidates = sorted(
        candidates,
        key=lambda c: c["gibbs"] if c.get("gibbs") is not None else float("inf"),
    )
    gibbs_values = [
        c["gibbs"] if c.get("gibbs") is not None else c.get("energy", 0.0) for c in candidates
    ]
    weights = boltzmann_weights([float(g) for g in gibbs_values], temperature_k)

    for rank, (cand, weight) in enumerate(zip(candidates, weights), start=1):
        cand["rank"] = rank
        cand["weight"] = weight
        cand["index"] = rank - 1

    summary = build_ensemble_summary(
        candidates,
        weights,
        temperature_k,
        external_weights=external_weights,
        external_total_gibbs=external_total_gibbs,
        external_total_gibbs_censo=external_total_gibbs_censo,
        population_weights=population_weights,
        external_table_source=external_table_source,
    )
    thermo_json = result_energies / "ensemble_thermo.json"
    summary.write_json(thermo_json)

    ensemble_xyz = result_structures / "all_conformers.xyz"
    frames = _ensemble_xyz_frames(candidates, external_weights, screening_records)
    with open(ensemble_xyz, "w") as f:
        for c in frames:
            e_fmt = f"{c['energy']:.6f}" if c.get("energy") is not None else "N/A"
            comment = (
                f"Conformer {c['index']}, E={e_fmt}, Rank={c['rank']}, Weight={c['weight']:.4f},"
                f" conf_id={c.get('source', 'unknown')}"
            )
            f.write(f"{len(c['symbols'])}\n")
            f.write(comment + "\n")
            for sym, coord in zip(c["symbols"], c["coordinates"]):
                f.write(f"{sym:2s} {coord[0]:15.10f} {coord[1]:15.10f} {coord[2]:15.10f}\n")

    thermo_csv = result_energies / "conformer_thermo.csv"
    with open(thermo_csv, "w") as f:
        f.write(
            "index,rank,energy_hartree,gibbs_correction,gibbs_hartree,"
            "h_correction,u_correction,s_total,g_conc,weight,source\n"
        )
        for c in candidates:
            f.write(f"{c['index']},{c['rank']},")
            f.write(
                f"{c['energy']:.10f},"
                if c.get("energy") is not None and c["energy"] != float("inf")
                else "N/A,"
            )
            for key in (
                "gibbs_correction",
                "gibbs",
                "h_correction",
                "u_correction",
                "s_total",
                "g_conc",
            ):
                val = c.get(key)
                f.write(f"{val:.10f}," if val is not None else ",")
            f.write(f"{c['weight']:.6f},")
            f.write(f"{c.get('source', 'unknown')}\n")
        # TOTAL summary row appended inside the write block — column header
        # set stays untouched so existing parsers keep working (G_total
        # lands in the gibbs_hartree column, source marker "ensemble_total").
        f.write(
            ",".join(
                [
                    "TOTAL",
                    "",
                    "",
                    "",
                    f"{summary.total_gibbs_hartree:.10f}",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "ensemble_total",
                ]
            )
            + "\n"
        )

    boltzmann_table_json: str | None = None
    if external_weights is not None:
        bt_path = result_ensembles / "boltzmann_table.json"
        bt_path.write_text(
            json.dumps(
                {
                    "temperature_k": temperature_k,
                    "source": "censo" if external_table_source == "censo" else "xtb",
                    "weights": {str(k): float(v) for k, v in sorted(external_weights.items())},
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        boltzmann_table_json = str(bt_path)

    global_min = candidates[0]
    global_min_xyz = result_structures / f"{mol_name}_global_min.xyz"
    gm_energy = (
        global_min.get("g_conc")
        if global_min.get("g_conc") is not None
        else (
            global_min.get("gibbs")
            if global_min.get("gibbs") is not None
            else global_min.get("energy")
        )
    )
    write_xyz(
        global_min_xyz,
        global_min["coordinates"],
        global_min["symbols"],
        title=f"Global minimum for {mol_name}",
        energy=gm_energy if gm_energy is not None else float("inf"),
        comment=f"Rank {global_min['rank']}, Weight {global_min['weight']:.4f}",
    )

    outputs: dict[str, Any] = {
        "all_conformers_xyz": str(ensemble_xyz),
        "thermo_csv": str(thermo_csv),
        "global_min_xyz": str(global_min_xyz),
        "total_gibbs_hartree": summary.total_gibbs_hartree,
        "total_gibbs_kcal_mol": summary.total_gibbs_kcal_mol,
        "ensemble_thermo_json": str(thermo_json),
        "temperature_k": temperature_k,
        "population_coverage": summary.population_coverage,
        "weight_source": "dft" if external_weights is None else external_table_source,
        "weight_method": summary.method,
    }
    if summary.censo_reference_gibbs_hartree is not None:
        outputs["total_gibbs_censo_hartree"] = summary.censo_reference_gibbs_hartree
    if boltzmann_table_json is not None:
        outputs["boltzmann_table_json"] = boltzmann_table_json

    result_summary_products = [
        {
            "label": "Ranked conformers (XYZ)",
            "path": "RESULT/structures/all_conformers.xyz",
            "kind": "xyz",
        },
        {
            "label": "Ensemble thermo (G_total)",
            "path": "RESULT/energies/ensemble_thermo.json",
            "kind": "report",
        },
        {
            "label": "Conformer thermo table (CSV)",
            "path": "RESULT/energies/conformer_thermo.csv",
            "kind": "table",
        },
        {
            "label": "Global minimum structure",
            "path": f"RESULT/structures/{mol_name}_global_min.xyz",
            "kind": "xyz",
            "role": "final_stable_structure",
        },
    ]
    write_result_summary(mol_dir, workflow="energy", products=result_summary_products)
    write_v2_manifest(
        mol_dir,
        "energy",
        [
            {
                "id": "all_conformers",
                "label": "Ranked conformers (XYZ)",
                "path": "structures/all_conformers.xyz",
                "kind": "structure",
                "metadata": {"auto_reusable": False},
            },
            {
                "id": "ensemble_thermo",
                "label": "Ensemble thermo (G_total)",
                "path": "energies/ensemble_thermo.json",
                "kind": "energy_report",
            },
            {
                "id": "conformer_thermo_csv",
                "label": "Conformer thermo table (CSV)",
                "path": "energies/conformer_thermo.csv",
                "kind": "file",
            },
            {
                "id": "global_min",
                "label": "Global minimum structure",
                "path": f"structures/{mol_name}_global_min.xyz",
                "kind": "structure",
            },
        ],
    )
    return outputs


def build_result_ensemble(
    candidates: list[dict[str, Any]],
    structure: Structure,
) -> StructureEnsemble:
    records: list[StructureRecord] = []
    for c in candidates:
        conf_id = c.get("source") or f"{structure.id}_conf{c['index']:03d}"
        conf_struct = Structure(
            id=conf_id,
            charge=structure.charge,
            multiplicity=structure.multiplicity,
            symbols=c["symbols"],
            coordinates=c["coordinates"].tolist()
            if isinstance(c["coordinates"], np.ndarray)
            else c["coordinates"],
            metadata={
                "rank": c.get("rank"),
                "source": c.get("source"),
                # Screening join key consumed by the Confsearch protocols.
                "conf_id": conf_id,
            },
        )
        records.append(
            StructureRecord(
                structure=conf_struct,
                energy_hartree=c.get("energy"),
                free_energy_hartree=c.get("gibbs"),
                weight=c.get("weight"),
                properties={
                    "gibbs_correction": c.get("gibbs_correction"),
                    "g_conc": c.get("g_conc"),
                },
            )
        )
    return StructureEnsemble(records=records)


def censo_record_to_candidate(rec: Any, index: int = 0) -> dict[str, Any]:
    """Convert a CensoConformerRecord (cheap path) into a candidate dict.

    On the ``--no-opt`` path the CENSO gtot already is the final free energy
    (E_SP + δGsolv + G_mRRHO at xTB level).
    """
    return {
        "index": index,
        "coordinates": np.asarray(rec.coordinates),
        "symbols": list(rec.symbols),
        "energy": rec.energy,
        "gibbs": rec.gtot,
        "gibbs_correction": rec.grrho,
        "h_correction": None,
        "u_correction": None,
        "s_total": None,
        "g_conc": None,
        "source": rec.conf_id,
    }


# ---------------------------------------------------------------------------
# xTB passthrough (censo-zero) + solvent / ewin resolvers (ex-ensemble.py)
# ---------------------------------------------------------------------------


def xtb_passthrough_result(
    ensemble_xyz: Path,
    temperature: float,
) -> CensoRunResult:
    """Build a CensoRunResult directly from an xTB-ranked ensemble (censo-zero).

    The censo-zero preset does not invoke CENSO (§7): the ensemble is
    exported as-is, sorted by the xTB energies parsed from the frame title
    lines. ``gsolv``/``grrho`` are zero — the ``gtot`` equals the xTB
    electronic energy.
    """
    all_coords, symbols = read_xyz_multiframe(ensemble_xyz)
    n_atoms = len(symbols)
    if n_atoms == 0:
        raise ValueError(f"No atoms found in ensemble: {ensemble_xyz}")
    n_frames = len(all_coords) // n_atoms

    energies: list[float] = []
    with open(ensemble_xyz, encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    idx = 0
    while idx < len(lines) and len(energies) < n_frames:
        try:
            frame_atoms = int(lines[idx].strip())
        except ValueError:
            break
        title = lines[idx + 1].strip() if idx + 1 < len(lines) else ""
        match = _FLOAT_RE.search(title)
        energies.append(float(match.group()) if match else 0.0)
        idx += frame_atoms + 2

    if len(energies) < n_frames:
        logger.warning(
            "Parsed %d/%d title energies from %s — missing values set to 0.0",
            len(energies),
            n_frames,
            ensemble_xyz,
        )
        energies.extend([0.0] * (n_frames - len(energies)))

    records = []
    for i in range(n_frames):
        start = i * n_atoms
        records.append(
            CensoConformerRecord(
                conf_id=f"CONF{i + 1}",
                frame_index=i,
                energy=energies[i],
                gsolv=0.0,
                grrho=0.0,
                gtot=energies[i],
                coordinates=np.array(all_coords[start : start + n_atoms], dtype=float),
                symbols=list(symbols),
            )
        )

    result = CensoRunResult(
        preset="censo-zero",
        records=records,
        final_part="crest_passthrough",
        work_dir=ensemble_xyz.parent,
        temperature=temperature,
    )
    result.sort_by_gtot()
    return result


def resolve_solvent_config(
    cfg: dict[str, Any],
    user_solvent: str | None,
) -> tuple[str | None, str]:
    censo_solvent = (
        user_solvent if user_solvent is not None else cfg.get("censo", {}).get("solvent")
    )
    preopt_model = (
        cfg.get("theory", {}).get("preoptimization", {}).get("solvent_model") or ""
    ).lower()
    censo_model = (cfg.get("censo", {}).get("solvent_model") or "").lower()

    if preopt_model and preopt_model != "none":
        solvent_model = preopt_model
    elif censo_model and censo_model != "none":
        solvent_model = censo_model
    else:
        solvent_model = "none"

    return censo_solvent, solvent_model


def resolve_crest_ewin(
    cfg: dict[str, Any],
    ewin: float | None,
) -> float:
    """Resolve the CREST energy window: explicit arg > censo.ewin > 6.0."""
    if ewin is not None and ewin > 0:
        return float(ewin)
    raw = cfg.get("censo", {}).get("ewin", 6.0)
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return 6.0
    return value if value > 0 else 6.0


# ---------------------------------------------------------------------------
# Per-stage solvent-model resolution (todo 8 → moved here by todo 9/T08b)
# ---------------------------------------------------------------------------

#: Dedicated sampling-segment solvent-model key (section ``nmr``).
#: Intentionally ABSENT from ``cccp.config._get_default_config()`` and
#: ``config/defaults.yaml``: absence itself is the signal (see
#: :func:`resolve_sampling_solvent`).
SAMPLING_SOLVENT_CONFIG_KEY: Final = "sampling_solvent_model"
#: Sampling model applied when the key is absent but a solvent name is present.
SAMPLING_DEFAULT_SOLVENT_MODEL: Final = "alpb"


@dataclass(frozen=True)
class SamplingSolventReceipt:
    """Effective-parameters receipt for the sampling (CREST/xTB) segment.

    ``defaulted`` is ``True`` ONLY when the dedicated key was absent and a
    solvent name was present, so ACP chose ALPB rather than the user. An
    explicit ``none``/``alpb``/``gbsa`` is never ``defaulted`` — a recorded
    default must never masquerade as a user statement.
    """

    solvent: str | None
    solvent_model: str
    defaulted: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "solvent": self.solvent,
            "solvent_model": self.solvent_model,
            "defaulted": self.defaulted,
        }


def resolve_sampling_solvent(
    cfg: Mapping[str, Any],
    solvent: str | None,
) -> SamplingSolventReceipt:
    """Resolve the sampling (CREST/xTB) solvent model for one candidate run.

    Reads ONLY the dedicated :data:`SAMPLING_SOLVENT_CONFIG_KEY` key — the
    legacy ``theory.preoptimization.solvent_model`` / ``censo.solvent_model``
    keys keep their CENSO/DFT semantics and are deliberately not consulted
    here (todo 8). The model vocabulary is validated against the single source
    :data:`cccp.utils.solvent_map.LEGAL_SOLVENT_MODELS`, so a CREST/xTB
    sampling stage can only ever receive a legal model.

    Three-state semantics:

    * key ABSENT + solvent name present → ``alpb`` (``defaulted=True``);
    * key ABSENT + no solvent → ``none`` (gas phase, no flags emitted);
    * key explicitly ``none`` → gas phase (``defaulted=False``);
    * key explicitly ``alpb``/``gbsa`` → used as given.

    Moved from ``workflows/nmr.py`` (T08b) so the retired Confsearch engines
    (ensemble/energy/xtbmd_censo_energy) and the NMR workflow share ONE rule;
    ``nmr.py`` re-exports it under its historical private names.

    Raises:
        SolventValueError: the key carries a value outside
            :data:`LEGAL_SOLVENT_MODELS`.
    """
    nmr_section = cfg.get("nmr")
    raw = nmr_section.get(SAMPLING_SOLVENT_CONFIG_KEY) if isinstance(nmr_section, Mapping) else None
    name = solvent if solvent else None
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        # Absence (or an empty/whitespace value) is the signal — never read as
        # an explicit statement. A named solvent defaults to ALPB; otherwise
        # the sampling segment runs gas phase.
        if name is None:
            return SamplingSolventReceipt(solvent=None, solvent_model="none", defaulted=False)
        return SamplingSolventReceipt(
            solvent=name, solvent_model=SAMPLING_DEFAULT_SOLVENT_MODEL, defaulted=True
        )
    model = str(raw).strip().lower()
    if model not in LEGAL_SOLVENT_MODELS:
        raise SolventValueError(
            f"Unknown xTB solvent model {raw!r} for nmr.{SAMPLING_SOLVENT_CONFIG_KEY}; "
            f"legal solvent models: {', '.join(sorted(LEGAL_SOLVENT_MODELS))}"
        )
    return SamplingSolventReceipt(solvent=name, solvent_model=model, defaulted=False)


@dataclass(frozen=True)
class StageSolventModels:
    """Effective solvent models of one run, split by science stage.

    ``sampling`` is the CREST/xTB segment (legal models only: ``alpb`` /
    ``gbsa`` / ``none``); ``dft_model`` is the CENSO/ORCA DFT segment where
    the historical ``none → smd`` fallback is legal. The solvent *name*
    (``solvent``) is shared — only the model is stage-split.
    """

    solvent: str | None
    dft_model: str
    sampling: SamplingSolventReceipt


def resolve_stage_solvent_models(
    cfg: Mapping[str, Any],
    solvent: str | None,
    *,
    dft_model_override: str | None = None,
) -> StageSolventModels:
    """Split one run's solvent into sampling (CREST/xTB) and DFT models.

    The DFT side keeps the legacy contract (``resolve_solvent_config``
    precedence, then *dft_model_override* from UI wizard levels, then the
    historical ``none → smd`` fallback when a solvent name is present — SMD
    is legal for CENSO/ORCA). The sampling side resolves through the
    dedicated-key rule of :func:`resolve_sampling_solvent`, so a CREST/xTB
    stage NEVER receives SMD/CPCM: absence defaults to ALPB (receipt
    ``defaulted=True``) and an unknown dedicated-key value raises
    ``SolventValueError`` (strict failure).
    """
    name, legacy_model = resolve_solvent_config(dict(cfg), solvent)
    if name and dft_model_override:
        legacy_model = dft_model_override
    dft_model = legacy_model or "none"
    if name and dft_model == "none":
        logger.info(
            "Solvent %r has no configured DFT model — defaulting to SMD for the "
            "CENSO/DFT stage (the CREST/xTB sampling stage resolves separately).",
            name,
        )
        dft_model = "smd"
    return StageSolventModels(
        solvent=name,
        dft_model=dft_model,
        sampling=resolve_sampling_solvent(cfg, solvent),
    )


__all__ = [
    "SAMPLING_SOLVENT_CONFIG_KEY",
    "SAMPLING_DEFAULT_SOLVENT_MODEL",
    "SamplingSolventReceipt",
    "StageSolventModels",
    "boltzmann_weights",
    "build_ensemble_summary",
    "build_result_ensemble",
    "censo_record_to_candidate",
    "conformer_tag",
    "resolve_crest_ewin",
    "resolve_levels",
    "resolve_sampling_solvent",
    "resolve_solvent_config",
    "resolve_stage_solvent_models",
    "run_rank1_handoff",
    "select_cumulative_boltzmann",
    "write_final_outputs",
    "xtb_passthrough_result",
]
