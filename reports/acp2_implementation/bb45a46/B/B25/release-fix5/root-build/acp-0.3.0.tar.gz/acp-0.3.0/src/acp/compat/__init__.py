"""Compatibility readers for historical ACP artifacts."""

from __future__ import annotations

from .legacy.layouts import (
    LEGACY_FALLBACK_ENABLED,
    MechanismStudyLayout,
    find_reaction_json,
    find_study_layout,
)
from .legacy.manifests import (
    read_batch_calculation_manifest,
    read_reaction_definition,
    read_refinement_manifest,
    read_result_summary,
    read_s2_candidate_manifest,
    read_s2_path_manifest,
    read_s2_review,
    read_s3_lowconfirm_manifest,
    read_s4_highconfirm_manifest,
)

__all__ = [
    "read_s2_path_manifest",
    "read_s3_lowconfirm_manifest",
    "read_s4_highconfirm_manifest",
    "read_refinement_manifest",
    "read_batch_calculation_manifest",
    "read_result_summary",
    "read_reaction_definition",
    "read_s2_review",
    "read_s2_candidate_manifest",
    "LEGACY_FALLBACK_ENABLED",
    "MechanismStudyLayout",
    "find_reaction_json",
    "find_study_layout",
]
