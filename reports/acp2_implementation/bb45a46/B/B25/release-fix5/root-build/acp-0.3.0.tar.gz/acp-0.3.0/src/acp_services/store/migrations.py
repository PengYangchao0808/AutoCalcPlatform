# pyright: reportAny=false, reportUnusedCallResult=false
"""SQLite schema migrations for the ACP scheduler."""

from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

from acp_services.runtime.helpers import utc_now_iso as _utc_now_iso

_SCHEMA_MIGRATIONS_SQL = """
CREATE TABLE IF NOT EXISTS _schema_migrations (
    id TEXT PRIMARY KEY,
    applied_at TEXT NOT NULL
)
"""


_MIGRATIONS: list[dict[str, str]] = [
    {
        "id": "001",
        "description": "create projects table",
        "sql": """
CREATE TABLE IF NOT EXISTS projects (
    project_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    tags TEXT NOT NULL DEFAULT '[]',
    run_root TEXT NOT NULL,
    settings TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
""",
    },
    {
        "id": "002",
        "description": "add project_id and input_hash to jobs",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility",
    },
    {
        "id": "003",
        "description": "create stage_tasks table",
        "sql": """
CREATE TABLE IF NOT EXISTS stage_tasks (
    task_id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    stage_name TEXT NOT NULL,
    task_type TEXT,
    state TEXT NOT NULL DEFAULT 'pending',
    exit_status INTEGER,
    retry_count INTEGER DEFAULT 0,
    pid INTEGER,
    stderr_summary TEXT,
    started_at TEXT,
    completed_at TEXT,
    updated_at TEXT NOT NULL,
    result_json TEXT,
    provenance_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_stage_tasks_job_id ON stage_tasks(job_id);
""",
    },
    {
        "id": "004",
        "description": "create artifacts table",
        "sql": """
CREATE TABLE IF NOT EXISTS artifacts (
    artifact_id TEXT PRIMARY KEY,
    task_id TEXT,
    job_id TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    file_path TEXT NOT NULL,
    checksum TEXT,
    size_bytes INTEGER,
    parser_status TEXT NOT NULL DEFAULT 'pending',
    mime_type TEXT,
    metadata_json TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_artifacts_job_id ON artifacts(job_id);
CREATE INDEX IF NOT EXISTS idx_artifacts_task_id ON artifacts(task_id);
""",
    },
    {
        "id": "005",
        "description": "add remote_job_id to jobs",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility",
    },
    {
        "id": "006",
        "description": "create mechanism study review tables",
        "sql": """
CREATE TABLE IF NOT EXISTS mechanism_studies (
    id TEXT PRIMARY KEY,
    job_id TEXT,
    study_json TEXT,
    status TEXT,
    created_at TEXT,
    updated_at TEXT
);
CREATE TABLE IF NOT EXISTS decision_points (
    id TEXT PRIMARY KEY,
    study_id TEXT,
    status TEXT,
    payload TEXT,
    resolution TEXT,
    created_at TEXT,
    resolved_at TEXT
 );
 """,
    },
    {
        "id": "007",
        "description": "add reaction/plan columns to mechanism_studies",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility",
    },
    {
        "id": "008",
        "description": "add group_id to jobs (queue grouping / rerun lineage)",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility",
    },
    {
        "id": "009",
        "description": "add status_detail to stage_tasks (phase sub-step progress)",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility",
    },
    {
        "id": "011",
        "description": "unique index on lower(name) for projects (v2 project dir naming)",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility",
    },
    {
        "id": "010",
        "description": "create tasks table (v2 task index §9.1/§9.3)",
        "sql": """
CREATE TABLE IF NOT EXISTS tasks (
    task_id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    project_id TEXT,
    molecule_name TEXT NOT NULL DEFAULT '',
    task_name TEXT NOT NULL DEFAULT '',
    remark TEXT NOT NULL DEFAULT '',
    display_name TEXT NOT NULL DEFAULT '',
    workflow TEXT NOT NULL DEFAULT '',
    task_dir_name TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    node_id TEXT,
    node_path TEXT,
    input_hash TEXT,
    result_manifest_path TEXT,
    current_stage TEXT,
    storage_mode TEXT NOT NULL DEFAULT 'local',
    layout_version INTEGER NOT NULL DEFAULT 2,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_job_id ON tasks(job_id);
CREATE INDEX IF NOT EXISTS idx_tasks_project_id ON tasks(project_id);
""",
    },
    {
        "id": "012",
        "description": "create mechanism_projects table (design §9)",
        "sql": """
CREATE TABLE IF NOT EXISTS mechanism_projects (
    project_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    reaction_definition_hash TEXT NOT NULL DEFAULT '',
    charge INTEGER NOT NULL DEFAULT 0,
    multiplicity INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'created',
    s1_job_id TEXT,
    s2_job_id TEXT,
    s3_job_id TEXT,
    s4_job_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
""",
    },
    {
        "id": "013",
        "description": "add node_id and host to jobs (persisted execution target)",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility",
    },
    {
        "id": "014",
        "description": "add org columns to tasks (molecule_key, tags, archived, batch_id, etc.)",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility + backfill",
    },
    {
        "id": "015",
        "description": "create molecule_groups and molecule_aliases tables (P2 aliases/merge)",
        "sql": """
CREATE TABLE IF NOT EXISTS molecule_groups (
    project_id TEXT NOT NULL,
    group_key TEXT NOT NULL,
    display_name TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (project_id, group_key)
);
CREATE TABLE IF NOT EXISTS molecule_aliases (
    project_id TEXT NOT NULL,
    alias_key TEXT NOT NULL,
    group_key TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (project_id, alias_key)
);
""",
    },
    {
        "id": "016",
        "description": "refresh molecule_key to case-preserving (alias rows keep target)",
        "sql": "-- handled in Python: recomputes molecule_key case-preserving",
    },
    {
        "id": "017",
        "description": "add custom_name columns to tasks + create organization_events table",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility",
    },
    {
        "id": "018",
        "description": (
            "create job_edit_operations table (edit-and-recalculate idempotency, "
            "docs/archive/2026-10-16/history/ACP_Edit_And_Recalculate_Plan.md §9/§10)"
        ),
        "sql": """
CREATE TABLE IF NOT EXISTS job_edit_operations (
    request_id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    operation TEXT NOT NULL,
    mode TEXT NOT NULL,
    status TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    result_json TEXT,
    error TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_job_edit_ops_job ON job_edit_operations(job_id, created_at);
""",
    },
    {
        "id": "019",
        "description": "indexes for bounded task-view pages",
        "sql": """
CREATE INDEX IF NOT EXISTS idx_tasks_archived_created
    ON tasks(archived, created_at DESC, task_id ASC);
CREATE INDEX IF NOT EXISTS idx_tasks_project_archived_created
    ON tasks(project_id, archived, created_at DESC, task_id ASC);
""",
    },
    {
        "id": "020",
        "description": "add revision/attempt columns to jobs (CAS transitions, 1-based attempt)",
        "sql": "-- handled in Python for SQLite ALTER TABLE compatibility + backfill",
    },
    {
        "id": "021",
        "description": "create job_outbox table (transactional outbox, B04-2)",
        "sql": """
CREATE TABLE IF NOT EXISTS job_outbox (
    event_id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    owner_type TEXT NOT NULL DEFAULT 'job',
    scope TEXT NOT NULL DEFAULT 'task',
    event_type TEXT NOT NULL,
    payload_json TEXT NOT NULL DEFAULT '{}',
    dedup_key TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 0,
    attempt INTEGER,
    emitted_at TEXT NOT NULL,
    delivered_at TEXT,
    delivered_seq INTEGER,
    delivery_attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT
);
CREATE INDEX IF NOT EXISTS idx_job_outbox_pending ON job_outbox(delivered_at);
CREATE INDEX IF NOT EXISTS idx_job_outbox_job ON job_outbox(job_id, delivered_at);
""",
    },
    {
        "id": "022",
        "description": (
            "persistent idempotency ledger (B08): one row per verified "
            "scope/action/key with a canonical request digest, owner lease and "
            "the committed TaskRef"
        ),
        "sql": """
CREATE TABLE IF NOT EXISTS idempotency_records (
    claim_id         TEXT PRIMARY KEY,
    scope_id         TEXT NOT NULL,
    action           TEXT NOT NULL,
    idempotency_key  TEXT NOT NULL,
    request_digest   TEXT NOT NULL,
    state            TEXT NOT NULL,
    owner_token      TEXT,
    lease_epoch      INTEGER NOT NULL DEFAULT 0,
    lease_expires_at TEXT,
    task_id          TEXT,
    operation_id     TEXT,
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL,
    UNIQUE (scope_id, action, idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_idempotency_task
    ON idempotency_records(task_id);
CREATE INDEX IF NOT EXISTS idx_idempotency_state_lease
    ON idempotency_records(state, lease_expires_at);
CREATE INDEX IF NOT EXISTS idx_idempotency_action_key
    ON idempotency_records(action, idempotency_key);
""",
    },
    {
        "id": "023",
        "description": (
            "persistent Proposal/ResearchRecord approvals bound to a frozen "
            "scientific plan digest (B16): state, optimistic revision, expiry, "
            "requester/approver principals and the approval binding"
        ),
        "sql": """
CREATE TABLE IF NOT EXISTS approval_records (
    approval_id            TEXT PRIMARY KEY,
    proposal_ref           TEXT NOT NULL,
    proposal_digest        TEXT NOT NULL,
    plan_digest            TEXT NOT NULL,
    plan_definition_json   TEXT NOT NULL DEFAULT '{}',
    project_id             TEXT NOT NULL,
    requester_principal    TEXT NOT NULL,
    approver_principal     TEXT,
    budget_json            TEXT,
    budget_digest          TEXT NOT NULL DEFAULT '',
    allowed_change_range_json TEXT NOT NULL DEFAULT '{}',
    state                  TEXT NOT NULL,
    expires_at             TEXT,
    revision               INTEGER NOT NULL DEFAULT 1,
    created_at             TEXT NOT NULL,
    updated_at             TEXT NOT NULL,
    decided_at             TEXT,
    reason                 TEXT,
    task_ref_json          TEXT,
    idempotency_key        TEXT,
    last_event_revision    INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_approval_pending_pair
    ON approval_records(requester_principal, proposal_ref, plan_digest)
    WHERE state = 'pending';
CREATE UNIQUE INDEX IF NOT EXISTS idx_approval_idempotency
    ON approval_records(requester_principal, idempotency_key)
    WHERE idempotency_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_approval_project_state
    ON approval_records(project_id, state, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_approval_proposal
    ON approval_records(proposal_ref, plan_digest);
""",
    },
]


def _connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
        (table,),
    ).fetchone()
    return row is not None


def _column_exists(conn: sqlite3.Connection, table: str, column: str) -> bool:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return any(row["name"] == column for row in rows)


def _ensure_meta_table(conn: sqlite3.Connection) -> None:
    conn.executescript(_SCHEMA_MIGRATIONS_SQL)


def get_schema_version(conn: sqlite3.Connection) -> int:
    _ensure_meta_table(conn)
    row = conn.execute("SELECT COUNT(*) AS n FROM _schema_migrations").fetchone()
    return int(row["n"]) if row is not None else 0


def _apply_jobs_column_migration(conn: sqlite3.Connection) -> bool:
    if not _table_exists(conn, "jobs"):
        return False
    if not _column_exists(conn, "jobs", "project_id"):
        conn.execute("ALTER TABLE jobs ADD COLUMN project_id TEXT")
    if not _column_exists(conn, "jobs", "input_hash"):
        conn.execute("ALTER TABLE jobs ADD COLUMN input_hash TEXT")
    return True


def _apply_remote_job_id_column(conn: sqlite3.Connection) -> bool:
    if not _table_exists(conn, "jobs"):
        return False
    if not _column_exists(conn, "jobs", "remote_job_id"):
        conn.execute("ALTER TABLE jobs ADD COLUMN remote_job_id TEXT")
    return True


def _apply_mechanism_studies_columns(conn: sqlite3.Connection) -> bool:
    if not _table_exists(conn, "mechanism_studies"):
        return False
    if not _column_exists(conn, "mechanism_studies", "reaction_json"):
        conn.execute("ALTER TABLE mechanism_studies ADD COLUMN reaction_json TEXT")
    if not _column_exists(conn, "mechanism_studies", "mechanism_plan_json"):
        conn.execute("ALTER TABLE mechanism_studies ADD COLUMN mechanism_plan_json TEXT")
    if not _column_exists(conn, "mechanism_studies", "config_hash"):
        conn.execute("ALTER TABLE mechanism_studies ADD COLUMN config_hash TEXT")
    if not _column_exists(conn, "mechanism_studies", "cycle_index"):
        conn.execute("ALTER TABLE mechanism_studies ADD COLUMN cycle_index INTEGER DEFAULT 0")
    if not _column_exists(conn, "mechanism_studies", "consumed_cycle"):
        conn.execute("ALTER TABLE mechanism_studies ADD COLUMN consumed_cycle INTEGER")
    return True


def _apply_jobs_group_id_column(conn: sqlite3.Connection) -> bool:
    """Add ``group_id`` to jobs (self-rooted by default) plus an index.

    ``group_id`` is the queue-grouping / rerun-lineage key. Every job is
    its own group root unless it was cloned by ``rerun_job`` (which
    inherits the original's group id), so historical rows backfill to
    ``group_id = id``.
    """
    if not _table_exists(conn, "jobs"):
        return False
    if not _column_exists(conn, "jobs", "group_id"):
        conn.execute("ALTER TABLE jobs ADD COLUMN group_id TEXT")
    conn.execute("UPDATE jobs SET group_id = id WHERE group_id IS NULL")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_group_id ON jobs(group_id)")
    return True


def _apply_stage_tasks_status_detail_column(conn: sqlite3.Connection) -> bool:
    """Add ``status_detail`` to stage_tasks (human phase sub-step, e.g. ``scan 7/24``)."""
    if not _table_exists(conn, "stage_tasks"):
        return False
    if not _column_exists(conn, "stage_tasks", "status_detail"):
        conn.execute("ALTER TABLE stage_tasks ADD COLUMN status_detail TEXT")
    return True


def _apply_jobs_node_columns(conn: sqlite3.Connection) -> bool:
    """Add ``node_id`` / ``host`` to jobs (persisted execution target).

    NULL for historical rows — read side falls back to ``result["node"]`` /
    ``spec.target_node``.  Deliberately no backfill (plan locked).
    """
    if not _table_exists(conn, "jobs"):
        return False
    if not _column_exists(conn, "jobs", "node_id"):
        conn.execute("ALTER TABLE jobs ADD COLUMN node_id TEXT")
    if not _column_exists(conn, "jobs", "host"):
        conn.execute("ALTER TABLE jobs ADD COLUMN host TEXT")
    return True


def _apply_projects_name_unique_index(conn: sqlite3.Connection) -> bool:
    """Index lower(name) on projects; tolerated when legacy duplicates exist."""
    if not _table_exists(conn, "projects"):
        return False
    try:
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_projects_name_ci ON projects(lower(name))"
        )
    except sqlite3.IntegrityError:
        logging.getLogger(__name__).warning(
            "projects table has duplicate names; skipping unique index (v2 dir naming "
            "still enforced at creation time by ProjectManager)"
        )
    return True


def _apply_tasks_org_columns(conn: sqlite3.Connection) -> bool:
    """Add organization columns to tasks + indexes + backfill from jobs."""
    if not _table_exists(conn, "tasks"):
        return False

    _org_columns = [
        ("molecule_key", "TEXT NOT NULL DEFAULT ''"),
        ("tags", "TEXT NOT NULL DEFAULT '[]'"),
        ("archived", "INTEGER NOT NULL DEFAULT 0"),
        ("batch_id", "TEXT"),
        ("last_activity_at", "TEXT"),
        ("started_at", "TEXT"),
        ("completed_at", "TEXT"),
        ("group_id", "TEXT"),
        ("progress", "REAL"),
    ]
    for col_name, col_def in _org_columns:
        if not _column_exists(conn, "tasks", col_name):
            conn.execute(f"ALTER TABLE tasks ADD COLUMN {col_name} {col_def}")

    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_tasks_project_archived ON tasks(project_id, archived)"
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_molecule_key ON tasks(molecule_key)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_batch_id ON tasks(batch_id)")

    _backfill_tasks_from_jobs(conn)
    return True


def _backfill_tasks_from_jobs(conn: sqlite3.Connection) -> None:
    """Populate task rows from jobs for any jobs not yet indexed.

    Idempotent: only INSERTs missing rows (task_id == jobs.id).
    """
    if not _table_exists(conn, "tasks") or not _table_exists(conn, "jobs"):
        return

    log = logging.getLogger(__name__)

    existing_task_ids = {row[0] for row in conn.execute("SELECT task_id FROM tasks").fetchall()}

    for job_row in conn.execute("SELECT * FROM jobs").fetchall():
        job_id = job_row["id"]
        if job_id in existing_task_ids:
            continue

        spec_raw: dict[str, Any] = {}
        spec_json_str = job_row["spec_json"]
        try:
            spec_raw = json.loads(spec_json_str)
        except (json.JSONDecodeError, TypeError):
            log.warning("Corrupt spec_json for job %s — backfilling with defaults", job_id)

        molecule_name = spec_raw.get("molecule_name", "") if isinstance(spec_raw, dict) else ""
        task_name = spec_raw.get("task_name", "") if isinstance(spec_raw, dict) else ""
        remark = spec_raw.get("remark", "") if isinstance(spec_raw, dict) else ""
        workflow = spec_raw.get("workflow", "") if isinstance(spec_raw, dict) else ""
        tags_list = spec_raw.get("tags", []) if isinstance(spec_raw, dict) else []
        if not isinstance(tags_list, list):
            tags_list = []
        tags_json = json.dumps(tags_list)

        resources = spec_raw.get("resources", {}) if isinstance(spec_raw, dict) else {}
        batch_id = resources.get("batch_id") if isinstance(resources, dict) else None

        group_id = job_row["group_id"] if "group_id" in job_row.keys() else job_id

        work_dir = job_row["work_dir"] or ""
        display_name = Path(work_dir).name if work_dir else ""
        task_dir_name = Path(work_dir).name if work_dir else ""

        from acp_services.store.naming import molecule_group_key

        molecule_key = molecule_group_key(molecule_name)

        remote_job_id = job_row["remote_job_id"] if "remote_job_id" in job_row.keys() else None
        storage_mode = "sftp" if remote_job_id else "local"
        node_path = work_dir
        node_id = "remote" if remote_job_id else "local"

        status = job_row["status"] if "status" in job_row.keys() else "pending"
        started_at = job_row["started_at"] if "started_at" in job_row.keys() else None
        completed_at = job_row["completed_at"] if "completed_at" in job_row.keys() else None
        progress = job_row["progress"] if "progress" in job_row.keys() else None
        created_at = job_row["created_at"] if "created_at" in job_row.keys() else ""
        updated_at = job_row["updated_at"] if "updated_at" in job_row.keys() else ""

        input_hash = job_row["input_hash"] if "input_hash" in job_row.keys() else None

        last_activity_at = completed_at or started_at or created_at

        conn.execute(
            """INSERT INTO tasks (
                task_id, job_id, project_id, molecule_name, task_name, remark,
                display_name, workflow, task_dir_name, status, node_id, node_path,
                input_hash, result_manifest_path, current_stage, storage_mode,
                layout_version, created_at, updated_at,
                molecule_key, tags, archived, batch_id,
                last_activity_at, started_at, completed_at, group_id, progress
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                NULL, NULL, ?, 2, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )""",
            (
                job_id,
                job_id,
                job_row["project_id"] if "project_id" in job_row.keys() else None,
                molecule_name,
                task_name,
                remark,
                display_name,
                workflow,
                task_dir_name,
                status,
                node_id,
                node_path,
                input_hash,
                storage_mode,
                created_at,
                updated_at,
                molecule_key,
                tags_json,
                0,
                batch_id,
                last_activity_at,
                started_at,
                completed_at,
                group_id,
                progress,
            ),
        )


def _apply_case_preserving_molecule_key_refresh(conn: sqlite3.Connection) -> bool:
    """Refresh molecule_key values to case-preserving form.

    Rows whose alias_key maps to a group_key via molecule_aliases keep
    their merge-target key (alias resolution is consulted first).  All
    other rows get the new case-preserving molecule_group_key(molecule_name).
    """
    if not _table_exists(conn, "tasks"):
        return False

    from acp_services.store.molecule_groups import resolve_molecule_key

    rows = conn.execute(
        "SELECT task_id, project_id, molecule_name, molecule_key FROM tasks"
    ).fetchall()

    now = _utc_now_iso()
    for row in rows:
        project_id = row["project_id"]
        if not project_id:
            continue
        new_key = resolve_molecule_key(conn, project_id, row["molecule_name"])
        if new_key != row["molecule_key"]:
            conn.execute(
                "UPDATE tasks SET molecule_key=?, updated_at=? WHERE task_id=?",
                (new_key, now, row["task_id"]),
            )
    return True


def _apply_tasks_custom_name_columns(conn: sqlite3.Connection) -> bool:
    """Add custom_name, name_revision, name_updated_at to tasks + create organization_events."""
    if not _table_exists(conn, "tasks"):
        return False

    _name_columns = [
        ("custom_name", "TEXT"),
        ("name_revision", "INTEGER NOT NULL DEFAULT 0"),
        ("name_updated_at", "TEXT"),
    ]
    for col_name, col_def in _name_columns:
        if not _column_exists(conn, "tasks", col_name):
            conn.execute(f"ALTER TABLE tasks ADD COLUMN {col_name} {col_def}")

    if not _table_exists(conn, "organization_events"):
        conn.executescript("""
CREATE TABLE IF NOT EXISTS organization_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    object_type TEXT NOT NULL,
    object_id TEXT NOT NULL,
    action TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_org_events_object ON organization_events(object_type, object_id);
""")
    else:
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_org_events_object "
            "ON organization_events(object_type, object_id)"
        )

    return True


def _apply_jobs_revision_attempt_columns(conn: sqlite3.Connection) -> bool:
    """Add ``revision`` / ``attempt`` to jobs (CAS token + 1-based attempt).

    ``attempt`` backfills from the legacy ``result_json['attempts']`` counter
    for rows still sitting on the column default (1).  JSON1 is probed first;
    when unavailable, a Python row scan takes over with default 1.
    """
    if not _table_exists(conn, "jobs"):
        return False
    if not _column_exists(conn, "jobs", "revision"):
        conn.execute("ALTER TABLE jobs ADD COLUMN revision INTEGER NOT NULL DEFAULT 0")
    if not _column_exists(conn, "jobs", "attempt"):
        conn.execute("ALTER TABLE jobs ADD COLUMN attempt INTEGER NOT NULL DEFAULT 1")

    if _json1_available(conn):
        conn.execute(
            "UPDATE jobs SET attempt = MAX("
            "CAST(COALESCE(json_extract(result_json, '$.attempts'), 1) AS INTEGER), 1) "
            "WHERE attempt = 1 AND json_valid(result_json)"
        )
    else:
        log = logging.getLogger(__name__)
        log.info("JSON1 unavailable; backfilling jobs.attempt via Python row scan")
        rows = conn.execute("SELECT id, result_json FROM jobs WHERE attempt = 1").fetchall()
        for row in rows:
            attempts = 1
            raw = row["result_json"]
            if raw:
                try:
                    payload = json.loads(raw)
                except (json.JSONDecodeError, TypeError):
                    payload = None
                if isinstance(payload, dict):
                    try:
                        attempts = int(payload.get("attempts") or 1)
                    except (TypeError, ValueError):
                        attempts = 1
            conn.execute(
                "UPDATE jobs SET attempt=? WHERE id=?",
                (max(attempts, 1), row["id"]),
            )
    return True


def _json1_available(conn: sqlite3.Connection) -> bool:
    try:
        conn.execute("SELECT json_valid('[]')").fetchone()
    except sqlite3.Error:
        return False
    return True


# ---------------------------------------------------------------------------
# Prepare operations schema (D05 / task 12)
# ---------------------------------------------------------------------------
#
# ``data_operations`` is **owned by the Data layer** and created by
# :class:`acp_services.data.operations.PrepareOperationService` — never by
# ``JobStore``.  This is the single migration implementation both a standalone
# prepare DB and a mixed ``acp_jobs.db`` go through; it is deliberately
# restricted so a standalone prepare DB never receives unrelated scheduler
# tables.  It records its own version (``_prepare_schema_migrations``) so the
# prepare schema version is distinct from the jobs schema version.
#
# Explicit order (do not reorder):
#   1. create/verify ``data_operations`` (``create_table=False`` verifies only
#      and never marks a missing table as migrated);
#   2. apply the additive prepare columns and indexes;
#   3. mark the prepare schema version last (a partially applied schema is
#      never recorded as migrated).

#: Bumped when the prepare schema changes; independent of the jobs migrations.
PREPARE_SCHEMA_VERSION = 1

_PREPARE_SCHEMA_MIGRATIONS_SQL = """
CREATE TABLE IF NOT EXISTS _prepare_schema_migrations (
    id INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
)
"""

_PREPARE_TABLE_DDL = """
CREATE TABLE IF NOT EXISTS data_operations (
    operation_id TEXT PRIMARY KEY,
    idempotency_key TEXT NOT NULL UNIQUE,
    job_id TEXT NOT NULL,
    job_attempt INTEGER NOT NULL,
    resource_id TEXT NOT NULL,
    resource_kind TEXT NOT NULL,
    resource_digest TEXT NOT NULL,
    resource_key TEXT NOT NULL,
    permission_scope TEXT NOT NULL,
    state TEXT NOT NULL,
    owner_generation INTEGER NOT NULL DEFAULT 0,
    lease_token TEXT,
    lease_expires_at REAL,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 3,
    authorization_version INTEGER NOT NULL DEFAULT 0,
    binding_id TEXT NOT NULL DEFAULT '',
    resource_generation INTEGER NOT NULL DEFAULT 0,
    availability TEXT NOT NULL DEFAULT 'absent',
    error_code TEXT,
    error_message TEXT,
    result_json TEXT,
    payload_json TEXT,
    size_bytes INTEGER,
    sha256 TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    available_at REAL NOT NULL DEFAULT 0.0,
    content_identity TEXT NOT NULL DEFAULT '',
    client_idempotency_key TEXT NOT NULL DEFAULT '',
    dedup_epoch INTEGER NOT NULL DEFAULT 0
)
"""

#: Additive columns applied to pre-D05 rows.  Old rows get ``''``/``''``/``0``
#: and stay conservative (revalidate/reprepare, never silently current-ready).
_PREPARE_COLUMNS: tuple[tuple[str, str], ...] = (
    ("content_identity", "TEXT NOT NULL DEFAULT ''"),
    ("client_idempotency_key", "TEXT NOT NULL DEFAULT ''"),
    ("dedup_epoch", "INTEGER NOT NULL DEFAULT 0"),
)

#: ``idx_data_operations_client_key`` is the DB-level guard that the
#: idempotency hash alone cannot provide: it rejects the same explicit client
#: key at the same epoch even when the request content (and therefore the hash)
#: differs.  Legacy rows carry ``''`` and are excluded by the predicate.
_PREPARE_INDEX_STATEMENTS: tuple[str, ...] = (
    "CREATE INDEX IF NOT EXISTS idx_data_operations_state ON data_operations(state, available_at)",
    "CREATE INDEX IF NOT EXISTS idx_data_operations_key ON data_operations(idempotency_key)",
    "CREATE INDEX IF NOT EXISTS idx_data_operations_resource "
    "ON data_operations(permission_scope, resource_key, dedup_epoch)",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_data_operations_client_key "
    "ON data_operations(permission_scope, client_idempotency_key, dedup_epoch) "
    "WHERE client_idempotency_key <> ''",
)


def _ensure_prepare_meta_table(conn: sqlite3.Connection) -> None:
    conn.executescript(_PREPARE_SCHEMA_MIGRATIONS_SQL)


def _apply_prepare_columns(conn: sqlite3.Connection) -> None:
    for column, declaration in _PREPARE_COLUMNS:
        if not _column_exists(conn, "data_operations", column):
            try:
                conn.execute(f"ALTER TABLE data_operations ADD COLUMN {column} {declaration}")
            except sqlite3.OperationalError as exc:  # pragma: no cover - race guard
                if "duplicate column name" not in str(exc).lower():
                    raise


def _apply_prepare_indexes(conn: sqlite3.Connection) -> None:
    for statement in _PREPARE_INDEX_STATEMENTS:
        conn.execute(statement)


def migrate_prepare_schema(
    db_path: Path | str,
    *,
    create_table: bool = True,
) -> bool:
    """Create/verify and migrate the Data-owned prepare-operation schema.

    This is the **only** implementation of the prepare schema migration.  It is
    safe to call from every ``PrepareOperationService`` initialisation (new DB,
    old prepare-only DB, mixed jobs DB) and from concurrent initialisers: the
    whole body runs under ``BEGIN IMMEDIATE`` with a busy timeout, and every
    statement is idempotent.

    Args:
        db_path: SQLite database path (created when missing).
        create_table: When ``True`` (the service path) create ``data_operations``
            if missing.  When ``False`` this is a restricted verify-only entry:
            a missing table returns ``False`` and is **never** marked migrated.

    Returns:
        ``True`` when ``data_operations`` exists and the schema version is
        recorded; ``False`` only in verify-only mode when the table is missing.
    """
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = _connect(path)
    try:
        conn.execute("PRAGMA busy_timeout=15000")
        _ensure_prepare_meta_table(conn)
        conn.commit()
        conn.execute("BEGIN IMMEDIATE")
        try:
            if not _table_exists(conn, "data_operations"):
                if not create_table:
                    conn.rollback()
                    return False
                conn.execute(_PREPARE_TABLE_DDL)
            if not _table_exists(conn, "data_operations"):  # pragma: no cover - DDL failed
                conn.rollback()
                return False
            _apply_prepare_columns(conn)
            _apply_prepare_indexes(conn)
            conn.execute(
                "INSERT OR IGNORE INTO _prepare_schema_migrations (id, applied_at) VALUES (?, ?)",
                (PREPARE_SCHEMA_VERSION, _utc_now_iso()),
            )
            conn.commit()
            return True
        except BaseException:
            conn.rollback()
            raise
    finally:
        conn.close()


def get_prepare_schema_version(conn: sqlite3.Connection) -> int:
    """Return the highest applied prepare schema version (``0`` when absent)."""
    if not _table_exists(conn, "_prepare_schema_migrations"):
        return 0
    row = conn.execute("SELECT MAX(id) AS v FROM _prepare_schema_migrations").fetchone()
    return int(row["v"]) if row is not None and row["v"] is not None else 0


def _apply_migration(conn: sqlite3.Connection, migration: dict[str, str]) -> bool:
    migration_id = migration["id"]
    if migration_id == "002":
        return _apply_jobs_column_migration(conn)
    if migration_id == "005":
        return _apply_remote_job_id_column(conn)
    if migration_id == "007":
        return _apply_mechanism_studies_columns(conn)
    if migration_id == "008":
        return _apply_jobs_group_id_column(conn)
    if migration_id == "009":
        return _apply_stage_tasks_status_detail_column(conn)
    if migration_id == "011":
        return _apply_projects_name_unique_index(conn)
    if migration_id == "013":
        return _apply_jobs_node_columns(conn)
    if migration_id == "014":
        return _apply_tasks_org_columns(conn)
    if migration_id == "016":
        return _apply_case_preserving_molecule_key_refresh(conn)
    if migration_id == "017":
        return _apply_tasks_custom_name_columns(conn)
    if migration_id == "020":
        return _apply_jobs_revision_attempt_columns(conn)
    sql = migration["sql"].strip()
    if sql:
        conn.executescript(sql)
    return True


def migrate(db_path: Path | str) -> int:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    applied = 0
    with _connect(path) as conn:
        _ensure_meta_table(conn)
        existing = {
            row["id"] for row in conn.execute("SELECT id FROM _schema_migrations").fetchall()
        }
        for migration in _MIGRATIONS:
            if migration["id"] in existing:
                continue
            if not _apply_migration(conn, migration):
                continue
            conn.execute(
                "INSERT INTO _schema_migrations (id, applied_at) VALUES (?, ?)",
                (migration["id"], _utc_now_iso()),
            )
            applied += 1
        conn.commit()
    return applied


__all__ = [
    "PREPARE_SCHEMA_VERSION",
    "get_prepare_schema_version",
    "get_schema_version",
    "migrate",
    "migrate_prepare_schema",
]
