"""
Scheduler Runner
================

Maps a :class:`JobSpec` to a concrete execution. Real workflows run as
``python -m acp.cli run <workflow>`` subprocesses for
crash isolation and clean PID-based cancellation. The ``fake`` workflow runs
in-process so the workbench is demoable without QC binaries.

Stage progress is observed by polling the workflow's ``state.json`` and emitting
``stage.*`` events; stdout/stderr are captured to log files.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import signal
import subprocess
import sys
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from acp.scheduler.remote.runner import RemotePollObservation

from acp.chem.embedding import smiles_to_xyz, xyz_to_multiframe_demo
from acp.scheduler.artifacts import ArtifactRegistry, capture_stage_artifacts
from acp.scheduler.events import JobEventLog
from acp.scheduler.files import is_archived_attempt_path
from acp.scheduler.jobs import (
    GRADIENT_CONFIG_FILENAME,
    PATH_CONFIG_FILENAME,
    SCAN_CONFIG_FILENAME,
    JobRecord,
    JobSpec,
    JobStatus,
    batchoptimize_method_flags,
    build_task_record,
    censo_ewin_from_method,
    censo_preset_from_method,
    censo_solvent_from_method,
    confsearch_method_flags,
    electronic_state_from_method,
    input_chemistry_flags,
    nmr_candidate_metadata_flags,
    nmr_flag_config,
    nmr_method_flags,
    scan_method_flags,
    xtbmd_method_flags,
)
from acp.scheduler.processctl import find_task_processes, pid_is_alive, process_references
from acp.scheduler.provenance import Provenance, build_provenance_for_job
from acp.scheduler.stage_tasks import StageTaskObserver, StageTaskStore
from acp.storage.layout import TaskStorage, runtime_file
from acp_services.runtime.execution_chain import (
    DEFAULT_ENVELOPE_WORKFLOWS,
    EXECUTION_ENTRY_ENVELOPE,
    AttemptExecutionChoice,
    FrozenGroupError,
    frozen_artifacts_present,
    local_launch,
    read_attempt_choice,
    resolve_attempt_choice,
    with_attempt_choice,
    worker_argv,
    write_attempt_choice,
)
from acp_services.runtime.helpers import utc_now_iso as _utc_now_iso

logger = logging.getLogger(__name__)

_POLL_INTERVAL = 1.0


def _electronic_state_cli_flags(module: Mapping[str, object], work_dir: Path) -> list[str]:
    """Materialize an expanded electronic-state module as a ``--spin-config`` file.

    The submitted config is persisted verbatim next to the job files so the
    subprocess never depends on in-memory scheduler state (§14.1).
    """
    import json as _json

    work_dir.mkdir(parents=True, exist_ok=True)
    sidecar = work_dir / "electronic_state.json"
    sidecar.write_text(
        _json.dumps({"electronic_state": dict(module)}, indent=2, sort_keys=True, default=str),
        encoding="utf-8",
    )
    return ["--spin-config", sidecar.as_posix()]


_GFN_DISPLAY_TO_INT: dict[str, int] = {
    "GFN0-xTB": 0,
    "GFN1-xTB": 1,
    "GFN2-xTB": 2,
    "0": 0,
    "1": 1,
    "2": 2,
}


class JobRunnerRemoteProtocol(Protocol):
    """Structural type shared by :class:`~acp.scheduler.remote.runner.RemoteJobRunner`.

    Avoids importing ``acp.scheduler.remote`` (which requires paramiko) at
    module load time when remote execution is not configured.
    """

    def run(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        cancel_event: threading.Event,
    ) -> int: ...

    def submit_remote(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        target_node: str | None = None,
        *,
        remote_job_dir: str | None = None,
        on_submitted: Callable[[str], None] | None = None,
        submission_id: str | None = None,
        on_code_release_bound: Callable[[str], None] | None = None,
    ) -> str: ...

    def poll_remote(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        cancel_event: threading.Event,
    ) -> RemotePollObservation: ...

    def reconcile_submission(self, record: JobRecord) -> str: ...

    def apply_terminal_side_effects(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        stage_events: tuple[tuple[str, dict[str, Any]], ...] = (),
    ) -> None: ...

    def cancel_remote(self, job_id: str) -> None: ...

    def recover_job_state(self, record: JobRecord) -> bool: ...


class LocalCleanupProtocol(Protocol):
    """Structural type for :class:`~acp.scheduler.local_cleanup.LocalCleanup`.

    Avoids importing the concrete class at module load time.  Only
    :meth:`pre_submit_housekeeping` is invoked from the runner.
    """

    def pre_submit_housekeeping(self) -> Any: ...


def _safe_timestamp(value: object) -> float:
    """Convert a state.json timestamp to a sortable float.  Unknown / missing
    timestamps map to 0.0 so they sort earliest (best-effort fallback)."""
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value).timestamp()
        except (ValueError, TypeError):
            return 0.0
    return 0.0


def find_workflow_state(work_dir: Path) -> Path | None:
    """Locate the workflow's ``state.json``, preferring the shallowest match.

    Real workflows nest state.json one level under the output dir
    (``<output>/<mol_id>/state.json``); NMR additionally writes an inner
    conformer state at ``<output>/conformer/<id>/state.json``. Shallowest-first
    selection picks the correct (outer) state in both cases. The ``fake``
    workflow writes directly at the root.

    Archived attempt receipts under ``WORK/00_RUNTIME/attempts/`` (contract B)
    are never candidates — they belong to a closed attempt and must not be
    replayed into the current attempt's observation.
    """
    root_state = work_dir / "state.json"
    if root_state.exists():
        return root_state
    candidates = [c for c in work_dir.rglob("state.json") if not is_archived_attempt_path(c)]
    if not candidates:
        return None

    def _key(path: Path) -> tuple[int, float]:
        try:
            depth = len(path.relative_to(work_dir).parts)
            mtime = path.stat().st_mtime
        except OSError:
            return (99, 0.0)
        return (depth, -mtime)

    return min(candidates, key=_key)


def _opt_text(value: object) -> str | None:
    if isinstance(value, str):
        text = value.strip()
        if text:
            return text
    return None


def _read_json_object(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        logger.debug("Failed to read JSON object from %s", path, exc_info=True)
        return None
    if not isinstance(payload, dict):
        logger.debug("Ignoring non-object JSON payload at %s", path)
        return None
    return payload


def _materialized_input_name(source: str, stem: str = "input") -> str:
    """Name for a materialized input file."""
    suffix = Path(source).suffix.lower()
    if suffix in (".com", ".inp"):
        return f"{stem}{suffix}"
    return f"{stem}.xyz"


def _extract_input_source(inp: dict[str, Any]) -> str:
    source = (
        inp.get("input_artifact")
        or inp.get("source")
        or inp.get("input")
        or inp.get("smiles")
        or ""
    )
    return str(source)


def _write_log_header(
    record: JobRecord,
    work_dir: Path,
    cmd: list[str],
    out: Any,
    err: Any,
) -> None:
    """Write the v2 provenance header to ``stdout.log`` and ``stderr.log``.

    The timestamped job id no longer appears in any path (v2 task dirs are
    named ``<molecule>_<task>_<remark>``); instead it is embedded into the
    log content itself, ahead of any subprocess output.
    """
    header_lines = [
        f"# job_id: {record.id}",
        f"# workflow: {record.spec.workflow}",
        f"# task_dir_name: {work_dir.name}",
        f"# work_dir: {work_dir}",
        f"# launched_at: {datetime.now(timezone.utc).isoformat()}",
        f"# command: {' '.join(cmd)}",
        "",
    ]
    header = "\n".join(header_lines)
    out.write(header)
    out.flush()
    err.write(header)
    err.flush()


def _copy_structure_asset(source: str, inputs_dir: Path, run_root: Path, stem: str) -> Path:
    candidate = (run_root / source).resolve()
    try:
        candidate.relative_to(run_root.resolve())
    except ValueError as exc:
        raise ValueError(f"Asset path escapes run_root: {source}") from exc
    if not candidate.is_file():
        raise ValueError(f"Asset file not found: {source}")
    dest = inputs_dir / _materialized_input_name(str(candidate), stem)
    shutil.copy2(candidate, dest)
    return dest


def _materialize_single_input(
    inp: dict[str, Any],
    inputs_dir: Path,
    run_root: Path,
    *,
    stem: str = "input",
) -> Path | None:
    source_type = str(inp.get("source_type", ""))
    source = _extract_input_source(inp)

    if not source:
        return None

    inputs_dir.mkdir(parents=True, exist_ok=True)
    dest = inputs_dir / f"{stem}.xyz"

    if source_type == "xyz_text":
        dest.write_text(source, encoding="utf-8")
        return dest

    if source_type == "structure_asset":
        return _copy_structure_asset(source, inputs_dir, run_root, stem)

    if (
        source.endswith(".xyz")
        or source.endswith(".gjf")
        or source.endswith(".sdf")
        or source.endswith(".com")
        or source.endswith(".inp")
    ):
        candidate = Path(source)
        if candidate.is_file():
            dest = inputs_dir / _materialized_input_name(str(candidate), stem)
            shutil.copy2(candidate, dest)
            return dest

    if source_type == "smiles" or _looks_like_smiles(source):
        xyz = smiles_to_xyz(source)
        dest.write_text(xyz, encoding="utf-8")
        return dest

    try:
        xyz = smiles_to_xyz(source)
        dest.write_text(xyz, encoding="utf-8")
        return dest
    except (ImportError, RuntimeError, ValueError):
        return None


def _materialize_batch_structures(inp: dict[str, Any], inputs_dir: Path) -> Path | None:
    """Expand a Workbench ``batch_structures`` payload into an items file.

    The v2 frontend bundles per-structure entries into
    ``{source_type: "batch_structures", items: [...]}``; the BatchOptimize
    CLI only reads files, so the payload is serialised to
    ``inputs/batch_items.json`` (schema ``batch_structures_v1``) before the
    subprocess starts.  ``source_id`` references must already have been
    inlined by the API layer (they need store/remote-fetcher access).
    """
    items = inp.get("items")
    if not isinstance(items, list):
        return None
    entries: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        xyz = str(item.get("xyz") or "")
        if not xyz.strip():
            continue
        entry: dict[str, Any] = {"xyz": xyz}
        for key in ("name", "tag", "role", "candidate_id", "charge", "multiplicity", "include"):
            if item.get(key) is not None:
                entry[key] = item[key]
        entries.append(entry)
    if not entries:
        return None
    payload = {"schema_version": "batch_structures_v1", "items": entries}
    inputs_dir.mkdir(parents=True, exist_ok=True)
    dest = inputs_dir / "batch_items.json"
    dest.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return dest


def _batch_structures_xyz_snapshot(inp: dict[str, Any]) -> str | None:
    """Return the included XYZ geometries for the task-level input snapshot."""
    items = inp.get("items")
    if not isinstance(items, list):
        return None
    geometries = [
        item["xyz"].strip()
        for item in items
        if isinstance(item, dict)
        and item.get("include") is not False
        and isinstance(item.get("xyz"), str)
        and item["xyz"].strip()
    ]
    return "\n".join(geometries) + "\n" if geometries else None


def _materialize_tsmode_bundle(inp: dict[str, Any], inputs_dir: Path) -> Path | None:
    """Stage TS Mode source assets and write ``INPUT/tsmode/bundle.json``.

    ``spec.input`` carries the API-resolved source (``frequency_out`` /
    ``hess`` / optional ``geometry`` absolute paths, ``source_mode_index``,
    charge/multiplicity/level snapshot).  The assets are copied into the
    task's own ``INPUT/tsmode/`` so the job owns its snapshot (plan §11 —
    remote nodes never touch the web API), and SHA-256 checksums are
    verified when supplied.
    """
    if str(inp.get("source_type") or "") != "tsmode_bundle":
        return None
    frequency_out = inp.get("frequency_out")
    hess = inp.get("hess")
    if not isinstance(frequency_out, str) or not isinstance(hess, str):
        raise ValueError("tsmode_bundle input requires frequency_out and hess paths")

    bundle_dir = inputs_dir / "INPUT" / "tsmode"
    bundle_dir.mkdir(parents=True, exist_ok=True)
    staged: dict[str, str] = {}
    checksums: dict[str, str] = {
        "frequency_out": "frequency_out_sha256",
        "hess": "hess_sha256",
        "geometry": "geometry_sha256",
    }
    for key, filename in (
        ("frequency_out", "source.out"),
        ("hess", "source.hess"),
        ("geometry", "source.xyz"),
    ):
        raw = inp.get(key)
        if not isinstance(raw, str) or not raw:
            continue
        source_path = Path(raw)
        if not source_path.is_file():
            raise ValueError(f"tsmode source asset not found: {raw}")
        dest = bundle_dir / filename
        shutil.copy2(source_path, dest)
        expected = inp.get(checksums[key])
        if isinstance(expected, str) and expected:
            import hashlib

            digest = hashlib.sha256(dest.read_bytes()).hexdigest()
            if digest != expected:
                raise ValueError(
                    f"tsmode source asset {key} hash mismatch (expected {expected[:12]}…, "
                    f"got {digest[:12]}…)"
                )
        staged[key] = filename

    if "frequency_out" not in staged or "hess" not in staged:
        raise ValueError("tsmode_bundle input requires both frequency_out and hess")

    payload: dict[str, Any] = {
        "schema_version": "tsmode_bundle_v1",
        "files": {
            "output": staged["frequency_out"],
            "hessian": staged["hess"],
        },
        "origin": inp.get("origin") or {"kind": "scheduler"},
    }
    if "geometry" in staged:
        payload["files"]["geometry"] = staged["geometry"]
    for key in ("charge", "multiplicity"):
        if isinstance(inp.get(key), int):
            payload[key] = inp[key]
    if isinstance(inp.get("level"), dict):
        payload["level"] = dict(inp["level"])
    optimization: dict[str, Any] = {}
    for key in (
        "max_iterations",
        "recalc_hess",
        "trust_radius",
        "retry_limit",
        "allow_unverified_mapping",
    ):
        if inp.get(key) is not None:
            optimization[key] = inp[key]
    if inp.get("final_frequency") is not None:
        payload["final_frequency"] = bool(inp["final_frequency"])
    if optimization:
        payload["optimization"] = optimization

    bundle_path = bundle_dir / "bundle.json"
    bundle_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return bundle_path


def materialize_job_input(
    inp: dict[str, Any],
    inputs_dir: Path,
    run_root: Path,
    materialized_roles: dict[str, Path] | None = None,
    *,
    stem: str = "input",
) -> Path | None:
    if isinstance(inp.get("scan_request"), dict):
        return None

    if isinstance(inp.get("path_request"), dict):
        return None

    if isinstance(inp.get("gradient_request"), dict):
        return None

    if str(inp.get("source_type") or "") == "batch_structures":
        materialized = _materialize_batch_structures(inp, inputs_dir)
        if materialized is not None:
            return materialized

    tsmode_bundle = _materialize_tsmode_bundle(inp, inputs_dir)
    if tsmode_bundle is not None:
        return tsmode_bundle

    return _materialize_single_input(inp, inputs_dir, run_root, stem=stem)


def _looks_like_smiles(s: str) -> bool:
    stripped = s.strip()
    if not stripped or "\n" in stripped or len(stripped) > 200:
        return False
    if stripped[0].isdigit():
        return False
    return True


class JobRunner:
    """Execute jobs as subprocesses (or in-process for the ``fake`` workflow)."""

    def __init__(
        self,
        python_executable: str | None = None,
        stage_task_observer: StageTaskObserver | None = None,
        remote_runner: JobRunnerRemoteProtocol | None = None,
        local_cleanup: LocalCleanupProtocol | None = None,
    ):
        self.python = python_executable or sys.executable
        self.stage_task_observer = stage_task_observer
        # When set, eligible jobs are dispatched to a remote compute node
        # instead of a local subprocess.  Populated by ``JobManager`` when
        # ``remote_config.is_remote`` is True.
        self.remote_runner = remote_runner
        # Local disk-protection manager (Phase 5B).  When set, the local
        # branch runs pre-submit housekeeping before materializing input.
        # Populated by ``JobManager`` when ``local_retention.enabled``.
        self.local_cleanup = local_cleanup
        # 07-C activation: default-envelope attempts are frozen here before the
        # dispatcher selects the entry.  Tests may inject a prepared release.
        self.freeze_release: Any | None = None
        self._default_release: Any | None = None
        self._repo_root = Path(__file__).resolve().parents[3]
        # Worker-independence probe only (controlled integration tests): when
        # set, envelope-selected local attempts pass ``--probe-executor`` to the
        # Services worker.  Production leaves it ``None``; no ordinary job is
        # affected and the worker remains the same executable.
        self.worker_probe_executor: str | None = None
        self._proc_lock = threading.Lock()
        self._processes: dict[str, subprocess.Popen[Any]] = {}
        self._seen_stages: dict[str, set[str]] = {}
        self._cancel_events: dict[str, threading.Event] = {}
        self._event_logs: dict[str, JobEventLog] = {}
        # Per-task execution locks (WORK/00_RUNTIME/run.lock): at most one
        # live execution per task directory, across service restarts.
        self._run_locks: dict[str, Path] = {}
        # Serializes the read-registered-paths → register flow so concurrent
        # capture passes (manager terminal side effects, repeat retries) can
        # never both register the same file.
        self._artifact_capture_lock = threading.Lock()

    # ------------------------------------------------------------------ #
    # New non-blocking API (poller-driven)
    # ------------------------------------------------------------------ #

    def submit(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        cancel_event: threading.Event,
    ) -> None:
        """Start job subprocess, return immediately. Non-blocking.

        For the ``fake`` workflow, runs in-process to completion
        (still non-blocking from the API caller's perspective since
        this runs on a daemon submission thread).
        """
        work_dir = Path(record.work_dir)
        work_dir.mkdir(parents=True, exist_ok=True)

        with self._proc_lock:
            self._cancel_events[record.id] = cancel_event
            self._event_logs[record.id] = event_log

        if record.spec.workflow == "fake":
            TaskStorage(work_dir).result_dir().mkdir(parents=True, exist_ok=True)
            self._run_fake(record, event_log, cancel_event)
            record.exit_code = 0
            record.completed_at = datetime.now(timezone.utc).isoformat()
            return

        # v2 task-storage layout (§3/§5): WORK/00_RUNTIME + RESULT/ scaffold,
        # input.xyz + task.json at the task root.  Scheduler zone-A files
        # (stdout/stderr/events/job.json) intentionally stay at the root for
        # backward compatibility with logs.py / events.py / v1_routes readers.
        storage = TaskStorage(work_dir)
        storage.ensure_layout()
        self._guard_single_execution(record)
        self._acquire_run_lock(record)
        try:
            self._prepare_and_launch(record, work_dir, storage, event_log)
        except BaseException:
            self._release_run_lock(record.id)
            raise

    def _prepare_and_launch(
        self,
        record: JobRecord,
        work_dir: Path,
        storage: TaskStorage,
        event_log: JobEventLog,
    ) -> None:
        """Materialize input, build the command, and spawn the subprocess."""
        observer = self._observer_for_record(record)
        observer.initialize_job_stages(record.id, record.spec)
        event_log.append("job.started", job_id=record.id, workflow=record.spec.workflow)

        skip = self._pre_submit_housekeeping_local(record, event_log)
        if skip:
            raise RuntimeError(f"Local disk full, submission blocked for job {record.id}")

        materialized_roles: dict[str, Path] = {}
        inputs_dir = work_dir
        materialized = materialize_job_input(
            record.spec.input,
            inputs_dir,
            work_dir.parent.parent,
            materialized_roles,
        )
        if materialized is not None and materialized != work_dir / "input.xyz":
            try:
                if record.spec.workflow != "tsmode":
                    if record.spec.input.get("source_type") == "batch_structures":
                        xyz_snapshot = _batch_structures_xyz_snapshot(record.spec.input)
                        if xyz_snapshot is not None:
                            storage.write_input_xyz(xyz_snapshot)
                    else:
                        storage.write_input_xyz(materialized.read_text(encoding="utf-8"))
            except OSError:
                logger.warning("Could not copy primary input.xyz for job %s", record.id)
        storage.write_task_json(build_task_record(record))

        effective_input_path = (
            str(materialized) if materialized else _extract_input_source(record.spec.input)
        )
        self._ensure_default_frozen_attempt(record, work_dir, effective_input_path, event_log)
        cmd = self._build_execution_cmd(
            record,
            work_dir,
            effective_input_path,
            materialized_roles,
        )
        stdout_path = runtime_file(work_dir, "stdout.log")
        stderr_path = runtime_file(work_dir, "stderr.log")

        event_log.append("process.starting", job_id=record.id, cmd=" ".join(cmd))

        with (
            stdout_path.open("w", encoding="utf-8") as out,
            stderr_path.open("w", encoding="utf-8") as err,
        ):
            _write_log_header(record, work_dir, cmd, out, err)
            env = dict(os.environ)
            env["PYTHONUNBUFFERED"] = "1"
            proc = subprocess.Popen(
                cmd,
                stdout=out,
                stderr=err,
                cwd=str(work_dir),
                env=env,
                start_new_session=True,
            )
            record.pid = proc.pid

        self._write_run_lock(self._run_locks[record.id], record, task_pid=proc.pid)
        with self._proc_lock:
            self._processes[record.id] = proc
            self._seen_stages[record.id] = set()
        observer.initialize_job_stages(record.id, record.spec)

    def poll(self, record: JobRecord) -> tuple[bool, int | None]:
        """Single non-blocking check of job status.

        Returns ``(is_terminal, exit_code)``.  *is_terminal* is True when
        the job has finished (or vanished).
        """
        with self._proc_lock:
            proc = self._processes.get(record.id)

        if proc is None:
            # Untracked RUNNING job: when its task process is still alive the
            # job is owned by a peer server (or was deliberately skipped by
            # restart recovery) — keep waiting instead of failing it.  The
            # 2026-09-05 incident showed a second server instance must not
            # re-fail a job just because it is absent from ``_processes``.
            if self._foreign_task_alive(record):
                return (False, None)
            # The worker exited in another controller's lifetime (no live
            # process remains).  Never finalise from ``record.exit_code``
            # alone: that column is only filled by the controller that
            # observed the exit, so a cross-process rerun/continue leaves it
            # ``None`` and a completed workflow would be recorded as FAILED.
            # Read the durable completion evidence instead; a persisted
            # CANCELLING intent wins over any observation (control intent is
            # never overwritten).
            if record.status == JobStatus.CANCELLING:
                exit_code = record.exit_code if record.exit_code not in (None, 0) else 130
                event_type = "job.cancelled"
            else:
                evidence = self.disk_completion_exit_code(record)
                exit_code = (
                    evidence
                    if evidence is not None
                    else (record.exit_code if record.exit_code is not None else 1)
                )
                event_type = "job.completed" if exit_code == 0 else "job.failed"
            event_log = self._event_logs.get(record.id)
            if event_log:
                event_log.append(
                    event_type,
                    job_id=record.id,
                    exit_code=exit_code,
                    idempotency_key=f"terminal:{record.id}:{record.attempt}:{event_type}",
                )
            self._release_run_lock(record.id)
            with self._proc_lock:
                self._seen_stages.pop(record.id, None)
                self._cancel_events.pop(record.id, None)
                self._event_logs.pop(record.id, None)
            return (True, exit_code)

        with self._proc_lock:
            cancel_event = self._cancel_events.get(record.id)

        if cancel_event and cancel_event.is_set():
            self._terminate(proc)
            event_log = self._event_logs.get(record.id)
            if event_log:
                event_log.append("job.cancelled", job_id=record.id, exit_code=130)
            self._release_run_lock(record.id)
            with self._proc_lock:
                self._processes.pop(record.id, None)
                self._seen_stages.pop(record.id, None)
                self._cancel_events.pop(record.id, None)
                self._event_logs.pop(record.id, None)
            return (True, 130)

        if record.pid is None:
            record.pid = proc.pid

        ret = proc.poll()
        if ret is not None:
            record.exit_code = ret
            event_log = self._event_logs.get(record.id)
            with self._proc_lock:
                seen = self._seen_stages.setdefault(record.id, set())
            if event_log:
                state_path = find_workflow_state(Path(record.work_dir))
                self._observe_state(record, event_log, state_path, seen)
            observer = self._observer_for_record(record)
            observer.poll_and_mirror(record.id, Path(record.work_dir))
            # Terminal completion events are emitted by the manager AFTER the
            # terminal CAS (idempotent, attempt-scoped) — never here, so a
            # CAS-rejected stale observation leaves no terminal side effect.
            self._release_run_lock(record.id)
            with self._proc_lock:
                self._processes.pop(record.id, None)
                self._seen_stages.pop(record.id, None)
                self._cancel_events.pop(record.id, None)
                self._event_logs.pop(record.id, None)
            return (True, ret)

        event_log = self._event_logs.get(record.id)
        if event_log:
            with self._proc_lock:
                seen = self._seen_stages.setdefault(record.id, set())
            state_path = find_workflow_state(Path(record.work_dir))
            self._observe_state(record, event_log, state_path, seen)
        observer = self._observer_for_record(record)
        observer.poll_and_mirror(record.id, Path(record.work_dir))
        return (False, None)

    def cancel_local(self, job_id: str) -> None:
        """Terminate a locally-running subprocess."""
        self._release_run_lock(job_id)
        with self._proc_lock:
            proc = self._processes.pop(job_id, None)
            self._seen_stages.pop(job_id, None)
            self._cancel_events.pop(job_id, None)
            self._event_logs.pop(job_id, None)
        if proc and proc.poll() is None:
            self._terminate(proc)

    def pause_local(self, job_id: str) -> bool:
        """Freeze a locally-running job's whole process group (SIGSTOP).

        The ``_processes`` entry is **retained** so the poller re-adopts the
        job once :meth:`resume_local` revives it — no state is popped and
        ``record.exit_code`` stays untouched while paused.

        Returns:
            ``True`` when the stop signal was delivered; ``False`` when the
            job is not tracked or its process already exited (let the poller
            finalize it instead of wedging it in PAUSED).
        """
        with self._proc_lock:
            proc = self._processes.get(job_id)
        if proc is None or proc.poll() is not None:
            return False
        try:
            pgid = os.getpgid(proc.pid)
            os.killpg(pgid, signal.SIGSTOP)
        except ProcessLookupError:
            return False
        except OSError:
            logger.warning("Failed to SIGSTOP process group for job %s", job_id, exc_info=True)
            return False
        return True

    def resume_local(self, job_id: str) -> bool:
        """Revive a paused local job's process group (SIGCONT).

        Returns:
            ``True`` when the job is still tracked — either revived, or it
            exited while paused (nothing to signal; the poller finalizes it
            as soon as the record is RUNNING again).  ``False`` means the
            job is not tracked locally at all (e.g. after a server restart).
        """
        with self._proc_lock:
            proc = self._processes.get(job_id)
        if proc is None:
            return False
        if proc.poll() is not None:
            return True
        try:
            pgid = os.getpgid(proc.pid)
            os.killpg(pgid, signal.SIGCONT)
        except ProcessLookupError:
            return True
        except OSError:
            logger.warning("Failed to SIGCONT process group for job %s", job_id, exc_info=True)
            return False
        return True

    # ------------------------------------------------------------------ #
    # Per-task single-execution guard (run.lock)
    # ------------------------------------------------------------------ #

    def _live_task_pids(self, record: JobRecord) -> list[int]:
        """Live, non-zombie processes still bound to this task directory.

        Combines the runner-tracked subprocess (same-service case) with a
        ``/proc`` scan so orphans from a previous service instance are found.
        """
        work_dir = Path(record.work_dir)
        with self._proc_lock:
            proc = self._processes.get(record.id)
        pids = set(find_task_processes(work_dir))
        if proc is not None and proc.poll() is None and pid_is_alive(proc.pid):
            pids.add(proc.pid)
        return sorted(pids)

    def _foreign_task_alive(self, record: JobRecord) -> bool:
        """True when an untracked task process is still computing in work_dir.

        Probes the ``run.lock`` task pid first (cheap) and falls back to a
        ``/proc`` scan; the PID-recycling guard requires the pid to actually
        reference the task directory.  Only invoked on the rare
        untracked-RUNNING poll path, so the scan cost is bounded.
        """
        work_dir = Path(record.work_dir)
        payload: dict[str, object] = {}
        try:
            payload = json.loads(runtime_file(work_dir, "run.lock").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            payload = {}
        task_pid = payload.get("task_pid") if isinstance(payload, dict) else None
        if isinstance(task_pid, int) and task_pid > 0:
            if pid_is_alive(task_pid) and process_references(task_pid, work_dir):
                return True
        return bool(find_task_processes(work_dir))

    def disk_completion_exit_code(self, record: JobRecord) -> int | None:
        """Return the exit code proven by on-disk completion evidence.

        Cross-process finishing (rerun/continue started by a controller that
        exited before the worker) leaves ``record.exit_code`` empty.  The
        wrapper marker is authoritative when present; otherwise the workflow
        ``state.json`` records the terminal status.  Evidence declaring a
        different attempt is ignored (stale receipt fence).
        """
        work_dir = Path(record.work_dir)
        try:
            marker = (work_dir / ".exit_code").read_text(encoding="utf-8").strip()
        except OSError:
            marker = ""
        if marker:
            try:
                return int(marker)
            except ValueError:
                logger.debug("Ignoring non-numeric .exit_code marker in %s", work_dir)
        state_path = find_workflow_state(work_dir)
        if state_path is None:
            return None
        data = _read_json_object(state_path)
        if data is None:
            return None
        declared_attempt = data.get("attempt")
        if isinstance(declared_attempt, int) and not isinstance(declared_attempt, bool):
            if declared_attempt != record.attempt:
                return None
        status = data.get("status")
        if status == "completed":
            return 0
        if status == "failed":
            return 1
        stages = data.get("stages")
        if isinstance(stages, dict) and stages:
            if all(
                isinstance(info, dict) and info.get("status") in ("completed", "skipped")
                for info in stages.values()
            ):
                return 0
        return None

    def attach_run_lock(self, record: JobRecord, *, task_pid: int | None) -> None:
        """Persist this controller's ownership of an adopted task process."""
        lock_path = runtime_file(Path(record.work_dir), "run.lock")
        try:
            self._write_run_lock(lock_path, record, task_pid=task_pid)
        except OSError:
            logger.warning("Failed to write adopted run.lock for %s", record.id, exc_info=True)
            return
        self._run_locks[record.id] = lock_path

    def _guard_single_execution(self, record: JobRecord) -> None:
        """Refuse to start when a live process already occupies the task."""
        live = self._live_task_pids(record)
        if live:
            raise RuntimeError(
                f"task {record.id} still has live process(es) {live} in "
                f"{record.work_dir}; refusing to start a second execution"
            )

    def _write_run_lock(self, lock_path: Path, record: JobRecord, task_pid: int | None) -> None:
        payload = {
            "job_id": record.id,
            "owner_pid": os.getpid(),
            "task_pid": task_pid,
            "attempt": record.attempt,
            "acquired_at": datetime.now(timezone.utc).isoformat(),
        }
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        lock_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def _acquire_run_lock(self, record: JobRecord) -> None:
        """Atomically claim ``WORK/00_RUNTIME/run.lock`` for this execution.

        A pre-existing lock is stale (and stolen) when its owner service is
        gone, or when it belongs to this very service with no live task
        process left behind by a crashed submission thread.  A lock held by
        a live foreign owner is a hard conflict.
        """
        lock_path = runtime_file(Path(record.work_dir), "run.lock")
        try:
            lock_path.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
        except FileExistsError:
            self._resolve_existing_run_lock(record, lock_path)
        self._write_run_lock(lock_path, record, task_pid=None)
        self._run_locks[record.id] = lock_path

    def _resolve_existing_run_lock(self, record: JobRecord, lock_path: Path) -> None:
        try:
            payload = json.loads(lock_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            payload = {}
        owner_pid = payload.get("owner_pid") if isinstance(payload, dict) else None
        owner_pid = int(owner_pid) if isinstance(owner_pid, int) else 0
        if pid_is_alive(owner_pid):
            if owner_pid == os.getpid() and not self._live_task_pids(record):
                logger.warning(
                    "Stolen stale run.lock for job %s (crashed submission thread)",
                    record.id,
                )
            else:
                raise RuntimeError(
                    f"run.lock for task {record.id} is held by live process {owner_pid}; "
                    "refusing to start a duplicate execution"
                )
            return
        logger.info("Stolen run.lock of dead service (pid=%s) for job %s", owner_pid, record.id)
        lock_path.unlink(missing_ok=True)

    def _release_run_lock(self, job_id: str) -> None:
        lock_path = self._run_locks.pop(job_id, None)
        if lock_path is None:
            return
        try:
            lock_path.unlink(missing_ok=True)
        except OSError:
            logger.debug("Failed to remove run.lock for job %s", job_id, exc_info=True)

    # ------------------------------------------------------------------ #
    # Legacy blocking API (kept for backward compat)
    # ------------------------------------------------------------------ #

    def _should_run_remote(self, spec: JobSpec) -> bool:
        """True when this job should be dispatched to a remote compute node.

        Requires ``remote_runner`` to be configured (set by
        :class:`~acp.scheduler.manager.JobManager` when
        ``remote_config.is_remote``) **and** the workflow to be one that
        has a remote CLI mapping (``fake`` is always local).
        """
        if self.remote_runner is None:
            return False
        return spec.workflow != "fake"

    def run(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        cancel_event: threading.Event,
    ) -> int:
        """Run the job. Returns process exit code (0 = success)."""
        work_dir = Path(record.work_dir)
        work_dir.mkdir(parents=True, exist_ok=True)

        # Remote dispatch — the fake workflow always stays local so the
        # workbench remains demoable without QC binaries or SSH access.
        if self._should_run_remote(record.spec):
            assert self.remote_runner is not None
            return self.remote_runner.run(record, event_log, cancel_event)

        observer = self._observer_for_record(record)
        observer.initialize_job_stages(record.id, record.spec)
        event_log.append("job.started", job_id=record.id, workflow=record.spec.workflow)

        try:
            if record.spec.workflow == "fake":
                exit_code = self._run_fake(record, event_log, cancel_event)
            else:
                exit_code = self._run_subprocess(record, event_log, cancel_event)
        except Exception as exc:
            logger.exception("Job %s crashed", record.id)
            record.error = str(exc)
            event_log.append("job.failed", job_id=record.id, error=str(exc))
            observer.finalize_job(record.id, "failed")
            return 1

        if cancel_event.is_set():
            event_log.append("job.cancelled", job_id=record.id)
        elif exit_code == 0:
            event_log.append("job.completed", job_id=record.id, exit_code=exit_code)
        else:
            event_log.append("job.failed", job_id=record.id, exit_code=exit_code)

        final_status = "failed"
        if cancel_event.is_set() and exit_code != 0:
            final_status = "cancelled"
        elif exit_code == 0:
            final_status = "completed"
        observer.finalize_job(record.id, final_status)
        return exit_code

    def _run_subprocess(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        cancel_event: threading.Event,
    ) -> int:
        work_dir = Path(record.work_dir)
        inputs_dir = work_dir / "inputs"
        inputs_dir.mkdir(exist_ok=True)
        run_root = work_dir.parent.parent

        # Phase 5B: local disk-pressure housekeeping before materializing
        # input.  When the run_root filesystem is critically full the job
        # is rejected gracefully (exit_code=1) instead of running out of
        # disk mid-computation.  Local mode does NOT raise — there is no
        # "switch node" option, so we just fail the job.
        skip = self._pre_submit_housekeeping_local(record, event_log)
        if skip:
            return 1

        materialized = None
        materialized_roles: dict[str, Path] = {}
        try:
            materialized = materialize_job_input(
                record.spec.input,
                inputs_dir,
                run_root,
                materialized_roles,
            )
        except Exception as exc:
            event_log.append("job.failed", job_id=record.id, error=str(exc))
            return 1

        effective_input_path = (
            str(materialized) if materialized else _extract_input_source(record.spec.input)
        )
        self._ensure_default_frozen_attempt(record, work_dir, effective_input_path, event_log)
        cmd = self._build_execution_cmd(
            record,
            work_dir,
            effective_input_path,
            materialized_roles,
        )
        stdout_path = runtime_file(work_dir, "stdout.log")
        stderr_path = runtime_file(work_dir, "stderr.log")

        event_log.append("process.starting", job_id=record.id, cmd=" ".join(cmd))

        with (
            stdout_path.open("w", encoding="utf-8") as out,
            stderr_path.open("w", encoding="utf-8") as err,
        ):
            _write_log_header(record, work_dir, cmd, out, err)
            env = dict(os.environ)
            env["PYTHONUNBUFFERED"] = "1"
            proc = subprocess.Popen(
                cmd,
                stdout=out,
                stderr=err,
                cwd=str(work_dir),
                env=env,
                start_new_session=True,
            )
            record.pid = proc.pid

        self._observer_for_record(record).initialize_job_stages(record.id, record.spec)
        exit_code = self._monitor(record, proc, event_log, cancel_event)
        if exit_code == 0:
            self._capture_artifacts(record, work_dir)
            self._capture_ensemble_thermo(record, work_dir)
            self._store_provenance(record, command_line=" ".join(cmd))
        return exit_code

    def _monitor(
        self,
        record: JobRecord,
        proc: subprocess.Popen[Any],
        event_log: JobEventLog,
        cancel_event: threading.Event,
    ) -> int:
        seen_stages: set[str] = set()
        observer = self._observer_for_record(record)

        while True:
            state_path = find_workflow_state(Path(record.work_dir))
            self._observe_state(record, event_log, state_path, seen_stages)
            observer.poll_and_mirror(record.id, Path(record.work_dir))
            if cancel_event.is_set():
                self._terminate(proc)
                break
            ret = proc.poll()
            if ret is not None:
                record.exit_code = ret
                state_path = find_workflow_state(Path(record.work_dir))
                self._observe_state(record, event_log, state_path, seen_stages)
                observer.poll_and_mirror(record.id, Path(record.work_dir))
                break
            time.sleep(_POLL_INTERVAL)

        if proc.poll() is None:
            proc.wait(timeout=10)
        return proc.returncode if proc.returncode is not None else 1

    def _observe_state(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        state_path: Path | None,
        seen: set[str],
    ) -> None:
        if state_path is None or not state_path.exists():
            return
        try:
            data = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return

        if data.get("status") == "failed":
            return

        record.current_stage = data.get("current_stage")
        stages = data.get("stages") if isinstance(data.get("stages"), dict) else {}
        total = max(len(stages), 1)
        done = sum(
            1
            for stage in stages.values()
            if isinstance(stage, dict) and stage.get("status") in ("completed", "skipped")
        )
        record.progress = round(done / total, 3)

        # Extended schema: ProgressReporter provides blended overall progress
        overall = data.get("overall_progress")
        if isinstance(overall, (int, float)):
            record.progress = round(float(overall), 3)

        # Mirror the running stage onto its stage_tasks row so the job-detail
        # stepper can show live phase detail ("status_detail").
        if record.current_stage:
            try:
                observer = self._observer_for_record(record)
                for task in observer.store.list_by_job(record.id):
                    if (
                        task.stage_name == record.current_stage
                        and task.status_detail != record.current_stage
                    ):
                        task.status_detail = record.current_stage
                        observer.store.update(task)
            except Exception:
                logger.debug("status_detail mirror failed for job %s", record.id, exc_info=True)

        pending_events: list[tuple[float, str, str, dict[str, object]]] = []
        for name, info in stages.items():
            if not isinstance(info, dict):
                continue
            status = info.get("status")
            if status == "running" and f"running:{name}" not in seen:
                seen.add(f"running:{name}")
                ts = _safe_timestamp(info.get("started_at"))
                pending_events.append((ts, "stage.started", name, {"stage": name}))
            elif status == "completed" and f"done:{name}" not in seen:
                seen.add(f"done:{name}")
                ts = _safe_timestamp(info.get("completed_at"))
                pending_events.append((ts, "stage.completed", name, {"stage": name}))
            elif status == "failed" and f"failed:{name}" not in seen:
                seen.add(f"failed:{name}")
                ts = _safe_timestamp(info.get("completed_at"))
                pending_events.append(
                    (ts, "stage.failed", name, {"stage": name, "error": str(info.get("error", ""))})
                )

        for _ts, event_type, _name, payload in sorted(pending_events, key=lambda x: x[0]):
            event_log.append(event_type, job_id=record.id, **payload)

    def _terminate(self, proc: subprocess.Popen[Any]) -> None:
        if proc.poll() is not None:
            return
        try:
            pgid = os.getpgid(proc.pid)
        except ProcessLookupError:
            return
        try:
            # Defensive SIGCONT: a SIGSTOP-frozen group cannot act on
            # SIGTERM (handlers never run while stopped) — revive it first
            # so the terminate handshake and SIGKILL escalation both work.
            try:
                os.killpg(pgid, signal.SIGCONT)
            except ProcessLookupError:
                pass
            os.killpg(pgid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(pgid, signal.SIGKILL)
                proc.wait(timeout=5)
        except OSError:
            logger.warning("Failed to terminate subprocess", exc_info=True)

    def _pre_submit_housekeeping_local(
        self,
        record: JobRecord,
        event_log: JobEventLog,
    ) -> bool:
        """Run local disk-pressure housekeeping before a local submission.

        Delegates to the injected :class:`LocalCleanup` (Phase 5B) when
        one is configured.  Fail-open for transient errors: a stat or
        sweep failure is logged but does **not** block submission.  Only
        the explicit ``should_skip`` decision blocks it.

        Unlike the remote path, the local branch **returns** ``True`` to
        signal "skip submission" rather than raising — there is no other
        node to fall back to, so the job is simply marked FAILED with a
        disk-full error message.

        Returns:
            ``True`` when submission must be skipped (disk full).
        """
        if self.local_cleanup is None:
            return False

        try:
            decision = self.local_cleanup.pre_submit_housekeeping()
        except Exception as exc:
            # Defensive: housekeeping must never crash the job.  Log and
            # proceed (fail-open).
            logger.warning("Local housekeeping crashed: %s", exc)
            event_log.append(
                "local.housekeeping_error",
                job_id=record.id,
                error=str(exc),
            )
            return False

        removed = len(decision.cleanup.work_dirs_removed) if decision.cleanup else 0
        errors = len(decision.cleanup.errors) if decision.cleanup else 0
        event_log.append(
            "local.housekeeping",
            job_id=record.id,
            disk_before=decision.disk_usage_before,
            disk_after=decision.disk_usage_after,
            should_skip=decision.should_skip,
            removed_dirs=removed,
            cleanup_errors=errors,
            reason=decision.reason,
        )

        if decision.should_skip:
            record.error = (
                f"Local disk full ({decision.disk_usage_after}%), "
                f"submission blocked: {decision.reason}"
            )
            logger.warning("Job %s blocked by disk pressure: %s", record.id, decision.reason)
            return True

        return False

    def _ensure_default_frozen_attempt(
        self,
        record: JobRecord,
        work_dir: Path,
        input_path: str,
        event_log: JobEventLog,
    ) -> None:
        """Freeze the default-envelope attempt BEFORE the dispatcher decides.

        Ordinary submissions for :data:`DEFAULT_ENVELOPE_WORKFLOWS` get a
        verified group here; the existing dispatcher then selects the envelope
        entry.  A same-attempt replay keeps the recorded choice/group/claim; a
        recorded envelope choice with a missing/corrupt group is a typed
        failure (never a silent legacy re-submit).
        """
        workflow = str(record.spec.workflow)
        if workflow not in DEFAULT_ENVELOPE_WORKFLOWS:
            return
        previous = read_attempt_choice(work_dir)
        if previous is not None and previous.attempt == record.attempt:
            if previous.entry == EXECUTION_ENTRY_ENVELOPE:
                if not frozen_artifacts_present(work_dir, expected_attempt=record.attempt):
                    raise FrozenGroupError(
                        f"envelope choice for attempt {record.attempt} is recorded but the "
                        "frozen group is missing/corrupt; refusing a legacy re-submit"
                    )
            # Same attempt: never re-select or re-freeze, regardless of entry.
            return
        if previous is not None and previous.attempt != record.attempt:
            # The caller (continue/rerun) owns archiving; a surviving old group
            # is a typed conflict in the builder, never silently overwritten.
            pass

        if self.freeze_release is not None:
            release = self.freeze_release
        elif self._default_release is not None:
            release = self._default_release
        else:
            from acp.calculations.attempt_freeze import build_local_release

            release = build_local_release(self._repo_root, work_dir.parent.parent)
            self._default_release = release

        from acp.calculations.attempt_freeze import build_freeze_spec
        from acp_services.runtime.attempt_freeze import write_frozen_attempt

        spec = build_freeze_spec(record, work_dir, input_path, release)
        group = write_frozen_attempt(work_dir, spec)
        event_log.append(
            "attempt.frozen",
            job_id=record.id,
            workflow=workflow,
            attempt=record.attempt,
            release_id=group.manifest.release_id,
            release_digest=group.manifest.release_digest,
        )

    def _resolve_attempt_choice(
        self, record: JobRecord, work_dir: Path, *, remote: bool = False
    ) -> AttemptExecutionChoice:
        """Resolve (and record) this attempt's execution entry via the dispatcher.

        The single dispatcher (``execution_chain``) owns the decision: an
        already-recorded choice for the same attempt is reused verbatim (resume
        never re-selects), a new attempt re-selects from the frozen table. The
        choice is persisted in the attempt runtime dir so the same attempt can
        never dispatch a second, different entry.
        """
        previous = read_attempt_choice(work_dir)
        remote_meta = (record.result or {}).get("remote")
        release_id = ""
        if isinstance(remote_meta, Mapping):
            raw_release = remote_meta.get("code_release")
            if isinstance(raw_release, str):
                release_id = raw_release
        choice = resolve_attempt_choice(
            workflow=record.spec.workflow,
            attempt=record.attempt,
            remote=remote,
            envelope_available=frozen_artifacts_present(work_dir, expected_attempt=record.attempt),
            previous=previous,
            release_id=release_id,
        )
        if previous != choice:
            write_attempt_choice(work_dir, choice)
        return choice

    def _build_execution_cmd(
        self,
        record: JobRecord,
        work_dir: Path,
        input_path: str,
        materialized_roles: Mapping[str, Path | str] | None,
    ) -> list[str]:
        """Return the ONE entry command for this attempt (dispatcher-driven).

        Envelope-selected attempts run the Services worker bootstrap; every
        other attempt keeps the legacy CLI mapping. Never both — the selection
        is frozen on the attempt first.
        """
        choice = self._resolve_attempt_choice(record, work_dir)
        record.result = with_attempt_choice(record.result, choice)
        if choice.entry == EXECUTION_ENTRY_ENVELOPE:
            launch = local_launch(work_dir, choice)
            return worker_argv(
                self.python,
                launch,
                work_dir=str(work_dir),
                probe_executor=self.worker_probe_executor,
            )
        return self._build_cmd(record.spec, work_dir, input_path, materialized_roles)

    def _build_cmd(
        self,
        spec: JobSpec,
        work_dir: Path,
        input_path: str = "",
        materialized_roles: Mapping[str, Path | str] | None = None,
    ) -> list[str]:
        from acp.scheduler.resources import with_job_resources

        spec = with_job_resources(spec)
        wf = spec.workflow
        if wf not in (
            "Confsearch",
            "PESsearch",
            "XtbPathSearch",
            "OrcaGradient",
            "BatchOptimize",
            "ensemble",
            "energy",
            "nmr",
            "xtbmd_censo_energy",
            "singlepoint",
            "optimize",
            "frequency",
            "scan",
            "irc",
            "tsmode",
            "casscf",
            "xtb_optimize",
        ):
            raise ValueError(f"No subprocess mapping for workflow: {wf}")

        cmd: list[str] = [self.python, "-m", "acp.cli", "run", wf]
        inp = spec.input
        method = spec.method
        res = spec.resources
        cli_work_dir = work_dir.as_posix()

        source = input_path or _extract_input_source(inp)
        if wf == "PESsearch":
            return self._build_pessearch_cmd(spec, work_dir, source)
        if wf == "XtbPathSearch":
            return self._build_xtb_path_cmd(spec, work_dir)
        if wf == "OrcaGradient":
            return self._build_orca_gradient_cmd(spec, work_dir)
        if wf == "nmr":
            return self._build_nmr_cmd(spec, work_dir)

        if wf == "tsmode":
            bundle_path = Path(input_path) if input_path else None
            if (
                bundle_path is None
                or not bundle_path.is_file()
                or not str(bundle_path).endswith("bundle.json")
            ):
                raise ValueError("tsmode job requires a materialized INPUT/tsmode/bundle.json")
            cmd += [
                "--source-bundle",
                bundle_path.as_posix(),
                "--output",
                cli_work_dir,
            ]
            mode_index = inp.get("source_mode_index")
            if not isinstance(mode_index, int) or isinstance(mode_index, bool):
                raise ValueError("tsmode job requires an integer source_mode_index")
            cmd += ["--source-mode-index", str(mode_index)]
            if spec.name:
                cmd += ["--name", spec.name]
            if res.get("nproc") is not None:
                cmd += ["--nproc", str(res["nproc"])]
            if res.get("mem"):
                cmd += ["--mem", str(res["mem"])]
            if spec.config_path:
                cmd += ["--config", str(spec.config_path)]
            return cmd

        if wf == "BatchOptimize":
            artifact = inp.get("from_artifact")
            items_file = inp.get("items_file")
            if artifact:
                cmd += ["--from-artifact", str(artifact), "--output", cli_work_dir]
            elif items_file:
                cmd += ["--items-file", str(items_file), "--output", cli_work_dir]
            elif inp.get("source_type") == "batch_structures":
                if not input_path or not Path(input_path).is_file():
                    raise ValueError("BatchOptimize batch_structures input was not materialized")
                cmd += ["--items-file", Path(input_path).as_posix(), "--output", cli_work_dir]
            elif input_path and Path(input_path).is_file():
                # The Workbench creates one scheduler job per structure.  Its
                # materialized input.xyz is therefore a valid one-item XYZ
                # batch for the BatchOptimize CLI.  Keep this task flat, just
                # like the ordinary single-structure workflows.
                # Prefer the scheduler's canonical root input.xyz even when
                # the uploaded source had another suffix (e.g. .gjf).
                staged_input = work_dir / "input.xyz"
                batch_input = staged_input if staged_input.is_file() else Path(input_path)
                cmd += ["--items-file", str(batch_input), "--output", cli_work_dir]
            else:
                raise ValueError(
                    "BatchOptimize job requires a batch artifact, items file, or "
                    "materialized structure"
                )
            # Scheduler tasks are one-structure-per-task (layout spec §1a):
            # every dispatch shape must produce the flat WORK/03_OPT…
            # layout, never the nested WORK/03_OPT/batch/item_001 tree.
            cmd += ["--layout-mode", "single_flat"]
            cmd += batchoptimize_method_flags(method, inp)
            if spec.config_path:
                cmd += ["--config", str(spec.config_path)]
            if res.get("nproc") is not None:
                cmd += ["--nproc", str(res["nproc"])]
            if res.get("mem"):
                cmd += ["--mem", str(res["mem"])]
            cmd += input_chemistry_flags(inp)
            return cmd

        if not source:
            raise ValueError(f"{wf} job requires a valid input structure")

        if wf == "Confsearch":
            cmd += ["--input", str(source), "--output", cli_work_dir]
            if spec.name:
                cmd += ["--name", spec.name]
            cmd += confsearch_method_flags(method)
            solvent = censo_solvent_from_method(method)
            if solvent:
                cmd += ["--solvent", solvent]
            ewin = censo_ewin_from_method(method)
            if ewin is not None:
                cmd += ["--ewin", str(ewin)]
        elif wf in {"ensemble", "energy"}:
            cmd += ["--input", str(source), "--output", cli_work_dir]
            preset = censo_preset_from_method(method)
            if preset:
                cmd += ["--preset", preset]
            if spec.name:
                cmd += ["--name", spec.name]
            if wf == "energy" and method.get("no_opt"):
                cmd += ["--no-opt"]
            if wf == "energy" and method.get("rank1_only"):
                cmd += ["--rank1-only"]
            if wf == "energy" and method.get("rank1_only") is False:
                # CLI defaults to rank1-only; an explicit opt-out must be
                # forwarded so the full-ensemble path is restored.
                cmd += ["--full-ensemble"]
            if wf == "energy" and method.get("threshold") is not None:
                cmd += ["--threshold", str(method["threshold"])]
            if wf == "energy" and method.get("levels"):
                cmd += ["--levels", json.dumps(method["levels"])]
            if wf == "ensemble" and method.get("keep_all"):
                cmd += ["--keep-all"]
            solvent = censo_solvent_from_method(method)
            if solvent:
                cmd += ["--solvent", solvent]
            ewin = censo_ewin_from_method(method)
            if ewin is not None:
                cmd += ["--ewin", str(ewin)]
        elif wf == "xtbmd_censo_energy":
            cmd += ["--input", str(source), "--output", cli_work_dir]
            preset = censo_preset_from_method(method)
            if preset:
                cmd += ["--preset", preset]
            if spec.name:
                cmd += ["--name", spec.name]
            if method.get("levels"):
                cmd += ["--levels", json.dumps(method["levels"])]
            # MD / batch-opt / ISOSTAT / conv / resume control group —
            # single shared flag builder keeps this branch in parity with
            # the remote script_gen path (E7, DevDoc §10.2).
            cmd += xtbmd_method_flags(method)
            solvent = censo_solvent_from_method(method)
            if solvent:
                cmd += ["--solvent", solvent]
            ewin = censo_ewin_from_method(method)
            if ewin is not None:
                # GFN1 energy window for this workflow (CLI --ewin);
                # the same flag name, different object vs. energy.
                cmd += ["--ewin", str(ewin)]
        elif wf in ("singlepoint", "optimize", "frequency", "scan"):
            cmd += ["--input", str(source), "--output", cli_work_dir]
            if spec.name:
                cmd += ["--name", spec.name]
            levels = method.get("levels", {})
            if levels:
                from acp_services.runtime.method_flags import method_levels_to_cli_flags

                cmd += method_levels_to_cli_flags(levels, workflow=wf)
                spin_module = electronic_state_from_method(method)
                if isinstance(spin_module, Mapping):
                    cmd += _electronic_state_cli_flags(spin_module, work_dir)
            if wf == "scan":
                cmd += scan_method_flags(method, inp)
        elif wf == "casscf":
            cmd += ["--input", str(source), "--output", cli_work_dir]
            if spec.name:
                cmd += ["--name", spec.name]
            levels = method.get("levels", {})
            casscf_level = levels.get("casscf", {}) if isinstance(levels, Mapping) else {}
            if not isinstance(casscf_level, Mapping):
                casscf_level = {}
            nel = casscf_level.get("cas_active_electrons") or method.get("active_electrons")
            norb = casscf_level.get("cas_active_orbitals") or method.get("active_orbitals")
            if nel is None or norb is None:
                raise ValueError(
                    "casscf job requires active-space information "
                    "(cas_active_electrons / cas_active_orbitals)"
                )
            cmd += ["--active-electrons", str(nel), "--active-orbitals", str(norb)]
            basis = casscf_level.get("basis") or method.get("basis")
            if basis:
                cmd += ["--basis", str(basis)]
            nroots = casscf_level.get("cas_nroots")
            if nroots:
                cmd += ["--nroots", str(nroots)]
            dc = casscf_level.get("cas_dynamic_correlation")
            if dc and dc != "none":
                cmd += ["--dynamic-correlation", str(dc)]
            orbital_source = method.get("orbital_source")
            if orbital_source:
                cmd += ["--orbital-source", str(orbital_source)]
            if casscf_level.get("electronic_state"):
                cmd += _electronic_state_cli_flags(casscf_level["electronic_state"], work_dir)
        elif wf == "irc":
            cmd += ["--input", str(source), "--output", cli_work_dir]
            provenance = inp.get("ts_source")
            if not isinstance(provenance, dict) or provenance.get("schema") != "irc_ts_source_v1":
                raise ValueError("IRC requires verified TS source provenance")
            cmd += ["--ts-provenance-json", json.dumps(provenance, sort_keys=True)]
            if spec.name:
                cmd += ["--name", spec.name]
            input_role = inp.get("input_role")
            if input_role:
                cmd += ["--input-role", str(input_role)]
            raw_directions = inp.get("directions")
            if isinstance(raw_directions, (list, tuple)):
                direction_names = {str(direction).strip().lower() for direction in raw_directions}
                if direction_names == {"forward"}:
                    cmd += ["--direction", "forward"]
                elif direction_names == {"reverse"}:
                    cmd += ["--direction", "reverse"]
                elif direction_names in ({"forward", "reverse"}, {"both"}):
                    cmd += ["--direction", "both"]
                elif direction_names:
                    raise ValueError("irc directions must be forward, reverse, or both")
            levels = method.get("levels")
            irc_level = levels.get("irc", {}) if isinstance(levels, Mapping) else {}
            if not isinstance(irc_level, Mapping):
                irc_level = {}
            irc_method = method.get("method") or method.get("functional") or irc_level.get("method")
            if irc_method:
                cmd += ["--method", str(irc_method)]
            irc_basis = method.get("basis") or irc_level.get("basis")
            if irc_basis:
                cmd += ["--basis", str(irc_basis)]
            cmd += ["--charge", str(inp["charge"]), "--multiplicity", str(inp["multiplicity"])]
            maxpoints = method.get("maxpoints") or irc_level.get("maxpoints")
            if maxpoints is not None:
                cmd += ["--maxpoints", str(maxpoints)]
            irc_step = method.get("step") or irc_level.get("step")
            if irc_step is not None:
                cmd += ["--step", str(irc_step)]
        elif wf == "xtb_optimize":
            cmd += ["--input", str(source), "--output", cli_work_dir]
            if spec.name:
                cmd += ["--name", spec.name]
            xtb_level = (method.get("levels") or {}).get("xtb_opt", {})
            gfn_val = xtb_level.get("gfn")
            if gfn_val is not None:
                gfn_int = _GFN_DISPLAY_TO_INT.get(str(gfn_val), gfn_val)
                cmd += ["--gfn", str(gfn_int)]
            if xtb_level.get("opt_level"):
                cmd += ["--opt-level", str(xtb_level["opt_level"])]
            if xtb_level.get("max_steps") is not None:
                cmd += ["--max-steps", str(xtb_level["max_steps"])]
            if xtb_level.get("solvent"):
                cmd += ["--solvent", str(xtb_level["solvent"])]
            sm = xtb_level.get("solvent_model")
            if sm and str(sm).lower() not in ("", "none"):
                cmd += ["--solvent-model", str(sm)]

        if spec.config_path and wf != "mech-chain":
            cmd += ["--config", str(spec.config_path)]
        if res.get("nproc") is not None:
            cmd += ["--nproc", str(res["nproc"])]
        if res.get("mem"):
            cmd += ["--mem", str(res["mem"])]
        cmd += input_chemistry_flags(inp)
        return cmd

    def _build_nmr_cmd(self, spec: JobSpec, work_dir: Path) -> list[str]:
        """Build the ``acp run nmr`` argv (multi-candidate + spectrum).

        Payload convention (DevDoc §11.1):
        ``spec.input = {"candidates": [{source_type, source, charge, ...}],
                        "experiment": {"content": "<§6.2 text>"}}``.
        For backwards compatibility a single-candidate ``spec.input`` is
        also accepted (treated as a one-element candidate list).
        """
        from acp.scheduler.resources import with_job_resources

        spec = with_job_resources(spec)
        cmd: list[str] = [self.python, "-m", "acp.cli", "run", "nmr"]
        cmd += ["--output", work_dir.as_posix()]

        inp = spec.input
        method = spec.method
        res = spec.resources

        inputs_dir = work_dir / "inputs"
        inputs_dir.mkdir(parents=True, exist_ok=True)

        candidates = inp.get("candidates") if isinstance(inp.get("candidates"), list) else None
        if candidates is None:
            # legacy single-candidate payload
            candidates = [inp]

        enumerate_mode = bool(inp.get("enumerate"))
        for idx, cand in enumerate(candidates):
            if not isinstance(cand, dict):
                continue
            cand_source = cand.get("source") or cand.get("smiles") or cand.get("input")
            if not cand_source:
                continue
            if enumerate_mode and _looks_like_smiles(str(cand_source)):
                # Enumerate needs bond information (stereochemistry is
                # topological): pass SMILES through verbatim instead of
                # materializing to XYZ (which has no bond table).
                cmd += ["--input", str(cand_source)]
                continue
            materialized = materialize_job_input(cand, inputs_dir, work_dir, stem=f"input_{idx}")
            if materialized is not None:
                cmd += ["--input", str(materialized)]
            else:
                # fall back to the raw source (SMILES strings survive)
                cmd += ["--input", str(cand_source)]

        experiment = inp.get("experiment") or method.get("experiment")
        exp_mode = (experiment or {}).get("mode", "assigned")
        if exp_mode == "bruker":
            # P3: Bruker raw-data zip uploaded via /uploads?parse=false.
            bruker_dir = self._materialize_bruker_asset(experiment, inputs_dir, work_dir)
            if bruker_dir is None:
                raise ValueError(
                    "nmr bruker job requires experiment.spectrum_asset_id (+ filename)"
                )
            cmd += ["--bruker", str(bruker_dir)]
            refs = experiment.get("references") if isinstance(experiment, dict) else None
            if isinstance(refs, dict):
                for key, value in refs.items():
                    cmd += ["--bruker-ref", f"{key}={value}"]
        else:
            spectrum_path = self._materialize_experiment(experiment, inputs_dir)
            if spectrum_path is None:
                raise ValueError("nmr job requires an 'experiment' payload (spectrum text)")
            cmd += ["--spectrum", str(spectrum_path)]

        # P2: diastereomer enumeration (single-candidate payload only).
        # The backend expands the one candidate into its full diastereomer
        # set; enantiomer pairs collapse (DP4 cannot distinguish them).
        if enumerate_mode:
            cmd += ["--enumerate"]
            stereocenters = inp.get("stereocenters")
            if isinstance(stereocenters, str) and stereocenters.strip():
                cmd += ["--stereocenters", stereocenters.strip()]
            elif isinstance(stereocenters, list) and stereocenters:
                cmd += ["--stereocenters", ",".join(str(s) for s in stereocenters)]

        # --name intentionally not emitted: the nmr parser never accepted it
        # (G06) — task naming is manager-owned (spec.name → work_dir name).
        # INVARIANT (E7): all nmr flags come from the single resolver-backed
        # group — no caller-side censo_preset/solvent/ewin here (duplicate
        # emission; and the nmr wizard nests ewin under levels.conformer,
        # which censo_ewin_from_method never reads).
        cmd += nmr_method_flags(method, nmr_flag_config(spec.config_path))
        cmd += nmr_candidate_metadata_flags(inp)

        if spec.config_path:
            cmd += ["--config", str(spec.config_path)]
        if res.get("nproc") is not None:
            cmd += ["--nproc", str(res["nproc"])]
        if res.get("mem"):
            cmd += ["--mem", str(res["mem"])]
        cmd += input_chemistry_flags(inp)
        return cmd

    def _build_pessearch_cmd(self, spec: JobSpec, work_dir: Path, source: str) -> list[str]:
        """Build the PESsearch argv for local execution."""
        inp = spec.input
        method = spec.method
        res = spec.resources
        bond_scan_mode = str(method.get("mode") or "") == "bond_length_scan"

        cmd: list[str] = [self.python, "-m", "acp.cli", "run", "PESsearch"]
        if bond_scan_mode:
            cmd += ["--mode", "bond_length_scan"]
            scan_request = dict(inp.get("scan_request") or method.get("scan_request") or {})
            work_dir.mkdir(parents=True, exist_ok=True)
            scan_config_path = work_dir / SCAN_CONFIG_FILENAME
            scan_config_path.write_text(
                json.dumps(scan_request, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            cmd += [
                "--scan-config",
                scan_config_path.as_posix(),
                "--output",
                work_dir.as_posix(),
            ]
        else:
            from_manifest = inp.get("from")
            if from_manifest:
                cmd += ["--from", str(from_manifest)]
            cmd += ["--output", work_dir.as_posix()]
            if method.get("strategy"):
                cmd += ["--strategy", str(method["strategy"])]
            select = method.get("select")
            if isinstance(select, (list, tuple)) and select:
                cmd += ["--select", ",".join(str(item) for item in select)]
            elif isinstance(select, str) and select.strip():
                cmd += ["--select", select.strip()]
            plan = inp.get("coordinate_plan") or method.get("coordinate_plan")
            if plan is not None:
                cmd += ["--plan", json.dumps(plan)]
            product = inp.get("product")
            if product:
                cmd += ["--product", str(product)]
            ts_guess = inp.get("ts_guess")
            if ts_guess:
                cmd += ["--ts-guess", str(ts_guess)]

        if spec.config_path:
            cmd += ["--config", str(spec.config_path)]
        if res.get("nproc") is not None:
            cmd += ["--nproc", str(res["nproc"])]
        if res.get("mem"):
            cmd += ["--mem", str(res["mem"])]
        cmd += input_chemistry_flags(inp)
        return cmd

    def _build_xtb_path_cmd(self, spec: JobSpec, work_dir: Path) -> list[str]:
        """Build the XtbPathSearch argv (frozen ``pes2ts_xtb_path_request_v1``).

        Mirrors :meth:`_build_pessearch_cmd` ``--scan-config`` form: the
        request payload is persisted verbatim as ``path_config.json`` in the
        task dir and forwarded via ``--path-config``; the recipe knobs are
        never defaulted by ACP.
        """
        inp = spec.input
        res = spec.resources
        path_request = dict(inp.get("path_request") or spec.method.get("path_request") or {})
        if not path_request:
            raise ValueError(
                "XtbPathSearch job requires input.path_request (pes2ts_xtb_path_request_v1 payload)"
            )
        work_dir.mkdir(parents=True, exist_ok=True)
        path_config_path = work_dir / PATH_CONFIG_FILENAME
        path_config_path.write_text(
            json.dumps(path_request, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        cmd: list[str] = [
            self.python,
            "-m",
            "acp.cli",
            "run",
            "XtbPathSearch",
            "--path-config",
            path_config_path.as_posix(),
            "--output",
            work_dir.as_posix(),
        ]
        if spec.config_path:
            cmd += ["--config", str(spec.config_path)]
        if res.get("nproc") is not None:
            cmd += ["--nproc", str(res["nproc"])]
        if res.get("mem"):
            cmd += ["--mem", str(res["mem"])]
        return cmd

    def _build_orca_gradient_cmd(self, spec: JobSpec, work_dir: Path) -> list[str]:
        """Build the OrcaGradient argv (frozen ``pes2ts_orca_gradient_request_v1``).

        Mirrors :meth:`_build_xtb_path_cmd` ``--path-config`` form: the
        request payload is persisted verbatim as ``gradient_config.json`` in
        the task dir and forwarded via ``--gradient-config``; the request
        knobs are never defaulted by ACP.
        """
        inp = spec.input
        res = spec.resources
        gradient_request = dict(
            inp.get("gradient_request") or spec.method.get("gradient_request") or {}
        )
        if not gradient_request:
            raise ValueError(
                "OrcaGradient job requires input.gradient_request "
                "(pes2ts_orca_gradient_request_v1 payload)"
            )
        work_dir.mkdir(parents=True, exist_ok=True)
        gradient_config_path = work_dir / GRADIENT_CONFIG_FILENAME
        gradient_config_path.write_text(
            json.dumps(gradient_request, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        cmd: list[str] = [
            self.python,
            "-m",
            "acp.cli",
            "run",
            "OrcaGradient",
            "--gradient-config",
            gradient_config_path.as_posix(),
            "--output",
            work_dir.as_posix(),
        ]
        if spec.config_path:
            cmd += ["--config", str(spec.config_path)]
        if res.get("nproc") is not None:
            cmd += ["--nproc", str(res["nproc"])]
        if res.get("mem"):
            cmd += ["--mem", str(res["mem"])]
        return cmd

    @staticmethod
    def _materialize_experiment(
        experiment: dict[str, Any] | None,
        inputs_dir: Path,
    ) -> Path | None:
        """Write the §6.2 spectrum text to ``inputs/experiment.txt``."""
        if experiment is None:
            return None
        content = experiment.get("content")
        if not content:
            return None
        inputs_dir.mkdir(parents=True, exist_ok=True)
        out = inputs_dir / "experiment.txt"
        out.write_text(str(content), encoding="utf-8")
        return out

    @staticmethod
    def _materialize_bruker_asset(
        experiment: dict[str, Any] | None,
        inputs_dir: Path,
        work_dir: Path,
    ) -> Path | None:
        """Resolve + extract an uploaded Bruker zip into ``inputs/bruker``.

        The frontend uploads the zip via ``/uploads?parse=false`` and
        submits ``experiment = {mode: "bruker", spectrum_asset_id,
        filename, project_id}``. The asset lives at
        ``<run_root>/<project_id>/uploads/<upload_id>/original/<filename>``
        (``run_root`` derives from the job work dir, mirroring
        ``_run_subprocess``). Non-zip assets (an already-extracted
        directory tarball layout) are rejected with a clear error.
        """
        if not experiment:
            return None
        upload_id = experiment.get("spectrum_asset_id")
        filename = experiment.get("filename")
        if not upload_id or not filename:
            return None
        if Path(str(filename)).name != str(filename):
            raise ValueError(f"Unsafe bruker asset filename: {filename!r}")
        project_id = str(experiment.get("project_id") or "uncategorized")
        if project_id in ("", ".", "..") or "/" in project_id or "\\" in project_id:
            raise ValueError(f"Unsafe bruker asset project_id: {project_id!r}")

        run_root = work_dir.parent.parent
        asset = (
            run_root / project_id / "uploads" / str(upload_id) / "original" / str(filename)
        ).resolve()
        try:
            asset.relative_to(run_root.resolve())
        except ValueError:
            raise ValueError(f"Bruker asset path escapes run_root: {asset}")
        if not asset.is_file():
            raise ValueError(f"Bruker asset not found: {asset}")
        if asset.suffix.lower() != ".zip":
            raise ValueError(f"Bruker asset must be a .zip archive: {asset.name}")

        import zipfile

        dest = inputs_dir / "bruker"
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(asset) as zf:
            for member in zf.namelist():
                target = (dest / member).resolve()
                if not str(target).startswith(str(dest.resolve())):
                    raise ValueError(f"Unsafe path in bruker zip: {member!r}")
            zf.extractall(dest)
        return dest

    def _run_fake(
        self,
        record: JobRecord,
        event_log: JobEventLog,
        cancel_event: threading.Event,
    ) -> int:
        from acp.core.state import WorkflowState

        work_dir = Path(record.work_dir)
        state = WorkflowState(work_dir=work_dir, job_name=record.spec.name or record.id)
        state.initialize(input_source="fake", stage_names=["init", "compute", "finalize"])
        observer = self._observer_for_record(record)
        tasks = observer.initialize_job_stages(record.id, record.spec)
        tasks_by_stage = {task.stage_name: task for task in tasks}
        stages = ["init", "compute", "finalize"]

        try:
            for name in stages:
                if cancel_event.is_set():
                    return 130

                task = tasks_by_stage.get(name)
                if task is None:
                    tasks = observer.initialize_job_stages(record.id, record.spec)
                    tasks_by_stage = {item.stage_name: item for item in tasks}
                    task = tasks_by_stage.get(name)
                if task is None:
                    raise ValueError(f"Missing stage task row for fake stage '{name}'")

                started_at = _utc_now_iso()
                self._write_stage_task_event(
                    work_dir,
                    name,
                    task.task_id,
                    "started",
                    {
                        "task_id": task.task_id,
                        "stage": name,
                        "status": "running",
                        "pid": os.getpid(),
                        "started_at": started_at,
                    },
                )
                observer.poll_and_mirror(record.id, work_dir)
                state.set_stage(name)
                event_log.append("stage.started", job_id=record.id, stage=name)
                event_log.append(
                    "log", job_id=record.id, stream="stdout", line=f"[fake] running {name}"
                )
                time.sleep(0.8)
                if cancel_event.is_set():
                    return 130

                state.complete_stage(name, result={"fake": True})
                self._write_stage_task_event(
                    work_dir,
                    name,
                    task.task_id,
                    "completed",
                    {
                        "task_id": task.task_id,
                        "stage": name,
                        "status": "completed",
                        "pid": os.getpid(),
                        "started_at": started_at,
                        "completed_at": _utc_now_iso(),
                        "exit_code": 0,
                        "result": {"fake": True},
                    },
                )
                observer.poll_and_mirror(record.id, work_dir)
                event_log.append("stage.completed", job_id=record.id, stage=name)

            source_type = record.spec.input.get("source_type", "")
            source = (
                record.spec.input.get("source")
                or record.spec.input.get("input")
                or record.spec.input.get("smiles")
            )
            if not source:
                raise ValueError("fake workflow requires input.source")

            if source_type == "xyz_text":
                xyz = str(source)
                if not xyz.strip().startswith(str(xyz.count("\n"))):
                    pass
            elif source_type == "structure_asset":
                run_root = Path(record.work_dir).parent.parent
                asset_path = (run_root / str(source)).resolve()
                try:
                    asset_path.relative_to(run_root.resolve())
                    xyz = asset_path.read_text(encoding="utf-8")
                except (ValueError, OSError) as exc:
                    raise ValueError(f"Cannot read structure asset: {source}") from exc
            else:
                xyz = smiles_to_xyz(str(source))

            (TaskStorage(work_dir).result_dir() / "input_preview.xyz").write_text(
                xyz,
                encoding="utf-8",
            )

            demo_frames = bool(record.spec.input.get("demo_frames"))
            if demo_frames:
                demo_xyz = xyz_to_multiframe_demo(xyz, frames=3)
                (TaskStorage(work_dir).result_dir() / "demo_frames.xyz").write_text(
                    demo_xyz,
                    encoding="utf-8",
                )

            method_levels = record.spec.method.get("levels") if record.spec.method else None
            if method_levels:
                from acp.catalog import method_levels_to_workflow_config

                schema_id = record.spec.method.get("schema_id", "confsearch")
                wf_config = method_levels_to_workflow_config(
                    method_levels, schema_id, record.spec.workflow
                )
                (TaskStorage(work_dir).result_dir() / "method_config.json").write_text(
                    json.dumps(wf_config, indent=2),
                    encoding="utf-8",
                )

            self._capture_artifacts(record, work_dir)
            self._store_provenance(record)
            state.mark_completed()
            return 0
        except Exception as exc:
            current = str(state.state.get("current_stage") or "unknown")
            error_message = str(exc)
            state.fail_stage(current, error=error_message)
            task = tasks_by_stage.get(current)
            if task is not None:
                self._write_stage_task_event(
                    work_dir,
                    current,
                    task.task_id,
                    "failed",
                    {
                        "task_id": task.task_id,
                        "stage": current,
                        "status": "failed",
                        "pid": os.getpid(),
                        "completed_at": _utc_now_iso(),
                        "exit_code": 1,
                        "error": error_message,
                    },
                )
                observer.poll_and_mirror(record.id, work_dir)
            raise

    def _observer_for_record(self, record: JobRecord) -> StageTaskObserver:
        if self.stage_task_observer is None:
            fallback_db = Path(record.work_dir) / ".acp_stage_tasks.db"
            self.stage_task_observer = StageTaskObserver(StageTaskStore(fallback_db))
        return self.stage_task_observer

    def _capture_artifacts(self, record: JobRecord, work_dir: Path) -> None:
        """Register output files as artifacts after job completion.

        At-least-once: the whole read-registered-paths → register flow runs
        under ``_artifact_capture_lock`` so a repeat capture (terminal retry)
        cannot double-register.  Already-registered paths are supplied as the
        snapshot AND ``result.artifacts`` is rebuilt from the full registry,
        so a crash mid-capture converges on the next pass.
        """
        observer = self.stage_task_observer
        store = getattr(observer, "store", None) if observer is not None else None
        db_path = getattr(store, "db_path", None)
        results_dir = TaskStorage(work_dir).result_dir()
        if db_path is None or not results_dir.exists():
            return

        with self._artifact_capture_lock:
            registry = ArtifactRegistry(db_path)
            registered = {artifact.file_path for artifact in registry.list_by_job(record.id)}
            capture_stage_artifacts(
                registry=registry,
                job_id=record.id,
                task_id=None,
                work_dir=work_dir,
                stage_dir=results_dir,
                snapshot_before=registered,
            )
            artifacts = registry.list_by_job(record.id)

        if not artifacts:
            return
        result = dict(record.result or {})
        result["artifacts"] = [asdict(artifact) for artifact in artifacts]
        record.result = result

    def _capture_ensemble_thermo(self, record: JobRecord, work_dir: Path) -> None:
        """Merge the energy workflow's ensemble_thermo.json into the job result.

        Makes ``total_gibbs_kcal_mol`` (and friends) available to the
        workbench info panel without re-parsing the workflow output files.
        The canonical ``RESULT/energies/ensemble_thermo.json`` is preferred;
        historical ``finalDFT/ensemble_thermo.json`` is accepted as a
        read-only fallback (single-mol jobs nest one level under ``work_dir``).
        """
        canonical = sorted(
            (
                p
                for p in work_dir.rglob("RESULT/energies/ensemble_thermo.json")
                if not is_archived_attempt_path(p)
            ),
            key=lambda p: len(p.parts),
        )
        legacy = sorted(
            (
                p
                for p in work_dir.rglob("finalDFT/ensemble_thermo.json")
                if not is_archived_attempt_path(p)
            ),
            key=lambda p: len(p.parts),
        )
        candidates = canonical or legacy
        if not candidates:
            return
        try:
            data = json.loads(candidates[0].read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if not isinstance(data, dict):
            return
        result = dict(record.result or {})
        result["ensemble_thermo"] = data
        record.result = result

    def _store_provenance(self, record: JobRecord, command_line: str = "") -> None:
        if record.completed_at is None:
            record.completed_at = _utc_now_iso()
        result = dict(record.result or {})
        if command_line:
            result["command_line"] = command_line
        if record.spec.workflow == "fake":
            result.setdefault("backend_name", "fake")
            result.setdefault("method", "demo")
        elif "backend_name" not in result and record.spec.method.get("backend") is not None:
            result["backend_name"] = str(record.spec.method["backend"])
        if "method" not in result:
            method = record.spec.method.get("protocol")
            if method is not None:
                result["method"] = str(method)
        record.result = result

        provenance = build_provenance_for_job(record.spec, record)
        record.result = dict(record.result or {})
        record.result["provenance"] = asdict(provenance)
        self._persist_provenance_to_stage_tasks(record, provenance)

    def _persist_provenance_to_stage_tasks(self, record: JobRecord, provenance: Provenance) -> None:
        observer = self.stage_task_observer
        store = getattr(observer, "store", None) if observer is not None else None
        if store is None:
            return
        tasks = store.list_by_job(record.id)
        if not tasks:
            return
        task = tasks[-1]
        task.provenance = asdict(provenance)
        task.updated_at = _utc_now_iso()
        store.update(task)

    def _write_stage_task_event(
        self,
        work_dir: Path,
        stage_name: str,
        task_id: str,
        marker: str,
        payload: dict[str, Any],
    ) -> None:
        stage_dir = work_dir / "stage_tasks" / stage_name
        stage_dir.mkdir(parents=True, exist_ok=True)
        path = stage_dir / f"{task_id}.{marker}.json"
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


__all__ = [
    "JobRunner",
    "JobRunnerRemoteProtocol",
    "find_workflow_state",
    "materialize_job_input",
]
