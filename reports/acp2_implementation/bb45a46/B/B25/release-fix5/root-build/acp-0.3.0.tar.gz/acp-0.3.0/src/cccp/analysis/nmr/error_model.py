# pyright: reportMissingTypeStubs=false, reportExplicitAny=false, reportAny=false, reportUnknownVariableType=false, reportUnknownMemberType=false, reportUnknownArgumentType=false
"""Error models for DP4/DP5 (DevDoc §10).

Verified against the Goodman-lab/DP5 source (``DP4.py`` / ``DP5.py``,
fetched 2026-08-07):

* **DP4** uses a **Gaussian** distribution (not Student-t as the DevDoc
  draft §8.5 speculated) with σ_C = 2.269372, σ_H = 0.187311 ppm
  (``DP4.py:17-21``, probability ``2·Φ(-|r/σ|)``).
* **DP5** uses a Gaussian KDE over folded scaled residuals
  (``folded_scaled_errors``, 106 416 points) for per-atom probabilities,
  then a Bayesian rescale via two weighted KDEs of per-candidate scores
  (``c_w_kde`` = correct-assignment, ``i_w_kde`` = incorrect-assignment).

The trained KDE/KDE-rescale assets live in the single CCCP asset location
``src/cccp/analysis/nmr/model_assets/`` (resolved through
:func:`cccp.analysis.nmr.assets.resolve_asset`) and are rebuilt at load time
from their stored ``dataset``+``weights``+``factor`` (scipy's internal API
changed; we do not rely on the pickled methods).
"""

from __future__ import annotations

import logging
import math
import pickle
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
from scipy.special import log_ndtr

from cccp.analysis.nmr.assets import asset_dir
from cccp.analysis.nmr.models import NmrConfig

if TYPE_CHECKING:
    from cccp.analysis.nmr.fchl import AtomFchlProbability
    from cccp.analysis.nmr.protocol import NmrProtocolSpec

logger = logging.getLogger(__name__)

_MODELS_DIR = asset_dir()


# ---------------------------------------------------------------------------
# Reference-level binding (DevDoc §10.2)
# ---------------------------------------------------------------------------


_GOODMAN_LEVEL = ("mPW1PW91", "6-311G(d)", "goodman-legacy")

#: Error-model id → trained (method, basis) level — single source for both
#: the name-level check below and the protocol-level check (todo 29).
_TRAINED_ERROR_MODEL_LEVELS = {_GOODMAN_LEVEL[2]: (_GOODMAN_LEVEL[0], _GOODMAN_LEVEL[1])}


def validate_error_model_binding(config: NmrConfig) -> None:
    """Raise ``ValueError`` when the error model and NMR level diverge.

    DevDoc §10.2: the Goodman distributions are trained on
    ``mPW1PW91/6-311G(d)``. Using them with a different level produces
    meaningless probabilities.

    This is the NAME-level check only. The protocol-level check — what
    actually ran (geometry/reference/model presence) — lives in
    :func:`validate_protocol_binding`, whose mismatch verdict is
    ``unvalidated_protocol`` instead of an exception.
    """
    method_ok = config.nmr_method.strip().lower() == _GOODMAN_LEVEL[0].lower()
    basis_ok = _basis_equal(config.nmr_basis, _GOODMAN_LEVEL[1])
    model_ok = config.error_model.strip().lower() == _GOODMAN_LEVEL[2].lower()
    placeholder = config.error_model.strip().lower().startswith("placeholder")

    if placeholder:
        logger.warning(
            "Using placeholder error model '%s' — DP4/DP5 values are "
            "relative only, not for publication.",
            config.error_model,
        )
        return

    if model_ok and not (method_ok and basis_ok):
        raise ValueError(
            f"Error model '{config.error_model}' requires NMR level "
            f"mPW1PW91/6-311G(d) but got {config.nmr_method}/{config.nmr_basis}. "
            "Switch the error model (and its trained parameters) to match."
        )


def validate_protocol_binding(spec: NmrProtocolSpec) -> list[str]:
    """Protocol-level binding check (todo 29 / gap G04) — returns issue codes.

    Name-only matching (method/basis/model strings) is insufficient: the
    statistical model must be bound to the RECORDING — every segment it
    depends on has to be present and consistent with what actually ran.

    Issue codes (empty list = fully bound, calibration claims allowed):

    * ``statistical_model_not_bound`` — placeholder model, unknown model id,
      or the recorded level diverges from the model's trained level;
    * ``missing_reference`` — a required nucleus has no TMS reference (a
      shielding must never stand in for a missing shift reference), or pinned
      reference validation was requested without a real reference dataset
      attached (todo 31);
    * ``reference_not_for_level`` — the table has no row for the recorded
      level, so the in-force references are unverifiable defaults;
    * ``geometry_not_optimized`` — no optimization level executed (or
      provenance is unknown): calling CENSO is not DFT-optimized geometry.

    Args:
        spec: The six-segment protocol record to validate.

    Returns:
        Issue codes; ``[]`` when the protocol is fully bound.
    """
    issues: list[str] = []

    model_id = spec.statistical_model.error_model.strip().lower()
    trained = _TRAINED_ERROR_MODEL_LEVELS.get(model_id)
    if model_id.startswith("placeholder") or trained is None:
        issues.append("statistical_model_not_bound")
    else:
        method_ok = spec.shielding.nmr_method.strip().lower() == trained[0].lower()
        basis_ok = _basis_equal(spec.shielding.nmr_basis, trained[1])
        if not (method_ok and basis_ok):
            issues.append("statistical_model_not_bound")

    if spec.reference.missing_nuclei or (
        spec.reference.reference_validation_requested and not spec.reference.reference_data_present
    ):
        issues.append("missing_reference")
    if spec.reference.tms_source == "unknown":
        issues.append("reference_not_for_level")
    if spec.geometry.optimization_executed is not True:
        issues.append("geometry_not_optimized")

    return issues


def _basis_equal(actual: str, expected: str) -> bool:
    a = actual.strip().lower().replace(" ", "")
    b = expected.strip().lower().replace(" ", "")
    return a == b


# ---------------------------------------------------------------------------
# DP4 ErrorModel abstraction
# ---------------------------------------------------------------------------


class ErrorModel(ABC):
    """Abstract DP4 error distribution for residual → likelihood conversion."""

    model_id: str = "abstract"

    @abstractmethod
    def log_likelihood(self, residuals: list[float], nucleus: str) -> float:
        """Return ``ln Π_i f(r_i)`` for *residuals* of one nucleus."""
        raise NotImplementedError

    def likelihood(self, residuals: list[float], nucleus: str) -> float:
        """Return ``exp(log_likelihood)`` (may underflow to 0)."""
        return math.exp(self.log_likelihood(residuals, nucleus))


class PlaceholderStudentTErrorModel(ErrorModel):
    """Student-t error model with literature-approximate parameters.

    **Deprecated** since P1b — kept for backward-compat / fallback only.
    The real Goodman DP4 uses a Gaussian (:class:`GoodmanErrorModel`).
    """

    model_id = "placeholder-student-t"

    def __init__(
        self,
        sigma: dict[str, float] | None = None,
        nu: float = 4.0,
    ) -> None:
        self.sigma = sigma or {"1H": 0.12, "13C": 2.2}
        self.nu = float(nu)

    def log_likelihood(self, residuals: list[float], nucleus: str) -> float:
        if not residuals:
            return 0.0
        sigma = self.sigma.get(nucleus)
        if sigma is None or sigma <= 0:
            return 0.0
        nu = self.nu
        log_const = (
            math.lgamma((nu + 1) / 2)
            - math.lgamma(nu / 2)
            - 0.5 * math.log(nu * math.pi)
            - math.log(sigma)
        )
        total = 0.0
        for r in residuals:
            z = float(r) / sigma
            total += log_const - 0.5 * (nu + 1) * math.log1p(z * z / nu)
        return total


class NonFiniteResidualError(ValueError):
    """Raised when a DP4 residual is NaN/±Inf instead of silently poisoning the total."""


class GoodmanErrorModel(ErrorModel):
    """Goodman DP4 Gaussian error model (verified DP4.py:17-21, 190-194).

    Per-residual probability ``P = 2·Φ(-|r/σ|)`` (two-tailed Gaussian),
    σ_C = 2.269372, σ_H = 0.187311 ppm, mean = 0. The likelihood is the
    product of per-residual probabilities; ``log_likelihood`` returns the
    sum of logs for numerical stability.
    """

    model_id = "goodman-legacy"

    # Verified against DP4.py:17-21
    SIGMA = {"13C": 2.269372270818724, "1H": 0.18731058105269952}
    MEAN = 0.0

    def log_likelihood(self, residuals: list[float], nucleus: str) -> float:
        if not residuals:
            return 0.0
        sigma = self.SIGMA.get(nucleus)
        if sigma is None or sigma <= 0:
            logger.debug("No σ for nucleus %s in Goodman model; skipping", nucleus)
            return 0.0
        # P(r) = 2 * Φ(-|r/σ|); log P = log(2) + log Φ(-|z|)
        # Φ(-|z|) = 0.5 * erfc(|z| / sqrt(2)) → log P = log(erfc(|z|/sqrt(2))),
        # evaluated as log(2) + log_ndtr(-|z|) because math.erfc underflows to
        # 0.0 for |z| ≳ 37 (e.g. a 100 ppm carbon residual) and log(0) raises.
        total = 0.0
        for r in residuals:
            r_val = float(r)
            if not math.isfinite(r_val):
                raise NonFiniteResidualError(
                    f"non-finite {nucleus} residual {r_val!r} in Goodman DP4 likelihood"
                )
            z = abs(r_val / sigma)
            log_p = math.log(2.0) + float(log_ndtr(-z))
            total += log_p
        return total


# ---------------------------------------------------------------------------
# DP5 model (KDE-based, Goodman DP5.py)
# ---------------------------------------------------------------------------


def _rebuild_kde(pickle_path: Path):
    """Rebuild a fresh scipy ``gaussian_kde`` from a legacy pickle.

    The Goodman pickles were created with an older scipy whose
    ``gaussian_kde`` lacks the ``cho_cov`` attribute the current version
    expects. We extract ``dataset``+``weights``+``factor`` and build a
    new KDE instead of trusting the pickled methods.
    """
    import warnings

    from scipy.stats import gaussian_kde

    # The legacy gaussian_kde pickle emits a DeprecationWarning on unpickle
    # (scipy.stats.kde namespace rename); suppress it for both load + rebuild.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        with pickle_path.open("rb") as fh:
            old = pickle.load(fh)
        dataset = np.asarray(old.dataset)  # shape (d, n)
        weights = np.asarray(old.weights).flatten()
        return gaussian_kde(dataset, weights=weights, bw_method=old.factor)


# ---------------------------------------------------------------------------
# Typed DP5 path record: weighted vs unweighted calibration (todo 38 / G12)
# ---------------------------------------------------------------------------

DP5_PATH_FCHL = "fchl"
DP5_PATH_FALLBACK = "fallback"
DP5_PATH_MIXED = "mixed"
#: Closed vocabulary of DP5 atom paths.
DP5_PATHS: tuple[str, ...] = (DP5_PATH_FCHL, DP5_PATH_FALLBACK, DP5_PATH_MIXED)

#: Goodman FCHL-weighted KDE — the calibrated path (in-domain samples only).
DP5_CALIBRATION_WEIGHTED = "weighted"
#: Unweighted global KDE fallback — its own (distinct) calibration status.
DP5_CALIBRATION_UNWEIGHTED = "unweighted"
#: Out-of-domain: no contributing training neighbour — no formal probability.
DP5_CALIBRATION_OUT_OF_DOMAIN = "out_of_domain"
#: Closed vocabulary of DP5 calibration statuses.
DP5_CALIBRATION_STATUSES: tuple[str, ...] = (
    DP5_CALIBRATION_WEIGHTED,
    DP5_CALIBRATION_UNWEIGHTED,
    DP5_CALIBRATION_OUT_OF_DOMAIN,
)


@dataclass(frozen=True)
class Dp5ProbabilityRecord:
    """A DP5 probability plus which path produced it and its calibration status.

    ``calibration_status`` is one of :data:`DP5_CALIBRATION_STATUSES`:
    ``weighted`` (FCHL-weighted KDE), ``unweighted`` (global-KDE fallback) or
    ``out_of_domain`` (no contributing training neighbour). In the
    out-of-domain case the raw fallback value is kept for diagnostics but
    :attr:`formal_probability` is None — it must never be presented as a
    formal calibrated probability.
    """

    probability: float
    path: str
    calibration_status: str
    out_of_domain: bool
    n_atoms: int
    out_of_domain_atoms: int
    min_effective_neighbors: float | None = None
    min_support_fraction: float | None = None
    reasons: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.path not in DP5_PATHS:
            raise ValueError(f"unknown DP5 path {self.path!r}")
        if self.calibration_status not in DP5_CALIBRATION_STATUSES:
            raise ValueError(f"unknown DP5 calibration status {self.calibration_status!r}")

    @property
    def formal_probability(self) -> float | None:
        """The value only when it may be presented as a formal probability."""
        if self.calibration_status == DP5_CALIBRATION_OUT_OF_DOMAIN:
            return None
        return self.probability

    def as_dict(self) -> dict[str, object]:
        """JSON-safe view for workflow/report diagnostics."""
        return {
            "probability": float(self.probability),
            "formal_probability": self.formal_probability,
            "path": self.path,
            "calibration_status": self.calibration_status,
            "out_of_domain": bool(self.out_of_domain),
            "n_atoms": int(self.n_atoms),
            "out_of_domain_atoms": int(self.out_of_domain_atoms),
            "min_effective_neighbors": self.min_effective_neighbors,
            "min_support_fraction": self.min_support_fraction,
            "reasons": list(self.reasons),
        }


@dataclass(frozen=True)
class Dp5FchlDiagnostics:
    """FCHL DP5 outcome + per-conformer per-atom records from the same pass.

    ``atom_records[c][i]`` is the
    :class:`~acp.nmr.fchl.AtomFchlProbability` computed for atom/signal *i*
    in the *c*-th conformer that entered the Boltzmann average. The records
    come from the weighted-KDE pass itself — never recomputed (the kernel is
    expensive) and never fabricated: an atom with no contributing training
    neighbour is flagged by ``record.out_of_domain`` / its
    :class:`~acp.nmr.fchl.FchlSupport`.
    """

    record: Dp5ProbabilityRecord
    atom_records: tuple[tuple[AtomFchlProbability, ...], ...]


class GoodmanDP5Model:
    """Goodman DP5 probability model (verified DP5.py:73-141, 356-383).

    Two per-atom probability paths:

    * **FCHL-weighted** (``DP5.py:85-108``) — per-atom FCHL19
      representations built from the conformer geometry are kernel-compared
      against the training-set atoms (``atomic_reps.gz``) with ``qml``, and
      the resulting similarity vector weights the Gaussian KDE over the
      folded scaled residuals. This is Goodman's full DP5 innovation and is
      active when ``qml`` is importable and the FCHL assets are present
      (:attr:`fchl_available`).
    * **Unweighted fallback** (``DP5.py:98``) — the global KDE over
      ``folded_scaled_errors``, used when ``qml``/assets are unavailable or
      when an atom has no similar training neighbours (``sum(K_sim)==0``).

    Both share the same downstream ``Rescale_DP5`` (DP5.py:367-383) via the
    correct/incorrect KDEs.

    Deprecated (G07): the former ``dp5_mode``/``fchl_kernel`` mutable
    attributes were removed — they were shared state where the last
    candidate's path overwrote every earlier candidate's mode. Which path
    ran is a per-call fact: callers report it themselves (the workflow's
    ``_compute_candidate_dp5`` returns an immutable outcome carrying mode +
    kernel), and callers needing the kernel call ``kernel_backend()``.
    """

    model_id = "goodman-dp5"

    def __init__(self, models_dir: Path | None = None) -> None:
        models_dir = models_dir or _MODELS_DIR
        fse_path = models_dir / "folded_scaled_errors.p"
        c_path = models_dir / "c_w_kde_mean_s_0.025.p"
        i_path = models_dir / "i_w_kde_mean_s_0.025.p"
        if not all(p.exists() for p in (fse_path, c_path, i_path)):
            raise FileNotFoundError(
                f"Goodman DP5 model files missing in {models_dir}; expected "
                "folded_scaled_errors.p, c_w_kde_mean_s_0.025.p, "
                "i_w_kde_mean_s_0.025.p"
            )
        with fse_path.open("rb") as fh:
            self.folded_errors = np.asarray(pickle.load(fh))
        self.mean_abs_error = float(np.mean(np.abs(self.folded_errors)))
        self._correct_kde = _rebuild_kde(c_path)
        self._incorrect_kde = _rebuild_kde(i_path)
        self._atom_kde = None  # lazy — built on first use
        self._atomic_reps = None  # lazy — loaded when FCHL first used
        self._fragment_reps = None  # lazy — loaded when the >=86-atom path first used
        self.models_dir = models_dir

    @property
    def atom_kde(self):
        """Lazy-build the unweighted atom-level KDE (DP5.py:98 fallback)."""
        from scipy.stats import gaussian_kde

        if self._atom_kde is None:
            self._atom_kde = gaussian_kde(self.folded_errors)
        return self._atom_kde

    # -- FCHL support (DevDoc appendix D / P4) ---------------------------

    @property
    def fchl_available(self) -> bool:
        """True when the FCHL-weighted atom path should run.

        Needs the FCHL assets **and** an active kernel backend: the compiled
        ``qml`` kernel (fast Fortran reference, used when importable), or the
        pure-numpy port (opt-in via ``ACP_FCHL_NUMPY=1`` — same math, but
        minutes/atom on the full 53 208-atom training set). When False the
        DP5 path degrades to the unweighted KDE fallback.
        """
        from cccp.analysis.nmr.fchl import fchl_assets_available, fchl_kernel_active

        return fchl_kernel_active() and fchl_assets_available(self.models_dir)

    def _get_atomic_reps(self) -> np.ndarray:
        """Lazily load the training-set atom FCHL representations."""
        from cccp.analysis.nmr.fchl import load_atomic_reps

        if self._atomic_reps is None:
            self._atomic_reps = load_atomic_reps(self.models_dir)
        return self._atomic_reps

    def _get_fragment_reps(self) -> np.ndarray:
        """Lazily load + verify the fragment training-set FCHL representations.

        The >=86-atom path pairs ``K_sim`` from ``frag_reps.gz`` with the
        doubled ``folded_scaled_errors`` vector, so the training-index
        correspondence (``2 * n_fragment_train == len(folded_errors)``) is
        enforced here: a mismatched asset set raises instead of silently
        weighting residuals with the wrong neighbours (the shipped upstream
        assets mismatch — see :func:`acp.nmr.fchl.fragment_path_status`).
        """
        from cccp.analysis.nmr.fchl import (
            FragmentPathUnavailableError,
            fragment_residual_index_ok,
            load_atomic_reps,
        )

        if self._fragment_reps is None:
            reps = load_atomic_reps(self.models_dir, use_frag=True)
            if not fragment_residual_index_ok(int(reps.shape[0]), int(self.folded_errors.size)):
                raise FragmentPathUnavailableError(
                    f"frag_reps.gz has {reps.shape[0]} training fragments but "
                    f"folded_scaled_errors.p has {self.folded_errors.size} residuals; "
                    "the doubled fragment similarities cannot be paired with the "
                    "residual vector (refusing to weight the wrong neighbours)"
                )
            self._fragment_reps = reps
        return self._fragment_reps

    def atom_probability(self, scaled_error: float) -> float:
        """Per-atom DP5 probability (DP5.py:104-108).

        ``s_e_diff = |scaled_error - mean_abs_error|``
        ``p = kde.integrate_box_1d(mean - diff, mean + diff)``
        """
        diff = abs(float(scaled_error) - self.mean_abs_error)
        lo = self.mean_abs_error - diff
        hi = self.mean_abs_error + diff
        return float(self.atom_kde.integrate_box_1d(lo, hi))

    def atom_probability_fchl_diagnostic(
        self,
        representation: np.ndarray,
        scaled_error: float,
        *,
        use_fragment_reps: bool = False,
    ) -> AtomFchlProbability:
        """FCHL-weighted per-atom DP5 probability with path/support diagnostics.

        Same computation as :meth:`atom_probability_fchl` (its float view),
        but the result records the path (weighted vs ``sum(K_sim)==0``
        fallback) and the neighbour-support metrics; ``out_of_domain`` is True
        when no training neighbour contributes. With ``use_fragment_reps=True``
        the training side is ``frag_reps.gz`` (>=86-atom radius-3 fragments).
        """
        from cccp.analysis.nmr.fchl import atom_probability_fchl_diagnostic

        training_reps = self._get_fragment_reps() if use_fragment_reps else self._get_atomic_reps()
        return atom_probability_fchl_diagnostic(
            representation,
            scaled_error,
            self.folded_errors,
            self.mean_abs_error,
            training_reps,
        )

    def atom_probability_fchl(
        self,
        representation: np.ndarray,
        scaled_error: float,
        *,
        use_fragment_reps: bool = False,
    ) -> float:
        """FCHL-weighted per-atom DP5 probability (DP5.py:85-108).

        Uses the atom's FCHL representation to weight the KDE against the
        training-set similarity. With ``use_fragment_reps=True`` the training
        side is ``frag_reps.gz`` (>=86-atom radius-3 fragments, capacity 53)
        instead of ``atomic_reps.gz``; the two paths are not numerically
        equivalent. Falls back to the global KDE when ``qml`` is unavailable
        (the caller should route via :meth:`probability_per_conformer_fchl`,
        which handles the switch).
        """
        return self.atom_probability_fchl_diagnostic(
            representation, scaled_error, use_fragment_reps=use_fragment_reps
        ).probability

    def candidate_probability(self, atom_probs: list[float]) -> float:
        """Raw per-candidate DP5 before rescale (DP5.py:356-364).

        ``DP5scaled = 1 - gmean(1 - p_si)``
        """
        if not atom_probs:
            return 0.0
        from scipy.stats import gmean

        complements = [1.0 - p for p in atom_probs]
        # gmean of complements; guard against zeros
        if any(c <= 0 for c in complements):
            return 1.0
        return float(1.0 - gmean(complements))

    def rescale(self, raw_dp5: float) -> float:
        """Bayesian rescale (DP5.py:381).

        ``DP5 = 1 - incorrect.pdf(x) / (incorrect.pdf(x) + correct.pdf(x))``
        """
        x = np.array([[raw_dp5]])
        ip = float(self._incorrect_kde.pdf(x)[0])
        cp = float(self._correct_kde.pdf(x)[0])
        denom = ip + cp
        if denom <= 0:
            return 0.5
        return float(1.0 - ip / denom)

    def probability(self, scaled_errors: list[float]) -> float:
        """Full DP5 pipeline on a single (already-averaged) residual set.

        Simplified path: atom probs → gmean → rescale. Use
        :meth:`probability_per_conformer` for the Goodman-faithful path
        where KDE is evaluated per conformer before probability averaging.
        """
        atom_probs = [self.atom_probability(abs(se)) for se in scaled_errors]
        raw = self.candidate_probability(atom_probs)
        return self.rescale(raw)

    def probability_per_conformer(
        self,
        conformer_calc_shifts: list[list[float]],
        exp_shifts: list[float],
        boltzmann_weights: list[float],
    ) -> float:
        """Goodman-faithful DP5, unweighted-KDE atom path (DP5.py:73-141, 339-383).

        Per conformer: independently scale that conformer's calc shifts
        against ``exp_shifts`` (DP5.py:81-83), compute per-atom KDE
        probability (DP5.py:104-108), then **Boltzmann-average the
        probabilities across conformers** (DP5.py:339-353). The averaged
        per-atom probabilities are then geometric-mean combined
        (DP5.py:356-364) and Bayesian-rescaled (DP5.py:367-383).

        This differs from :meth:`probability` which evaluates the KDE
        once on Boltzmann-averaged shieldings. Since the KDE
        (``integrate_box_1d``) is nonlinear, ``avg(P(σ_i)) ≠ P(avg(σ_i))``.

        Args:
            conformer_calc_shifts: Per-conformer ¹³C calc shifts (TMS-
                converted), one list per conformer. Length = n_conformers.
            exp_shifts: Experimental ¹³C shifts (same length as each
                conformer's calc list).
            boltzmann_weights: Boltzmann weights per conformer
                (sum to 1; length = n_conformers).

        Returns:
            DP5 probability in ``[0, 1]``.
        """
        return self._probability_per_conformer(conformer_calc_shifts, exp_shifts, boltzmann_weights)

    def probability_per_conformer_diagnostic(
        self,
        conformer_calc_shifts: list[list[float]],
        exp_shifts: list[float],
        boltzmann_weights: list[float],
    ) -> Dp5ProbabilityRecord:
        """Unweighted-KDE DP5 with a typed path/calibration record (todo 38).

        The unweighted path is its own calibration regime
        (:data:`DP5_CALIBRATION_UNWEIGHTED`), recorded separately from the
        FCHL-weighted one.
        """
        return self._probability_per_conformer_record(
            conformer_calc_shifts, exp_shifts, boltzmann_weights
        )

    def probability_per_conformer_fchl(
        self,
        conformer_calc_shifts: list[list[float]],
        exp_shifts: list[float],
        boltzmann_weights: list[float],
        conformer_reps: list[list[np.ndarray]],
        *,
        use_fragment_reps: bool = False,
    ) -> float:
        """Goodman-faithful DP5 with the FCHL-weighted atom path.

        Same per-conformer scaling + Boltzmann averaging as
        :meth:`probability_per_conformer`, but each atom's probability uses
        its FCHL19 representation to weight the KDE against the training set
        (``DP5.py:85-108``; see :meth:`atom_probability_fchl`). Requires the
        FCHL assets (``atomic_reps.gz``); the kernel runs on ``qml`` when
        importable, else the pure-numpy port.

        With ``use_fragment_reps=True`` (molecules >= 86 atoms) the training
        side is ``frag_reps.gz`` and ``conformer_reps`` must hold radius-3
        fragment descriptors (see
        :func:`acp.nmr.fchl.build_fragment_representations`); the fragment
        and atomic paths are **not numerically equivalent** and the fragment
        asset/residual index correspondence is enforced by
        :meth:`_get_fragment_reps`.

        Args:
            conformer_calc_shifts: Per-conformer ¹³C calc shifts.
            exp_shifts: Experimental ¹³C shifts.
            boltzmann_weights: Boltzmann weights per conformer.
            conformer_reps: Per-conformer FCHL19 representations of the
                ¹³C atoms (parallel to ``conformer_calc_shifts``);
                ``conformer_reps[c][i]`` = descriptor of atom *i* in
                conformer *c*.
            use_fragment_reps: Use the fragment training set (>=86 atoms).

        Returns:
            DP5 probability in ``[0, 1]``.
        """
        return self.probability_per_conformer_fchl_diagnostic(
            conformer_calc_shifts,
            exp_shifts,
            boltzmann_weights,
            conformer_reps,
            use_fragment_reps=use_fragment_reps,
        ).probability

    def probability_per_conformer_fchl_diagnostic(
        self,
        conformer_calc_shifts: list[list[float]],
        exp_shifts: list[float],
        boltzmann_weights: list[float],
        conformer_reps: list[list[np.ndarray]],
        *,
        use_fragment_reps: bool = False,
    ) -> Dp5ProbabilityRecord:
        """FCHL-weighted DP5 with path/support/calibration record (todo 38).

        Same computation as :meth:`probability_per_conformer_fchl` (its float
        view). ``calibration_status`` distinguishes the weighted path from the
        unweighted fallback, and :attr:`Dp5ProbabilityRecord.formal_probability`
        is None when any atom slot is out of domain (no contributing training
        neighbour) — such values must never be presented as formal
        probabilities.
        """
        if not self.fchl_available:
            raise RuntimeError(
                "FCHL-weighted DP5 requires the FCHL assets (atomic_reps.gz/"
                "frag_reps.gz). Use probability_per_conformer() for the "
                "fallback path."
            )
        if len(conformer_reps) != len(conformer_calc_shifts):
            raise ValueError("conformer_reps and conformer_calc_shifts lengths differ")
        return self._probability_per_conformer_record(
            conformer_calc_shifts,
            exp_shifts,
            boltzmann_weights,
            conformer_reps=conformer_reps,
            use_fragment_reps=use_fragment_reps,
        )

    def probability_per_conformer_fchl_atom_diagnostics(
        self,
        conformer_calc_shifts: list[list[float]],
        exp_shifts: list[float],
        boltzmann_weights: list[float],
        conformer_reps: list[list[np.ndarray]],
        *,
        use_fragment_reps: bool = False,
    ) -> Dp5FchlDiagnostics:
        """FCHL-weighted DP5 plus the per-atom records from the same KDE pass.

        Same computation as
        :meth:`probability_per_conformer_fchl_diagnostic` (which stays the
        record-only view), additionally returning the per-conformer
        :class:`~acp.nmr.fchl.AtomFchlProbability` records whose support /
        out-of-domain flags back the atomic diagnostics (todo 39 / G16).
        """
        if not self.fchl_available:
            raise RuntimeError(
                "FCHL-weighted DP5 requires the FCHL assets (atomic_reps.gz/"
                "frag_reps.gz). Use probability_per_conformer() for the "
                "fallback path."
            )
        if len(conformer_reps) != len(conformer_calc_shifts):
            raise ValueError("conformer_reps and conformer_calc_shifts lengths differ")
        collector: list[list[AtomFchlProbability]] = []
        record = self._probability_per_conformer_record(
            conformer_calc_shifts,
            exp_shifts,
            boltzmann_weights,
            conformer_reps=conformer_reps,
            use_fragment_reps=use_fragment_reps,
            atom_records=collector,
        )
        return Dp5FchlDiagnostics(
            record=record,
            atom_records=tuple(tuple(row) for row in collector),
        )

    def _probability_per_conformer(
        self,
        conformer_calc_shifts: list[list[float]],
        exp_shifts: list[float],
        boltzmann_weights: list[float],
        conformer_reps: list[list[np.ndarray]] | None = None,
        use_fragment_reps: bool = False,
    ) -> float:
        """Shared per-conformer DP5 pipeline (float view over the record path)."""
        return self._probability_per_conformer_record(
            conformer_calc_shifts,
            exp_shifts,
            boltzmann_weights,
            conformer_reps,
            use_fragment_reps,
        ).probability

    def _probability_per_conformer_record(
        self,
        conformer_calc_shifts: list[list[float]],
        exp_shifts: list[float],
        boltzmann_weights: list[float],
        conformer_reps: list[list[np.ndarray]] | None = None,
        use_fragment_reps: bool = False,
        atom_records: list[list[AtomFchlProbability]] | None = None,
    ) -> Dp5ProbabilityRecord:
        """Shared per-conformer DP5 pipeline (DP5.py:73-141, 339-383).

        When *conformer_reps* is provided, per-atom probabilities use the
        FCHL-weighted KDE (fragment training set when *use_fragment_reps*);
        otherwise the unweighted global KDE fallback. The returned record
        distinguishes the weighted/unweighted calibration status and flags
        out-of-domain atom slots (no contributing training neighbour).

        *atom_records*, when passed, collects the per-conformer
        :class:`~acp.nmr.fchl.AtomFchlProbability` records produced by the
        weighted-KDE pass (one list per conformer that entered the average).
        """
        import numpy as np
        from scipy.stats import linregress

        from cccp.analysis.nmr.fchl import (
            ATOM_PROBABILITY_MODE_FALLBACK,
            ATOM_PROBABILITY_MODE_FCHL,
        )

        n_atoms = len(exp_shifts)
        if n_atoms == 0 or not conformer_calc_shifts:
            return Dp5ProbabilityRecord(
                probability=0.0,
                path=DP5_PATH_FALLBACK,
                calibration_status=DP5_CALIBRATION_UNWEIGHTED,
                out_of_domain=False,
                n_atoms=0,
                out_of_domain_atoms=0,
            )

        use_fchl = conformer_reps is not None
        modes_seen: set[str] = set()
        out_of_domain_flags = [False] * n_atoms
        effective_values: list[float] = []
        fraction_values: list[float] = []

        # Per-conformer: scale + per-atom KDE probability (DP5.py:75-110)
        # Boltzmann-average the probabilities (DP5.py:339-353)
        avg_atom_probs = [0.0] * n_atoms
        for conf_idx, (conf_shifts, weight) in enumerate(
            zip(conformer_calc_shifts, boltzmann_weights)
        ):
            if len(conf_shifts) != n_atoms:
                continue
            conf_atom_records: list[AtomFchlProbability] = []
            if n_atoms >= 2:
                slope, intercept, _, _, _ = linregress(exp_shifts, conf_shifts)
                if slope == 0 or not np.isfinite(slope):
                    slope, intercept = 1.0, 0.0
                scaled = [(c - intercept) / slope for c in conf_shifts]
            else:
                scaled = list(conf_shifts)
            for i in range(n_atoms):
                err = abs(scaled[i] - exp_shifts[i])
                if use_fchl:
                    atom_record = self.atom_probability_fchl_diagnostic(  # type: ignore[index]
                        conformer_reps[conf_idx][i], err, use_fragment_reps=use_fragment_reps
                    )
                    modes_seen.add(atom_record.mode)
                    out_of_domain_flags[i] = out_of_domain_flags[i] or atom_record.out_of_domain
                    effective_values.append(atom_record.support.effective_neighbors)
                    fraction_values.append(atom_record.support.support_fraction)
                    if atom_records is not None:
                        conf_atom_records.append(atom_record)
                    p = atom_record.probability
                else:
                    p = self.atom_probability(err)
                avg_atom_probs[i] += weight * p
            if atom_records is not None and use_fchl:
                atom_records.append(conf_atom_records)

        # Candidate-level: gmean combine (DP5.py:356-364) + rescale (DP5.py:381)
        raw = self.candidate_probability(avg_atom_probs)
        probability = self.rescale(raw)

        if not use_fchl:
            return Dp5ProbabilityRecord(
                probability=probability,
                path=DP5_PATH_FALLBACK,
                calibration_status=DP5_CALIBRATION_UNWEIGHTED,
                out_of_domain=False,
                n_atoms=n_atoms,
                out_of_domain_atoms=0,
            )

        if modes_seen == {ATOM_PROBABILITY_MODE_FCHL}:
            path = DP5_PATH_FCHL
        elif modes_seen and modes_seen <= {ATOM_PROBABILITY_MODE_FALLBACK}:
            path = DP5_PATH_FALLBACK
        elif modes_seen:
            path = DP5_PATH_MIXED
        else:
            path = DP5_PATH_FALLBACK
        out_of_domain_atoms = sum(1 for flag in out_of_domain_flags if flag)
        out_of_domain = out_of_domain_atoms > 0
        if out_of_domain:
            calibration_status = DP5_CALIBRATION_OUT_OF_DOMAIN
            reasons: tuple[str, ...] = ("out_of_domain",)
            logger.warning(
                "FCHL-weighted DP5: %d/%d atom slots out of domain (no contributing "
                "training neighbours); values are uncalibrated fallbacks, not formal "
                "probabilities",
                out_of_domain_atoms,
                n_atoms,
            )
        elif path == DP5_PATH_FCHL:
            calibration_status = DP5_CALIBRATION_WEIGHTED
            reasons = ()
        else:
            calibration_status = DP5_CALIBRATION_UNWEIGHTED
            reasons = ()
        return Dp5ProbabilityRecord(
            probability=probability,
            path=path,
            calibration_status=calibration_status,
            out_of_domain=out_of_domain,
            n_atoms=n_atoms,
            out_of_domain_atoms=out_of_domain_atoms,
            min_effective_neighbors=min(effective_values) if effective_values else None,
            min_support_fraction=min(fraction_values) if fraction_values else None,
            reasons=reasons,
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def load_error_model(
    model_id: str,
    model_path: Path | None = None,
) -> ErrorModel:
    """Resolve a DP4 :class:`ErrorModel` by id."""
    mid = (model_id or "").strip().lower()
    if mid.startswith("placeholder"):
        return PlaceholderStudentTErrorModel()
    if mid in ("", "goodman-legacy"):
        return GoodmanErrorModel()
    raise ValueError(f"Unknown DP4 error model: {model_id}")


def load_dp5_model(models_dir: Path | None = None) -> GoodmanDP5Model:
    """Load the Goodman DP5 KDE model (raises if model files missing)."""
    return GoodmanDP5Model(models_dir)


def dp5_model_available(models_dir: Path | None = None) -> bool:
    """Return True when the Goodman DP5 model files are present."""
    d = models_dir or _MODELS_DIR
    return all(
        (d / name).exists()
        for name in ("folded_scaled_errors.p", "c_w_kde_mean_s_0.025.p", "i_w_kde_mean_s_0.025.p")
    )


def dp5_fchl_available(models_dir: Path | None = None) -> bool:
    """Return True when the FCHL-weighted DP5 path will actually run.

    Needs the FCHL assets **and** an active kernel backend. The kernel runs
    on ``qml`` (compiled Fortran, fast) when importable; otherwise on the
    pure-numpy port when opted in via ``ACP_FCHL_NUMPY=1`` (same math, but
    minutes/atom on the full training set). When False the DP5 path degrades
    to the unweighted KDE fallback.
    """
    from cccp.analysis.nmr.fchl import fchl_assets_available, fchl_kernel_active

    d = models_dir or _MODELS_DIR
    return fchl_kernel_active() and fchl_assets_available(d)


__all__ = [
    "DP5_CALIBRATION_OUT_OF_DOMAIN",
    "DP5_CALIBRATION_STATUSES",
    "DP5_CALIBRATION_UNWEIGHTED",
    "DP5_CALIBRATION_WEIGHTED",
    "DP5_PATHS",
    "DP5_PATH_FALLBACK",
    "DP5_PATH_FCHL",
    "DP5_PATH_MIXED",
    "Dp5ProbabilityRecord",
    "Dp5FchlDiagnostics",
    "ErrorModel",
    "NonFiniteResidualError",
    "PlaceholderStudentTErrorModel",
    "GoodmanErrorModel",
    "GoodmanDP5Model",
    "load_error_model",
    "load_dp5_model",
    "dp5_model_available",
    "dp5_fchl_available",
    "validate_error_model_binding",
    "validate_protocol_binding",
]
